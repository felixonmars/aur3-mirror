#!/bin/sh

mkdir -p ${DESTDIR}/usr/share/splashy/

cp -r themes ${DESTDIR}/usr/share/splashy/themes/

JPGTHEMES=(	archlinux-burn
		archlinux-burn-43
		archlinux-deep-aurora
		archlinux-deep-aurora-43
	)

PNGTHEMES=(	archlinux-simplyblack
		archlinux-simplyblack-43
	)

EXTTHEMES=(	darch-grey	
		darch-grey-43
		darch-white
		darch-white-43
	)

for i in ${JPGTHEMES[@]}; do
	ln -sf /usr/share/archlinux/wallpaper/$i.jpg ${DESTDIR}/usr/share/splashy/themes/$i/background.jpg
	ln -sf /usr/share/archlinux/wallpaper/$i.jpg ${DESTDIR}/usr/share/splashy/themes/$i/suspend.jpg
	ln -sf /usr/share/archlinux/wallpaper/$i.jpg ${DESTDIR}/usr/share/splashy/themes/$i/error.jpg
	ln -sf /usr/share/splashy/themes/default/FreeSans.ttf ${DESTDIR}/usr/share/splashy/themes/$i/FreeSans.ttf
done

for i in ${PNGTHEMES[@]}; do
	ln -sf /usr/share/archlinux/wallpaper/$i.png ${DESTDIR}/usr/share/splashy/themes/$i/background.png
	ln -sf /usr/share/archlinux/wallpaper/$i.png ${DESTDIR}/usr/share/splashy/themes/$i/suspend.png
	ln -sf /usr/share/archlinux/wallpaper/$i.png ${DESTDIR}/usr/share/splashy/themes/$i/error.png
	ln -sf /usr/share/splashy/themes/default/FreeSans.ttf ${DESTDIR}/usr/share/splashy/themes/$i/FreeSans.ttf
done

for i in ${EXTTHEMES[@]}; do
	ln -sf /usr/share/splashy/themes/default/FreeSans.ttf ${DESTDIR}/usr/share/splashy/themes/$i/FreeSans.ttf
done

install -m 755 -d ${DESTDIR}/usr/share/licenses/splashy-themes
install -m 644 -D LICENSE.txt ${DESTDIR}/usr/share/licenses/splashy-themes/
