#!/bin/bash

if test "$1" = ""; then
	echo "update_po "
	exit
fi

cd "`dirname "$0"`"

update_po() {
	cd po
	intltool-update -p
	cd ../dist/doc/po
	make update-po
}

$1
