
/* Gnome Encfs Manager (GEncfsM)
 * Copyright (C) 2011 Moritz Molch <mail@moritzmolch.de>

 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include "tools.h"

gchar* get_glade_file(gchar *filename) {
    return g_build_filename(DATA_PATH, "glade", filename, NULL);
}

gchar* get_data_path() {
    return g_strdup(DATA_PATH);
}

static EggSMClient *master_client = NULL;

/* quit_requested handler for the master client */
static void
client_quit_requested_cb (EggSMClient *client,
              gpointer     data)
{
    gnome_encfs_manager_on_logout();
    egg_sm_client_will_quit (client, TRUE);
    //gtk_main_quit ();
}

/* quit handler for the master client */
static void
client_quit_cb (EggSMClient *client,
        gpointer     data)
{
    gtk_main_quit ();
}

void session_init (void)
{
    if (master_client)
        return;

    GOptionContext *goption_context;
    GError *err = NULL;

    goption_context = g_option_context_new ("- Test logout functionality");
    g_option_context_add_group (goption_context, gtk_get_option_group (TRUE));
    g_option_context_add_group (goption_context, egg_sm_client_get_option_group ());

    g_option_context_parse(goption_context, NULL, NULL, &err);

    master_client = egg_sm_client_get ();

    g_signal_connect (master_client,
              "quit_requested",
              G_CALLBACK (client_quit_requested_cb),
              NULL);
    g_signal_connect (master_client,
              "quit",
              G_CALLBACK (client_quit_cb),
              NULL);
}
