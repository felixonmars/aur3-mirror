#ifndef _TOOLS_H_
#define _TOOLS_H_

#include <glib.h>
#include <sys/inotify.h>
#include "smclient/eggsmclient.h"
#include <stdio.h>
#include <gtk/gtk.h>

gchar* get_glade_file(gchar* filename);
gchar* get_data_path();

void session_init (void);

#endif
