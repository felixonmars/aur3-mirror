pyrapport
====

Send mail when motion save a picture

Depend
======

python3

Installation
============

```
python setup.py install
```

Usage
=====

```
systemctl enable mailmotiond
or
python mailmotiond
```
