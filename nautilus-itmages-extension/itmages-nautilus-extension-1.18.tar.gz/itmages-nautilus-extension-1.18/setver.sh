#!/bin/bash -x

set_revision() {
    VER="$1"
    if test -n "$VER"
    then
        echo "Correction of revision to $VER"
        sed -i "/useragent/s/rev.*)/rev ${VER}.0)/" ./itmages/iomod.py
        sed -i "/version/s/=.*/= ${VER}/" ./setup.cfg
        sed -i "/VERSION =/s/=.*/= \'${VER}\'/" ./setup.py
    else
        echo "Number of revision not found."
    fi
}

set_py_version() {
    echo "Correct version of python"
    if test -f "/usr/bin/python2.7"
    then
        PYVER=2.7
    elif test -f "/usr/bin/python2.6"
    then
        PYVER=2.6
    elif test -f "/usr/bin/python2.5"
    then
        PYVER=2.5
    else
        echo "FAIL! Not found correct version of python."
        exit 1
    fi

    for script in `find ./* | grep -v setver.sh`;
    do
        test -f ${script} && sed -i "s#\#\!/usr/bin/env python.*#\#\!/usr/bin/env python${PYVER}#" "${script}" ;
    done;
    echo "Done!"
}

make_mo_file() {
    for pofile in `find ./po/* -name "*.po"`;
    do
        mofile=`echo ${pofile} | sed 's/\.po/\.mo/'`
        echo "Convert ${pofile} --> ${mofile}"
        /usr/bin/msgfmt -o ${mofile} ${pofile}
    done;
}

compile_extension() {
    echo "Making extension for nautilus".
    cd ./src
    EXTENSION="itmages-extension"
    gcc -DPIC -fPIC -c "./$EXTENSION.c" `pkg-config --cflags gtk+-2.0,glib-2.0,libnautilus-extension,gconf-2.0` || exit 1
    gcc -shared -o "lib${EXTENSION}.so" "./$EXTENSION.o" || exit 1
    rm "./$EXTENSION.o"
    mv "./lib$EXTENSION.so" "../scripts"
    cd ../
    echo "Done!"
}

set_revision $1 && set_py_version
if [ "$2" == "--make" ];
then
#    make_mo_file || exit 1
    compile_extension || exit 1
fi



    
