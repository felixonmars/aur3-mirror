#!/usr/bin/env python
#-*- coding: utf-8 -*-
import os
import re
import shelve
import base64
import time
import sys
import urllib


def geticonname():

    # REPLACE THIS NAME OF ICON TO REAL NAME OF ICON
    iconname = 'complex.png'

    abspath = os.path.abspath
    for path in [abspath('./'), abspath('../'),
                 abspath('../pixmaps'), '/usr/share/itmages/icons']:
        fname = os.path.join(path, iconname)
        if os.path.exists(fname):
            return fname
            
    else: return iconname
    

# The structure of main colorize icon.
# Insert the actual number of rows(LINES) and
# columns(COLS) for the selection of items with icons
ICONNAME = geticonname()
LINES = 3
COLS = 11

PREVSIZE = (200, 200)


MESSAGES = {
            1 : 'Not valid command prompt',
            2 : 'Wrong username or password',
            3 : 'Command prompt nothing',
            4 : 'Password exist without login',
            5 : 'Login exist without password',
            6 : 'Login and password exist without file',
            7 : 'This file does not exist',
            8 : 'Not valid argument or option',
            9 : 'Service temporarily unavailable.',
            11 : 'Already uploaded this image!',
            12 : 'Image exceeds allowable value!',
            14 : 'The file is not uploaded to the server. Perhaps it is very large. The max size of 5MB',
            15 : 'This file type is not allowed to upload! Allowed file types: GIF, PNG, JPG.',
            16 : 'Exceeded the limit of a day to download from your IP without your account',
            19 : 'Not valid login or password',
            'auth failed' : 'Not valid login or password',
            
            26 : 'Sorry, but for some reason you are banned on this site. Perhaps you have violated one of the points of the rules',
            30 : 'In time a connection error occurred. Maybe hosting is overloaded. Please try again later.',
            31 : 'Error closing session. Perhaps the server was overloaded. Try to upload later.',
            32 : 'Authorization Error. Perhaps the server was overloaded. Try to upload later.',
            33 : 'I can only send one.',

            'lbLinkToImage' : 'Link to image',
            'openLink'      : 'Open in browser',
            'wlogin'        : 'ITmages - Login',
            'success'       : 'ITmages - Done',
            'werror'        : 'ITmages - Error',
            'btnCopy'       : 'Copy',
            'btnDoneClose'  : 'Close',
            'lbDone'        : 'Done!',
            'profile'       : 'Without profile',
            'login_text'    : 'Login:',
            'password_text' : 'Password:',
            'saveData'      : 'Remember me',
            
            'check'         : 'Check authority...',
            'login'         : 'Authorization...',
            'upload'        : 'Upload file...',
            'logout'        : 'Closing of the session...',
            'exit'          : 'Closing of the session...',
            'None'          : 'Connecting...'
           }
           
TYPE_LINK = ['Link to full size image', 'Link to preview', "Page with all links",
             'HTML preview for forum', 
             'HTML full size image','BB preview for forum', 'BB full size image']


SAVES = {
        'save_data' : '/apps/itmages/script/save_data',
        'profile'   : '/apps/itmages/script/profile',
        'user_id'   : '/apps/itmages/script/user_id',
        'open_link' : '/apps/itmages/script/open_link',
        'type_link' : '/apps/itmages/script/type_link',
        'script'    : '/apps/itmages/script',
        'browser'   : '/desktop/gnome/applications/browser/exec'
        }

LINK = 'http://itmages.ru/image/view/%s'
DIRECT    = 'http://%s.static.itmages.ru/%s'         # full
PREVIEW   = 'http://itmages.ru/image/preview/%s'  # id/key
BB_CODE   = '[url=http://itmages.ru/image/view/%s][img]http://%s.static.itmages.ru/%s[/img][/url]' # id/key, server, small
HTML      = '<a target="_blank" href="http://itmages.ru/image/view/%s"><img src="http://%s.static.itmages.ru/%s" ></a>' # id/key, server, small
BB_FULL   = '[url=http://itmages.ru/][img]http://%s.static.itmages.ru/%s[/img][/url]' # id/key, server, full
HTML_FULL = '<a target="_blank" href="http://itmages.ru/image/view/%s"><img src="http://%s.static.itmages.ru/%s" ></a>' # id/key,server,full

HIST_FILE = os.path.expanduser('~/.itmages/history')
CONFIG_FILE = os.path.expanduser('~/.itmages/script/itmages.conf')

if not os.path.exists(os.path.dirname(CONFIG_FILE)):
    os.makedirs(os.path.dirname(CONFIG_FILE))
if not os.path.isfile(CONFIG_FILE):
    db = shelve.open(CONFIG_FILE, 'n')
    db['profile']   = True
    db['save_data'] = False
    db['open_link'] = True
    db['type_link'] = 0
    db['user_id']   = ''
    db.close()


#-------------------------------------------------------------------------------
def conf_set(key, value = '', passwd = ''):
    '''Saves configuration to the config file'''
    db = shelve.open(CONFIG_FILE,'c')
    if (key == 'user_id') and (value is not '') and (passwd is not ''):
        text = '''login=%s\npasswd=%s'''%(value,passwd)
        value = base64.b64encode(text)
    elif key == 'user_id' and value == '' and passwd == '':
        value = ''
    db.__setitem__(key, value)
    db.sync()
    db.close()
    
#-------------------------------------------------------------------------------
def conf_get(key):
    '''Loads configurations from a file'''
    value = ''
    db = shelve.open(CONFIG_FILE)
    if key in ('login','passwd') and len(db['user_id']) > 2:
        try:
            if key == 'login':
                value = base64.b64decode(db['user_id']).split('\n')[0].split('=')[1]
            elif key == 'passwd':
                value = base64.b64decode(db['user_id']).split('\n')[1].split('=')[1]
            db.close()
            return value
        except TypeError:
            db.close
            return ''
    elif key in ('login','passwd') and len(db[ 'user_id']) <= 2:
        db.close()
        return ''
    return db.get(key)

#-------------------------------------------------------------------------------
def save_history(filename, link):
    history = time.strftime('%Y/%m/%d %H:%M:%S :',time.localtime())
    history = history + sys.argv[0] + ' :' + filename + ' --> ' + link

    ### Please fix this crutch!!!
    os.system("echo '%s' >> '%s'" % (history, HIST_FILE))


#-------------------------------------------------------------------------------
def check_file(filename):
    code = 0
    filename = urllib.unquote(filename)
    fsize = os.path.getsize(filename)
    if  fsize > 5242880: code = 14
    return filename, code, fsize


#-------------------------------------------------------------------------------
def getresponse(xml_):
    d = {}
    reason = ''
    try:
        status = re.findall('<status>(.*)</status>', xml_)[0]
    except IndexError:
        status = 'failed'
        reason = ''
        d = {}
    else:
        if status == 'ok':
            if re.findall('<path>(.*)</path>|<obj>(.*)</obj>', xml_):
                d['id'] = re.findall('<id>(.*)</id>', xml_)[0]
                d['key'] = re.findall('<key>(.*)</key>', xml_)[0]
                d['full'] = re.findall('<full>(.*)</full>', xml_)[0]
                d['small'] = re.findall('<thumb>(.*)</thumb>', xml_)[0]
                d['server'] = re.findall('<server>(.*)</server>', xml_)[0]
                date = re.findall('<created>(.*)</created>', xml_)
                size = re.findall('<size>(.*)</size>', xml_)
                width = re.findall('<width>(.*)</width>', xml_)
                height = re.findall('<height>(.*)</height>', xml_)
                d['date'] = date and date[0]
                d['fsize'] = size and int(size[0])
                width = width and width[0]
                height = height and height[0]
                d['imsize'] = '%sx%s pix' % (width, height) 
        else: reason = re.findall('<reason>(.*)</reason>', xml_)[0]
    return status, reason, d
