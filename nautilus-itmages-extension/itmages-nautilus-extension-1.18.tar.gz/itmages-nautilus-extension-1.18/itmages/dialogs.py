#!/usr/bin/env python
#-*- coding: utf-8 -*-

import pygtk
pygtk.require('2.0')
import os
import re
import gtk
import cgi
import sys
import time
import iomod
import signal
import pango
import gettext
import thread
import gobject 
    
from icommon import conf_set
from icommon import conf_get
from icommon import save_history
from icommon import check_file
from icommon import getresponse
from icommon import TYPE_LINK
from icommon import DIRECT
from icommon import LINK
from icommon import PREVIEW
from icommon import BB_CODE
from icommon import HTML
from icommon import BB_FULL
from icommon import HTML_FULL
from icommon import MESSAGES
from icommon import ICONNAME
from icommon import LINES
from icommon import COLS

gettext.install('iomod', '/usr/share/locale', unicode=True)
APPNAME = os.path.basename(gobject.get_application_name())

RED = APPNAME + '-red-%s'
GREEN = APPNAME + '-green-%s'
BLUE = APPNAME + '-blue-%s'
VERBOSE = 1

#-------------------------------------------------------------------------------
def register_icons(mainicon = ICONNAME):
    pixbuf = gtk.gdk.pixbuf_new_from_file(mainicon)
    allw = pixbuf.get_width()
    allh = pixbuf.get_height()
    w = allw // COLS
    h = allh // LINES
    iconfactory = gtk.IconFactory()
    icons = {}

    for posy in xrange(LINES):
        for posx in xrange(COLS):
            x = posx * w
            y = posy * h
            pix = pixbuf.subpixbuf(x, y, w, h)
            if posy == 0: prefix = GREEN
            elif posy == 1: prefix = RED
            elif posy == 2: prefix = BLUE
            stockid = prefix % (posx * 10)
            iconset = gtk.IconSet(pix)
            icons[stockid] = pix
            iconfactory.add(stockid, iconset)
            iconfactory.add_default()

    return icons


#-------------------------------------------------------------------------------
def create_icon(window, icon_name):
    ic = gtk.Style().lookup_icon_set(icon_name)
    style = window.get_style()
    pix = ic.render_icon(style, gtk.TEXT_DIR_NONE, gtk.STATE_NORMAL,
                             gtk.ICON_SIZE_DIALOG, window, None)
    return pix
                              

#-------------------------------------------------------------------------------
class DialogLogin(gtk.Dialog):
    '''This class provides a GUI window to configure login policy'''
    profile   = conf_get('profile')
    save_data = conf_get('save_data')
 
    def __init__(self, *args):
        gtk.Dialog.__init__(self, 
                            title   = _('ITmages - Login'), 
                            parent  = None, 
                            flags   = gtk.DIALOG_MODAL|gtk.DIALOG_DESTROY_WITH_PARENT, 
                            buttons = (gtk.STOCK_CANCEL, 
                                        gtk.RESPONSE_CLOSE, 
                                        gtk.STOCK_OK, 
                                        gtk.RESPONSE_OK))
        self.set_icon(create_icon(self, BLUE % 100))
        self.set_border_width(5)
        self.set_resizable(False)
        self.set_has_separator(True)
        self.set_position(gtk.WIN_POS_CENTER_ALWAYS)
        self.set_default_response(gtk.RESPONSE_OK)
        vbox = gtk.VBox(False, 10)
        self.ckbtnProfile  = gtk.CheckButton(_('Without profile'))
        self.ckbtnSaveData = gtk.CheckButton(_('Remember me'))
        lbLogin            = gtk.Label(_('Login:'))
        lbPasswd           = gtk.Label(_('Password:'))
        self.entryLogin    = gtk.Entry()
        self.entryPasswd   = gtk.Entry()
        alProf             = gtk.Alignment(0.3, 0.5, 0.5, 0.5)
        allbLog            = gtk.Alignment(1.0, 0.5, 0.5, 0.5)
        allbPass           = gtk.Alignment(1.0, 0.5, 0.5, 0.5)
        alentLog           = gtk.Alignment(0.0, 0.5, 0.5, 0.5)
        alentPass          = gtk.Alignment(0.0, 0.5, 0.5, 0.5)
        alSave             = gtk.Alignment(0.3, 0.5, 0.5, 0.5)
        table              = gtk.Table(2, 2)
        self.ckbtnProfile.set_active(self.profile)
        self.ckbtnSaveData.set_active(self.save_data)
        lbLogin.set_properties('xalign', 1.0)
        lbPasswd.set_properties('xalign', 1.0)
        self.entryLogin.set_properties('can-focus', True)
        self.entryLogin.set_text(conf_get('login'))
        self.entryLogin.set_activates_default(True)
        self.entryPasswd.set_visibility(False)
        self.entryPasswd.set_activates_default(True)
        self.entryPasswd.set_text(conf_get('passwd'))
        self._entry_changed(None)
        self._btn_toggled(self.ckbtnProfile, 'profile')
        self.ckbtnProfile.connect('toggled', self._btn_toggled, 'profile')
        self.ckbtnSaveData.connect('toggled', self._btn_toggled, 'save_data')
        self.entryLogin.connect('changed', self._entry_changed)
        self.entryPasswd.connect('changed', self._entry_changed)
        alProf.set_padding(5, 0, 10, 0)
        alSave.set_padding(0, 0, 10, 0)
        allbLog.set_padding(0, 0, 20, 10)
        allbPass.set_padding(0, 0, 12, 10)
        alentLog.set_padding(0, 0, 0, 10)
        alentPass.set_padding(0, 0, 0, 10)
        self.vbox.set_spacing(2)
        table.set_row_spacings(10)
        table.set_col_spacings(10)
        alProf.add(self.ckbtnProfile)
        alSave.add(self.ckbtnSaveData)
        allbLog.add(lbLogin)
        allbPass.add(lbPasswd)
        alentLog.add(self.entryLogin)
        alentPass.add(self.entryPasswd)
        table.attach(allbLog, 0, 1, 0, 1)
        table.attach(allbPass, 0, 1, 1, 2)
        table.attach(alentLog, 1, 2, 0, 1)
        table.attach(alentPass, 1, 2, 1, 2)
        vbox.pack_start(alProf, True, True)
        vbox.pack_start(table, True, True)
        vbox.pack_start(alSave, True, True)
        vbox.show_all()
        self.vbox.pack_start(vbox, True, True)

                
    def _btn_toggled(self, btn, key):
        '''This method processes checkbox state changing'''
        state = btn.get_active()
        conf_set(key, state)
        self.profile = state
        if key == 'profile':
            self.entryLogin.set_sensitive(not state)
            self.entryPasswd.set_sensitive(not state)
            self.ckbtnSaveData.set_sensitive(not state)
            if state:
                self.set_response_sensitive(gtk.RESPONSE_OK, state)
            else:
                self.set_response_sensitive(gtk.RESPONSE_OK, self._allows())
        


    def _allows(self):
        '''Validates password and login'''
        login  = self.entryLogin.get_text()
        passwd = self.entryPasswd.get_text()
        if login != '' and passwd != '':
            state = True
        else:
            state = False
        return state
        


    def _entry_changed(self, entry, *args):
        '''This method is called every time contents of either entry are changed'''
        login  = self.entryLogin.get_text()
        passwd = self.entryPasswd.get_text()
        if self._allows():
            state = True
        else:
            state = False
        self.set_response_sensitive(gtk.RESPONSE_OK, state)
        return login, passwd
            


    def run(self):
        response = gtk.Dialog.run(self)
        login = None
        passwd = None
        profile = conf_get('profile')
        savedata = conf_get('save_data')
        if response == gtk.RESPONSE_OK:
            login, passwd = self._entry_changed(None)
            profile = self.ckbtnProfile.get_active()
            savedata = self.ckbtnSaveData.get_active()
            conf_set('user_id', login, passwd)
            conf_set('profile', profile)
            conf_set('save_data', savedata)
        return response, login, passwd, profile
            


    def _entry_changed(self, entry, *args):
        '''This method is called every time contents of either entry are changed'''
        login  = self.entryLogin.get_text()
        passwd = self.entryPasswd.get_text()
        if self._allows():
            state = True
        else:
            state = False
        self.set_response_sensitive(gtk.RESPONSE_OK, state)
        return login, passwd

        
#-------------------------------------------------------------------------------
class DialogError(gtk.Dialog):
    '''Shows error message in a GUI window'''


    def __init__(self, back = False,  text = '', icons = None):
        gtk.Dialog.__init__(self, flags = gtk.DIALOG_MODAL)
        self.set_title(_('ITmages - Error!'))

        self.set_icon(create_icon(self, BLUE % 100))
            
        if back is True:
            self.add_buttons(_('Back'),  gtk.RESPONSE_OK,  
                                gtk.STOCK_CLOSE, gtk.RESPONSE_CLOSE)
        else:
            self.add_buttons(gtk.STOCK_CLOSE,  gtk.RESPONSE_CLOSE)
        self.set_border_width(5)
        self.set_resizable(False)
        self.set_position(gtk.WIN_POS_CENTER_ALWAYS)
        self.set_default_response(gtk.RESPONSE_CLOSE)
        self.set_has_separator(False)
        hbox = gtk.HBox(False, 10)
        vbox = gtk.VBox(False, 2)
        image = gtk.Image()
        lbTitle = gtk.Label()
        lbText = gtk.Label(_(text))
        image.set_from_stock('gtk-dialog-error', 6)
        lbTitle.set_justify(gtk.JUSTIFY_CENTER)
        lbTitle.set_alignment(0.45, 0.5)
        lbTitle.set_markup('<span weight="bold" size="14000">%s</span>'%_('Error!'))
        lbText.set_justify(gtk.JUSTIFY_CENTER)
        lbText.set_line_wrap(True)
        lbText.set_selectable(True)
        lbText.set_alignment(0.5, 0)
        lbText.set_size_request(200,  -1)
        lbText.set_text(_(text))
        hbox.pack_start(image,  False, False)
        vbox.pack_start(lbTitle, False, False)
        vbox.pack_start(lbText, True, True)
        hbox.pack_start(vbox, True, True)
        self.vbox.pack_start(hbox,  True, True)
        self.vbox.show_all()


    def run(self):
        response = gtk.Dialog.run(self)
        return response
        


#-------------------------------------------------------------------------------
class CustomStatusIcon(gtk.StatusIcon):
    
    __gsignals__ = { 'cancelled':(
            gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE, []),
                     'visible_toggled':(
            gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE, [gobject.TYPE_BOOLEAN]),
            }

    stockid = BLUE
    index = 100
    
    def __init__(self, status = None):
        gtk.StatusIcon.__init__(self)

        ui = '''<ui><popup name="popup"><menuitem action="Show"/>
            <separator/><menuitem action="Cancel"/></popup></ui>'''

        acg = gtk.ActionGroup('')
        acg.add_actions([('Cancel', gtk.STOCK_CANCEL,
                            _('Cancel'), None, None, self.cancelled_cb),])
        canshow = conf_get('progress_visible')
        self.__state = canshow
        if canshow is None: canshow = True
        acg.add_toggle_actions([('Show', None, _('Show progress'),
                                 None, None, self.visible_toggled, canshow),])
        uiman = gtk.UIManager()
        uiman.insert_action_group(acg)
        uiman.add_ui_from_string(ui)
        self.set_from_stock(self.stockid % 0)
        self.connect('button_press_event', self.button_press_cb, uiman)
        if status: self.set_status(status)
        else: self.set_status(2)
        self.orig_tooltip = ''


    def cancelled_cb(self, *args):
        self.index = 100
        self.set_status('red')
        self.emit('cancelled')

    
    def visible_toggled(self, action):
        state = action.get_active()
        self.emit('visible_toggled', state)
        conf_set('progress_visible', state)
        self.__state = state
        

    def button_press_cb(self, icon, event, uiman):
        if event.button == 3:
            menu = uiman.get_widget('/popup')
            menu.popup(None, None,
                gtk.status_icon_position_menu,event.button,
                event.time, icon)
            return True

        else: return False
        

    def set_tooltip_text(self, text):
        if not self.orig_tooltip:
            self.orig_tooltip = text
        gtk.StatusIcon.set_tooltip_text(self, text)


    def set_status(self, status):
        if status in ('red', 'RED', 'Red', 'error', 'ERROR', 'Error',
                'auth failed', 'fail', 'Fail', 'Failed', 'failed', 0, False):
            self.stockid = RED
        elif status in ('green', 'GREEN', 'Green', 'Done', 
                        'ok', 'Ok', 'OK','Success', 'success', 1, -5, True):
            self.stockid = GREEN
        elif status in ('BLUE', 'blue', 'Blue', 2):
            self.stockid = BLUE
        stockid = self.stockid % self.index
        self.set_from_stock(stockid)
            

    def set_value(self, *args):
        value = args[-1]
        index = 0
        if value >= 0.95 : index = 100
        elif value > 0.90 : index = 90
        elif value > 0.80 : index = 80
        elif value > 0.70 : index = 70
        elif value > 0.60 : index = 60
        elif value > 0.50 : index = 50
        elif value > 0.40 : index = 40
        elif value > 0.30 : index = 30
        elif value > 0.20 : index = 20
        elif value > 0.10 : index = 10
        stockid = self.stockid % index
        self.index = index
        self.set_from_stock(stockid)
        self.emit('visible_toggled', self.__state)
        self._settooltip(value)

    def _settooltip(self, value):
        if self.get_blinking():
            text = self.orig_tooltip
        else:
            if 0.0 < value < 1.0: value += 0.01
            percent = str(int(value * 100))
            text = self.orig_tooltip + ' (' + percent + '%)'
        self.set_tooltip_text(text)


    def get_value(self):
        return self.index


    
#-------------------------------------------------------------------------------
class WindowWait(gtk.Window):
    '''A window that is used to indicate ongoing work'''

    __gsignals__ = { 
        'set_fraction':(
            gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE, [gobject.TYPE_FLOAT]),
        'cancelled':(
            gobject.SIGNAL_RUN_LAST, gobject.TYPE_NONE, []),
            }
    
    state = True


    def __init__(self, text = ''):
        gtk.Window.__init__(self)
        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_SPLASHSCREEN)
        self.set_size_request(270, 65)
        self.set_position(gtk.WIN_POS_CENTER_ALWAYS)
        self.set_border_width(7)
        vbox = gtk.VBox()
        hbox = gtk.HBox(False, 3)
        self.__msg  = gtk.Label()
        self.__pbar = gtk.ProgressBar()
        btn = gtk.Button()
        img = gtk.Image()
        alnb = gtk.Alignment(0.5, 0.5, 0.0, 0.0)
        alni = gtk.Alignment(0.5, 0.5, 0.0, 0.0)
        self.__pbar.set_size_request(-1, 15)
        self.__pbar.set_pulse_step(0.015)
        self.__msg.set_alignment(0, -1)
        self.__msg.set_text(text)
        self.__text = text
        img.set_property('icon-name', 'gtk-cancel')
        alni.add(img)
        alnb.add(btn)
        btn.add(alni)
        vbox.pack_start(self.__msg, True, True)
        vbox.pack_start(self.__pbar, True, False)
        hbox.pack_start(vbox, True, True)
        hbox.pack_start(alnb, False, False)
        hbox.show_all()
        self.add(hbox)
        btn.connect('clicked',  self.cancelled)
        self.use_pulse = False
        self.visible_block = False
        self.visible = conf_get('progress_visible') in (None, True)
        


    def set_visible(self, *args):
        status = args[-1]
        if isinstance(status, bool):
            self.visible = status
            conf_set('progress_visible', status)
            if self.visible_block:
                self.props.visible = False
            else:
                self.props.visible = status
        return True
        

    def block(self):
        self.visible_block = True
        self.hide()
        

    def pulse(self):
        self.__pbar.pulse()
        self.__msg.set_text(self.__text)
        return self.use_pulse
        
        
    def _pulse(self):
        gobject.timeout_add(10, self.pulse)
        

    def set_text(self,  text):
        self.__msg.set_text(text)
        self.__text = text
        

    def get_text(self):
        return self.__msg.get_text()
        

    def fraction(self, obj, dt, dr, ut, ur):
        fract = -1.0
        if self.visible: self.show_all()
        else: self.hide()
        while gtk.events_pending():
            gtk.main_iteration()

        if (dt, dr) > (0, 0): 
            fract = dr / (dt + 1)
        elif (ut, ur) > (0, 0):
            fract = ur / (ut + 1)

        if 0.05 < fract < 1.0:
            self.__pbar.props.fraction = fract
            self.emit('set_fraction', fract)
            self.use_pulse = False
        elif not self.use_pulse:
            self._pulse()
            self.use_pulse = True
            
        return self.state

        

    def start(self):
        if self.visible:
            self.show_all()
            self.use_pulse = True
            self._pulse()
        else:
            self.hide()
            self.use_pulse = False
        return self.state
        

    def stop(self):
        self.hide()
        self.state = False
        return


    def cancelled(self, button):
        self.staet = False
        self.emit('cancelled')


#-------------------------------------------------------------------------------


#-------------------------------------------------------------------------------
class DialogDone(gtk.Dialog):
    '''Shows dialog for successful finishing some job'''

    type_link = conf_get('type_link')


    def __init__(self, ids, icons = None):
        gtk.Dialog.__init__(self, buttons = (gtk.STOCK_CLOSE, gtk.RESPONSE_CLOSE))
        self.set_title(_('ITmages - Done!'))

        self.set_icon(create_icon(self, BLUE % 100))
        self.set_type_hint(gtk.gdk.WINDOW_TYPE_HINT_NORMAL)
        self.set_border_width(5)
        self.set_resizable(False)
        self.set_has_separator(False)
        self.set_position(gtk.WIN_POS_CENTER_ALWAYS)
        vbox = gtk.VBox(False, 2)
        hbox_ttl = gtk.HBox(False, 2)
        hbox_links = gtk.HBox(True, 2)
        hbox_btn = gtk.HBox(True, 2)
        table = gtk.Table(1, 1, True)
        btnLabel = gtk.Label()
        btnCopy = gtk.Button(_('Copy this link'))
        btnOpen = gtk.Button(_('Open this link'))
        img = gtk.Image()
        lbDone = gtk.Label()
        label_1 = gtk.Label(_('The type of link'))
        combo = gtk.combo_box_new_text()
        alImg = gtk.Alignment(0.5, 0.0, 1.0, 1.0)
        alLabel = gtk.Alignment(0.5, 0.0, 1.0, 1.0)
        alCombo = gtk.Alignment(0.5, 0.0, 1.0, 1.0)
        alCopy = gtk.Alignment(0.5, 0.0, 1.0, 1.0)
        alOpen = gtk.Alignment(0.5, 0.0, 1.0, 1.0)
        alImg.set_padding(0, 0, 0, 5)
        alLabel.set_padding(0, 0, 5, 0)
        alCombo.set_padding(0, 0, 2, 5)
        alCopy.set_padding(5, 0, 5, 2)
        alOpen.set_padding(5, 0, 2, 5)
        btnLabel.set_ellipsize(pango.ELLIPSIZE_MIDDLE)
        btnLabel.set_size_request(90, -1)
        btnCopy.set_property('receives-default',  True)
        btnCopy.set_property('has-focus', True)
        btnCopy.set_property('can-focus', True)
        lbDone.set_property('xalign',  0.0)
        lbDone.set_markup('<span weight="bold" size="13000">%s</span>' % _('Image uploaded!'))
        img.set_from_stock(gtk.STOCK_APPLY, 6)
        alImg.add(img)
        alCombo.add(combo)
        alCopy.add(btnCopy)
        alOpen.add(btnOpen)

        hbox_ttl.pack_start(alImg, False, False)
        hbox_ttl.pack_start(lbDone, False, False)
        hbox_links.pack_start(label_1, True, True)
        hbox_links.pack_start(alCombo, True, True)
        hbox_btn.pack_start(alCopy, True, True)
        hbox_btn.pack_start(alOpen, True, True)
        table.attach(hbox_ttl, 0, 1, 0, 1, gtk.EXPAND, gtk.EXPAND, 0, 0)

        vbox.pack_start(table, True, True)
        vbox.pack_start(hbox_links, False, False)
        vbox.pack_start(hbox_btn, False, False)
        vbox.show_all()
        self.vbox.pack_start(vbox, True, True)

        btnOpen.set_tooltip_markup(_('<b>Open derect link in your default browser</b>'))
        id = '%s/%s' % (ids['id'], ids['key'])
        server = ids["server"]

        link = { 0 : DIRECT    % (server, ids['full']), 
                 1 : DIRECT    % (server, ids['small']), 
                 2 : PREVIEW   % id, 
                 3 : HTML      % (id, server, ids['small']), 
                 4 : HTML_FULL % (id, server, ids['full']), 
                 5 : BB_CODE   % (id, server, ids['small']), 
                 6 : BB_FULL   % (server, ids['full'])}

        [combo.append_text(_(i)) for i in TYPE_LINK]

        combo.set_active(self.type_link)
        combo.connect('changed', self._change_active, btnCopy, link, btnOpen)
        btnCopy.connect('clicked', self._copy_to_clipboard, combo, link)
        btnOpen.connect('clicked', self._do_open_link, link)
        self.connect('response', self.response_cb, combo, link)
        self._change_active(combo, btnCopy, link, btnOpen)
        save_history(ids.get('fname'), link.get(1))
            
        
    def _do_open_link(self, btn, link):
        if self.type_link > 2:
            l = link.get(0)
        else:
            l = link.get(self.type_link)
        os.system('xdg-open %s &' % l)


    def _change_active(self, combo, btn, link, btnOpen):
        self.type_link = combo.get_active()
        conf_set('type_link', self.type_link)
        text = _('<b>Click for choose tyoe of link. Selected type:\n</b>%s')
        combo.set_tooltip_markup(text % _(combo.get_active_text()))
        text = _('<b>Click for copy selected link to the clipboard. Selected link:\n</b>%s')
        btn.set_tooltip_markup(text % cgi.escape(link.get(self.type_link)))
        if self.type_link in (0, 1, 2):
            state = True
        else:
            state = False
        btnOpen.set_sensitive(state)
        

    def _copy_to_clipboard(self, btn, combo, link):
        text = link.get(combo.get_active())
        clip = gtk.Clipboard(display = gtk.gdk.display_get_default(),  selection = "CLIPBOARD")
        clip.set_text(text)
        clip.store()
            

    def response_cb(self, w, resp, combo, link):
        self._copy_to_clipboard(None, combo, link)
        

    def run(self):
        response = gtk.Dialog.run(self)
        return response   

        
#-------------------------------------------------------------------------------

class IOInterface(gobject.MainLoop):

    def __init__(self, user, passwd, filename, progress):
        gobject.MainLoop.__init__(self)
        import Queue
        queue = Queue.Queue()
        self.progressfunction = progress
        self.data = dict(user = user,
                        passwd = passwd,
                        filename = filename,
                        progress = lambda *a: queue.put(a),
                        endfunc = self.obtained_data_cb,
                        verbose = True)
        self.iom = iomod.IOModule()
        gobject.timeout_add(30, self.__getdata, queue)

    def __getdata(self, queue):
        if queue.empty(): return True
        else:
            data = queue.get()
            apply(self.progress, data)
            return True
            

    def progress(self, obj, dt, dr, ut, ur):
        self.progressfunction(obj, dt, dr, ut, ur)


    def obtained_data_cb(self, *args):
        job, code, url, resp, obj = args
        self.response = getresponse(resp)
        self.quit()
        

    def login(self):
        self.data['job'] = 'login'
        return self._run()


    def upload(self):
        self.data['job'] = 'upload'
        return self._run()


    def logout(self):
        self.data['job'] = 'logout'
        return self._run()


    def _def_thread(self):
        apply(self.iom.connect, (), self.data)
        

    def _run(self):
        thread.start_new_thread(self._def_thread, ())
        self.run()
        return self.response



def force_exit(self, *args):
    thread.exit_thread()
    sys.exit()

def make_dialog_error(back, msg_error, sicon, icons):
    sicon.set_status('error')
    sicon.set_blinking(True)
    message = MESSAGES.get(msg_error) or msg_error or MESSAGES[30]
    dialog = DialogError(back, _(message), icons)
    response = not dialog.run() == gtk.RESPONSE_CLOSE
    dialog.destroy()
    return response


class MainExecute:
    
    def __init__(self, filename):
        self.icons = register_icons(ICONNAME)
        if isinstance(filename, (list, tuple)):
            self.fname = filename[0]
        else:
            self.fname = filename 

    def settooltip(self, widget):
        widget.set_tooltip_text(os.path.basename(self.fname))
        

    def main(self):
        gobject.threads_init()
        sicon = CustomStatusIcon('blue')
        status = ''
        back = False
        msg_error = ''
        image_info = {}
        response = None
        ac_eval = 'iom.%s()'

        self.fname, msg_error, fsize = check_file(self.fname)
        if msg_error:
            response = make_dialog_error(False, msg_error, sicon, self.icons)

        self.settooltip(sicon)
        while (response not in (False, -7, -4, -6, -1)):
            back = False
            prefix = '%s'
            sicon.set_blinking(False)
            logindialog = DialogLogin(self.icons)
            response, user, passwd, use_profile = logindialog.run()
            logindialog.destroy()
            if response != gtk.RESPONSE_OK: return
            use_profile = not use_profile
            wait = WindowWait('check')
            self.settooltip(wait)
            wait.connect('cancelled', force_exit)
            wait.connect('set-fraction', sicon.set_value)
            sicon.connect('cancelled', force_exit)
            sicon.connect('visible_toggled', wait.set_visible)
            iom = IOInterface(user, passwd, self.fname, wait.fraction)

            if not use_profile: action_list = ['upload',]
            else: action_list = ['login', 'upload', 'logout']

            for action in action_list:
                wait.set_text(prefix % _(MESSAGES[action]))
                status, reason, data = eval(ac_eval % action)
                if status == 'ok':
                    if action in 'upload':
                        image_info = data
                elif action in 'upload' and use_profile:
                    prefix = _('ERROR: ') + '%s'
                    msg_error = reason
                else:
                    if reason in 'auth failed':
                        wait.block()
                        response = make_dialog_error(True, reason, sicon, self.icons)
                        break
                    msg_error = reason

                sicon.set_status(not msg_error)

            else:
                sicon.set_status(not msg_error)
                sicon.set_blinking(True)
                wait.block()
                if image_info:
                    image_info['fname'] = self.fname
                    donedialog = DialogDone(image_info, self.icons)
                    self.settooltip(donedialog)
                    response = donedialog.run()
                    donedialog.destroy()
                    return
                else:
                    response = make_dialog_error(False, msg_error, sicon, self.icons)
                    return
                
###-------------------------------------------------------------------------------
        
    
if __name__ == '__main__':
    ex = MainExecute(sys.argv)
    ex.main()


