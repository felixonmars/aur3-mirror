#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#       Без имени.py
#       
#       Copyright 2010 Voldemar Khramtsov <harestomper@gmail.com>
#       
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 2 of the License, or
#       (at your option) any later version.
#       
#       This program is distributed in the hope that it will be useful, 
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#       
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, 
#       MA 02110-1301, USA.

import os
import sys
import Queue
import urllib
import pycurl

try:
    import cStringIO as StringIO
except ImportError:
    import StringIO
    stringio_type = StringIO.StringIO
else:
    stringio_type = StringIO.OutputType
    

homedir = os.path.join(os.environ['HOME'], '.itmages')
cookiedir = os.path.join(homedir, 'cookies')
COOKIES = os.path.join(homedir, 'cookies', '%s@itmages')
loadpath = os.path.join(homedir, 'download')
useragent = 'User-Agent: ITmages upload client (Python, rev .0)'
URLPROTO = 'http://itmages.ru/api/%s'


if not os.path.exists(loadpath): os.makedirs(loadpath)
if not os.path.exists(cookiedir): os.makedirs(cookiedir)

def debug(debug_type, debug_msg):
    types = {
                pycurl.INFOTYPE_DATA_IN: 'Input data',
                pycurl.INFOTYPE_DATA_OUT: 'Output data',
                pycurl.INFOTYPE_HEADER_IN: 'Input header',
                pycurl.INFOTYPE_HEADER_OUT: 'Output header',
                pycurl.INFOTYPE_TEXT: 'Text',
            }

    debug_str = types.get(debug_type)
    try:
        unicode(debug_msg, 'utf-8')
    except UnicodeError: pass
    else:
        fd = file('/tmp/debug.curl', 'a')
        fd.write("debug(%s): %s \n" % (debug_str, str(debug_msg)))


class IOModule:
    
    def __init__(self, **keywd):
        self.keywd = keywd
        self.usestop = True
        self.nth_error = 0
        try:
            os.remove('/tmp/debug.curl')
        except IOError: pass
        except OSError: pass


    def connect(self, *args, **keyword):
        if keyword:
            keywd = keyword
            self.keywd = keywd
        else:
            keywd = self.keywd

        buf = None
        fname = None
        outfile = None
        postfields = {}
        fdclose = False
        job = keywd['job']
        id_ = keywd.get('id')
        key = keywd.get('key')
        user = keywd.get('user')
        passwd = keywd.get('passwd')
        cookies = (user and COOKIES % user) or None

        if job == 'upload': job = 'add'
        elif job == 'getlist': job = 'getpictures'
        elif job in ('remove', 'del'): job = 'delete'

        filename = keywd.get('filename')
        url = URLPROTO % job

        pfset = postfields.__setitem__
        id_ and pfset('id', id_)
        key and pfset('key', key)

        c = pycurl.Curl()
        c.setopt(c.USERAGENT, useragent)
        c.setopt(c.NOSIGNAL, 1)
        
        if job in 'login':
            user and pfset('name', user)
            passwd and pfset('passwd', passwd)
            
        elif job == 'add':
            c.setopt(c.POST, 1)
            command = "file --mime-type '%s'" % filename
            mime = os.popen(command).read().strip().split()[-1]
            norm_name = filename.strip()
            lower = norm_name.lower()
            if not lower.endswith(('.jpeg', '.jpg', '.gif', '.png')):
                format = mime.split('/')[1]
                norm_name = norm_name + '.%s' % format

            c.setopt(c.POST, 1)
            c.setopt(c.HTTPPOST, [('xmldata', 'requested'),
                    ('UFileManager[picture]', os.path.basename(norm_name)),
                    ('UFileManager[picture]', (c.FORM_FILE, filename,
                                             c.FORM_CONTENTTYPE, mime,
                        c.FORM_FILENAME, os.path.basename(norm_name)))])
        elif job in 'load':
            postfields = {}
            path_to = keywd.get('path_to')
            if Id_.startswith('http://'): 
                url = id_
            else: 
                url = 'http://static.itmages.ru/%s' % id_

            if not keywd.get('outbuf'):
                if not os.path.exists(path_to): 
                    os.makedirs(path_to)

                fname = os.path.join(path_to, os.path.basename(id_))
                outfile = file(fname, 'wb')
                keywd['writefunc'] = outfile.write
                fdclose = True

            c.setopt(c.TIMEOUT, 30)
            c.setopt(c.FRESH_CONNECT, 1)
            c.setopt(c.MAXCONNECTS, 100)
            
        if postfields:
            c.setopt(c.POST, 1)
            c.setopt(c.POSTFIELDS, urllib.urlencode(postfields))

        if cookies:
            c.setopt(c.COOKIEJAR, cookies)
            c.setopt(c.COOKIEFILE, cookies)

        if keywd.has_key('writefunc'):
            wfunc = keywd['writefunc']
        else:
            buf = StringIO.StringIO()
            wfunc = buf.write

        if wfunc:
            c.setopt(c.WRITEFUNCTION, wfunc)

        if keywd.get('progress'):
            c.setopt(c.NOPROGRESS, 0)
            c.setopt(c.PROGRESSFUNCTION, self.progress)

        if keywd.get('verbose'):
            v = 1
            c.setopt(c.DEBUGFUNCTION, debug)
        else: v = 0

        c.setopt(c.URL, str(url))
        c.setopt(c.VERBOSE, v)
            
        try:
            c.perform()
        except pycurl.error, e:
            msg = '<status>failed</status>separator<reason>%s</reason>' % e[1]
            rcode = e[0]
            efurl = url
        else:
            efurl = c.getinfo(c.EFFECTIVE_URL)
            rcode = c.getinfo(c.RESPONSE_CODE)
        finally:

            if fdclose and outfile:
                outfile.close()

            reload = keywd.get('reload')
            c.close()

            if (not (rcode in (404, 502))) and (keywd.get('job') in 'load') \
                                and (buf and len(buf.getvalue()) == 0) \
                                and ((reload and reload < 3) or reload is None):
                reload = reload is None and 1 or reload + 1
                keywd['reload'] = reload
                arg = apply(self.net_connect, args, keywd)

            elif reload is None or reload > 0:
                keywd['reload'] = -1
                obj = keywd.get('object')
                
                func = keywd.get('endfunc')
                arg = (job, rcode, efurl, None, obj)

                if keywd.get('outbuf'):
                    arg = (job, rcode, efurl, buf, obj)
                elif isinstance(buf, stringio_type):
                    arg = (job, rcode, efurl, buf.getvalue(), obj)
                    buf.close()
                elif fname:
                    arg = (job, rcode, efurl, fname, obj)

                if func:
                    apply(func, arg)
                return arg
            

    def progress(self, dt, dr, ut, ur):
        obj = self.keywd.get('object')
        progress = self.keywd.get('progress')
        if callable(progress):
            apply(progress, (obj, dt, dr, ut, ur))
            

def check_connection(url = 'http://itmages.ru'):
    import pycurl
    c = pycurl.Curl()
    buf = StringIO.StringIO()
    c.setopt(c.URL, url)
    c.setopt(c.USERAGENT, useragent)
    c.setopt(c.WRITEFUNCTION, buf.write)
    c.setopt(c.CONNECT_ONLY, 1)
    c.setopt(c.VERBOSE, 0)
    try:
        c.perform()
    except:
        val = False
    else:
        rcode = c.getinfo(c.RESPONSE_CODE)
        if rcode == 404:
            val = False
        else:
            val = True
    finally:
        c.close()
        buf.close()
        return val



if __name__ == '__main__':
    main()
