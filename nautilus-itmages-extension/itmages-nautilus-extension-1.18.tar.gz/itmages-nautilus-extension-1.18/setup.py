#!/usr/bin/env python2.7
#
# setup.py for gnuConcept

import os
import sys

sys.path.insert(0, '/usr/bin')
try:
    import msgfmt
except ImportError:
    use_pyfmt = False
    if not os.path.exists('/usr/bin/msgfmt'):
        raise OSError ('Could not found the compiler localization')
    else:
        print 'Python module "msgfmt.py" not found. Use "msgfmt" from gettext'
else:
    use_pyfmt = True
    print 'Found msgfmt python module'

    
    
from glob import glob


VERSION = '1.14'
AUTHOR = 'Khramtsov Vladimir'
AUTHOR_EMAIL = 'harestomper@gmail.com'
URL = 'https://code.launchpad.net/~itmages/itmages/itmages-nautilus-extension'



long_desc = '''This is an extension for the file manager Nautilus,
which allows you to quickly upload your images to
free image hosting ITmages.ru, in 'two clicks'.
Your suggestions for improving the script, and bug
reports can be left on the pages:
requests - https://blueprints.launchpad.net/itmages
bug tracker - https://bugs.launchpad.net/itmages'''

def getarg(opt):
    lib = opt.split('=')[1]
    idx = sys.argv.index(opt)
    sys.argv.pop(idx)
    return lib.replace('/usr/', '')

archlib = None
cext = False
argv = ["%s" % i for i in sys.argv]

for arg in argv:
    if '--archlib=' in arg:
        archlib = getarg(arg)
    elif '--c-ext' in arg:
        cext = True
        idx = sys.argv.index(arg)
        sys.argv.pop(idx)


if not archlib:
    ARCH = os.uname()[4]
    archlib = ARCH in 'x86_64' and 'lib64' or 'lib'

if (not cext) or (not os.path.exists('./scripts/libitmages-extension.so')):
    extension = ('%s/nautilus/extensions-2.0/python' % archlib, [
                                    'scripts/itmages-extension.py',])
else:
    extension = ('%s/nautilus/extensions-2.0' % archlib, [
                                'scripts/libitmages-extension.so',])
                                    

from distutils.core import setup, Distribution, Command
from distutils.command.build import build as _build
from distutils.command import bdist_rpm as _bdistrpm

print "EXTENSION = ", extension

                                  
def make_mofiles():
    po_dir = os.path.join(os.path.dirname(os.curdir), 'po')

    for src in glob(os.path.join(po_dir, '*.po')):
        lang = os.path.basename(src).replace('.po', '')
        build_dir = os.path.join('share', 'locale', lang, 'LC_MESSAGES')

        if not os.path.exists(build_dir):
            os.makedirs(build_dir)

        dest = os.path.join(build_dir, 'iomod.mo')
        print 'Compiling %s' % src
        if use_pyfmt:
            msgfmt.make(src, dest)
        else:
            fd = os.popen('msgfmt %s -o %s 2>/dev/null' % (src, dest))
            
        yield src, dest
                            


class build(_build, Distribution):

    user_options = [("--c-ext", "", ""), ("--archlib=", "", "")]

    def run(self):
        data_files = self.distribution.data_files

        if data_files is None:
            self.distribution.data_files = data_files = []

        for src, dest in make_mofiles():
            data_files.append((os.path.dirname(dest), [dest,]))

        _build.run(self)


class bdist_rpm(_bdistrpm.bdist_rpm):
    
    def run(self):
        for path in ['build', 'share', 'dist']:
            try:
                os.removedirs('build')
            except: pass
            
        if os.path.exists('MANIFEST'):
            os.remove('MANIFEST')

        fd = file('MANIFEST', 'a')

        data_files = self.distribution.data_files
        if data_files is None:
            self.distribution.data_files = data_files = []
        
        for src in glob('po/*.po'):
            fd.write('\n%s' % src)
            data_files.append((os.path.dirname(src), [src,]))
        
        fd.write('\npixmaps/complex.png')
        fd.write('\nsetup.py')
        fd.write('\nsetup.cfg')
        fd.write('\nMANIFEST')
        fd.write('\nREADME')
        fd.write('\nINSTALL')
        fd.write('\nitmages')
        for module in glob('itmages/*.py') + glob('scripts/upload-picture*') + extension[1]:
            fd.write('\n%s' % module)

        fd.close()
        _bdistrpm.bdist_rpm.run(self)




setup(  
        name = 'nautilus-itmages-extension',
        version = VERSION,
        author = AUTHOR,
        author_email = AUTHOR_EMAIL,
        description = 'The scripts for upload images to itmages.ru',
        long_description = long_desc,
        url = URL,
        license = "GNU General Public License (GPL)",

        classifiers = ['Development Status :: 5 - Production/Stable',
                       'Environment :: X11 Applications :: Gnome',
                       'Environment :: Console',
                       'Natural Language :: English',
                       'Natural Language :: Russian',
                       'Operating System :: POSIX :: Linux',
                       'Operating System :: MacOS :: MacOS X',
                       'Programming Language :: Python :: 2.6',
                       'Topic :: Communications :: Email',
                      ],
        packages = ['itmages',],
        data_files = [
                        ('share/itmages/icons', ['pixmaps/complex.png',]),
                        extension],
        scripts = glob('scripts/upload-*'),

        cmdclass = {
                    'build': build,
                    'bdist_rpm': bdist_rpm,
                    }
    )

