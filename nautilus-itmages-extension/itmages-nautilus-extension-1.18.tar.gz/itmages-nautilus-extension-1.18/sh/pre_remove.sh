#!/bin/bash

ARCH="$(uname -m)"

if [ "$ARCH" == "x86_64" ] || [ "$ARCH" == "amd64" ]; then 
    _extensiondir64="/usr/lib64/nautilus/extensions-2.0/python"
    _extension="itmages-extension.py"
    test -f "${_extensiondir64}/${_extension}" && rm -f "${_extensiondir64}/${_extension}" 2>/dev/null
    test -z "$(ls ${_extensiondir64} 2> /dev/null)" && rm -rf "${_extensiondir64}" 2>/dev/null
fi
