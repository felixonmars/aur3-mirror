#!/bin/bash

ARCH="$(uname -m)"

if [ "$ARCH" == "x86_64" ] || [ "$ARCH" == "amd64" ]; then 
    _lib='libpython2.6.so'
    _extensiondir64="/usr/lib64/nautilus/extensions-2.0/python"
    _extensiondir="/usr/lib/nautilus/extensions-2.0/python"
    _extension="itmages-extension.py"

    if ( ! test -f "/usr/lib/${_lib}" ) && test -f "/usr/lib64/${_lib}.1.0"; then
        ln -s "/usr/lib64/${_lib}.1.0" "/usr/lib/${_lib}" 2>/dev/null
    else
        if ! test -f "/usr/lib/${_lib}"; then
            echo "WARNING: Check install libpython_2.6"
        fi
    fi

    if ! test -d ${_extensiondir64}; then
        mkdir -m 755 -p ${_extensiondir64} 2> /dev/null
    fi

    test -L "${_extensiondir}/${_extension}" || \
    ln -s "${_extensiondir}/${_extension}" "${_extensiondir64}/${_extension}" 2> /dev/null
fi
