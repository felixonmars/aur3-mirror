#!/usr/bin/env python
# -*- coding: utf-8 -*-


import pygtk
pygtk.require('2.0')
import nautilus
#import commands
import os
import gettext
import urllib
import re
import sys
import gtk
import gobject
import gconf

from commands import getoutput

sys.path.insert(0, '/usr/lib/itmages')
sys.path.insert(0, '/usr/lib64/itmages')

from itmages.dialogs import register_icons
from itmages.dialogs import BLUE
from itmages.dialogs import GREEN
from itmages.dialogs import RED
from itmages.icommon import check_file

gettext.install( 'iomod', '/usr/share/locale' , unicode=True)

NAUTILUS_MENU_LABEL = _('Upload this picture to ITmages')
NAUTILUS_MENU_HELP = _('Uploads the images to hosting ITmages')
ALLOWED_TYPES = ('image/jpg', 'image/png', 'image/jpeg', 'image/gif')

register_icons()

EXT_DIR = "/apps/itmages_ext"
HIST_KEY = os.path.join(EXT_DIR, "show_history")


def parse_history(*args):
    histlist = []
    historyfile = os.path.join(os.environ['HOME'], '.itmages', 'history')
    try:
        fd = file(historyfile, 'r')
    except IOError: pass
    else:
        data = fd.read().split('\n')
        fd.close()
        data.reverse()
        
        for line in data[:10]:
            if line:
                uri, url = re.findall('.*:.*:(.*) --> (.*)', line)[0]
                histlist.append((uri, url))

    return histlist


def log(*data):
    fd = file('/tmp/extension.log', 'a')
    fd.write('\n' + str(data))
    fd.close()
    

class UploadPicture(nautilus.MenuProvider):
   
    def __init__(self):
        pass


    def run(self, menu, list_of_files):
        os.environ['NAUTILUS_ITMAGES_SESLECTED_FILES'] = str(list_of_files)
        os.system("upload-picture &")
        return


    def make_history(self):
        items = []
        historylist = parse_history()

        if historylist:
            menuitem = nautilus.MenuItem('History',
                            _('Upload history'), _('Upload history'))
            menuitem.set_property('icon', GREEN % 100)
            menuitem.set_property('priority', True)
            menu = nautilus.Menu()
            menuitem.set_submenu(menu)
            items.append(menuitem)

            for uri, url in historylist:
                mitem = nautilus.MenuItem('NautilusPython::%s' % url, uri, url)
                mitem.connect('activate', self.copy_link, url)
                menu.append_item(mitem)
        return items
        


    def get_file_items(self, window, sel_items):
        show_history = True
        client = gconf.Client()
        
        if client.dir_exists(EXT_DIR):
            show_history = client.get_bool(HIST_KEY)
        else:
            client.set_bool(HIST_KEY, show_history)

        if show_history:
            items = self.make_history()
        else:
            items = []
            
        list_of_file = []
        show_item = False

        for naufile in sel_items:
            fname = naufile.get_uri().replace('file://', '')
            good_type = naufile.get_mime_type() in ALLOWED_TYPES
            if good_type:
                show_item = True
                list_of_file.append(fname)

        if show_item:
            item = nautilus.MenuItem('NautilusPython::upload-picture', \
                                NAUTILUS_MENU_LABEL, NAUTILUS_MENU_HELP)
            icon = BLUE % 100
            item.set_property('icon', icon)
            item.connect('activate', self.run, list_of_file)
            items.insert(0, item)

        return items
            


    def copy_link(self, item, url):
        clip = gtk.Clipboard(display = gtk.gdk.display_get_default(), 
                             selection = "CLIPBOARD")
        text = item.props.tip
        clip.set_text(text)
        clip.store()

