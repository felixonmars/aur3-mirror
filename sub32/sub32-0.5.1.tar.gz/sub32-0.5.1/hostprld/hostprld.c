#include <stdio.h>
#include <dlfcn.h>

#define APPEND "-32"

int gethostname(char *name, size_t namelen) {
  int *dlhandle = NULL;
  int (*f)() = NULL;

  char realhostname[namelen];

  if (name == NULL) 
    return -1;

  dlhandle = dlopen("libnsl.so", RTLD_LAZY);
  if (dlhandle == NULL) {
#ifdef DEBUG
    printf("Can't dlopen() libnsl.so\n");
#endif
    return -1;
  }
  f = dlsym(dlhandle, "gethostname");
  if (f == NULL) {
#ifdef DEBUG
    printf("Can't dlsym() \"gethostname\"\n");
#endif
    return -1;
  }

  if ((*f)(&realhostname, namelen) != 0) {
#ifdef DEBUG
    printf("gethostname returned non-zero\n");
#endif
    return -1;
  }

  snprintf(name, namelen, "%s%s", realhostname, APPEND);
  return 0;
}