#!/bin/bash

[ ${CC} -z ] && CC="gcc"
CFLAGS+="-shared -fpic -ldl"
#CFLAGS+="-DDEBUG" Optional debugging messages

OUTPUT="$@"
[ -z "${OUTPUT}" ] && OUTPUT="hostprld.so"

${CC} hostprld.c ${CFLAGS} -o ${OUTPUT}
