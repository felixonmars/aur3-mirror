#!/bin/bash


mkdir -p ${DESTDIR}/usr/bin
mkdir -p ${DESTDIR}/etc/rc.d
mkdir -p ${DESTDIR}/usr/share/sub32/sub32-skel
mkdir -p ${DESTDIR}/usr/share/sub32/hostprld
install sub32 ${DESTDIR}/usr/bin/sub32  -o root -m 0755
install sub32-init ${DESTDIR}/usr/bin/sub32-init  -o root -m 0755
install sub32.rc ${DESTDIR}/etc/rc.d/sub32 -o root -m 0755
install hostprld/hostprld.c ${DESTDIR}/usr/share/sub32/hostprld/hostprld.c -o root -m 0755
install hostprld/make.sh ${DESTDIR}/usr/share/sub32/hostprld/make.sh -o root -m 0755

for i in $(ls skel); do
    install skel/$i ${DESTDIR}/usr/share/sub32/sub32-skel/ -o root -m 0755
done

