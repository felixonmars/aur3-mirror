pastenshort
====

Get the temperature.

Depend
======

python3 PyQt4

Installation
============

```
git clone https://github.com/Chipsterjulien/pymeteo.git
python setup.py install
```

Usage
=====

```
python meteo
```
