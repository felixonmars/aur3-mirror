#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import shutil
import configparser

from PyQt4 import QtCore
from PyQt4 import QtGui
from PyQt4.QtCore import pyqtSlot

from .about_gui import Ui_aboutWidget
from .main_gui import Ui_mainDialog


ICONS_PATH = '/usr/share/pymeteo/images'


class AboutGui(QtGui.QWidget, Ui_aboutWidget):
    def __init__(self, x, y, width, height):
        QtGui.QWidget.__init__(self)
        self.setupUi(self)
        # Fenêtre toujours centrée sur la parente
        self.move((x + width / 2) - self.width() / 2,
                  (y + height / 2) - self.height() / 2)

        self.closeButton.setIcon(QtGui.QIcon(os.path.join(ICONS_PATH,
                                                          'dialog-close.png')))
        self.logoLabel.setPixmap(QtGui.QPixmap
                                 (os.path.join(ICONS_PATH,
                                               'weather-showers.svg')))

    def on_closeButton_clicked(self):
        self.close()


class MainGui(QtGui.QDialog, Ui_mainDialog):
    """Init GUI and action when button pressed."""

    def __init__(self, config_location, cfg, gnuplot_cfg, gnuplot_data):
        self.config_location = config_location
        self.gnuplot = gnuplot_cfg
        self.data = gnuplot_data
        self.cfg = cfg
        self.about = None

        QtGui.QDialog.__init__(self, None)

        self.setupUi(self)

        # On définit l'emplacement correct dans le line edit
        self.locationLineEdit.setText(self.cfg['Default']['data_file'])

        self.quitButton.clicked.connect(QtCore.QCoreApplication.
                                        instance().quit)

        self.aboutButton.setIcon(QtGui.QIcon(os.path.join(ICONS_PATH,
                                                          'documentinfo.png')))
        self.quitButton.setIcon(QtGui.QIcon
                                (os.path.join(ICONS_PATH,
                                              'system-shutdown.png')))
        self.okButton.setIcon(QtGui.QIcon
                              (os.path.join(ICONS_PATH,
                                            'dialog-ok-apply.png')))
        self.toolButton.setIcon(QtGui.QIcon
                                (os.path.join(ICONS_PATH,
                                              'document-open-folder.png')))

    def __change_gnuplot_conf(self, old_data_location):
        data_location = self.cfg['Default']['data_file']
        target_gnuplot_cfg = os.path.join(os.path.dirname(data_location),
                                          os.path.split(self.gnuplot)[1])

        with open(self.gnuplot, 'r') as src:
            with open(target_gnuplot_cfg, 'w') as target:
                old = os.path.split(old_data_location)[1]
                new = os.path.split(self.data)[1]
                while 1:
                    line = src.readline()
                    if not line:
                        break
                    if old in line:
                        target.write(line.replace(old, new))
                    else:
                        target.write(line)

    def __saving_conf(self):
        """It private and save config."""
        with open(self.config_location, 'w') as target:
            self.cfg.write(target)

    def __saving_data(self):
        """It private and save data."""
        with open(self.cfg['Default']['data_file'], 'a') as target:
            target.write('{0} {1} {2} {3} {4}\n'
                         .format(self.calendarWidget.selectedDate().toPyDate()
                                 .strftime("%d/%m/%Y"),
                                 self.insideMax.value(),
                                 self.insideMin.value(),
                                 self.outsideMax.value(),
                                 self.outsideMin.value()))

    # Permet de spécifier qu'une seule connection (Évite l'ouverture double
    # d'une fenêtre par exemple)
    @pyqtSlot()
    def on_toolButton_clicked(self):
        filename = QtGui.QFileDialog.getOpenFileName(self,
                                                     'Sélectionner un fichier',
                                                     '')
        if filename != '':
            self.locationLineEdit.setText(filename)

    @pyqtSlot()
    def on_aboutButton_clicked(self):
        self.about = AboutGui(self.geometry().x(), self.geometry().y(),
                              self.width(), self.height())
        self.about.setWindowModality(QtCore.Qt.ApplicationModal)
        self.about.show()

    @pyqtSlot()
    def on_okButton_clicked(self):
        # On récupère l'emplacement des données
        data_location = self.locationLineEdit.text()
        # Si l'emplacement a changé
        if data_location != self.cfg['Default']['data_file']:
            # On vérifie que l'emplacement existe
            if not os.path.exists(os.path.dirname(data_location)):
                text = "L'emplacement \"{0}\" n'existe pas !".format(
                    os.path.dirname(data_location))
                # On affiche une alerte
                QtGui.QMessageBox.warning(self, 'Erreur', text)
                return
            # On vérifie qu'on a les autorisations sur le nouvel emplacement
            if not os.access(os.path.dirname(data_location), os.W_OK):
                # On affiche une fenêtre d'alerte
                text = "Vous n'avez pas les droits pour écrire sur \
                        le fichier \"{0}\"".format(
                    os.path.dirname(data_location))
                QtGui.QMessageBox.warning(self, 'Erreur', text)
                # On fait un return
                return

            old_data_location = self.cfg['Default']['data_file']

            # On modifie la config dans self.cfg
            self.cfg.set('Default', 'data_file', data_location)
            # On sauvegarde la config self.cfg
            self.__saving_conf()
            # On copie la conf pour gnuplot en changeant l'emplacement
            self.__change_gnuplot_conf(old_data_location)
            # On copie le template
            shutil.copy2(self.data, data_location)
            # On sauvegarde les données
            self.__saving_data()

        else:
            target_gnuplot_cfg = os.path.join(os.path.dirname(data_location),
                                              os.path.split(self.gnuplot)[1])

            # vérifier si le fichier existe
            if not os.path.exists(target_gnuplot_cfg):
                shutil.copy2(self.gnuplot, target_gnuplot_cfg)

            if not os.path.exists(data_location):
                shutil.copy2(self.data, data_location)

            self.__saving_data()

        # Si gnuplot est installé, on génère l'affichage
        if os.path.exists(self.gnuplot):
            os.chdir(os.path.dirname(data_location))
            os.system('gnuplot config.plt')

            if self.cfg['Default']['viewer'] != '':
                os.system(self.cfg['Default']['viewer'] + ' meteo.png')

        QtGui.QApplication.quit()

    # Cette fonction est appelée quand on appuie sur une touche du clavier
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            event.ignore()


def create_config(conf):
    """It create config file with configparser if not exists.

    It take 1 argument who is the config filename

    """

    if os.path.exists(conf):
        return

    find = False
    viewer = ['gwenview', 'eog', 'gqview', 'geeqie', 'mirage', 'ristretto',
              'gpicview', 'feh']

    if not os.path.isdir(os.path.dirname(conf)):
        os.makedirs(os.path.dirname(conf))

    cfg = configparser.ConfigParser()
    cfg.add_section('Default')
    cfg.set('Default', 'data_file', os.path.join(os.path.dirname(conf),
                                                 'data.plt'))
    cfg.set('Default', 'gnuplot', '/usr/bin/gnuplot')

    for v in viewer:
        filename = os.path.join('/usr/bin', v)
        if os.path.exists(filename):
            find = True
            cfg.set('Default', 'viewer', filename)

    if not find:
        cfg.set('Default', 'viewer', '')

    with open(conf, 'w') as target:
        cfg.write(target)


def load_config(conf):
    """It read config file."""

    cfg = configparser.ConfigParser()
    cfg.read(conf)

    return cfg
