#!/usr/bin/env python3
# -*- coding: utf-8 -*-


__author__ = "Julien Freyermuth"
__author_email__ = "julien [dote] chipster [hate] gmail [dote] com"
__copyright__ = "Copyright (c) 2014, Julien Freyermuth"
__description__ = "Raise temperature"
__license__ = "WTFPL"
__name__ = "pymeteo"
__platforms__ = "GNU/Linux"
__url__ = "https://github.com/Chipsterjulien/pymeteo"
__version__ = '0.0.1'
__version_info__ = (0, 0, 1, '', 0)

from .Class import AboutGui, MainGui
from .about_gui import *
from .main_gui import *
#from .download import download
#from .img_info import Img_info
#from .mylog import *
#from .number import is_number
