var searchData=
[
  ['input_5fs',['input_s',['../structinput__s.html',1,'']]],
  ['is_5fover',['is_over',['../structgame__s.html#acf3c6322d2da8d917d38a5f19d40fd23',1,'game_s']]]
];
