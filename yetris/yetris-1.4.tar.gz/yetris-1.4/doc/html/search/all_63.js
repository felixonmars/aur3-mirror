var searchData=
[
  ['can_5fhold',['can_hold',['../structgame__s.html#a2880a0381333d3235314d1c914e2a19b',1,'game_s']]]
];
