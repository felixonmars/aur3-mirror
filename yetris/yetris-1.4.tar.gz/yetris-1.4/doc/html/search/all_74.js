var searchData=
[
  ['timer_2ec',['timer.c',['../timer_8c.html',1,'']]],
  ['timer_2eh',['timer.h',['../timer_8h.html',1,'']]],
  ['timer_5fdelta_5fuseconds',['timer_delta_useconds',['../timer_8c.html#a219e11ede616afec0ab0f1c9b56546c6',1,'timer_delta_useconds(struct timert *t):&#160;timer.c'],['../timer_8h.html#a219e11ede616afec0ab0f1c9b56546c6',1,'timer_delta_useconds(struct timert *t):&#160;timer.c']]],
  ['timer_5fstart',['timer_start',['../timer_8c.html#acc4ef4dba0c3eb686558c39e4514071e',1,'timer_start(struct timert *t):&#160;timer.c'],['../timer_8h.html#acc4ef4dba0c3eb686558c39e4514071e',1,'timer_start(struct timert *t):&#160;timer.c']]],
  ['timer_5fstop',['timer_stop',['../timer_8c.html#ac3c8023e45cd97e1162a3be9a9b09fb8',1,'timer_stop(struct timert *t):&#160;timer.c'],['../timer_8h.html#ac3c8023e45cd97e1162a3be9a9b09fb8',1,'timer_stop(struct timert *t):&#160;timer.c']]],
  ['timert',['timert',['../structtimert.html',1,'']]]
];
