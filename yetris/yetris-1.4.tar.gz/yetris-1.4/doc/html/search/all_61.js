var searchData=
[
  ['args_5fhandle',['args_handle',['../arguments_8h.html#ac1011321eb6d72971e9574c27c2ef455',1,'arguments.c']]],
  ['arguments_2eh',['arguments.h',['../arguments_8h.html',1,'']]]
];
