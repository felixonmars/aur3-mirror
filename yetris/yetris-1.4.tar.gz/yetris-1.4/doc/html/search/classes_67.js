var searchData=
[
  ['game_5fs',['game_s',['../structgame__s.html',1,'']]],
  ['globals_5fs',['globals_s',['../structglobals__s.html',1,'']]]
];
