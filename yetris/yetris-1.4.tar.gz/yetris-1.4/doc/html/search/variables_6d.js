var searchData=
[
  ['moved_5fpiece_5fdown',['moved_piece_down',['../structgame__s.html#aeee57e8380b2a47b879bd767b3a8314a',1,'game_s']]]
];
