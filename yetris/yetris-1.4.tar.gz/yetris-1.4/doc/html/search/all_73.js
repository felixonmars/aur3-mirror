var searchData=
[
  ['score_5fs',['score_s',['../structscore__s.html',1,'']]],
  ['screen_5fs',['screen_s',['../structscreen__s.html',1,'']]],
  ['speed',['speed',['../structgame__s.html#a8c9320d6d8c8a8587336ce00380cfebe',1,'game_s']]],
  ['start',['start',['../structtimert.html#a357b0b5b5667b2810275866168793f82',1,'timert']]]
];
