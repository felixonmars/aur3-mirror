var searchData=
[
  ['piece_5fs',['piece_s',['../structpiece__s.html',1,'']]],
  ['piece_5ftimer',['piece_timer',['../structgame__s.html#a7fcf6c05859bba0c6caa41bdac892c77',1,'game_s']]]
];
