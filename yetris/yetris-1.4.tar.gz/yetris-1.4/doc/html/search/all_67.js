var searchData=
[
  ['game_5fs',['game_s',['../structgame__s.html',1,'']]],
  ['gameplay_5fh',['gameplay_h',['../structgame__s.html#a8e6295abe6fcdeaff3de898aea933a50',1,'game_s']]],
  ['gameplay_5fm',['gameplay_m',['../structgame__s.html#a068230ef05baac0cf25d9da736917e07',1,'game_s']]],
  ['gameplay_5fs',['gameplay_s',['../structgame__s.html#a8dc8e7682b8a6b1385b020d1f0d2aeb6',1,'game_s']]],
  ['globals_5fs',['globals_s',['../structglobals__s.html',1,'']]]
];
