var searchData=
[
  ['score_5fs',['score_s',['../structscore__s.html',1,'']]],
  ['screen_5fs',['screen_s',['../structscreen__s.html',1,'']]]
];
