#!/usr/bin/perl
#
# format docbook xml files downloaded for Khronos OpenCL man-pages
#
# the man pages from Khronos are slightly malformed, and must be processed by this script for
# proper (or, better) formatting
#
# to run, first get the xml files from:
# svn co --username anonymous --password anonymous https://cvs.khronos.org/svn/repos/registry/trunk/public/cl/sdk/1.2/docs/man/ man
#
# then run this file on each xml file. example: ./opencl_manpage.pl *.xml
# Output will be a man formated file *.3
# these .3 files are then gzip'ed to *.3.gz
# these man files can be installed by copying to /usr/local/share/man/man3/
#

use File::Basename;

while($filenm = shift)
{
    $tmpfilenm = $filenm."tmp";
    ($fileonlynm, $foldernm, $suffix) = fileparse($filenm);

    open(FILE, $filenm);
    open(TMP, ">", $tmpfilenm);
    print "outputting to ".$filenm."tmp\n";
    $lic = 0;
    while(<FILE>)
    {
            #remove <link> tag and contents
            s/\<link[^<]*\>//g;
            s/\<\/link\>/ /g;

            #replace oversized holder string for mone more manigable
            if(/\<holder\>/)
            {
                $lic = 1;
                print TMP "<holder>The Khronos Group</holder>";
            }
            if(/\<\/holder\>/)
            {
                $lic = 0;
                next;
            }

            #remove blank lines
            if(/^\s*$/)
            {
                next;
            }

            #dont print <holder> tag; print all other lines
            if($lic == 0)
            {
                print TMP $_;
            }
    }
    close(FILE);
    close(TMP);
    `docbook2man $tmpfilenm`; #compile XML to man pages
    unlink($tmpfilenm);

    opendir(DIR, $foldernm);
    while(my $file = readdir(DIR))
        {
            next unless(-f "$foldernm/$file");
            next unless($file =~ m/\.[13]$/);
            $newfile = $file;
            $newfile =~ s/[_ ]//;
            $tmp = $newfile . "tmp";
            rename($file, $tmp);

            open(TMP, $tmp);
            open(FILE, ">", $newfile);
            while(<TMP>)
            {
                if(/\\\*\(T\>\\kx\.if/) #remove malformed 'if' in man
                {
                    next;
                }
                print FILE $_;
            }
            close(FILE);
            close(TMP);
            unlink($tmp);
            `gzip -9 $file`
        }
}
