#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->mainToolBar->hide();
    on_checkBoxTermOutput_clicked();

    homepath = QDir::homePath();

    ui->pushButtonForcestop->hide();

    //adds formats to comboBoxoutputformat
    OutFormatList << "mp3";
    OutFormatList << "ogg";
    OutFormatList << "wav";
    OutFormatList << "wma";
    OutFormatList << "flac";
    OutFormatList << "acc";

    OutFormatDescList << "MP3 -  MPEG-2 Audio Layer III";
    OutFormatDescList << "OGG -  Free, open container format";
    OutFormatDescList << "WAV -  Waveform Audio File Format";
    OutFormatDescList << "WMA -  Windows Media Audio";
    OutFormatDescList << "FLAC -  Free Lossless Audio Codec";
    OutFormatDescList << "AAC -  Advanced Audio Coding";



    int ListIndex = 0;
    foreach(QString format,OutFormatList)
    {
        ui->comboBoxoutputformat->addItem(OutFormatDescList[ListIndex],format);
        ListIndex +=1 ;
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


//The function used to run a cmd etc.
void MainWindow::runcmd(QString cmd,QStringList args)
{

    //Creates the new process.
    process = new QProcess(this);

    //Stats the process
    process->start(cmd,args);

    //Sets the connections
    connect(process,SIGNAL(readyReadStandardOutput()),this,SLOT(readstdoutput()));
    connect(process,SIGNAL(readyReadStandardError()),this,SLOT(readstderr()));
    connect(process, SIGNAL(finished(int, QProcess::ExitStatus)),
         this, SLOT(onProcessFinished(int, QProcess::ExitStatus)));

    //Clears the textedit
    ui->textEditTermoutput->clear();
}

void MainWindow::readstdoutput()
{
    ui->textEditTermoutput->setTextColor(Qt::black);
    QByteArray strdata = process->readAllStandardOutput();
    qDebug() << "Standard output:" << strdata;
    ui->textEditTermoutput->append(strdata);

    if(strdata.left(4) == "dump")
    {
        ui->statusBar->showMessage(trUtf8("Working: Extracting ")+ strdata.right(9));       
        ui->progressBar->setValue(strdata.right(9).remove(0,2).remove(4,100).toFloat());
    }

}

void MainWindow::readstderr()
{
    ui->textEditTermoutput->setTextColor(Qt::red);
    QByteArray stderrdata = process->readAllStandardError();
    qDebug() << "Standard Error:" <<stderrdata;
    ui->textEditTermoutput->append(stderrdata);

}

void MainWindow::onProcessFinished(int exitCode, QProcess::ExitStatus status)
{
    delete process;
    process = NULL;
    qDebug() << "Exitcode:" << exitCode << "\nExitstatus:" << status;

    if(!exitCode==0)
    {
        ui->checkBoxTermOutput->setChecked(true);
        on_checkBoxTermOutput_clicked();
        ui->statusBar->showMessage(trUtf8("An error occurred"),5000);

    }
    else
    {   ui->progressBar->setValue(100);
        ui->statusBar->showMessage(trUtf8("Done - See terminaloutput for details"),5000);
    }

    //disables the stop extract pushbutton
    ui->pushButtonForcestop->hide();
    ui->pushButtonExtractAudio->show();
    ui->lineEditInputfilename->setEnabled(1);
    ui->lineEditOuputfilename->setEnabled(1);
    ui->comboBoxoutputformat->setEnabled(1);
    ui->pushButtonInputbrowse->setEnabled(1);
    ui->pushButtonOutputbrowse->setEnabled(1);
}

void MainWindow::on_pushButtonExtractAudio_clicked()
{
    startExtract();
}

void MainWindow::on_pushButtonInputbrowse_clicked()
{
    QString prefileName = ui->lineEditInputfilename->text();

    QString fileName = QFileDialog::getOpenFileName(this, tr("Open"),
                               homepath,
                               tr("Movies (*.3g2 *.3gp *.asf *.asx *.flv *.mov *.mp4 *.mpg *.rm  *.swf *.vob *.wmv *.mkv *.avi *.mpeq *.ogg)"));


    if(fileName.size()>3){
        ui->lineEditInputfilename->setText(fileName);
    }
    else{
        ui->lineEditInputfilename->setText(prefileName);
    }

    QFileInfo fi(fileName);
    qDebug() << fi.baseName();
    qDebug() << fi.dir();
    QString outputfilepath = fi.path();
    QString outputfilename = fi.baseName();

    if(fileName.size()>3){
        ui->lineEditOuputfilename->setText(outputfilepath + "/" + outputfilename + ".mp3");
    }
    else{
        ui->lineEditOuputfilename->setText(prefileName);
    }


    //runs the formatcheck
    on_comboBoxoutputformat_currentIndexChanged(ui->comboBoxoutputformat->currentIndex());

}

void MainWindow::on_pushButtonOutputbrowse_clicked()
{
    QString prefileName = ui->lineEditOuputfilename->text();

    QString fileName = QFileDialog::getSaveFileName(this, tr("Save"),
                               prefileName,
                               "Soundfiles (*.mp3 *.ogg *.wav *.wma *.flac *.aac)");
    if(fileName.size()>3){
        ui->lineEditOuputfilename->setText(fileName);
    }
    else{
        ui->lineEditOuputfilename->setText(prefileName);
    }

    //runs the formatcheck
    on_comboBoxoutputformat_currentIndexChanged(ui->comboBoxoutputformat->currentIndex());
}

void MainWindow::startExtract()
{
    QString inputFilename =  ui->lineEditInputfilename->text();
    QString outputFilename = ui->lineEditOuputfilename->text();

    if(!inputFilename.size() > 0)
    {
        qDebug() << "No inputfile selected!";
        ui->statusBar->showMessage(trUtf8("You need to choose a movie from which the sound should be extracted"));
    }
    else if(!outputFilename.size()>0)
    {
        qDebug() << "No output selected!";
        ui->statusBar->showMessage(trUtf8("You need to choose where the extracted sound should be saved"));
    }
    else
    {

        //enables the stop extract pushbutton
        ui->pushButtonForcestop->show();
        ui->pushButtonExtractAudio->hide();
        ui->lineEditInputfilename->setEnabled(0);
        ui->lineEditOuputfilename->setEnabled(0);
        ui->comboBoxoutputformat->setEnabled(0);
        ui->pushButtonInputbrowse->setEnabled(0);
        ui->pushButtonOutputbrowse->setEnabled(0);

        QStringList args;
        args << "-dumpaudio";
        args << inputFilename;
        args << "-dumpfile";
        args << outputFilename;

        runcmd("mplayer",args);
        qDebug() << "Extracting audio";
        ui->statusBar->showMessage(trUtf8("Working: Starting up"));
    }


}

void MainWindow::on_pushButtonQuit_clicked()
{
    QApplication::quit();
}



void MainWindow::on_checkBoxTermOutput_clicked()
{
    if(ui->checkBoxTermOutput->isChecked())
    {
        ui->dockWidget->show();
        ui->textEditTermoutput->show();
    }
    else
    {
        ui->dockWidget->hide();
        ui->textEditTermoutput->hide();
    }
}

void MainWindow::on_actionFAudioExtractor_triggered()
{
    AboutDialogwindow = new AboutDialog;
    AboutDialogwindow->exec();
}

void MainWindow::on_actionQt_triggered()
{
    QApplication::aboutQt();
}




void MainWindow::on_comboBoxoutputformat_currentIndexChanged(int index)
{
    if(ui->lineEditOuputfilename->text().size()>3)
    {

        QString filename = ui->lineEditOuputfilename->text();

        int formattypeIndex = ui->comboBoxoutputformat->currentIndex();
        QString formattype = ui->comboBoxoutputformat->itemData(formattypeIndex).toString();

        //Gets the basename and path
        QFileInfo FileInfo = filename;
        filename = FileInfo.path() + "/" + FileInfo.baseName();

        //Creates new name and sends to GUI
        filename = filename + "." + formattype;
        ui->lineEditOuputfilename->setText(filename);

    }


}

void MainWindow::on_pushButtonForcestop_clicked()
{
    QMessageBox msgBox;    msgBox.setText(trUtf8("Force stop - sure?"));
    msgBox.setInformativeText(trUtf8("The process can NOT be resumed. The audio that have been extracted might not work."));
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::Save);
    int ret = msgBox.exec();



    switch (ret)  {
      case QMessageBox::Yes:
            process->kill();
            process->terminate();
          break;
      case QMessageBox::No:
          break;
    }

}
