<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs_CZ">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="24"/>
        <source>About FAudioExtractor</source>
        <translation>O FAudioExtractor</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="33"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Created by:&lt;/span&gt; Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licence: &lt;/span&gt;GPLv2&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Extra: &lt;/span&gt;MPlayer is used for extracting the audio. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.mplayerhq.hu/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.mplayerhq.hu/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Created by:&lt;/span&gt; Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licence: &lt;/span&gt;GPLv2&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Extra: &lt;/span&gt;MPlayer is used for extracting the audio. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.mplayerhq.hu/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.mplayerhq.hu/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; text-decoration: underline; color:#0057ae;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Vytvořeno:&lt;/span&gt; Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licence: &lt;/span&gt;GPLv2&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Navíc: &lt;/span&gt;MPlayer se používá na vytahování zvuku. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.mplayerhq.hu/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.mplayerhq.hu/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="49"/>
        <source>Translations</source>
        <translation>Překlady</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="55"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Czech &lt;/span&gt;- Pavel &amp;quot;fri&amp;quot; Fric&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Danish &lt;/span&gt;- Ole Holm &amp;quot;Froksen&amp;quot; Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;German &lt;/span&gt;- Schiwi &amp;quot;Schiwi&amp;quot; Schiwi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Čeština &lt;/span&gt;- Pavel &amp;quot;fri&amp;quot; Fric&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Dánština &lt;/span&gt;- Ole Holm &amp;quot;Froksen&amp;quot; Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Němčina &lt;/span&gt;- Schiwi &amp;quot;Schiwi&amp;quot; Schiwi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="72"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <location filename="mainwindow.ui" line="192"/>
        <source>FAudioExtractor</source>
        <translation>FAudioExtractor</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="32"/>
        <source>Choose from which movie the sound should be extracted</source>
        <translation>Vyberte, ze kterého filmu se má zvuk vytáhnout</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="46"/>
        <location filename="mainwindow.ui" line="77"/>
        <source>Browse</source>
        <translation>Procházet</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="63"/>
        <source>Choose where the extracted sound should be saved</source>
        <translation>Vyberte, kde se má vytažený zvuk uložit</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="92"/>
        <source>Choose audio output format</source>
        <translation>Vybrat výstupní formát zvuku</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="115"/>
        <source>Show terminal output</source>
        <translation>Ukázat výstup terminálu</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="124"/>
        <source>Extract sound</source>
        <translation>Vytáhnout zvuk</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>Quit Program</source>
        <translation>Ukončit program</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="138"/>
        <source>Force stop</source>
        <translation>Vynutit zastavení</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="157"/>
        <source>About</source>
        <translation>O</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="187"/>
        <source>Qt</source>
        <translation>Qt</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="63"/>
        <source>Working: Extracting </source>
        <translation>Pracuje se: Vytahuje se</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="87"/>
        <source>An error occurred</source>
        <translation>Vyskytla se chyba</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="92"/>
        <source>Done - See terminaloutput for details</source>
        <translation>Hotovo - Na podrobnosti se podívejte ve výstupu terminálu</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="122"/>
        <source>Open</source>
        <translation>Otevřít</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="124"/>
        <source>Movies (*.3g2 *.3gp *.asf *.asx *.flv *.mov *.mp4 *.mpg *.rm  *.swf *.vob *.wmv *.mkv *.avi *.mpeq *.ogg)</source>
        <translation>Filmy (*.3g2 *.3gp *.asf *.asx *.flv *.mov *.mp4 *.mpg *.rm  *.swf *.vob *.wmv *.mkv *.avi *.mpeq *.ogg)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="151"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="174"/>
        <source>You need to choose a movie from which the sound should be extracted</source>
        <translation>Musíte vybrat film, ze kterého se má zvuk vytáhnout</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="179"/>
        <source>You need to choose where the extracted sound should be saved</source>
        <translation>Musíte vybrat místo, kam se má vytažený zvuk uložit</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="191"/>
        <source>Working: Starting up</source>
        <translation>Pracuje se: Spouští se</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="265"/>
        <source>Force stop - sure?</source>
        <translation>Opravdu vynutit zastavení?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="266"/>
        <source>The process can NOT be resumed. The audio that have been extracted might not work.</source>
        <translation>Proces nelze obnovit. Vytažený zvuk nemusí jet.</translation>
    </message>
    <message>
        <source>Working: Extracting audio</source>
        <translation type="obsolete">Pracuje se: Vytahuje se zvuk</translation>
    </message>
</context>
</TS>
