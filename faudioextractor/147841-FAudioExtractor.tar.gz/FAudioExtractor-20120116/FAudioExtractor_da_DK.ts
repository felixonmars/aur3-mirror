<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="da_DK">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="24"/>
        <source>About FAudioExtractor</source>
        <translation>Om FAudioExtractor</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="33"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Created by:&lt;/span&gt; Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licence: &lt;/span&gt;GPLv2&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Extra: &lt;/span&gt;MPlayer is used for extracting the audio. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.mplayerhq.hu/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.mplayerhq.hu/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Created by:&lt;/span&gt; Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licence: &lt;/span&gt;GPLv2&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Extra: &lt;/span&gt;MPlayer is used for extracting the audio. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.mplayerhq.hu/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.mplayerhq.hu/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; text-decoration: underline; color:#0057ae;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lavet af:&lt;/span&gt; Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licens: &lt;/span&gt;GPLv2&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ekstra: &lt;/span&gt;MPlayer bliver brugt til at udtrække lyden. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.mplayerhq.hu/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.mplayerhq.hu/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="49"/>
        <source>Translations</source>
        <translation>Oversættelser</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="55"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Czech &lt;/span&gt;- Pavel &amp;quot;fri&amp;quot; Fric&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Danish &lt;/span&gt;- Ole Holm &amp;quot;Froksen&amp;quot; Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;German &lt;/span&gt;- Schiwi &amp;quot;Schiwi&amp;quot; Schiwi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="72"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <location filename="mainwindow.ui" line="192"/>
        <source>FAudioExtractor</source>
        <translation>FAudioExtractor</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="32"/>
        <source>Choose from which movie the sound should be extracted</source>
        <translation>Vælg hvilken film lyden skal udtrækkes fra</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="46"/>
        <location filename="mainwindow.ui" line="77"/>
        <source>Browse</source>
        <translation>Gennemse</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="63"/>
        <source>Choose where the extracted sound should be saved</source>
        <translation>Vælg hvor den udtrækkede lyd skal gemmes</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="92"/>
        <source>Choose audio output format</source>
        <translation>Vælg lyd format</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="115"/>
        <source>Show terminal output</source>
        <translation>Vis terminal output</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="124"/>
        <source>Extract sound</source>
        <translation>Udtræk lyden</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>Quit Program</source>
        <translation>Afslut program</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="138"/>
        <source>Force stop</source>
        <translation>Gennemtving stop</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="157"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="187"/>
        <source>Qt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="63"/>
        <source>Working: Extracting </source>
        <translation>Arbejder: Udtrækker </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="87"/>
        <source>An error occurred</source>
        <translation>Der skete en fejl</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="92"/>
        <source>Done - See terminaloutput for details</source>
        <translation>Færdig - Se terminal output for detaljer</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="122"/>
        <source>Open</source>
        <translation>Åben</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="124"/>
        <source>Movies (*.3g2 *.3gp *.asf *.asx *.flv *.mov *.mp4 *.mpg *.rm  *.swf *.vob *.wmv *.mkv *.avi *.mpeq *.ogg)</source>
        <translation>Film (*.3g2 *.3gp *.asf *.asx *.flv *.mov *.mp4 *.mpg *.rm  *.swf *.vob *.wmv *.mkv *.avi *.mpeq *.ogg)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="151"/>
        <source>Save</source>
        <translation>Gem</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="174"/>
        <source>You need to choose a movie from which the sound should be extracted</source>
        <translation>Du mangler at vælge en film hvor lyden skal udtrækkes fra</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="179"/>
        <source>You need to choose where the extracted sound should be saved</source>
        <translation>Du mangler at vælge hvor den udtrækkede lyd skal gemmes</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="191"/>
        <source>Working: Starting up</source>
        <translation>Arbejder: Starter op</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="265"/>
        <source>Force stop - sure?</source>
        <translation>Gennemtving stop - sikker?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="266"/>
        <source>The process can NOT be resumed. The audio that have been extracted might not work.</source>
        <translation>Processen kan IKKE blive genoptaget. Det lyd som allerede er udtrækket, virker måske ikke.</translation>
    </message>
    <message>
        <source>Working: Extracting audio</source>
        <translation type="obsolete">Arbejder: Udtrækker lyden</translation>
    </message>
</context>
</TS>
