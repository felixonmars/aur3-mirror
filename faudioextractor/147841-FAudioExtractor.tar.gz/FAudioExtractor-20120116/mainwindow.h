#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtGui>
#include <QtCore>
#include <QDir>
#include <aboutdialog.h>

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:

    //Slots for the QProcess
    void readstdoutput();
    void readstderr();
    void onProcessFinished(int exitCode, QProcess::ExitStatus status);

    void on_pushButtonExtractAudio_clicked();

    void on_pushButtonInputbrowse_clicked();

    void on_pushButtonOutputbrowse_clicked();

    void on_pushButtonQuit_clicked();


    void on_checkBoxTermOutput_clicked();

    void on_actionFAudioExtractor_triggered();

    void on_actionQt_triggered();

    void on_comboBoxoutputformat_currentIndexChanged(int index);

    void on_pushButtonForcestop_clicked();

private:
    Ui::MainWindow *ui;

    void runcmd(QString(cmd),QStringList(args));
    void startExtract();

    //FormatLists and desc
    QStringList OutFormatList;
    QStringList OutFormatDescList;

    //QProcess
    QProcess *process;

    //Variables
    QString homepath;

    //Windows
    AboutDialog *AboutDialogwindow;

};

#endif // MAINWINDOW_H
