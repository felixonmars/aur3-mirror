<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="24"/>
        <source>About FAudioExtractor</source>
        <translation>Über FAudioExtractor</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="49"/>
        <source>Translations</source>
        <translation>Übersetzung</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="55"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Czech &lt;/span&gt;- Pavel &amp;quot;fri&amp;quot; Fric&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Danish &lt;/span&gt;- Ole Holm &amp;quot;Froksen&amp;quot; Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;German &lt;/span&gt;- Schiwi &amp;quot;Schiwi&amp;quot; Schiwi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="72"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="aboutdialog.ui" line="33"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Created by:&lt;/span&gt; Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licence: &lt;/span&gt;GPLv2&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Extra: &lt;/span&gt;MPlayer is used for extracting the audio. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.mplayerhq.hu/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.mplayerhq.hu/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lavet af:&lt;/span&gt; Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licens: &lt;/span&gt;GPLv2&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;mplayer bruges til at selve selve udtrækningen af lyden.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Erstellt von:&lt;/span&gt; Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lizenz: &lt;/span&gt;GPLv2&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Extra: &lt;/span&gt;MPlayer wird für  das extrahieren der Audiospur verwendet. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.mplayerhq.hu/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.mplayerhq.hu/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <location filename="mainwindow.ui" line="192"/>
        <source>FAudioExtractor</source>
        <translation>FAudioExtractor</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="32"/>
        <source>Choose from which movie the sound should be extracted</source>
        <translation>Wähle ein Video</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="46"/>
        <location filename="mainwindow.ui" line="77"/>
        <source>Browse</source>
        <translation>Auswählen</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="63"/>
        <source>Choose where the extracted sound should be saved</source>
        <translation>Speichere Audiodatei in</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="92"/>
        <source>Choose audio output format</source>
        <translation>Wähle das Dateiformat für die Audioausgabe</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="115"/>
        <source>Show terminal output</source>
        <translation>Zeige Terminalausgabe</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="124"/>
        <source>Extract sound</source>
        <translation>Extrahiere Audio</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>Quit Program</source>
        <translation>Beenden</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="138"/>
        <source>Force stop</source>
        <translation>Anhalten erzwingen</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="157"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="187"/>
        <source>Qt</source>
        <translation>Qt</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="63"/>
        <source>Working: Extracting </source>
        <translation>Vorgang: Extrahiere</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="87"/>
        <source>An error occurred</source>
        <translation>Ein Fehler ist aufgetreten</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="92"/>
        <source>Done - See terminaloutput for details</source>
        <translation>Fertig - Siehe Terminalausgabe für Details</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="122"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="124"/>
        <source>Movies (*.3g2 *.3gp *.asf *.asx *.flv *.mov *.mp4 *.mpg *.rm  *.swf *.vob *.wmv *.mkv *.avi *.mpeq *.ogg)</source>
        <translation>Video (*.3g2 *.3gp *.asf *.asx *.flv *.mov *.mp4 *.mpg *.rm  *.swf *.vob *.wmv *.mkv *.avi *.mpeq *.ogg)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="151"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="174"/>
        <source>You need to choose a movie from which the sound should be extracted</source>
        <translation>Bitte wählen Sie ein Video aus</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="179"/>
        <source>You need to choose where the extracted sound should be saved</source>
        <translation>Bitte wählen Sie aus wohin die Audiodatei gespeichert werden soll</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="191"/>
        <source>Working: Starting up</source>
        <translation>Vorgang: Starte</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="265"/>
        <source>Force stop - sure?</source>
        <translation>Anhalten erzwingen - Sicher?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="266"/>
        <source>The process can NOT be resumed. The audio that have been extracted might not work.</source>
        <translation>Der Vorgang kann nicht fortgesetzt werden. Die Audiodatei funktioniert möglicherweise nicht.</translation>
    </message>
    <message>
        <source>Working: Extracting audio</source>
        <translation type="obsolete">Vorgang: Extrahiere Audio</translation>
    </message>
</context>
</TS>
