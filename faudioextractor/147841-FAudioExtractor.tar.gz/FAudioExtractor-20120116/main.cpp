#include <QtGui/QApplication>
#include "mainwindow.h"
#include <QDebug>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QString locale = QLocale::system().name();

    qDebug() << "Locale:" << locale;

    QTranslator translator;
    translator.load(":/translations/FAudioExtractor_"+locale);
    a.installTranslator(&translator);

    MainWindow w;
    w.show();

    return a.exec();
}
