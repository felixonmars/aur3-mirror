
#ifndef GLOBAL_H
#define GLOBAL_H

typedef union
{
	u_int32_t   ulValue;
	u_int8_t    btValue[4];
}ULONG_BYTEARRAY;

#endif
