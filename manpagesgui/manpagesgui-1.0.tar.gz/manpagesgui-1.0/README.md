Translation
-----------
If you want to translate manpagesgui and so fit your language you can send a message to elmoribond@gmail.com.

The translation file contains 36 words or clauses.

Currently the following languages are available:
- English
- French
