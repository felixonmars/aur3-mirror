#ifndef FORCEFEEDBACK_H
#define FORCEFEEDBACK_H

#include <sys/types.h>
#include "../include/jsw.h"


extern void *JSFFNew(void);
extern void JSFFDelete(void *ptr);


#endif	/* FORCEFEEDBACK_H */
