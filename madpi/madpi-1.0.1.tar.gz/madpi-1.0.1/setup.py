#!/usr/bin/env python
#-*- coding: utf-8 -*-

from distutils.core import setup
from glob import glob
from distutils.command.build import build
from distutils.core import Command
from distutils.util import *
from distutils.spawn import spawn, find_executable
from distutils.dep_util import newer


import os
import os.path

class build_db2man(Command):
  description = 'Generate man page from DocBook File'
  
  user_options = [('output=', 'O', 'output file'), 
                  ('stylesheet=', 'S', 'stylesheet'),
                  ('docbook=', 'I', 'input file'),
                  ('compress=', 'z', 'compress the man page? (yes,no)')]
  possible_stylesheets = ['/usr/share/xml/docbook/xsl-stylesheets-1.76.0/manpages/docbook.xsl', 
                  '/usr/share/xml/docbook/stylesheet/docbook-xsl-ns/manpages/docbook.xsl'] + glob('/usr/share/xml/docbook/xsl-stylesheets*/manpages/docbook.xsl')
  namespace = 'http://docbook.org/ns/docbook'
  def initialize_options(self):
    self.output = None
    self.stylesheet = ''
    for ss in self.possible_stylesheets:
      if os.path.exists(ss):
        self.stylesheet = ss
        break
    self.docbook = 'manfile.docbook'
    self.compress = 'yes'
    
  def finalize_options(self):
    if self.output == None:
      from xml.etree.ElementTree import ElementTree
      tree = ElementTree()
      tree.parse(self.docbook)
      refmeta = tree.find('{{{0}}}refentry/{{{0}}}refmeta'.format(self.namespace) )
      title = refmeta.find('{{{0}}}refentrytitle'.format(self.namespace) ).text
      section = refmeta.find('{{{0}}}manvolnum'.format(self.namespace) ).text
      self.output = '.'.join( (title, section) )
    self.compress = strtobool( self.compress.lower() )
  def run(self):
    if not newer(self.docbook, self.output):
      return
    #TODO: handle missing stylesheets
    com = ['xsltproc', self.stylesheet, self.docbook]
    spawn(com, dry_run=self.distribution.dry_run)
    #compress the file using gzip if necessary
    com = ['gzip', '-9', self.output]
    spawn(com, dry_run=self.distribution.dry_run)

build.sub_commands.append( ('build_db2man', lambda self: os.name == 'posix' ))

setup(name='madpi', 
    version='1.0.1', 
    platforms=['Linux'], 
    description='A simple interactive program for making funny stories', 
    author='Thayne McCombs', 
    author_email='astrothayne@gmail.com',
    url='https://sourceforge.net/projects/madpi',
    package_dir = {'': 'lib'}, 
    packages=['madpi'], 
    scripts=['madpi'], 
    data_files=[
                ('share/man/man1',  ['madpi.1.gz']), 
                ('share/madpi/doc',  ['HELP',  'README', 'manfile.docbook']), 
                ('share/madpi/stories',  glob('stories/*.mdlib') ),
                ('share/madpi',['madpi.cfg',  'LICENSE' ] ) ],
    cmdclass={'build_db2man': build_db2man}
    )
