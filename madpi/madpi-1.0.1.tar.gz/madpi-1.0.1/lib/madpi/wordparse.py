# -*- coding: utf-8 -*-
''' This module is used to parse the madlib file and extract an oredered array of the word types'''
#
#MadPi is a simple interactive program to make funny stories
#
#MadPi Copyright © 2010 Thayne McCombs
#
#This file is part of MadPi.
#
#    MadPi is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    any later version.
#
#    MadPi is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MadPi.  If not, see <http://www.gnu.org/licenses/>.

import re

class MadParser:
    '''Object that handles interaction with MadLib Files or other text iterator
    it is the users responsibility to open close, and reset files to beginning before each operation'''

    def __init__(self):
        self.exp = re.compile(r'(?<!\\)\*(.*?[^\\]?)\*')
        self.escape = re.compile(r'\\\*')
        self.lines = []
    def parse(self, it):
        '''Parses the iterator for words surrounded by *s and returns them as a list'''
        words = []
        for line in it:
            words += self.exp.findall(line)
            self.lines.append(line)
        return words

    def story(self, words):
        '''Yields the lines of the story one line at a time, replaceing each indicater
    surround by *__* with it's corresponding word chosen by the user'''
        if not isinstance(words, list):
            raise TypeError
        def repl(match):
            repl.i += 1
            return words[repl.i]
        repl.i = -1
        for line in self.lines:
            line = self.exp.sub(repl, line)
            line = self.escape.sub('*', line)
            yield line

    def compile_story(self, words):
        '''returns a string of the story instead of an iterator'''
        return ''.join(self.story(words) )
    
