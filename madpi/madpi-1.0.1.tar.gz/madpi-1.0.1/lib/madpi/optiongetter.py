# -*- coding: utf-8 -*-
'''
Parse command line options and arguments, and read the madlibrc file, or any other configurations we may add later, to figure out
the file to load, or the directories to search.  
'''
#
#MadPi is a simple interactive program to make funny stories
#
#MadPi Copyright © 2010 Thayne McCombs
#
#This file is part of MadPi.
#
#    MadPi is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    any later version.
#
#    MadPi is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MadPi.  If not, see <http://www.gnu.org/licenses/>.

from optparse import OptionParser
from .loadconfig import INTERFACE,  PATH
from .constants import WARRANTY,  LICENSE_PATH
import sys

#we should find a better place to define these constants
CLI = 'cli'
usage = '%prog [options]'
version = '%prog 1.0'
description= '''
A simple interactive program to make a silly story by replacing words in an original story with words input by the user.  Based on the popular MadLib game
'''
parser = OptionParser(usage=usage,  version=version,  description=description)

parser.add_option('-A',  '--append', '--add',   action='append',  dest='sources',  help='add directory or file to search path',  metavar='FILE')
parser.add_option('-f',  '--file',  action='store',  dest='load_file',  help='load a specific file (anything in the search path is ignored)',  metavar='FILE',  default=None)
parser.add_option('-P',  '--path', action='store',   dest='new_path',  help='set the search path to the given directories and files (ignoring the default).  Delimit items with colons, and only use spaces within quotes',  metavar='PATH',  default=None)
parser.add_option('--warranty',  action='store_true',  dest='show_warranty', default=False,   help='display the warranty for this program')
parser.add_option('--license',  action='store_true',  dest='show_license',  default=False,  help='display the license information for this program')
#TODO: Once we have other frontends we need to add command-line options to set which interface to use


def parseOptions(args=sys.argv[1:]):
    (options,  arguments) = parser.parse_args(args)
    if options.show_warranty:
        print(WARRANTY)
        sys.exit()
    if options.show_license:
        with open(LICENSE_PATH) as f:
            print(f.read())
            sys.exit()
    if options.load_file != None:
        sources = [options.load_file]
    elif options.new_path != None:
        sources = options.new_path.split(':')
    elif options.sources != None:
        sources =PATH.extend(options.sources)
    else:
        sources = PATH
    #TODO: figure out what to do with the rest of the arguments
    #TODO: add in code for determining the proper interface
    return (sources,  INTERFACE)


