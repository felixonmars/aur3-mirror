# -*- coding: utf-8 -*-
#constants and classes needed by other MadLib modules

#
#MadPi is a simple interactive program to make funny stories
#
#MadPi Copyright © 2010 Thayne McCombs
#
#This file is part of MadPi.
#
#    MadPi is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    any later version.
#
#    MadPi is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MadPi.  If not, see <http://www.gnu.org/licenses/>.
import os.path
import platform

CLI = 'cli'
WX = 'wx'
GTK = 'gtk'
KDE = 'kde'

if platform.system() == 'Linux':
    LIB_PATH = '/usr/lib/'
    STORY_PATH = os.path.join(LIB_PATH,  'stories')
else:
    LIB_PATH = None
    STORY_ATH = None

default_interface = CLI
default_path = [os.path.expanduser('~/.madlib/stories'),  STORY_PATH]

LICENSE_MESSAGE = '''
MadPi  Copyright (C) 2010  Thayne McCombs

    This program comes with ABSOLUTELY NO WARRANTY; for details use option `--warranty'.
    This is free software, and you are welcome to redistribute it
    under certain conditions; use option `--license' for details.
'''

WARRANTY = '''
THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY
APPLICABLE LAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT
HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY
OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE.  THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM
IS WITH YOU.  SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF
ALL NECESSARY SERVICING, REPAIR OR CORRECTION.
'''
LICENSE_PATH = '/usr/share/madpi/LICENSE'   #this is kind of hacky, we should figure out a better way to do this

EXTENSIONS = ['.madlib','.mdlib','.mdlb','.mdl','.madpi', '.mdpy', '.mdp']

class NoFileError(IOError):
    pass
