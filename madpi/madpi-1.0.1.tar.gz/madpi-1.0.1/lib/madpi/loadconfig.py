# -*- coding: utf-8 -*-
'''
This module will find and read run config files.  
 At the moment support INI-type files (that is madpi.cfg )
 
I will possibly later add support for config files written in python, or a bash-like script
although I think that might be overkill for such a simple program
(but a good exercise in figuring out how to do such things)

INI Config file definition
[madpi]
interface : < inteface type, supported are CLI, >
path : <path to madlib files, directories and files can be seperated by semi-colons >
'''
#
#MadPi is a simple interactive program to make funny stories
#
#MadPi Copyright © 2010 Thayne McCombs
#
#This file is part of MadPi.
#
#    MadPi is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    any later version.
#
#    MadPi is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MadPi.  If not, see <http://www.gnu.org/licenses/>.
__all__ = ['INTERFACE',  'PATH']


import os
from os import path
from io import StringIO

#This is ugly, but needed in order for this to work on both python 2 and 3
#perhaps we should later make a separate compatibility module, but for now we'll keep these
import sys
if sys.version_info[0] < 3:
    from ConfigParser import ConfigParser
else:
    from configparser import ConfigParser

from .constants import default_interface,  default_path

DEFAULTS = '''
[madpi]
path: {0}
interface: {1}'''.format(default_path,  default_interface)

parser = ConfigParser()
parser.readfp(StringIO(DEFAULTS))
parser.read(['/usr/share/madlib/madpi.cfg',  os.path.join(os.getcwd(), 'madpi.cfg'), os.path.expanduser('~/.madpi/madpi.cfg')])

INTERFACE = parser.get('madpi', 'interface').lower()
PATH = parser.get('madpi', 'path').split(';')


