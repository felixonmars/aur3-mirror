# -*- coding: utf-8 -*-
#
#MadPi is a simple interactive program to make funny stories
#
#MadPi Copyright © 2010 Thayne McCombs
#
#This file is part of MadPi.
#
#    MadPi is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    any later version.
#
#    MadPi is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with MadPi.  If not, see <http://www.gnu.org/licenses/>.
import random
import os
import sys
from .constants import NoFileError
from os import path


def chooseFile(source, exts):
    '''randomly chooses a file from source with a an extension from exts'''
    
    files = searchDirs(source, exts)
    if len(files) == 0:
        raise NoFileError('could not find any valid files')
    name = random.choice(files)
    #    if name == '-':
    #        return sys.stdin
    #    else:
    #        return open(name,  'r')
    return name

def chooseAndOpenFile(source, exts):
  ''' randomly choose a file from souce with an extension from exts, and return an open file object '''
  return open( chooseFile(source, exts), 'r' )


def searchDirs(source, exts):
    '''
Returns a list of all MadLib files within each directory in source
the special file '-' will be treated as a file
'''
    files = []
    
    #debug
    #print source
    #/debug
    
    for f in source:
        if ( path.isfile(f) and path.splitext(f)[1] in exts ) :
            files.append(f)
        elif path.isdir(f):
            files += searchDirs([path.join(f, sf) for sf in os.listdir(f)], exts)
        #else:
            #print('Warning: {0} not found'.format(f),  file=sys.stderr)

    #for d in source:    #look through every directory or file
        #for f in os.listdir(d):     #look at every file in each directory
            #f = path.join(d, f)
            ##insure it is a MadLib file
            #if path.isfile(f) and path.splitext(f)[1] in exts:
                ## possibly add other possible extensions
                #files += [f]
            #elif rec == True and path.isdir(f):
                #files +=  searchDirs([f])
    return files
