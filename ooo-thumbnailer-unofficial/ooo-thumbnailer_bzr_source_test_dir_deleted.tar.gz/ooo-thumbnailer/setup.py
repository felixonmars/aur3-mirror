#!/usr/bin/env python2.6
# 2009-2010 David D Lowe
# To the extent possible under law, David D. Lowe has waived all copyright and related or neighboring rights to this file.
# License: http://creativecommons.org/publicdomain/zero/1.0/

from distutils.core import setup
import distutils.command.install_data
import subprocess
import sys

def main():
        
    setup( name="ooo-thumbnailer",
    version="0.4.1",
    description="Thumbnailer for OpenOffice.org and Microsoft Office documents, spreadsheets, presentations and drawings.", # short
    author="David D Lowe",
    author_email="daviddlowe.flimm@gmail.com",
    url="", # home page for end-users
    license="GPL v3",
    data_files=[('/usr/share/gconf/schemas', ['ooo-thumbnailer.schemas', 'gsf-office-thumbnailer.schemas'])],
    scripts=["ooo-thumbnailer", "ooo-thumbnailer-config"],
    classifiers=["Development Status :: 5 - Production/Stable", "License :: OSI Approved :: GNU General Public License (GPL)", "Operating System :: POSIX :: Linux"],
        # a bunch of optional tags, a list of classifiers can be found at http://pypi.python.org/pypi?:action=list_classifiers
    long_description="""ooo-thumbnailer is an OpenOffice.org and Microsoft Office document thumbnailer that can be used by file
managers to create thumbnails for your documents, spreadsheets, presentations and drawings.""",
    cmdclass={"install_data":install_data})
	
class install_data(distutils.command.install_data.install_data):
    def run(self):
        distutils.command.install_data.install_data.run(self)
        def register_gconf_schemas():
            try:
                subprocess.call(["gconf-schemas", "--register",
                    "/usr/share/gconf/schemas/gsf-office-thumbnailer.schemas",
                    "/usr/share/gconf/schemas/ooo-thumbnailer.schemas"])
            except Exception, ee:
                sys.stderr.write("Could not call gconf-schemas: %s\n" % str(ee))
        self.execute(register_gconf_schemas, [])

if __name__ == "__main__":
    main()
