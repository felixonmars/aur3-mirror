#########################################
	DIALOGRC Custom Themes
#########################################

In this tarball you'll find four custom dialogrc "themes".
- dialogrc-default [The default color scheme]
- dialogrc-suse	[A "green" theme]
- dialogrc-elegant	[My preferred one]
- dialogrc-black_white	[An only-black-and-white theme]

If you want to use a custom theme, simply extract the one you want to use in your HOME and rename as ".dialogrc".

Enjoy
