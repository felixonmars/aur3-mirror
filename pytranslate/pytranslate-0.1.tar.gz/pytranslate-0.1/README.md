pytranslate
====

Translate one or many word(s) with google translate.

Depend
======

python3, requests, beautifulsoup4

Installation
============

```
git clone https://github.com/Chipsterjulien/pytranslate.git
python setup.py install
```

Usage
=====

```
python pytranslate -h
```
