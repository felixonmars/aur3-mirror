// Define a data type Tree.

domain Tree {
   node(int val, Tree left, Tree right)
   empty()
}
