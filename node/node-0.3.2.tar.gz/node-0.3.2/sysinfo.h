extern int loadavg(double *av1, double *av5, double *av15);
extern int uptime (double *uptime_secs, double *idle_secs);
extern int load_meminfo(void);
extern int meminfo(const char *s);
