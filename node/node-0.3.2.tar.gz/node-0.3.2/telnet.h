/* Telnet command characters */
#define	TN_SE		240	/* End of subnegotiation parameters 	*/
#define	TN_NOP		241	/* No operation 			*/
#define	TN_DM		242	/* Data Mark 				*/
#define	TN_BRK		243	/* NVT character BRK 			*/
#define	TN_IP		244	/* Interrupt Process 			*/
#define	TN_AO		245	/* Abort output 			*/
#define	TN_AYT		246	/* Are You There 			*/
#define	TN_EC		247	/* Erase character 			*/
#define	TN_EL		248	/* Erase Line 				*/
#define	TN_GA		249	/* Go ahead 				*/
#define	TN_SB		250	/* Start of of subnegotiation params	*/
#define	TN_WILL		251
#define	TN_WONT		252
#define	TN_DO		253
#define	TN_DONT		254
#define	TN_IAC		255	/* Interpret as command 		*/

/* Linemode extensions to telnet command characters */
#define	TN_EOF		236	/* End Of File 				*/
#define	TN_SUSP		237	/* Suspend 				*/
#define	TN_ABORT	238	/* Abort 				*/

/* Telnet options */
#define TN_TRANS_BINARY	0	/* Binary Transmission 			*/
#define TN_ECHO		1	/* Echo 				*/
#define TN_SUPPRESS_GA	3	/* Suppress Go Ahead 			*/
#define TN_STATUS	5	/* Status 				*/
#define TN_TIMING_MARK	6	/* Timing Mark 				*/
#define TN_LINEMODE	34	/* Linemode 				*/

/* Linemode options */
#define TN_LINEMODE_MODE	1
#define TN_LINEMODE_MODE_EDIT		1	/* Local edit 		*/
#define TN_LINEMODE_MODE_TRAPSIG	2	/* Trap signals 	*/
#define TN_LINEMODE_MODE_MODEACK	4	/* Acknowledge mode 	*/
#define TN_LINEMODE_MODE_SOFTTAB	8	/* Soft Tab 		*/
#define TN_LINEMODE_MODE_LITECHO	16	/* Literal Echo 	*/
#define	TN_LINEMODE_FORWARDMASK	2
#define TN_LINEMODE_SLC		3
