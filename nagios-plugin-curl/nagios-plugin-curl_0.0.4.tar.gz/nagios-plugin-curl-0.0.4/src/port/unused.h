#ifndef __UNUSED_H
#define __UNUSED_H

#include "port/sys.h"

#define UNUSED( x ) if( 0 && (x) ) { }

#endif /* ifndef __UNUSED_H */
