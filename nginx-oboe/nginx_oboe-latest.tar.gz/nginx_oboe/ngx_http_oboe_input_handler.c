/* 
 * Copyright (C) 2012 by Tracelytics, Inc.
 * All rights reserved.
 *
 * Use and distribution of this software is subject to the terms and
 * limitations contained in the file LICENSE, which is provided with
 * this software distribution.
 */
#include "ngx_http_oboe_filter_module.h"
#include <assert.h>

/* ngx_min doesn't exist on all nginx versions */
#define TLY_MIN(a,b) (((a) < (b)) ? (a) : (b))

extern struct plugin_data_t plugin_data;

/* helper function for request callback: sends request report */
static int ngx_http_oboe_handler_report_request(ngx_http_request_t *r,
                                                handler_ctx *hctx,
                                                ngx_table_elt_t *in_xtrace,
                                                ngx_table_elt_t *avw,
                                                ngx_int_t sampling_rate,
                                                ngx_int_t sample_source,
                                                ngx_str_t application) {
    oboe_event_t xte;
    int retval = -2; // -2 is a dummy value for assert below
    int result;

    result = oboe_event_init(&xte, &hctx->md);
    if (result < 0) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] event initalization failed");
        retval = -1;
        goto end;
    }

    // add edge from previous X-Trace ID to this one
    if (in_xtrace){
        (void)oboe_event_add_edge(&xte, &hctx->md);
    }

    // add X-TV-Meta information
    if (avw){
        (void)oboe_event_add_info_binary(&xte, "X-TV-Meta",
                                         (const char *)avw->value.data,
                                         avw->value.len);
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] x-tv-meta added to trace");
    }

    (void)oboe_event_add_info(&xte, "Layer", NGX_OBOE_MODULE_LAYER_NAME);
    (void)oboe_event_add_info(&xte, "Label", "entry");
    (void)oboe_event_add_info_int64(&xte, "SampleRate", sampling_rate);
    (void)oboe_event_add_info_int64(&xte, "SampleSource", sample_source);
    if (application.data != NULL) {
        (void)oboe_event_add_info_binary(&xte, "App",
                                         (const char *)application.data,
                                         application.len);
    }

    assert(plugin_data.reporter.send);

    result = oboe_reporter_send(&plugin_data.reporter, &hctx->md, &xte);
    if (result < 0) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] reporter send failed");
        retval = -1;
        goto free_event;
    }
    retval = 0;

free_event:
    (void)oboe_event_destroy(&xte);
end:
    assert(retval == 0 || retval == -1);
    return retval;
}

/* request callback, invoked upon incoming request read
   internal redirects and rewrites are handled basically
   the same way internally */
ngx_int_t ngx_http_oboe_handler(ngx_http_request_t *r) {
    plugin_config *conf;
    handler_ctx *hctx;
    int result = -1;
    int sample_rate, sample_source;
    ngx_table_elt_t *xtrace_header = NULL;
    ngx_table_elt_t *avw_header = NULL;
    char * xtrace = NULL;
    char *avw = NULL;
    oboe_metadata_t in_md;
    oboe_version_func version_func = NULL;

    /**
     * Check if we have a good enough liboboe
     */
    version_func = (oboe_version_func)dlsym(RTLD_DEFAULT, "oboe_config_check_version");

    /**
     * No version func? liboboe is too old, error and bail
     * Version too old? liboboe is too old, error and bail
     *
     * Current API version necessary is 1.1.0
     */
    if((version_func == NULL) || version_func(1, 1) < 1) {
        ngx_log_error(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] A newer version of liboboe is required, please upgrade to version 1.1.0 or higher.  Tracing is now disabled.");
        goto end;
    }

    conf = ngx_http_get_module_loc_conf(r, ngx_http_oboe_filter_module);
    assert(conf);

    // return immediately if handler has been invoked on this request (e.g. rewrite rule)
    if (ngx_http_oboe_get_ctx(r) != NULL) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] handler has already been invoked (rewrite or redirect)");
        goto end;
    }

    // make sure our liboboe settings are set up right
    if(conf->config_tracing_mode > NGX_CONF_UNSET) {
        oboe_settings_cfg_tracing_mode_set(conf->config_tracing_mode);
    }
    if(conf->config_sample_rate > NGX_CONF_UNSET) {
        oboe_settings_cfg_sample_rate_set(conf->config_sample_rate);
    }

    // get X-Trace header string and x-tv-meta header info
    xtrace_header = ngx_http_oboe_get_xtrace(&r->headers_in.headers.part);
    avw_header= ngx_http_oboe_get_xtvmeta(&r->headers_in.headers.part);

    // if we have an xtrace, verify it's good
    if(xtrace_header) {
        result = oboe_metadata_fromstr(&in_md, (const char *)xtrace_header->value.data, xtrace_header->value.len);
        if (result < 0) {
            ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] reading metadata from string failed");
            xtrace_header = NULL;
        }
    }

    // grab out our values for sending to layer
    if(xtrace_header && xtrace_header->value.len) {
        xtrace = (char *) xtrace_header->value.data;
    }
    if(avw_header && avw_header->value.len) {
        avw = (char *) avw_header->value.data;
    }

    // 1. see if this request should be traced:
    if(!oboe_sample_layer(NGX_OBOE_MODULE_LAYER_NAME, xtrace, avw, &sample_rate, &sample_source)) {
        goto end;
    }

    // 2. create metadata, store in request struct for abstract edge
    hctx = ngx_http_oboe_set_ctx(r);
    if (hctx == NULL) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] setting context failed");
        goto end;
    }

    // stick our xtrace metadata in or generate a new one
    if (result < 0) {
        result = oboe_metadata_init(&hctx->md);
        if (result < 0) {
            ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] initializing metadata failed");
            goto end;
        }

        oboe_metadata_random(&hctx->md);
    } else {
        hctx->md = in_md;
    }

    // 3. send off a report
    result = ngx_http_oboe_handler_report_request(r,
                                                  hctx,
                                                  xtrace_header,
                                                  avw_header,
                                                  sample_rate,
                                                  sample_source,
                                                  conf->application);

    if (result < 0) {
        // no logging necessary; done in helper function
        goto end;
    } else {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] entry trace successfully sent");
    }


    // 4. store new metadata in upstream header for downward edge 
    result = ngx_http_oboe_handler_set_header(r, r->pool, &r->headers_in.headers,
                                              &hctx->md, xtrace_header);
    if (result < 0) {
        // no logging necessary; done in helper function
       goto end;
    }

end:
    return NGX_DECLINED;
}
