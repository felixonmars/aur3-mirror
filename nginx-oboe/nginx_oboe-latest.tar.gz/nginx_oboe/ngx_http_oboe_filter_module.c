/* 
 * Copyright (C) 2012 by Tracelytics, Inc.
 * All rights reserved.
 *
 * Use and distribution of this software is subject to the terms and
 * limitations contained in the file LICENSE, which is provided with
 * this software distribution.
 */
#include "ngx_http_oboe_filter_module.h"

#include <ngx_config.h>
#include <ngx_core.h>
#include <ngx_http.h>
#include <nginx.h>          /* For NGINX_VER version string. */

#include <assert.h>

/* forward declarations (functions) */
static char *ngx_http_oboe_enable_tracing(ngx_conf_t *, ngx_command_t *,
                                          void *); 
static char *ngx_http_oboe_set_sample_rate(ngx_conf_t *cf, ngx_command_t *cmd,
                                             void *conf);
static ngx_int_t ngx_http_oboe_filter_init(ngx_conf_t *); 
static void *ngx_http_oboe_create_loc_conf(ngx_conf_t *); 
static char *ngx_http_oboe_merge_loc_conf(ngx_conf_t *, void *, void *); 

/* forward declarations (data structures) */
static ngx_command_t ngx_http_oboe_filter_commands[];
static ngx_http_module_t ngx_http_oboe_filter_module_ctx;

/* module-specific information global */
struct plugin_data_t plugin_data;

/* global for the next link in the output filter chain */
ngx_http_output_header_filter_pt ngx_http_next_header_filter;
ngx_http_output_body_filter_pt ngx_http_next_body_filter;

/* primary module declaration */
ngx_module_t ngx_http_oboe_filter_module = {
    NGX_MODULE_V1,
    &ngx_http_oboe_filter_module_ctx,      /* module context */
    ngx_http_oboe_filter_commands,         /* module directives */
    NGX_HTTP_MODULE,                       /* module type */
    NULL,                                  /* init master */
    NULL,                                  /* init module */
    NULL,                                  /* init process */
    NULL,                                  /* init thread */
    NULL,                                  /* exit thread */
    NULL,                                  /* exit process */
    NULL,                                  /* exit master */
    NGX_MODULE_V1_PADDING
};

/* module directives */
static ngx_command_t ngx_http_oboe_filter_commands[] = {
    {
        ngx_string("oboe_tracing_mode"),   /* name */
        NGX_HTTP_MAIN_CONF                 /* type */
            |NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1, 
        ngx_http_oboe_enable_tracing,      /* set */
        NGX_HTTP_LOC_CONF_OFFSET,          /* conf */
        0,                                 /* offset */
        NULL                               /* post */
    },
    {
        ngx_string("oboe_reporter_host"),
        NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1, 
        ngx_conf_set_str_slot,
        NGX_HTTP_LOC_CONF_OFFSET,
        offsetof(plugin_config, reporter_host),
        NULL
    },
    {
        ngx_string("oboe_reporter_port"),
        NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1, 
        ngx_conf_set_num_slot,
        NGX_HTTP_LOC_CONF_OFFSET,
        offsetof(plugin_config, reporter_port),
        NULL
    },
    {
        ngx_string("oboe_sampling_rate"),
        NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1, 
        ngx_http_oboe_set_sample_rate,
        NGX_HTTP_LOC_CONF_OFFSET,
        0,
        NULL
    },
    {
        ngx_string("oboe_application"),
        NGX_HTTP_MAIN_CONF|NGX_HTTP_SRV_CONF|NGX_HTTP_LOC_CONF|NGX_CONF_TAKE1, 
        ngx_conf_set_str_slot,
        NGX_HTTP_LOC_CONF_OFFSET,
        offsetof(plugin_config, application),
        NULL
    },
    ngx_null_command
};

/* module context (structure of primary callbacks) */
static ngx_http_module_t ngx_http_oboe_filter_module_ctx = {
    NULL,                                  /* preconfiguration */
    ngx_http_oboe_filter_init,             /* postconfiguration */

    NULL,                                  /* create main configuration */
    NULL,                                  /* init main configuration */

    NULL,                                  /* create server configuration */
    NULL,                                  /* merge server configuration */

    ngx_http_oboe_create_loc_conf,         /* create location configuration */
    ngx_http_oboe_merge_loc_conf,          /* merge location configuation */
};

/* callback for "oboe_tracing_mode" directive */
static char *ngx_http_oboe_enable_tracing(ngx_conf_t *cf, ngx_command_t *cmd,
                                          void *conf) {
    plugin_config *ocf = (plugin_config *) conf;

    ngx_str_t *value;
    value = cf->args->elts;
    assert(cf->args->nelts == 2);

    if (!ngx_strcmp(value[1].data, "always")) {
        ocf->config_tracing_mode = OBOE_TRACE_ALWAYS;
    } else if (!ngx_strcmp(value[1].data, "through")) {
        ocf->config_tracing_mode = OBOE_TRACE_THROUGH;
    } else if (!ngx_strcmp(value[1].data, "never")) {
        ocf->config_tracing_mode = OBOE_TRACE_NEVER;
    } else {
        return "argument to enable_tracing must be one of 'always', 'through', "
               "or 'never'";
    }

    return NGX_CONF_OK;
}

/* callback for "oboe_sampling_rate" directive
   now needed because the datatype of sampling_rate has changed to an int (see oboe_settings_cfg_t),
   from ngx_uint_t. The built in ngx_conf_set_num_slot assumed this datatype.
   also, we can do our own validation here.
*/
static char *ngx_http_oboe_set_sample_rate(ngx_conf_t *cf, ngx_command_t *cmd,
                                             void *conf) {
    plugin_config *ocf = (plugin_config *) conf;

    ngx_str_t *value;
    if (cf->args->nelts != 2) {
        return "oboe_sampling_rate requires a value";
    }

    value = cf->args->elts;
    int sr = ngx_atoi(value[1].data, value[1].len);

    if (sr < 0 || sr > OBOE_SAMPLE_RESOLUTION) {
        return "oboe_sampling_rate must be between 0 and 1000000";
    } 

    ocf->config_sample_rate = sr;
    return NGX_CONF_OK;
}

/* callback for "create location configuration" */
static void *ngx_http_oboe_create_loc_conf(ngx_conf_t *cf) {
    plugin_config *conf;

    conf = ngx_pcalloc(cf->pool, sizeof(plugin_config));
    if (conf == NULL) {
        return NGX_CONF_ERROR;
    }

    conf->config_tracing_mode = NGX_CONF_UNSET;
    conf->config_sample_rate = NGX_CONF_UNSET;
    conf->reporter_port = NGX_CONF_UNSET_UINT;
    conf->reporter_host.data = NULL; // no such unset_str, could use unset_ptr?
    conf->application.data = NULL;
    return conf;
}

/* callback for "merge location configuration" */
static char *ngx_http_oboe_merge_loc_conf(ngx_conf_t *cf, void *parent,
                                          void *child){
    plugin_config *prev = parent;
    plugin_config *conf = child;

    ngx_conf_merge_value(conf->config_tracing_mode, prev->config_tracing_mode,
                              OBOE_TRACE_ALWAYS);
    ngx_conf_merge_value(conf->config_sample_rate, prev->config_sample_rate,
                              OBOE_SETTINGS_UNSET);
    ngx_conf_merge_str_value(conf->reporter_host, prev->reporter_host,
                             "127.0.0.1");
    ngx_conf_merge_uint_value(conf->reporter_port, prev->reporter_port, 7831);
    ngx_conf_merge_str_value(conf->application, prev->application, NULL);

    return NGX_CONF_OK;
}


/**
 * Report a layer initialization event.
 *
 * Generate a pseudo-trace consisting of an entry and exit event that
 * identify what is running both to register with our servers and for
 * statistical purposes.
 *
 * @param reporter An initialized reporter to handle sending the messages.
 * @return Non-zero on error.
 */
static int oboe_report_layer_init(oboe_reporter_t *reporter) {
    oboe_metadata_t md;
    oboe_event_t evt1, evt2;
    oboe_metadata_init(&md);
    oboe_metadata_random(&md);

    oboe_event_init(&evt1, &md); /* first event */
    oboe_event_add_info(&evt1, "Layer", NGX_OBOE_MODULE_LAYER_NAME);
    oboe_event_add_info(&evt1, "Label", "entry");
    oboe_event_add_info_bool(&evt1, "__Init", 1);
    oboe_event_add_info(&evt1, "Nginx.Oboe.Version", NGX_OBOE_MODULE_VERSION);
    oboe_event_add_info(&evt1, "Oboe.Version", oboe_config_get_version_string());
    oboe_event_add_info(&evt1, "Nginx.Version", NGINX_VER);
    oboe_reporter_send(reporter, &md, &evt1);
    oboe_event_destroy(&evt1);

    oboe_event_init(&evt2, &md); /* second event */
    oboe_event_add_info(&evt2, "Layer", NGX_OBOE_MODULE_LAYER_NAME);
    oboe_event_add_info(&evt2, "Label", "exit");
    oboe_event_add_edge(&evt2, &md);
    oboe_reporter_send(reporter, &md, &evt2);
    oboe_event_destroy(&evt2);

    oboe_metadata_destroy(&md);
    /* we can't destroy the reporter here - this is the same reporter used for the entirety of the request */
    return 0;
}


/* callback for "postconfiguration" */
static ngx_int_t ngx_http_oboe_filter_init(ngx_conf_t *cf) {
    ngx_http_core_main_conf_t *clcf;
    ngx_http_handler_pt *h;
    int result;

    // TODO 
    // - read configuration values for reporter initialization
    // - gethostbyname
    // - don't install handlers if tracing is disabled, for efficiency
    //
    // main configuration can be accessed as follows (needs to be populated):
    //
    // plugin_config *conf;
    // conf = ngx_http_conf_get_module_main_conf(cf, ngx_http_oboe_filter_module);
    // assert(conf);

    oboe_init();
    result = oboe_reporter_udp_init(&plugin_data.reporter, "127.0.0.1", "7831");
    assert(plugin_data.reporter.send);
    if (result < 0) {
        return NGX_ERROR;
    }

    oboe_report_layer_init(&plugin_data.reporter);

    /* install header filter */
    ngx_http_next_header_filter = ngx_http_top_header_filter;
    ngx_http_top_header_filter = ngx_http_oboe_header_filter;

    /* install body filter */
    ngx_http_next_body_filter = ngx_http_top_body_filter;
    ngx_http_top_body_filter = ngx_http_oboe_body_filter;

    /* install handler */
    clcf = ngx_http_conf_get_module_main_conf(cf, ngx_http_core_module);
    assert(clcf);
    h = ngx_array_push(&clcf->phases[NGX_HTTP_REWRITE_PHASE].handlers);
    if (h == NULL) {
        return NGX_ERROR;
    }
    *h = ngx_http_oboe_handler;

    return NGX_OK;
}

/* helper function, extracts X-TV-Meta header from output header list */
ngx_table_elt_t *ngx_http_oboe_get_xtvmeta(ngx_list_part_t *part) {
     // modified from an example of "the iteration through the list" from
     //   nginx-0.7.67, src/core/ngx_list.h
     ngx_list_part_t *data = part->elts;
     unsigned i;

    for (i = 0;; i++) {
        if (i >= part->nelts) {
            if (part->next == NULL) {
                break;
            }

            part = part->next;
            data = part->elts;
            i = 0;
        }

        ngx_table_elt_t *hdr = (ngx_table_elt_t *)data + i;
        if (!ngx_strcmp(hdr->key.data, "X-TV-Meta")) {
            return hdr;
        }
    }

    return NULL;
}

/* helper function, extracts X-Trace header from output header list */
ngx_table_elt_t *ngx_http_oboe_get_xtrace(ngx_list_part_t *part) {
     // modified from an example of "the iteration through the list" from
     //   nginx-0.7.67, src/core/ngx_list.h
     ngx_list_part_t *data = part->elts;
     unsigned i;

    for (i = 0;; i++) {
        if (i >= part->nelts) {
            if (part->next == NULL) {
                break;
            }

            part = part->next;
            data = part->elts;
            i = 0;
        }

        ngx_table_elt_t *hdr = (ngx_table_elt_t *)data + i;
        if (!ngx_strcmp(hdr->key.data, "X-Trace")) {
            return hdr;
        }
    }

    return NULL;
}

/* the following set of helper functions store/retrieve the oboe context.
   it used to be stored in r->ctx, the nginx-provided construct for storing
   module-related request-specific information, but since this gets cleared
   over internal redirects, we're using the hack suggested below on
   nginx-devel: using the data storage feature of request cleanup handlers.

   http://nginx.org/pipermail/nginx-devel/2010-June/000341.html */

/* the dummy cleanup handler */
static void ngx_http_oboe_dummy_cleanup(void *arg) {
    handler_ctx *hctx = arg;
    if (hctx) {
        if (hctx->event_set) {
            oboe_event_destroy(&hctx->xte);
        }
        if (oboe_metadata_is_valid(&hctx->md)) {
            oboe_metadata_destroy(&hctx->md);
        }
    }
    return;
}

handler_ctx *ngx_http_oboe_get_ctx(ngx_http_request_t *r) {
    ngx_http_cleanup_t *cln;

    ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] trying to retrieve context");

    for (cln = r->cleanup; cln; cln = cln->next) {
        if (cln->handler == &ngx_http_oboe_dummy_cleanup && cln->data != NULL) {
            ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] context found, returning");
            return cln->data;
        }
    }
    ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] context not found");
    return NULL;
}

handler_ctx *ngx_http_oboe_set_ctx(ngx_http_request_t *r) {
    ngx_http_cleanup_t *cln;

    ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] setting context");
    cln = ngx_http_cleanup_add(r, sizeof(handler_ctx));
    if (cln == NULL || cln->data == NULL) {
        return NULL;
    }
    cln->handler = &ngx_http_oboe_dummy_cleanup;
    ((handler_ctx *)cln->data)->event_set = 0;
    ((handler_ctx *)cln->data)->reported = 0;
    ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] new context data");
    return cln->data;
}

/* helper function for request/response callback: *
 * pass header up/downstream (e.g. fastcgi)       */
int ngx_http_oboe_handler_set_header(ngx_http_request_t *r,
                                     ngx_pool_t *pool,
                                     ngx_list_t *headers,
                                     oboe_metadata_t *md,
                                     ngx_table_elt_t *in_or_out_xtrace) {
    void *buf;
    ngx_table_elt_t *h;
    int result;

    buf = ngx_palloc(pool, OBOE_MAX_METADATA_PACK_LEN);
    if (buf == NULL) {
        ngx_log_error(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] ngx_palloc() failed");
        return -1;
    }
    result = oboe_metadata_tostr(md, buf, OBOE_MAX_METADATA_PACK_LEN);
    if (result < 0) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] metadata to string failed");
        return -1;
    }

    // add X-Trace header to header set (forwarded down/up FastCGI)
    if (!in_or_out_xtrace) {
        if (headers == NULL || headers->last == NULL) {
            // nginx hasn't initialized headers: ignore this request
            //
            // this could happen, for instance, if nginx is sending a 400 Bad Request response
            // and doesn't bother to call ngx_list_init on the headers_in struct
            return -1;
        }
        h = ngx_list_push(headers);
        if (h == NULL) {
             ngx_log_error(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] ngx_list_push() failed");
            return -1;
        }
    }
    else {
        h = in_or_out_xtrace;
    }

    /*
    This trick tells ngx_http_header_module to reflect the header value
    in the actual response. Otherwise the header will be ignored and client
    will never see it. To date the value must be just non zero.

    information from http://wiki.nginx.org/HeadersManagement
    */
    h->hash = 1;
    h->key.data = (u_char *)"X-Trace";
    h->key.len = sizeof("X-Trace") - 1;
    /* Mayday!  proxy_pass and other old modules might be stupid and expect
     * the header to have a lowcase_key value, we'll fill it in
     * otherwise the lazy module will crash */
    h->lowcase_key = (u_char *) "x-trace";

    h->value.data = buf;
    h->value.len = strlen(buf);

    return 0;
}
