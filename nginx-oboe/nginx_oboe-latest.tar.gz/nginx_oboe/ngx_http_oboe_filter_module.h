/* 
 * Copyright (C) 2012 by Tracelytics, Inc.
 * All rights reserved.
 *
 * Use and distribution of this software is subject to the terms and
 * limitations contained in the file LICENSE, which is provided with
 * this software distribution.
 */
#ifndef _NGX_HTTP_OBOE_FILTER_MODULE_H
#define _NGX_HTTP_OBOE_FILTER_MODULE_H

#include <ngx_core.h>
#include <ngx_http.h>

#include <oboe/oboe.h>

#include <dlfcn.h>

#ifndef OBOE_SETTINGS_VERSION
#error Please install the latest version of the liboboe-dev package. For more assistance, contact support@tracelytics.com
#endif

#define NGX_OBOE_MODULE_VERSION "1.2.1"
#define NGX_OBOE_MODULE_LAYER_NAME "nginx"

//#define OBOE_SAMPLE_RATE_DEFAULT 300000 // 30%

/* module configuration definition */
typedef struct {
    int config_tracing_mode;
    int config_sample_rate;
    ngx_str_t reporter_host;
    ngx_uint_t reporter_port;
    ngx_str_t application;
} plugin_config;

/* request-specific information definition */
typedef struct {
    oboe_metadata_t md;
    oboe_event_t xte;
    int event_set;
    int reported;
} handler_ctx;

/* module-specific information definition */
struct plugin_data_t {
    oboe_reporter_t reporter;
};

/* forward declarations (functions) */
ngx_int_t ngx_http_oboe_header_filter(ngx_http_request_t *);
ngx_int_t ngx_http_oboe_body_filter(ngx_http_request_t *, ngx_chain_t *);
ngx_int_t ngx_http_oboe_handler(ngx_http_request_t *);
handler_ctx *ngx_http_oboe_set_ctx(ngx_http_request_t *);
handler_ctx *ngx_http_oboe_get_ctx(ngx_http_request_t *);
ngx_table_elt_t *ngx_http_oboe_get_xtrace(ngx_list_part_t *part);
ngx_table_elt_t *ngx_http_oboe_get_xtvmeta(ngx_list_part_t *part);
int ngx_http_oboe_handler_set_header(ngx_http_request_t *r,
                                     ngx_pool_t *, ngx_list_t *,
                                     oboe_metadata_t *,
                                     ngx_table_elt_t *);

/* forward declarations (data structures) */
ngx_module_t ngx_http_oboe_filter_module;

/* dlsym for liboboe check */
typedef int (*oboe_version_func)(int version, int revision);

#endif
