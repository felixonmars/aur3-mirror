/* 
 * Copyright (C) 2012 by Tracelytics, Inc.
 * All rights reserved.
 *
 * Use and distribution of this software is subject to the terms and
 * limitations contained in the file LICENSE, which is provided with
 * this software distribution.
 */
#include "ngx_http_oboe_filter_module.h"
#include <assert.h>

extern struct plugin_data_t plugin_data;
extern ngx_http_output_header_filter_pt ngx_http_next_header_filter;
extern ngx_http_output_body_filter_pt ngx_http_next_body_filter;

/* helper function for response callback: send response report */
static int ngx_http_oboe_filter_send_report(oboe_metadata_t *md,
                                            oboe_event_t *xte,
                                            ngx_http_request_t *r) {
    int result;
    int retval = -2; // -2 is a dummy value for assert at end

    (void)oboe_event_add_info(xte, "Layer", NGX_OBOE_MODULE_LAYER_NAME);
    (void)oboe_event_add_info(xte, "Label", "exit");
    if (r->method_name.len > 0) {
        (void)oboe_event_add_info_binary(xte, "Method", (char*)r->method_name.data,
                                         r->method_name.len);
    }
    if (r->request_line.len > 0) {
        (void)oboe_event_add_info_binary(xte, "Request-Line",
                                         (char*)r->request_line.data,
                                         r->request_line.len);
    }
    if (r->unparsed_uri.len > 0) {
        (void)oboe_event_add_info_binary(xte, "Request-Orig-URI",
                                         (char*)r->unparsed_uri.data,
                                         r->unparsed_uri.len);
    }
    if (r->uri.len > 0) {
        (void)oboe_event_add_info_binary(xte, "Request-URI",
                                         (char*)r->uri.data, r->uri.len);
    }
#ifdef BUILD_OBOE_NGINX_0_5 // fix for Hardy (nginx-0.5.33)
    if (r->headers_in.host_name_len > 0) {
        (void)oboe_event_add_info_binary(xte, "HTTP-Host", 
                                         (char*)r->headers_in.host->value.data,
                                         r->headers_in.host_name_len);
    }
#else // works on Lucid, Maverick, etc
    if (r->headers_in.server.len > 0) {
        (void)oboe_event_add_info_binary(xte, "HTTP-Host",
                                         (char*)r->headers_in.server.data,
                                         r->headers_in.server.len);
    }
#endif
    if (r->connection->addr_text.len > 0) {
        (void)oboe_event_add_info_binary(xte, "Remote-Host",
                                         (char*)r->connection->addr_text.data,
                                         r->connection->addr_text.len);
    }
    (void)oboe_event_add_info_int64(xte, "Status", r->headers_out.status);
    (void)oboe_event_add_info_int64(xte, "Content-Length", r->headers_out.content_length_n);

    assert(plugin_data.reporter.send);

    result = oboe_reporter_send(&plugin_data.reporter, md, xte);
    if (result < 0) {
         ngx_log_error(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] reporter exit send failed");
        retval = -1;
        goto end;
    } else {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] exit trace successfully sent");
    }

    retval = 0;

end:
    assert(retval == 0 || retval == -1);
    return retval;
}

/* header response callback, invoked before headers written */
ngx_int_t ngx_http_oboe_header_filter(ngx_http_request_t *r) {
    plugin_config *conf;
    handler_ctx *hctx = NULL;
    ngx_table_elt_t *out_xtrace;
    int result;

    conf = ngx_http_get_module_loc_conf(r, ngx_http_oboe_filter_module);
    assert(conf);

    // 1. bail out if this reponse isn't to be traced
    hctx = ngx_http_oboe_get_ctx(r);
    if (!hctx) {
        goto end;
    }

    // 2. save event, metadata in context
    if (!(oboe_metadata_is_valid(&hctx->md))) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] metadata is not valid, cannot save to context");
        goto end;
    }
    
    result = oboe_metadata_create_event(&hctx->md, &hctx->xte);
    if (result < 0) {
        ngx_log_error(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] creating event failed");
        goto end;
    }

    // guarantee that the body filter is invoked if and only if the event
    // is allocated
    hctx->event_set = 1;

    out_xtrace = ngx_http_oboe_get_xtrace(&r->headers_out.headers.part);
    if (out_xtrace) {
        result = oboe_event_add_edge_fromstr(&hctx->xte,
                                             (const char *)
                                             out_xtrace->value.data,
                                             out_xtrace->value.len);
        if (result < 0) {
            ngx_log_debug0(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] adding edge from string failed");
            goto end;
        }
    }


    // 3. set upstream output header to use new op_id

    // need to extract metadata from event, a job typically done by
    // reporter_send, which needs to be postponed
    result = ngx_http_oboe_handler_set_header(r, r->pool, &r->headers_out.headers,
                                              &hctx->xte.metadata, out_xtrace);
    if (result < 0) {
        // no logging necessary; done in helper function
        goto end;
    }


    // 4. report exit event if the body filter won't be called

    // (conditional modified from ngx_http_chunked_header_filter)
    if (r->headers_out.status == NGX_HTTP_NOT_MODIFIED
        || r->headers_out.status == NGX_HTTP_NO_CONTENT
        || r->headers_out.status == NGX_HTTP_CREATED
        || (r->method & NGX_HTTP_HEAD)) {

        result = ngx_http_oboe_filter_send_report(&hctx->md, &hctx->xte, r);
        if (result < 0) {
            goto end;
        }
        hctx->reported = 1;
    }

end:
    return ngx_http_next_header_filter(r);
}

ngx_int_t ngx_http_oboe_body_filter(ngx_http_request_t *r, ngx_chain_t *in) {
    ngx_chain_t *chain_link;
    int chain_contains_last_buffer;
    handler_ctx *hctx;
    int result;

    hctx = ngx_http_oboe_get_ctx(r);
    if (!hctx || !hctx->event_set || hctx->reported) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] no context, no event, or already reported");
        goto end;
    }

    chain_contains_last_buffer = 0;
    for (chain_link = in; chain_link != NULL; chain_link = chain_link->next) {
        if (chain_link->buf->last_buf) {
            chain_contains_last_buffer = 1;
            break;
        }
    }

    if (chain_contains_last_buffer) {
        result = ngx_http_oboe_filter_send_report(&hctx->md, &hctx->xte, r);
        if (result < 0) {
            ngx_log_error(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] reporter send failed in body filter");
            goto end;
        }
    }

end:
    return ngx_http_next_body_filter(r, in);
}
