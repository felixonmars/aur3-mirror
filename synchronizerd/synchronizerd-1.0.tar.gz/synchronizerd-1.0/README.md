filesynchronizer
================

File synchronizing GUI for rsync.
