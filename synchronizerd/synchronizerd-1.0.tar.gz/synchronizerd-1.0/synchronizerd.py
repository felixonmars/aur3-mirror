#-*- coding: utf-8 -*-
import sys
import os
import subprocess
from threading import Thread
import socket
from email.mime.text import MIMEText
import smtplib
#import paypalrestsdk
#from paypalrestsdk import Paymnet


def backend_error():
    """Displays the backend error (relative to PySide or PyQt4)."""
    print(
        "You should choose PySide as a UI-- Example: python synchhronizerd.py -PySide.")


def get_file(desired_file):
    """Gets requested file's full path, usually on current dir or on default path (/usr/share/synchronizerd)
    @param desired_file: name of the desired file.
    @type desired_file: str
    @rtype: str
    @return: returns the full path of the requested file.
    """
    usrpath = os.path.join('/usr/share/synchronizerd/', desired_file)
    try:
        if os.path.exists(desired_file):
            return desired_file
        elif os.path.exists(usrpath):
            return usrpath
    except Exception as ex:
        print(ex)

if len(sys.argv) == 2:
    if sys.argv[1] == '-PySide':
        # PySide -----------------------------------
        import PySide
        from PySide import QtGui
        from PySide import QtCore
        from PySide.QtCore import Signal as Signal
        from PySide.QtCore import Slot as Slot
        from PySide.QtGui import QMessageBox
        from PySide.QtCore import QThread, QObject
        from PySide.QtWebKit import QWebView
        from views.synchronizerd_ui_pyside import Ui_SyncMain
        from views.feedback_ui_pyside import Ui_FeedbackDialog
        from views.paypal_ui_pyside import Ui_PaypalDialog
        #------------------------------------------
    # elif sys.argv[1] == '-PyQt4':
    # PyQt4 ------------------------------------
    #    import PyQt4
    #    from PyQt4 import QtGui
    #    from PyQt4 import QtCore
    #    from PyQt4.QtGui import QMessageBox, QMainWindow
    #    from PyQt4.QtCore import QThread, QObject
    #    from PyQt4.QtCore import pyqtSignal as Signal
    #    from PyQt4.QtCore import pyqtSlot as Slot
    #    from PyQt4.QtWebKit import QWebView
    #    from views.synchronizerd_ui import Ui_SyncMain
    #    from views.feedback_ui import Ui_FeedbackDialog
    #    from views.paypal_ui import Ui_PaypalDialog
    # ------------------------------------------
    else:
        backend_error()
        sys.exit()
else:
    backend_error()
    sys.exit()

__version__ = '1.0.0'
import platform

dir_from = None
dir_to = None


@Slot(str)
def m_box_exec(message):
    """Show message box (error)
    @param message: message to show on QMessageBox"""
    QMessageBox.critical(None, 'Error!', message, QMessageBox.Ok)


@Slot(str)
def m_box_exec_success(message):
    """Show message box (sucess)
    @param message: message to show on QMessageBox"""
    QMessageBox.information(None, 'Sucess!', message, QMessageBox.Ok)


class Communicate(QObject):

    """Used for communicating between threads with signals and slots"""
    speak = Signal(str)
    mBox = Signal(str)
    mBoxEr = Signal(str)


class EmailSender(Thread):

    """Sends feedback mail"""

    def __init__(self, nome, app_name, email, mensagem, com):
        Thread.__init__(self)
        self.mensagem = mensagem
        self.app_name = app_name
        self.email = email
        self.nome = nome
        self.com = com

    def run(self):
        """Calls self.send_mail()"""
        self.send_mail(self.nome, self.app_name, self.email, self.mensagem)

    def send_mail(self, nome, app_name, email, mensagem):
        """Sends the email to suporte@roandigital"""
        try:
            sender = "contato@roandigital.com"
            receivers = ['suporte@roandigital.com']
            message = MIMEText(
                mensagem + os.linesep + "Application: %s" % app_name)
            message[
                'Subject'] = "Feedback SynchroniZeRD - %s" % socket.gethostname()
            message['From'] = " %s <%s>" % (nome, email)
            message['To'] = "Suporte <suporte@roandigital.com>"

            conn = smtplib.SMTP("smtp.roandigital.com:587")
            conn.login("suporte@roandigital.com", "erros1234")
            conn.sendmail(sender, receivers, message.as_string())
            conn.quit()
            self.com.mBox.emit(
                'The email was sent with sucess. \n\nThank you for your feedback. \n\nWe hope you enjoy SynchroniZeRD!')
        except Exception as e:
            self.com.mBoxEr.emit(
                'The email was not sent, sorry.\n\n You may want to check your internet connection.')
            print(e)


class CheckProgress(QThread):

    """Starts the rsync process and emits the status"""

    def __init__(self, dir_from, dir_to, some):
        QThread.__init__(self, None)
        box = Communicate()
        box.mBox.connect(m_box_exec)
        try:
            self.processo = subprocess.Popen(
                ["rsync", "-avh", "--progress", "%s" %
                 dir_from, "%s" % dir_to], shell=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE)
            self.some = some
        except Exception as e:
            box.mBox.emit(
                'Error invoking rsync, please check if you have rsync installed.\n %s' % e.message)
            print(e)

    def run(self):
        """Calls self.get_progress()"""
        self.get_progress()

    def get_progress(self):
        """Emits the progress of the rsync ongoing process to the communicate object"""
        while True:
            out = self.processo.stdout.readline(150)
            if out is '' or self.processo.poll() is not None:
                print("End of sync process.")
                self.some.speak.emit('end of sync process')
                break
            print(out)
            self.some.speak.emit(bytes.decode(out))


class Feedback(QtGui.QDialog):

    """Send feedback"""

    def __init__(self):
        super(Feedback, self).__init__()
        self.ui = Ui_FeedbackDialog()
        self.ui.setupUi(self)
        self.ui.sendButton.clicked.connect(self.send_mail)
        self.com = Communicate()
        self.com.mBox.connect(m_box_exec_success)
        self.com.mBoxEr.connect(m_box_exec)

    def send_mail(self):
        """Calls EmailSender to send the feedback"""
        mail = EmailSender(self.ui.nameEdit.text(), 'SynchroniZeRD',
                           self.ui.emailEdit.text(), self.ui.messageEdit.toPlainText(), self.com)
        mail.start()
        mail.join()
        self.close()

class MainUi(QtGui.QMainWindow):
    """Main GUI class"""
    def __init__(self, *args, **kwargs):
        super(MainUi, self).__init__()
        self.ui = Ui_SyncMain()
        self.ui.setupUi(self)
        self.ui.btOpenFrom.clicked.connect(self.from_open)
        self.ui.btOpenTo.clicked.connect(self.to_open)
        self.ui.btSync.clicked.connect(self.sync)
        self.some = Communicate()
        self.some.speak.connect(self.say_words)
        self.ui.actionOpen_Folder_From.activated.connect(self.from_open)
        self.ui.actionOpen_Folder_To.activated.connect(self.to_open)
        self.ui.action_About.activated.connect(self.about_box)
        self.ui.action_License.activated.connect(self.about_license)
        self.ui.actionAbout_Qt.activated.connect(self.about_box_qt)
        self.ui.action_Exit.activated.connect(self.exit_menu)
        self.ui.actionSend_Feedback.activated.connect(self.feedback)
        self.ui.btOpenTo.setIcon(QtGui.QIcon(get_file('openfolder.png')))
        self.ui.btOpenFrom.setIcon(QtGui.QIcon(get_file('openfolder.png')))
        self.ui.textFrom.textChanged.connect(self.from_change)
        self.ui.textTo.textChanged.connect(self.to_change)

    @Slot(str)
    def say_words(self, words):
        """Appends the stdout of rsync process to textStatus"""
        self.ui.textStatus.append(words)
        if words in 'end of sync process':
            self.ui.btSync.setEnabled(True)
  
    @staticmethod
    def paypalui():
        """Initializes paypal UI"""
        pay = PayPalUI()
        pay.exec_()

    @staticmethod
    def feedback():
        """Initializes feedback UI"""
        feed = Feedback()
        feed.exec_()

    def about_box(self):
        """Initializes about UI"""
        about = QMessageBox.about(self, "About SynchroniZeRD",
                                  """<b>SynchroniZeRD</b> v %s
        <p><b>Copyright (C) 2013</b> Ronnie Andrew.</p>
        <p>
        All rights reserved in accordance with
        GPL v3 or later - NO WARRANTIES!</p>
        <p>This application can be used to synchronize folders using <b>rsync</b> as main feature.</p>
        <p><b>Official Website:</b> <a href='http://roandigital.com/applications/synchronizerd'>Roan Digital</a></p>
        <p><b>Platform: </b>%s</p>
        """ % (__version__, platform.system()))

    def about_box_qt(self):
        """Initializes about Qt UI"""
        QMessageBox.aboutQt(self, 'About Qt')

    def about_license(self):
        """Initializes License UI"""
        try:
            f = open(get_file('GNU_HTML'))
            license = QtGui.QDialog()
            license.resize(650, 480)
            license.setWindowTitle('SynchroniZeRD License')
            licenseText = QWebView()
            licenseText.setHtml(f.read())
            layout = QtGui.QGridLayout(license)
            layout.addWidget(licenseText)
            license.exec_()
        except:
            QMessageBox.critical(
                self, 'Error', 'Unable to open GNU_HTML License file.')

    def from_open(self):
        """Choose folder 'from' dialog"""
        chosen_from_dir = self.get_directory()
        self.dir_from = chosen_from_dir
        print(self.dir_from)
        self.ui.textFrom.setText(self.dir_from)

    def to_open(self):
        """Choose folder 'to' dialog"""
        chosen_to_dir = self.get_directory()
        self.dir_to = chosen_to_dir
        print(self.dir_to)
        self.ui.textTo.setText(self.dir_to)

    def from_change(self):
        """Recognizes directory change on textFrom"""
        self.dir_from = self.ui.textFrom.text()

    def to_change(self):
        """Recognizes directory change on textTo"""
        self.to_open = self.ui.textTo.text()

    def sync(self):
        """Starts the rsync process"""
        files = self.ui.radioFiles.isChecked()
        folder = self.ui.radioFolder.isChecked()
        if files:
            self.thread_progress = CheckProgress(
                self.dir_from + os.sep, self.dir_to + os.sep, self.some)
            self.thread_progress.start()
            self.ui.btSync.setEnabled(False)
        elif folder:
            self.thread_progress = CheckProgress(
                self.dir_from, self.dir_to, self.some)
            self.thread_progress.start()
            self.ui.btSync.setEnabled(False)
        else:
            QMessageBox.information(
                self, 'Ops!', 'Please choose a sync mode (Files or Folder).')

    def get_directory(self):
        """Gets directory 
        @return: Returns a directory string path"""
        dialog = QtGui.QFileDialog()
        dialog.setFileMode(QtGui.QFileDialog.Directory)
        dialog.setOption(QtGui.QFileDialog.ShowDirsOnly)
        return dialog.getExistingDirectory()

    def exit_menu(self):
        """Exits the application"""
        self.close()


if __name__ == '__main__':
    app = QtGui.QApplication(sys.argv)
    main = MainUi()
    try:
        app.setWindowIcon(QtGui.QIcon(get_file('synchronizer-rd.png')))
        main.setWindowIcon(QtGui.QIcon(get_file('synchronizer-rd.png')))
    except:
        QMessageBox.critical(
            main, 'Error', 'Unable to open icon synchronizer-rd.png')
    main.show()
    sys.exit(app.exec_())
