use strict;

print "test for lsdvd ( >= 0.9) : ";

my $lsdvd = `lsdvd -V 2>&1`;

if ( $lsdvd !~ /0.(\d+)\s/ ) {
die "Not Found!\n\n***************\n" . 
  "AcidRip needs my little app \"lsdvd\" in order to see what is on your dvd\'s\n" .
  "Download it and install it (and libdvdread) before trying to use AcidRip.\n" .
  "If it\'s simply not on your path then set the full path inside AcidRip.\n" .
  "***************\n\n"
}
if ( $1 < 9 ) {
die "Too old!\n\n***************\n" . 
  "AcidRip needs at least version 0.9 of lsdvd, but version 0.$1 was found\n" .
  "Download it and install it (and libdvdread) before trying to use AcidRip.\n" .
  "***************\n\n"
}
print "found\n";

print "Everything looks good here...\n";
