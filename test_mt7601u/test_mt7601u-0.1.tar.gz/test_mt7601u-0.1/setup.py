#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
It paste a file and short the url.
Copyright (C) 2014 Julien Freyermuth
All Rights Reserved

See the file LICENSE for copying permission.
"""


#------
# Used http://www.python.org/dev/peps/pep-0314/ and
# http://getpython3.com/diveintopython3/packaging.html
#
# https://pypi.python.org/pypi?%3Aaction=list_classifiers
#
# to wrote this script
#------------------------


try:
    from setuptools import setup, find_packages
except ImportError:
    from distutils.core import setup, find_packages

CLASSIFIERS = [
    'Development Status :: 5 - Production/Stable',
    'Environment :: Console',
    'Intended Audience :: System Administrators',
    'License :: OSI Approved',
    'Natural Language :: English',
    'Operating System :: POSIX :: Linux',
    'Programming Language :: Python :: 3',
]

DATA_FILES = [('/usr/lib/systemd/system', ['test_mt7601u.service'])]

SCRIPTS = ['test_mt7601u', ]

setup(
    name             = 'test_mt7601u',
    version          = '0.1',
    description      = 'Test if mt7601u (wifi) is loaded. If not, it install it',
    author           = 'Freyermuth Julien',
    author_email     = 'julien.chipster@gmail.com',
    license          = 'WTFPL',
    platforms        = 'Linux',
    url              = ' ',
    data_files       = DATA_FILES,
    packages         = find_packages(),
    include_package_data = True,
    scripts          = SCRIPTS,
    requires         = ['python (>=3.4)'],
    classifiers      = CLASSIFIERS,
)
