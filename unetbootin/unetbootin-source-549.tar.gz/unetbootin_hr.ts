<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="hr_HR">
<context>
    <name></name>
    <message>
        <source></source>
        <translatorcomment>Croatian translation for unetbootin
Copyright (c) 2010 Rosetta Contributors and Canonical Ltd 2010
This file is distributed under the same license as the unetbootin package.
FIRST AUTHOR &lt;EMAIL@ADDRESS&gt;, 2010.

</translatorcomment>
        <translation>Project-Id-Version: unetbootin
Report-Msgid-Bugs-To: FULL NAME &lt;EMAIL@ADDRESS&gt;
POT-Creation-Date: 2011-04-01 15:37-0400
PO-Revision-Date: 2011-01-15 10:43+0000
Last-Translator: Geza Kovacs &lt;geza0kovacs@gmail.com&gt;
Language-Team: Croatian &lt;hr@li.org&gt;
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
X-Launchpad-Export-Date: 2011-04-02 17:48+0000
X-Generator: Launchpad (build 12710)
</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="main.cpp" line="266"/>
        <source>LeftToRight</source>
        <translation>S lijeva na desno</translation>
    </message>
</context>
<context>
    <name>unetbootin</name>
    <message>
        <location filename="unetbootin.cpp" line="202"/>
        <location filename="unetbootin.cpp" line="296"/>
        <location filename="unetbootin.cpp" line="297"/>
        <location filename="unetbootin.cpp" line="364"/>
        <location filename="unetbootin.cpp" line="480"/>
        <location filename="unetbootin.cpp" line="3185"/>
        <location filename="unetbootin.cpp" line="3198"/>
        <location filename="unetbootin.cpp" line="3370"/>
        <location filename="unetbootin.cpp" line="3962"/>
        <source>Hard Disk</source>
        <translation>Tvrdi disk</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="204"/>
        <location filename="unetbootin.cpp" line="293"/>
        <location filename="unetbootin.cpp" line="294"/>
        <location filename="unetbootin.cpp" line="366"/>
        <location filename="unetbootin.cpp" line="484"/>
        <location filename="unetbootin.cpp" line="649"/>
        <location filename="unetbootin.cpp" line="669"/>
        <location filename="unetbootin.cpp" line="923"/>
        <location filename="unetbootin.cpp" line="1454"/>
        <location filename="unetbootin.cpp" line="1516"/>
        <location filename="unetbootin.cpp" line="2435"/>
        <location filename="unetbootin.cpp" line="2477"/>
        <location filename="unetbootin.cpp" line="3189"/>
        <location filename="unetbootin.cpp" line="3215"/>
        <location filename="unetbootin.cpp" line="3374"/>
        <location filename="unetbootin.cpp" line="3697"/>
        <location filename="unetbootin.cpp" line="3966"/>
        <source>USB Drive</source>
        <translation>USB uređaj</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="205"/>
        <location filename="unetbootin.cpp" line="222"/>
        <location filename="unetbootin.cpp" line="223"/>
        <location filename="unetbootin.cpp" line="332"/>
        <location filename="unetbootin.cpp" line="600"/>
        <location filename="unetbootin.cpp" line="601"/>
        <location filename="unetbootin.cpp" line="3268"/>
        <source>ISO</source>
        <translation>ISO</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="206"/>
        <location filename="unetbootin.cpp" line="218"/>
        <location filename="unetbootin.cpp" line="219"/>
        <location filename="unetbootin.cpp" line="337"/>
        <location filename="unetbootin.cpp" line="605"/>
        <location filename="unetbootin.cpp" line="606"/>
        <location filename="unetbootin.cpp" line="3260"/>
        <source>Floppy</source>
        <translation>Disketa</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="239"/>
        <location filename="unetbootin.cpp" line="245"/>
        <location filename="unetbootin.cpp" line="249"/>
        <location filename="unetbootin.cpp" line="253"/>
        <location filename="unetbootin.cpp" line="259"/>
        <location filename="unetbootin.cpp" line="287"/>
        <source>either</source>
        <translation>ili</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="266"/>
        <source>LiveUSB persistence</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="281"/>
        <source>FAT32-formatted USB drive</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="285"/>
        <source>EXT2-formatted USB drive</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="597"/>
        <source>Open Disk Image File</source>
        <translation>Otvoriti Datoteku disketnog image-a</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="597"/>
        <source>All Files</source>
        <translation>Sve datoteke</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="615"/>
        <location filename="unetbootin.cpp" line="623"/>
        <location filename="unetbootin.cpp" line="631"/>
        <source>All Files (*)</source>
        <translation>Sve Datoteke (*)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="615"/>
        <source>Open Kernel File</source>
        <translation>Otvorena Kernel Datoteka</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="623"/>
        <source>Open Initrd File</source>
        <translation>Otvoriti Initrd Datoteku</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="631"/>
        <source>Open Bootloader Config File</source>
        <translation>Otvoriti Konfiguracijsku Datoteku Bootloadera</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="653"/>
        <source>Insert a USB flash drive</source>
        <translation>Umetnuti USB flash jedinicu</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="654"/>
        <source>No USB flash drives were found. If you have already inserted a USB drive, try reformatting it as FAT32.</source>
        <translation>Nisu nađene USB flash jedinice. Ako ste već umetnuli USB jedinicu, probajte ponovno formatirati kao FAT32.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="673"/>
        <source>%1 not mounted</source>
        <translation>%1 nije montirano</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="674"/>
        <source>You must first mount the USB drive %1 to a mountpoint. Most distributions will do this automatically after you remove and reinsert the USB drive.</source>
        <translation>Prvo morate mountati USB jedinicu %1 na točku montiranja. Većina distribucija će to učiniti automatski  nakon što izvadite i ponovno umetnete USB jedinicu.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="689"/>
        <source>Select a distro</source>
        <translation>Odabrati distribuciju</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="690"/>
        <source>You must select a distribution to load.</source>
        <translation>Morate odabrati distribuciju za učitavanje.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="704"/>
        <source>Select a disk image file</source>
        <translation>Odabrati datoteku disk image-a</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="705"/>
        <source>You must select a disk image file to load.</source>
        <translation>Morate odabrati diskovni image za učitavanje.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="719"/>
        <source>Select a kernel and/or initrd file</source>
        <translation>Odabrati kernel i/ili initrd datoteku</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="720"/>
        <source>You must select a kernel and/or initrd file to load.</source>
        <translation>Morate odabrati kernel i/ili initrd datoteku za učitavanje.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="734"/>
        <source>Diskimage file not found</source>
        <translation>Datoteka diskovnog image-a nije nađena</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="735"/>
        <source>The specified diskimage file %1 does not exist.</source>
        <translation>Zadani datoteka disk image-a %1 ne postoji.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="749"/>
        <source>Kernel file not found</source>
        <translation>Kernel datoteka nije nađena</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="750"/>
        <source>The specified kernel file %1 does not exist.</source>
        <translation>Zadana datoteka kernela %1 ne postoji.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="764"/>
        <source>Initrd file not found</source>
        <translation>Initrd nije nađen</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="765"/>
        <source>The specified initrd file %1 does not exist.</source>
        <translation>Zadana initrd datoteka %1 ne postoji.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="869"/>
        <source>%1 exists, overwrite?</source>
        <translation>%1 postoji, prepisati?</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="870"/>
        <source>The file %1 already exists. Press &apos;Yes to All&apos; to overwrite it and not be prompted again, &apos;Yes&apos; to overwrite files on an individual basis, and &apos;No&apos; to retain your existing version. If in doubt, press &apos;Yes to All&apos;.</source>
        <translation>Datoteka %1 već postoji. Odabrati  &apos;Da za Sve&apos; za prepisivanje i spriječavanje daljnjih budućih upita, &apos;Da&apos; za prepisivanje datoteka na inidividualnoj bazi, i &apos;Ne&apos; za zadržavanje vaše postojeće inačice. Ako postoji sumnja, odaberite &apos;Da za Sve&apos;.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="896"/>
        <source>%1 is out of space, abort installation?</source>
        <translation>%1 nema više mjesta, prekinuti instalaciju?</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="897"/>
        <source>The directory %1 is out of space. Press &apos;Yes&apos; to abort installation, &apos;No&apos; to ignore this error and attempt to continue installation, and &apos;No to All&apos; to ignore all out-of-space errors.</source>
        <translation>Datoteka %1 nema više mjesta. Odabrati &apos;Da&apos; za prekid instalacije, &apos;Ne&apos; za ignoriranje ove greške i pokušaj nastavka instalacije, i &apos;Ne za Sve&apos; za ignoriranje svi grešaka izvan-prostora.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="991"/>
        <source>Locating kernel file in %1</source>
        <translation>Traženje kernel datoteke u %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1032"/>
        <source>Copying kernel file from %1</source>
        <translation>Kopiranje kernel datoteke iz %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1038"/>
        <source>Locating initrd file in %1</source>
        <translation>Traženje initrd datoteke u %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1079"/>
        <source>Copying initrd file from %1</source>
        <translation>Kopiranje initrf datoteke iz %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1085"/>
        <location filename="unetbootin.cpp" line="1145"/>
        <source>Extracting bootloader configuration</source>
        <translation>Otpakiravanje konfiguracije bootloader-a</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1360"/>
        <location filename="unetbootin.cpp" line="1386"/>
        <source>&lt;b&gt;Extracting compressed iso:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Otpakiravanje kompresiranog iso-a:&lt;/b&gt; %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1615"/>
        <source>Copying file, please wait...</source>
        <translation>Kopiranje datoteke, molimo pričekajte...</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1616"/>
        <location filename="unetbootin.cpp" line="2420"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</source>
        <translation>&lt;b&gt;Izvor:&lt;/b&gt; &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1617"/>
        <location filename="unetbootin.cpp" line="2421"/>
        <source>&lt;b&gt;Destination:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Odredište:&lt;/b&gt; %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1618"/>
        <source>&lt;b&gt;Copied:&lt;/b&gt; 0 bytes</source>
        <translation>&lt;b&gt;Kopirano:&lt;/b&gt; 0 byte-ova</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1656"/>
        <source>Extracting files, please wait...</source>
        <translation>Otpakiravanje datoteka, molimo pričekajte...</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1657"/>
        <source>&lt;b&gt;Archive:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Arhiva:&lt;/b&gt; %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1658"/>
        <source>&lt;b&gt;Source:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Izvor:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1659"/>
        <source>&lt;b&gt;Destination:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Odredište:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1660"/>
        <source>&lt;b&gt;Extracted:&lt;/b&gt; 0 of %1 files</source>
        <translation>&lt;b&gt;Otpakirano:&lt;/b&gt;0 od %1 datoteka</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1663"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; %1 (%2)</source>
        <translation>&lt;b&gt;Izvor:&lt;/b&gt; %1 (%2)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1664"/>
        <source>&lt;b&gt;Destination:&lt;/b&gt; %1%2</source>
        <translation>&lt;b&gt;Odredište:&lt;/b&gt; %1%2</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1665"/>
        <source>&lt;b&gt;Extracted:&lt;/b&gt; %1 of %2 files</source>
        <translation>&lt;b&gt;Otpakirano:&lt;/b&gt; %1 od %2 datoteka</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2419"/>
        <source>Downloading files, please wait...</source>
        <translation>Skidanje datoteka, molimo pričekajte...</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2422"/>
        <source>&lt;b&gt;Downloaded:&lt;/b&gt; 0 bytes</source>
        <translation>&lt;b&gt;Skinuto:&lt;/b&gt; 0 byteova</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2499"/>
        <location filename="unetbootin.cpp" line="2514"/>
        <source>&lt;b&gt;Downloaded:&lt;/b&gt; %1 of %2</source>
        <translation>&lt;b&gt;Skinuto:&lt;/b&gt; %1 od %2</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2529"/>
        <source>&lt;b&gt;Copied:&lt;/b&gt; %1 of %2</source>
        <translation>&lt;b&gt;Kopirano:&lt;/b&gt; %1 od %2</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2605"/>
        <source>Searching in &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</source>
        <translation>Traženje u &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2609"/>
        <source>%1/%2 matches in &lt;a href=&quot;%3&quot;&gt;%3&lt;/a&gt;</source>
        <translation>%1/%2 odgovarajućih nađeno u &lt;a href=&quot;%3&quot;&gt;%3&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2882"/>
        <source>%1 not found</source>
        <translation>%1 nije pronađen</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2883"/>
        <source>%1 not found. This is required for %2 install mode.
Install the &quot;%3&quot; package or your distribution&apos;s equivalent.</source>
        <translation>%1 nije nađen. To je potrebno za %2 install mode.
Instaliranje &quot;%3&quot; paketa ili ekvivalent vaše distribucije.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3166"/>
        <source>(Current)</source>
        <translation>(Trenutno)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3167"/>
        <source>(Done)</source>
        <translation>(Napravljeno)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3449"/>
        <source>Configuring grub2 on %1</source>
        <translation>Konfiguracija grub2 na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3461"/>
        <source>Configuring grldr on %1</source>
        <translation>Konfiguriranje grldr na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3489"/>
        <source>Configuring grub on %1</source>
        <translation>Konfiguriranje grub na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3726"/>
        <source>Installing syslinux to %1</source>
        <translation>Konfiguriranje syslinux na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3761"/>
        <source>Installing extlinux to %1</source>
        <translation>Instaliranje extlinux na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3921"/>
        <source>Syncing filesystems</source>
        <translation>Synhronizacija datotečnih sustava</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3926"/>
        <source>Setting up persistence</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3964"/>
        <source>After rebooting, select the </source>
        <translation>Nakon restarta, odabrati </translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3969"/>
        <source>After rebooting, select the USB boot option in the BIOS boot menu.%1
Reboot now?</source>
        <translation>Nakon restarta, odabrati USB boot opciju u BIOS boot menu.%1
Restart odmah?</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3972"/>
        <source>The created USB device will not boot off a Mac. Insert it into a PC, and select the USB boot option in the BIOS boot menu.%1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="41"/>
        <source>
*IMPORTANT* Before rebooting, place an Ubuntu alternate (not desktop) install iso file on the root directory of your hard drive or USB drive. These can be obtained from cdimage.ubuntu.com</source>
        <translation>
*BITNO* Prije restarta, postaviti Ubutnu alternativnu (ne desktop) install iso datoteku u glavni direktorij vašeg tvrdog diska ili USB jedinice. Oni se mogu nabaviti da cdimage.ubuntu.com</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="232"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;mirrors.kernel.org&apos; when prompted for a server, and enter &apos;/centos/%1/os/%2&apos; when asked for the folder.</source>
        <translation>
*BITNO* Nakon restarta, ignorirati bilo kakve poruke o grešci i odabrati nazad ako se pojavi upit za CD, zatim otići u glavni meni, odabrati opciju &apos;Pokrenuti Instalaciju&apos;, odvrati &apos;Mreža&apos; kao izvor, odabrati &apos;HTTP&apos; kao protokol, ući u &apos;mirrors.kernel.org&apos; kada se pojavi upit za server, i unijeti &apos;/centos/%1/os/%2&apos; kada se pojavi upit za mapu.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="288"/>
        <source>
*IMPORTANT* Before rebooting, place a Debian install iso file on the root directory of your hard drive or USB drive. These can be obtained from cdimage.debian.org</source>
        <translation>
*BITNO* Nakon restarta, staviti Debian install iso datoteku u glavni direktorij vašeg tvrdog diska ili USB jedinice. One se mogu nabaviti sa cdimage.debian.org</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="381"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.fedora.redhat.com&apos; when prompted for a server, and enter &apos;/pub/fedora/linux/development/%1/os&apos; when asked for the folder.</source>
        <translation>
*BITNO* Nakon restarta, ignorirati poruke o greškama i odabrati natrag ako se pojavi upit za CD, nakon toga otići u glavni meni, odabrati opciju &apos;Pokrenuti Instalaciju&apos;, odabrati &apos;Mreža&apos; kao izvor, odbarati &apos;HTTP&apos; kao protokol, ući u &apos;download.fedora.redhat.com&apos;, kada se pojavi upit o serveru, unijeti &apos;/pub/fedora/linux/development/%1/os&apos; kada se pojavi upit o mapi.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="387"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.fedora.redhat.com&apos; when prompted for a server, and enter &apos;/pub/fedora/linux/releases/%1/Fedora/%2/os&apos; when asked for the folder.</source>
        <translation>
*BITNO* Nakon restarta, ignorirati poruke o greškama i odabrati natrag ako se pojavi upit za CD, nakon toga otići u glavni meni, odabrati opciju &apos;Pokrenuti Instalaciju&apos;, odabrati &apos;Mreža&apos; kao izvor, odbarati &apos;HTTP&apos; kao protokol, ući u &apos;download.fedora.redhat.com&apos;, kada se pojavi upit o serveru, unijeti &apos;/pub/fedora/linux/development/%1/Fedora/%2/os&apos; kada se pojavi upit o mapi.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="747"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.opensuse.org&apos; when prompted for a server, and enter &apos;/factory/repo/oss&apos; when asked for the folder.</source>
        <translation>
*BITNO* Nakon restarta, ignorirati poruke o greškama i odabrati natrag ako se pojavi upit za CD, nakon toga otići u glavni meni, odabrati opciju &apos;Pokrenuti Instalaciju&apos;, odabrati &apos;Mreža&apos; kao izvor, odbarati &apos;HTTP&apos; kao protokol, ući u &apos;download.opensuse.com&apos;, kada se pojavi upit o serveru, unijeti &apos;/factory/repo/oss&apos; kada se pojavi upit o mapi.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="753"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.opensuse.org&apos; when prompted for a server, and enter &apos;/distribution/%1/repo/oss&apos; when asked for the folder.</source>
        <translation>
*BITNO* Nakon restarta, ignorirati poruke o greškama i odabrati natrag ako se pojavi upit za CD, nakon toga otići u glavni meni, odabrati opciju &apos;Pokrenuti Instalaciju&apos;, odabrati &apos;Mreža&apos; kao izvor, odbarati &apos;HTTP&apos; kao protokol, ući u &apos;download.opensuse.com&apos;, kada se pojavi upit o serveru, unijeti &apos;/distribution/%1/repo/oss&apos; kada se pojavi upit o mapi.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="23"/>
        <location filename="unetbootin.cpp" line="685"/>
        <source>== Select Distribution ==</source>
        <translation>== Odabrati Distribuciju ==</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="23"/>
        <location filename="distrover.cpp" line="27"/>
        <source>== Select Version ==</source>
        <translation>== Odabrati Verziju ==</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="24"/>
        <source>Welcome to &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;, the Universal Netboot Installer. Usage:&lt;ol&gt;&lt;li&gt;Select a distribution and version to download from the list above, or manually specify files to load below.&lt;/li&gt;&lt;li&gt;Select an installation type, and press OK to begin installing.&lt;/li&gt;&lt;/ol&gt;</source>
        <translation>Dobrodošli u &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;, the Universal Netboot Installer. Korištenje:&lt;ol&gt;&lt;li&gt;Odabrati distribuciju i verziju za skidanje iz gornje liste, ili ručno odrediti datoteke za skidanje ispod&lt;/li&gt;&lt;li&gt;Odabrati tip instalacije, i stisnuti OK za početak instalacije.&lt;/li&gt;&lt;/ol&gt;</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="29"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.archlinux.org/&quot;&gt;http://www.archlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Arch Linux is a lightweight distribution optimized for speed and flexibility.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for installation over the internet (FTP).</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.archlinux.org/&quot;&gt;http://www.archlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Arch Linux je lightweight distribution optimizirana za brzinu i fleksibilnost.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; Osnovna inačica dozvoljava instalaciju preko internet-a (FTP).</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="34"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.backtrack-linux.org/&quot;&gt;http://www.backtrack-linux.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; BackTrack is a distribution focused on network analysis and penetration testing.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; BackTrack is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.backtrack-linux.org/&quot;&gt;http://www.backtrack-linux.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  BackTrack je distribucija sa fokusom na analizu mreže i provjeru prodornosti.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; BackTrack se boota i pokreće u live mode; instalacija nije potrebna za korištenje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="39"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.centos.org/&quot;&gt;http://www.centos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; CentOS is a free Red Hat Enterprise Linux clone.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.centos.org/&quot;&gt;http://www.centos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  CentOS je besplatan Red Hat Enterprise Linux klon.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; Osnovna inačica dozvolj instalacije preko interneta (FTP), ili offline installation koristeći prije skinute ISO datoteke instalacije.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="44"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://clonezilla.org/&quot;&gt;http://clonezilla.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; CloneZilla is a distribution used for disk backup and imaging.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; CloneZilla is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://clonezilla.org/&quot;&gt;http://clonezilla.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; CloneZilla je sidtribucija koja se koristi za backup diska i pravljenje slika diska.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; CloneZilla se boot-a i pokreće u live mode-u; za korištenje nije potrebna instalacija.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="49"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://damnsmalllinux.org/&quot;&gt;http://damnsmalllinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Damn Small Linux is a minimalist distribution designed for older computers.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://damnsmalllinux.org/&quot;&gt;http://damnsmalllinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Damn Small Linux je minimalistička distribucija stvorena za starija računala.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; The Live inačica učitava cijeli sustav u RAM i boot-a u memoriju, dakle instalacija nije potrebna, već je opcionalna.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="54"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.debian.org/&quot;&gt;http://www.debian.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Debian is a community-developed Linux distribution that supports a wide variety of architectures and offers a large repository of packages.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The NetInstall version allows for installation over FTP. If you would like to use a pre-downloaded install iso, use the HdMedia option, and then place the install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.debian.org/&quot;&gt;http://www.debian.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Debian je community-developed Linux distribucija koja podržava cijelo čudo arhitektura i nudi vrlo veliki repozitorij paketa.&lt;br/&gt;&lt;b&gt;Napomene Instalacije:&lt;/b&gt; The NetInstall inačica dozvoljava instalaciju preko FTP. Ako želite koristiti  pre-downloaded install iso, koristiti HdMedia opciju, i zatim staviti install iso file u glavni direktorij vašeg tvrdog diska ili USB sticka</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="60"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.dreamlinux.com.br/&quot;&gt;http://www.dreamlinux.com.br&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Dreamlinux is a user-friendly Debian-based distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.dreamlinux.com.br/&quot;&gt;http://www.dreamlinux.com.br&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Dreamlinux je korisnički prijateljska Debian bazirana distribucija.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; The Live inačica dozvoljava boot u Live mode, iz kojega se instaler može pokrenuti prema potrebi.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="65"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.freedrweb.com/livecd&quot;&gt;http://www.freedrweb.com/livecd&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Dr.Web AntiVirus is an anti-virus emergency kit to restore a system that broke due to malware.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which malware scans can be launched.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.freedrweb.com/livecd&quot;&gt;http://www.freedrweb.com/livecd&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Dr.Web AntiVirus je anti-virus emergency kit za vraćanje sustava koji se srušio zbog malware-a.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; The Live inačica boot u Live mode, iz kojega se mogu pokrenuti malware pretrage.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="70"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Elive is a Debian-based distribution featuring the Enlightenment window manager.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Elive je Debian-based distribucija koja promovira Enlightenment window manager.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; The Live inačica dozvoljava boot u Live mode, iz kojega se prema potrebi može pokrenuti instaler.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="75"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://fedoraproject.org/&quot;&gt;http://fedoraproject.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Fedora is a Red Hat sponsored community distribution which showcases the latest cutting-edge free/open-source software.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://fedoraproject.org/&quot;&gt;http://fedoraproject.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Fedora je Red Hat sponzorirana community distribucija koja prikazuje zadnji najnoviji free/open-source software.&lt;br/&gt;&lt;b&gt;Napomene Instalacije:&lt;/b&gt; The Live version dozvoljava boot u Live mode, iz kojega se prema potrebi može pokrenuti instaler. NetInstall inačica dozvoljava instalaciju prekointerneta (FTP), ili offline instalaciju korištenjem prije skinutih installation ISO datoteka.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="80"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.freebsd.org/&quot;&gt;http://www.freebsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; FreeBSD is a general-purpose Unix-like operating system designed for scalability and performance.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.freebsd.org/&quot;&gt;http://www.freebsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  FreeBSD je općeniti Unix-like operacijski sustav koji je načinjen za skalabilnost i performanse.&lt;br/&gt;&lt;b&gt;Bilješka Instalacije
:&lt;/b&gt;  Podrazumijevana inačica dozvoljava instalaciju preko interneta (FTP), ili offline instalaciju korištenjem prije skinutih ISO datoteka.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="85"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.freedos.org/&quot;&gt;http://www.freedos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; FreeDOS is a free MS-DOS compatible operating system.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; See the &lt;a href=&quot;http://fd-doc.sourceforge.net/wiki/index.php?n=FdDocEn.FdInstall&quot;&gt;manual&lt;/a&gt; for installation details.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.freedos.org/&quot;&gt;http://www.freedos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  FreeDOS je besplatni MS-DOS kompatibilina operacijski sustav.&lt;br/&gt;&lt;b&gt;Bilješka Instalacije:&lt;/b&gt; Pogledati &lt;a href=&quot;http://fd-doc.sourceforge.net/wiki/index.php?n=FdDocEn.FdInstall&quot;&gt;uputstvo&lt;/a&gt;  za detalje instalacije.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="90"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://freenas.org/&quot;&gt;http://www.freenas.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; FreeNAS is an embedded open source NAS (Network-Attached Storage) distribution based on FreeBSD.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The LiveCD version creates a RAM drive for FreeNAS, and uses a FAT formatted floppy disk or USB key for saving the configuration file. The embedded version allows installation to hard disk.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://freenas.org/&quot;&gt;http://www.freenas.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  FreeNAS je ugrađena open source NAS (Network-Attached Storage) distribucija bazirana na FreeBSD.&lt;br/&gt;&lt;b&gt;Napomene Instalacije:&lt;/b&gt; The LiveCD inačica stvara RAM disk za FreeNAS, i koristi a FAT formatiranu disketu ili USB stick za spremanje datoteke postavki. Ugrađena inačica dozvoljava instalaciju na tvrdi disk.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="95"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://frugalware.org/&quot;&gt;http://frugalware.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Frugalware is a general-purpose Slackware-based distro for advanced users.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default option allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://frugalware.org/&quot;&gt;http://frugalware.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Frugalware je general-purpose Slackware-based distribucija za napredne korisnike.&lt;br/&gt;&lt;b&gt;Primjedba Instalacije:&lt;/b&gt; Podrazumijevana postavka dozvoljava obadvije i instalaciju preko interneta (FTP), ili offline instalaciju korištenjem  pre-downloaded installation ISO datoteka.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="100"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.f-secure.com/linux-weblog/&quot;&gt;http://www.f-secure.com/linux-weblog/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; F-Secure Rescue CD detects and removes malware from your Windows installation.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which malware scans can be launched.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.f-secure.com/linux-weblog/&quot;&gt;http://www.f-secure.com/linux-weblog/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  F-Secure Rescue CD otkriva i uklanja malware iz vaše Windows instalacije.&lt;br/&gt;&lt;b&gt;Primjedba Instalacije:&lt;/b&gt; The Live version dozvoljava boot u Live mode, iz kojega se može pokrenuti pretraživanje na malware.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="105"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.gentoo.org/&quot;&gt;http://www.gentoo.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Gentoo is a flexible source-based distribution designed for advanced users.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.gentoo.org/&quot;&gt;http://www.gentoo.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Gentoo je fleksibil ilna distribucija bazirana na izvornom kodu napravljena za napredne korisnike.&lt;br/&gt;&lt;b&gt;Primjedba Instalacije:&lt;/b&gt; The Live inačica dozvoljava boot u Live mode, iz kojega može dodatno pokrenuti instaler.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="115"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; gNewSense is an FSF-endorsed distribution based on Ubuntu with all non-free components removed.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; gNewSense je FSF-endorsed distribucija bazirana na Ubuntu sa svim non-free componentama uklonjenim.&lt;br/&gt;&lt;b&gt;Primjedba Instalacije:&lt;/b&gt; The Live version dozvoljava boot u Live mode, iz kojega se instaler eventualno može pokrenuti.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="120"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://gujin.sourceforge.net/&quot;&gt;http://gujin.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Gujin is a graphical boot manager which can bootstrap various volumes and files.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Gujin simply boots and runs; no installation is required to use it.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://gujin.sourceforge.net/&quot;&gt;http://gujin.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Gujin je grafički boot manager koji može raditi bootstrap raznih i particija i datoteka.&lt;br/&gt;&lt;b&gt;Bilješke Instalacije:&lt;/b&gt; Gujin se jednostavno boot-a i pokreće; instalacije nije nužna za korištenje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="125"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://ftp.kaspersky.com/devbuilds/RescueDisk/&quot;&gt;http://ftp.kaspersky.com/devbuilds/RescueDisk/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Kaspersky Rescue Disk detects and removes malware from your Windows installation.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which malware scans can be launched.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://ftp.kaspersky.com/devbuilds/RescueDisk/&quot;&gt;http://ftp.kaspersky.com/devbuilds/RescueDisk/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Kaspersky Rescue Disk otkriva i uklanja malware iz vaše Windows installacije.&lt;br/&gt;&lt;b&gt;Bilješke Instalacije:&lt;/b&gt; The Live inačica dozvoljava boot u Live mode, iz koje se može pokrenuti pretraživanje na malware.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="130"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.kubuntu.org/&quot;&gt;http://www.kubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Kubuntu is an official Ubuntu derivative featuring the KDE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.kubuntu.org/&quot;&gt;http://www.kubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Kubuntuje službeni Ubuntu derivati koji promovira KDE desktop.&lt;br/&gt;&lt;b&gt;Primjedbe Instalacije:&lt;/b&gt; The Live version dozvoljava boot u Live mode, iz koje se eventualno može pokrenuti instaler. The NetInstall inačica dozvoljava instalaciju preko FTP,  i može instalirati Kubuntu i druge službene Ubuntu derivate. Ako želite koristiti pre-downloaded alternate (ne desktop) install iso, koristiti HdMedia option, i zatim staviti alternativnu iso datoteku u osnovni direktorij vašeg tvrdog diska ili USB sticka</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="135"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://linuxconsole.org/&quot;&gt;http://linuxconsole.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; LinuxConsole is a desktop distro to play games, easy to install, easy to use and fast to boot .&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The 1.0.2009 is latest 1.0 release.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://linuxconsole.org/&quot;&gt;http://linuxconsole.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  LinuxConsole je desktop distro za igranje igara, jednostavnmo za instalaciju, jednostavno za korištenje i boot .&lt;br/&gt;&lt;b&gt;Primjedbe Instalacije:&lt;/b&gt; 1.0.2009 je zadnje 1.0 izdanje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="140"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://linuxmint.com/&quot;&gt;http://linuxmint.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Linux Mint is a user-friendly Ubuntu-based distribution which includes additional proprietary codecs and other software by default.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://linuxmint.com/&quot;&gt;http://linuxmint.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Linux Mint je korisnički prijateljska Ubuntu-based distribucija koja sadrži dodatne vlasničke kodeke i drugi software podrazumijevano.&lt;br/&gt;&lt;b&gt;Primjedbe Instalacije:&lt;/b&gt; The Live inačica dozvoljava boot u Live mode, iz koje se može pokrenuti instaler prema potrebi.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="145"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.mandriva.com/&quot;&gt;http://www.mandriva.com/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Mandriva is a user-friendly distro formerly known as Mandrake Linux.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over the internet (FTP) or via pre-downloaded &lt;a href=&quot;http://www.mandriva.com/en/download&quot;&gt;&quot;Free&quot; iso image files&lt;/a&gt;.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.mandriva.com/&quot;&gt;http://www.mandriva.com/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Mandriva je korisnički prijateljska distribucija poznata kao Mandrake Linux.&lt;br/&gt;&lt;b&gt;Bilješke Instalacije:&lt;/b&gt; The Live inačica dozvoljava boot u Live mode, iz kojega se po potrebi može pokrenuti instaler. The NetInstall inačica dozvoljava instalaciju preko interneta (FTP) ili preko prije skinutih &lt;a href=&quot;http://www.mandriva.com/en/download&quot;&gt;&quot;Free&quot; iso image datoteka&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="151"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.mepis.org/&quot;&gt;http://www.mepis.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; MEPIS is a Debian-based distribution. SimplyMEPIS is a user-friendly version based on KDE, while AntiX is a lightweight version for older computers.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; MEPIS supports booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.mepis.org/&quot;&gt;http://www.mepis.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; MEPIS se zasniva na Debian-u. SimplyMEPIS je inačica prilagođena za početnike, zasnovana na KDE sučelju, dok je AntiX lakša inačica namijenjena starijim računalima.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; MEPIS podržava pokretanje u Live načinu rada, iz kojeg se postavljanje može pokrenuti.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="156"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.netbsd.org/&quot;&gt;http://www.netbsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; NetBSD is a Unix-like operating system which focuses on portability.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt;The default version allows for both installation over the internet (FTP), or using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.netbsd.org/&quot;&gt;http://www.netbsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  NetBSD je Unix-like operativni sustav koji se fokusira naportabilnost.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt;Podrazumijevana inačica dozvoljava instalaciju preko interneta (FTP), ili korištenjem prije skinutih installation ISO datoteka.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="161"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; NimbleX is a small, versatile Slackware-based distribution. It is built using the linux-live scripts, and features the KDE desktop. It can be booted from CD or flash memory (USB pens or MP3 players), and can easily be customized and extended.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NimbleX boots in Live mode.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  NimbleX je mala, svestrana Slackware-based distribucija. Napravljena je korištenjem linux-live skripti, i sadrži KDE desktop. Može se boot-ati sa CD ili flash memorije (USB stikovi ili MP3 playeri),  i može se jednostavn prilagođavati i proširivati.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt;  NimbleX se boot-a u Live mode.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="166"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://home.eunet.no/pnordahl/ntpasswd/bootdisk.html&quot;&gt;http://home.eunet.no/pnordahl/ntpasswd/bootdisk.html&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; The Offline NT Password and Registry Editor can reset Windows passwords and edit the registry on Windows 2000-Vista.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NTPasswd is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://home.eunet.no/pnordahl/ntpasswd/bootdisk.html&quot;&gt;http://home.eunet.no/pnordahl/ntpasswd/bootdisk.html&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; The Offline NT Password i Registry Editor mogu Windows zaporke vratiti u početno stanje i izmjeniti zapisnik u Windows 2000-Vista.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; NTPasswd se pokreće u Live načinu rada; za uporabu nije potrebno postavljanje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="171"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.opensuse.org/&quot;&gt;http://www.opensuse.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; openSUSE is a user-friendly Novell sponsored distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.opensuse.org/&quot;&gt;http://www.opensuse.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; openSUSE je inačica prilagođena zabpočetnike, čiji je pokrovitelj Novell.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Osnovna inačica omogućuje postavljanje putem mreže (FTP), ili izvan mreže korištenjem ISO datoteka.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="176"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://ophcrack.sourceforge.net/&quot;&gt;http://ophcrack.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Ophcrack can crack Windows passwords.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Ophcrack is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://ophcrack.sourceforge.net/&quot;&gt;http://ophcrack.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Ophcrack može otkriti Windows zaporke.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Ophcrack se pokreće u Live načinu rada; za uporabu nije potrebno postavljanje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="181"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://partedmagic.com/&quot;&gt;http://partedmagic.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Parted Magic includes the GParted partition manager and other system utilities which can resize, copy, backup, and manipulate disk partitions.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Parted Magic is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://partedmagic.com/&quot;&gt;http://partedmagic.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Parted Magic uključuje GParted upravitelja odjeljcima i drugim alatima sustava koji mogu mijenjati veličinu, preslikavati, izrađivati sigurnosne preslike, i upravljati odjeljcima diska.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Parted Magic se pokreće u Live načinu rada; za uporabu nije potrebno postavljanje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="186"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.pclinuxos.com/&quot;&gt;http://www.pclinuxos.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; PCLinuxOS is a user-friendly Mandriva-based distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.pclinuxos.com/&quot;&gt;http://www.pclinuxos.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; PCLinuxOS je inačica prilagođena za početnike,a zasniva se na Mandriva-i.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Pokretanjem u Live načinu rada nije potrebno postavljanje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="191"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.puppylinux.com/&quot;&gt;http://www.puppylinux.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Puppy Linux is a lightweight distribution designed for older computers.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.puppylinux.com/&quot;&gt;http://www.puppylinux.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Puppy Linux je lagana distribucija stvirena za starija računala.&lt;br/&gt;&lt;b&gt;Bilješka Instalacije:&lt;/b&gt; The Live inačica učitava cijeli sustav u RAM i boot-a iz memorije, dakle instalacija nije potrebna ali moguća.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="196"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.sabayonlinux.org/&quot;&gt;http://www.sabayonlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Sabayon Linux is a Gentoo-based Live DVD distribution which features the Entropy binary package manager in addition to the source-based Portage.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The LiteMCE edition is 2 GB, while the full edition will need an 8 GB USB drive</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.sabayonlinux.org/&quot;&gt;http://www.sabayonlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Sabayon Linux se zasniva na Gentoo Live DVD inačici koja ističe binarnog upravitelja paketima Entropy, zajedno s sustavom Portage.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Live inačica omogućava pokretanje Live načina rada, iz kojeg  se može pokrenuti postavljanje. LiteMCE je inačica od 2 GB, dok je za cijelo izdanje potreban 8 GB USB medij.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="201"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.slax.org/&quot;&gt;http://www.slax.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Slax is a Slackware-based distribution featuring the KDE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.slax.org/&quot;&gt;http://www.slax.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Slax se zasniva na Slackware-u, a odlikuje ga KDE sučelje.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Live inačica omogućava pokretanje Live načina rada, iz kojeg  se može pokrenuti postavljanje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="206"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; SliTaz is a lightweight, desktop-oriented micro distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  SliTaz je malena, desktop-orientirana micro distribucija.&lt;br/&gt;&lt;b&gt;Napomena instalacije:&lt;/b&gt; The Live inačica učitava cijeli sustav u RAM i boot-a iz  memorije, dakle instalacija nije potrebna ali opcionalna.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="211"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://btmgr.sourceforge.net/about.html&quot;&gt;http://btmgr.sourceforge.net/about.html&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Smart Boot Manager is a bootloader which can overcome some boot-related BIOS limitations and bugs.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; SBM simply boots and runs; no installation is required to use it.</source>
        <translation>&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://btmgr.sourceforge.net/about.html&quot;&gt;http://btmgr.sourceforge.net/about.html&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Smart Boot Manager je bootloader koji može rješiti neka boot-related BIOS ograničenja i greške.&lt;br/&gt;&lt;b&gt;Napomena instalacije:&lt;/b&gt; SBM se jednostavno boot-a i radi; instalacija nije nužna za korištenje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="216"/>
        <location filename="distrovercust.cpp" line="12"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.supergrubdisk.org&quot;&gt;http://www.supergrubdisk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Super Grub Disk is a bootloader which can perform a variety of MBR and bootloader recovery tasks.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; SGD simply boots and runs; no installation is required to use it.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.supergrubdisk.org&quot;&gt;http://www.supergrubdisk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Super Grub Disk je pokretač sustava koji može izvoditi razne MBR i pokretačke zadatke za oporavak.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; SGD se jednostavno pokreće, nije potrebno prethodno postavljanje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="221"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://hacktolive.org/wiki/Super_OS&quot;&gt;http://hacktolive.org/wiki/Super_OS&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Super OS is an unofficial derivative of Ubuntu which includes additional software by default. Requires a 2GB USB drive to install.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://hacktolive.org/wiki/Super_OS&quot;&gt;http://hacktolive.org/wiki/Super_OS&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Super OS je neslužbena inačica Ubuntu-a koja standardno uključuje dodatnu programsku podršku. Zahtjeva 2GB USB medij za postavljanje.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Live inačica omogućava pokretanje u Live načinu rada, iz kojeg je moguće naknadno pokrenuti postavljanje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="226"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.sysresccd.org&quot;&gt;http://www.sysresccd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; SystemRescueCD includes various partition management and data recovery and backup tools.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; SystemRescueCD is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.sysresccd.org&quot;&gt;http://www.sysresccd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; SystemRescueCD uključuje razne alate za upravljanje odjeljcima diska, povrat podataka, te izradu sigurnosnih preslika.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; SystemRescueCD se pokreće u Live načinu rada; nije potrebno prethodno postavljanje.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="231"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu.com/&quot;&gt;http://www.ubuntu.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Ubuntu is a user-friendly Debian-based distribution. It is currently the most popular Linux desktop distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu.com/&quot;&gt;http://www.ubuntu.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Ubuntu je inačica prilagođena za početnike, zasnivana na Debian-u. Trenutno je najpoznatija desktop inačica Linux-a.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Live inačica omogućava pokretanje u Live načinu rada, iz kojeg je moguće naknadno pokrenuti postavljanje. NetInstall inačica omogućava postavljanje putem FTP-a, a može postaviti Kubuntu i druge službene Ubuntu inačice. Ukoliko želite koristiti preuzetu zamjensku (ne desktop) ISO datoteku, koristite HdMedia mogućnost, i tada stavite zamjensku ISO datoteku u korjenski direktorij vašeg čvrstog diska ili USB diska</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="236"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; xPUD is a lightweight distribution featuring a simple kiosk-like interface with a web browser and media player.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; xPUD je lagana inačica koja predstavlja jednostavno kiosk sučelje s web preglednikom i medijskim izvođačem.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Live inačica učita cijeli sustav u RAM i pokreće se iz RAM-a.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="241"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.xubuntu.org/&quot;&gt;http://www.xubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Xubuntu is an official Ubuntu derivative featuring the XFCE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.xubuntu.org/&quot;&gt;http://www.xubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Xubuntu je neslužbena Ubuntu inačica sa XFCE sučeljem.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Live inačica omogućava pokretanje u Live načinu rada, iz kojeg je moguće naknadno pokrenuti postavljanje. NetInstall inačica omogućava postavljanje putem FTP-a, a može postaviti Kubuntu i druge službene Ubuntu inačice. Ukoliko želite koristiti preuzetu zamjensku (ne desktop) ISO datoteku, koristite HdMedia mogućnost, i tada stavite zamjensku ISO datoteku u korjenski direktorij vašeg čvrstog diska ili USB diska</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="246"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.zenwalk.org/&quot;&gt;http://www.zenwalk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Zenwalk is a Slackware-based distribution featuring the XFCE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Početna stranica:&lt;/b&gt; &lt;a href=&quot;http://www.zenwalk.org/&quot;&gt;http://www.zenwalk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Zenwalk je inačica zasnovana na Slackware-u sa XFCE sučeljem.&lt;br/&gt;&lt;b&gt;Upute za postavljanje na računalo:&lt;/b&gt; Live inačica omogućava pokretanje u Live načinu rada, iz kojeg je moguće naknadno pokrenuti postavljanje.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="33"/>
        <source>&lt;img src=&quot;:/eeepclos.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.eeepclinuxos.com/&quot;&gt;http://www.eeepclinuxos.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; EeePCLinuxOS is a user-friendly PCLinuxOS based distribution for the EeePC.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation>&lt;img src=&quot;:/eeepclos.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.eeepclinuxos.com/&quot;&gt;http://www.eeepclinuxos.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  EeePCLinuxOS je korisnički prijateljska distribucija bazirana na PCLinuxOS za EeePC.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; Osigurati se kako je medij prazan i formatiran prije nastavka instalacije.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="41"/>
        <source>&lt;img src=&quot;:/eeeubuntu.png&quot; style=&quot;float:left;&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu-eee.com/&quot;&gt;http://www.ubuntu-eee.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Ubuntu Eee is not only Ubuntu optimized for the Asus Eee PC. It&apos;s an operating system, using the Netbook Remix interface, which favors the best software available instead of open source alternatives (ie. Skype instead of Ekiga).&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation>&lt;img src=&quot;:/eeeubuntu.png&quot; style=&quot;float:left;&quot; /&gt;&lt;br/&gt;&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu-eee.com/&quot;&gt;http://www.ubuntu-eee.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Ubuntu Eee nije samo Ubuntu optimiziran za Asus Eee PC. To je operativni sustav, koji koristi Netbook Remix interface, koji favorizira najwhich favors the best software available ibolji dostupan software umjesto open source alternative (npr. Skype umjesto Ekiga).&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; Osigurati se kako je medij prazan i formatiran prije nastavka instalacije.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="53"/>
        <source>&lt;img src=&quot;:/elive.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Elive is a Debian-based distribution featuring the Enlightenment window manager.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;img src=&quot;:/elive.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Elive je Debian-based distribucija koja promovira Enlightenment window manager.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; The Live version dozvoljava booting u Live mode, iz kojega se prema potrebi može pokrenuti installer.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="61"/>
        <source>&lt;img src=&quot;:/kiwi_logo_ro.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.kiwilinux.org/&quot;&gt;http://www.kiwilinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Kiwi Linux is an Ubuntu derivative primarily made for Romanian, Hungarian and English speaking users.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation>&lt;img src=&quot;:/kiwi_logo_ro.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.kiwilinux.org/&quot;&gt;http://www.kiwilinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  Kiwi Linux je Ubuntu derivative prvotno napravljen za korisnike koji govore Rumunjski, Mađarski i Engleski.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; Osigurati prazan i formatiran medij prije nastavka instalacije.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="69"/>
        <source>&lt;img src=&quot;:/gnewsense.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; gNewSense is a high-quality GNU/Linux distribution that extends and improves Ubuntu to create a completely free operating system without any binary blobs or package trees that contain proprietary software.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation>&lt;img src=&quot;:/gnewsense.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  gNewSense je visokokvalitetna GNU/Linux distribucija koja proširuje i poboljšava Ubuntu stvarajući potpuno slobodan operacijski sustav bez bilokakvih binary blobs ili stabla paketa koji sadrže proprietary software.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; Osigurati prazan i formatiran medij prije nastavka instalacije.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="77"/>
        <source>&lt;img src=&quot;:/nimblex.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; NimbleX is a small, versatile Slackware-based distribution. It is built using the linux-live scripts, and features the KDE desktop. It can be booted from CD or flash memory (USB pens or MP3 players), and can easily be customized and extended.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NimbleX boots in Live mode.</source>
        <translation>&lt;img src=&quot;:/nimblex.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Web stranica:&lt;/b&gt;  &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  NimbleX je mala, svestranae Slackware-based distribucija. Stvorena je korištenjem linux-live scripts,  i promovira KDE desktop. Može biti  boot-ana iz CD ili flash memorije (USB stickovi ili MP3 playeri), i može biti jednostavno prilagođavana i proširivana.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt;  NimbleX se boot-a u Live mode.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="85"/>
        <source>&lt;img src=&quot;:/slitaz.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; SliTaz is a lightweight, desktop-oriented micro distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional. This installer is based on &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;.</source>
        <translation>&lt;img src=&quot;:/slitaz.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  SliTaz je lightweight, desktop-oriented micro distribution.&lt;br/&gt;&lt;b&gt;Napomene Instalacije:&lt;/b&gt; The Live version učitava čitav sustav u RAM i boot-a iz memorije, dakle instalacija nije nužna ali je moguća. Ovaj installer se bazira na &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="93"/>
        <source>&lt;img src=&quot;:/xpud.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; xPUD is a lightweight distribution featuring a simple kiosk-like interface with a web browser and media player.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory.</source>
        <translation>&lt;img src=&quot;:/xpud.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Web stranica:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt;  xPUD je lightweight distribution koja promovira jednostavni kiosk-like interface sa preglednikom interneta i media player.&lt;br/&gt;&lt;b&gt;Napomena Instalacije:&lt;/b&gt; The Live version učitava cijeli sustav u RAM i boot-a iz  memorije.</translation>
    </message>
</context>
<context>
    <name>unetbootinui</name>
    <message>
        <location filename="unetbootin.ui" line="20"/>
        <source>Unetbootin</source>
        <translation>Unetbootin</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="44"/>
        <location filename="unetbootin.ui" line="65"/>
        <source>Select from a list of supported distributions</source>
        <translation>Odabrati iz liste podržanih distribucija</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="47"/>
        <source>&amp;Distribution</source>
        <translation>&amp;Distribucija</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="131"/>
        <source>Specify a disk image file to load</source>
        <translation>Odrediti image datoteku diska za učitavanje</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="134"/>
        <source>Disk&amp;image</source>
        <translation>Disk&amp;image</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="147"/>
        <source>Manually specify a kernel and initrd to load</source>
        <translation>Odrediti ručno kernel i initrd za učitavanje</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="150"/>
        <source>&amp;Custom</source>
        <translation>&amp;Podešeno</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="414"/>
        <location filename="unetbootin.ui" line="430"/>
        <source>Space to reserve for user files which are preserved across reboots. Works only for LiveUSBs for Ubuntu and derivatives. If value exceeds drive capacity, the maximum space available will be used.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="417"/>
        <source>Space used to preserve files across reboots (Ubuntu only):</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="440"/>
        <source>MB</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="503"/>
        <source>OK</source>
        <translation>U redu</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="506"/>
        <source>Return</source>
        <translation>Return</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="513"/>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="516"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="561"/>
        <source>Reboot Now</source>
        <translation>Restart Sada</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="568"/>
        <source>Exit</source>
        <translation>Izlaz</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="660"/>
        <source>1. Downloading Files</source>
        <translation>Skidanje Datoteka</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="667"/>
        <source>2. Extracting and Copying Files</source>
        <translation>Otpakiravanje i Kopiranje Datoteka</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="674"/>
        <source>3. Installing Bootloader</source>
        <translation>Instalacija Bootloader-a</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="681"/>
        <source>4. Installation Complete, Reboot</source>
        <translation>Instalacija Potpuna, Restart</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="477"/>
        <location filename="unetbootin.ui" line="496"/>
        <source>Select the target drive to install to</source>
        <translation>Odabrati ciljni disk za instalaciju</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="480"/>
        <source>Dri&amp;ve:</source>
        <translation>D&amp;isk</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="451"/>
        <location filename="unetbootin.ui" line="470"/>
        <source>Select the installation target type</source>
        <translation>Odabrati ciljni tip instalacije</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="454"/>
        <source>&amp;Type:</source>
        <translation>&amp;Tip:</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="81"/>
        <source>Select the distribution version</source>
        <translation>Odabrati inačicu distribucije</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="347"/>
        <source>Select disk image file</source>
        <translation>Odbarati datoteku diskovnog image-a</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="286"/>
        <location filename="unetbootin.ui" line="350"/>
        <location filename="unetbootin.ui" line="375"/>
        <location filename="unetbootin.ui" line="400"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="188"/>
        <source>Select the disk image type</source>
        <translation>Odabrati tip diskovnog image-a</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="243"/>
        <source>Specify a floppy/hard disk image, or CD image (ISO) file to load</source>
        <translation>Zadati disketni image/image tvrdog diska, ili CD image (ISO) datoteku za učitavanje</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="207"/>
        <location filename="unetbootin.ui" line="258"/>
        <source>Specify a kernel file to load</source>
        <translation>Zadati kernel datoteku za učitavanje</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="283"/>
        <source>Select kernel file</source>
        <translation>Odabrati kernel datoteku</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="293"/>
        <location filename="unetbootin.ui" line="312"/>
        <source>Specify an initrd file to load</source>
        <translation>Zadati initrd datoteku za učitavanje</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="372"/>
        <source>Select initrd file</source>
        <translation>Odabrati initrd datoteku</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="397"/>
        <source>Select syslinux.cfg or isolinux.cfg file</source>
        <translation>Odabrati syslinux.cfg ili isolinux.cfg datoteku</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="226"/>
        <location filename="unetbootin.ui" line="321"/>
        <source>Specify parameters and options to pass to the kernel</source>
        <translation>Zadati parametre i opcije koji će se slati kernelu</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="210"/>
        <source>&amp;Kernel:</source>
        <translation>&amp;Kernel:</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="296"/>
        <source>Init&amp;rd:</source>
        <translation>Init&amp;rd</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="229"/>
        <source>&amp;Options:</source>
        <translation>&amp;Opcije:</translation>
    </message>
</context>
<context>
    <name>uninstaller</name>
    <message>
        <location filename="main.cpp" line="156"/>
        <source>Uninstallation Complete</source>
        <translation>Deinstalacija Završena</translation>
    </message>
    <message>
        <location filename="main.cpp" line="157"/>
        <source>%1 has been uninstalled.</source>
        <translation>%1 je deinstalirano.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="319"/>
        <source>Must run as root</source>
        <translation>Nužno pokretanje kao root</translation>
    </message>
    <message>
        <location filename="main.cpp" line="321"/>
        <source>%2 must be run as root. Close it, and re-run using either:&lt;br/&gt;&lt;b&gt;sudo %1&lt;/b&gt;&lt;br/&gt;or:&lt;br/&gt;&lt;b&gt;su - -c &apos;%1&apos;&lt;/b&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="main.cpp" line="353"/>
        <source>%1 Uninstaller</source>
        <translation>%1 Deinstaler</translation>
    </message>
    <message>
        <location filename="main.cpp" line="354"/>
        <source>%1 is currently installed. Remove the existing version?</source>
        <translation>%1 je trenutno instalirano. Ukloniti postojeću inačicu?</translation>
    </message>
</context>
</TS>
