<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl_PL">
<context>
    <name></name>
    <message>
        <source></source>
        <translatorcomment>Polish translation for unetbootin
Copyright (c) 2009 Rosetta Contributors and Canonical Ltd 2009
This file is distributed under the same license as the unetbootin package.
FIRST AUTHOR &lt;EMAIL@ADDRESS&gt;, 2009.

</translatorcomment>
        <translation>Project-Id-Version: unetbootin
Report-Msgid-Bugs-To: FULL NAME &lt;EMAIL@ADDRESS&gt;
POT-Creation-Date: 2011-04-01 15:37-0400
PO-Revision-Date: 2011-04-01 20:48+0000
Last-Translator: Portals94 &lt;Unknown&gt;
Language-Team: Polish &lt;pl@li.org&gt;
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
X-Launchpad-Export-Date: 2011-04-02 17:48+0000
X-Generator: Launchpad (build 12710)
</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="main.cpp" line="266"/>
        <source>LeftToRight</source>
        <translation>od lewej do prawej</translation>
    </message>
</context>
<context>
    <name>unetbootin</name>
    <message>
        <location filename="unetbootin.cpp" line="202"/>
        <location filename="unetbootin.cpp" line="296"/>
        <location filename="unetbootin.cpp" line="297"/>
        <location filename="unetbootin.cpp" line="364"/>
        <location filename="unetbootin.cpp" line="480"/>
        <location filename="unetbootin.cpp" line="3185"/>
        <location filename="unetbootin.cpp" line="3198"/>
        <location filename="unetbootin.cpp" line="3370"/>
        <location filename="unetbootin.cpp" line="3962"/>
        <source>Hard Disk</source>
        <translation>Dysk twardy</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="204"/>
        <location filename="unetbootin.cpp" line="293"/>
        <location filename="unetbootin.cpp" line="294"/>
        <location filename="unetbootin.cpp" line="366"/>
        <location filename="unetbootin.cpp" line="484"/>
        <location filename="unetbootin.cpp" line="649"/>
        <location filename="unetbootin.cpp" line="669"/>
        <location filename="unetbootin.cpp" line="923"/>
        <location filename="unetbootin.cpp" line="1454"/>
        <location filename="unetbootin.cpp" line="1516"/>
        <location filename="unetbootin.cpp" line="2435"/>
        <location filename="unetbootin.cpp" line="2477"/>
        <location filename="unetbootin.cpp" line="3189"/>
        <location filename="unetbootin.cpp" line="3215"/>
        <location filename="unetbootin.cpp" line="3374"/>
        <location filename="unetbootin.cpp" line="3697"/>
        <location filename="unetbootin.cpp" line="3966"/>
        <source>USB Drive</source>
        <translation>Napęd USB</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="205"/>
        <location filename="unetbootin.cpp" line="222"/>
        <location filename="unetbootin.cpp" line="223"/>
        <location filename="unetbootin.cpp" line="332"/>
        <location filename="unetbootin.cpp" line="600"/>
        <location filename="unetbootin.cpp" line="601"/>
        <location filename="unetbootin.cpp" line="3268"/>
        <source>ISO</source>
        <translation>Plik ISO</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="206"/>
        <location filename="unetbootin.cpp" line="218"/>
        <location filename="unetbootin.cpp" line="219"/>
        <location filename="unetbootin.cpp" line="337"/>
        <location filename="unetbootin.cpp" line="605"/>
        <location filename="unetbootin.cpp" line="606"/>
        <location filename="unetbootin.cpp" line="3260"/>
        <source>Floppy</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="239"/>
        <location filename="unetbootin.cpp" line="245"/>
        <location filename="unetbootin.cpp" line="249"/>
        <location filename="unetbootin.cpp" line="253"/>
        <location filename="unetbootin.cpp" line="259"/>
        <location filename="unetbootin.cpp" line="287"/>
        <source>either</source>
        <translation>którykolwiek</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="266"/>
        <source>LiveUSB persistence</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="281"/>
        <source>FAT32-formatted USB drive</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="285"/>
        <source>EXT2-formatted USB drive</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="597"/>
        <source>Open Disk Image File</source>
        <translation>Otwórz plik obrazu dysku</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="597"/>
        <source>All Files</source>
        <translation>Wszystkie pliki</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="615"/>
        <location filename="unetbootin.cpp" line="623"/>
        <location filename="unetbootin.cpp" line="631"/>
        <source>All Files (*)</source>
        <translation>Wszystkie pliki (*)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="615"/>
        <source>Open Kernel File</source>
        <translation>Otwórz plik jądra</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="623"/>
        <source>Open Initrd File</source>
        <translation>Otwórz plik initrd</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="631"/>
        <source>Open Bootloader Config File</source>
        <translation>Otwórz plik konfiguracyjny bootloadera</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="653"/>
        <source>Insert a USB flash drive</source>
        <translation>Włóż napęd flash USB</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="654"/>
        <source>No USB flash drives were found. If you have already inserted a USB drive, try reformatting it as FAT32.</source>
        <translation>Nie znaleziono napędu flash USB. Jeśli już włożyłeś napęd USB spróbuj sformatować go w systemie plików FAT32.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="673"/>
        <source>%1 not mounted</source>
        <translation>%1 nie został zamontowany</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="674"/>
        <source>You must first mount the USB drive %1 to a mountpoint. Most distributions will do this automatically after you remove and reinsert the USB drive.</source>
        <translation>Najpierw musisz zamontować dysk USB %1 w punkcie montowania. Większość dystrybucji robi to automatycznie po odłączeniu i podłączeniu dysku USB.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="689"/>
        <source>Select a distro</source>
        <translation>Wybierz dystrybucję</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="690"/>
        <source>You must select a distribution to load.</source>
        <translation>Wybierz dystrybucję do załadowania.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="704"/>
        <source>Select a disk image file</source>
        <translation>Wybierz plik obrazu dysku</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="705"/>
        <source>You must select a disk image file to load.</source>
        <translation>Wybierz plik obrazu dysku do załadowania.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="719"/>
        <source>Select a kernel and/or initrd file</source>
        <translation>Wybierz plik jądra i/lub initrd</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="720"/>
        <source>You must select a kernel and/or initrd file to load.</source>
        <translation>Wybierz jądro i/lub plik initrd do załadowania.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="734"/>
        <source>Diskimage file not found</source>
        <translation>Plik obrazu dysku nie został znaleziony</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="735"/>
        <source>The specified diskimage file %1 does not exist.</source>
        <translation>Wskazany plik obrazu dysku %1 nie istnieje.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="749"/>
        <source>Kernel file not found</source>
        <translation>Plik jądra nie został znaleziony</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="750"/>
        <source>The specified kernel file %1 does not exist.</source>
        <translation>Wybrany plik jądra %1 nie istnieje.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="764"/>
        <source>Initrd file not found</source>
        <translation>Plik initrd nie został znaleziony</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="765"/>
        <source>The specified initrd file %1 does not exist.</source>
        <translation>Wybrany plik initrd %1 nie istnieje.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="869"/>
        <source>%1 exists, overwrite?</source>
        <translation>%1 istnieje. Nadpisać?</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="870"/>
        <source>The file %1 already exists. Press &apos;Yes to All&apos; to overwrite it and not be prompted again, &apos;Yes&apos; to overwrite files on an individual basis, and &apos;No&apos; to retain your existing version. If in doubt, press &apos;Yes to All&apos;.</source>
        <translation>Plik  %1 już istnieje. Naciśnij &quot;Tak dla wszystkich&quot;, aby go nadpisać i nie być pytanym przy następnych. Naciśnij &quot;Tak&quot;, aby być każdorazowo pytanym o nadpisanie pliku. Naciśnij &quot;Nie&quot;, aby zachować istniejącą wersję pliku. W razie wątpliwości naciśnij &quot;Tak dla wszystkich&quot;.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="896"/>
        <source>%1 is out of space, abort installation?</source>
        <translation>Na %1 zabrakło miejsca. Przerwać instalację?</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="897"/>
        <source>The directory %1 is out of space. Press &apos;Yes&apos; to abort installation, &apos;No&apos; to ignore this error and attempt to continue installation, and &apos;No to All&apos; to ignore all out-of-space errors.</source>
        <translation>W katalogu %1 zabrakło miejsca. Naciśnij &quot;Tak&quot;, aby przerwać instalację; &quot;Nie&quot;, aby zignorować ten błąd i spróbować kontynuować instalację; &quot;Nie dla wszystkich&quot;, aby zignorować wszystkie komunikaty o braku miejsca.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="991"/>
        <source>Locating kernel file in %1</source>
        <translation>Lokalizowanie pliku jądra w %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1032"/>
        <source>Copying kernel file from %1</source>
        <translation>Kopiowanie pliku jądra z %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1038"/>
        <source>Locating initrd file in %1</source>
        <translation>Lokalizowanie pliku initrd w %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1079"/>
        <source>Copying initrd file from %1</source>
        <translation>Kopiowanie pliku initrd z %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1085"/>
        <location filename="unetbootin.cpp" line="1145"/>
        <source>Extracting bootloader configuration</source>
        <translation>Rozpakowywanie konfiguracji programu rozruchowego</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1360"/>
        <location filename="unetbootin.cpp" line="1386"/>
        <source>&lt;b&gt;Extracting compressed iso:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Rozpakowuję spakowane iso:&lt;/b&gt; %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1615"/>
        <source>Copying file, please wait...</source>
        <translation>Kopiowanie plików, proszę czekać...</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1616"/>
        <location filename="unetbootin.cpp" line="2420"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</source>
        <translation>&lt;b&gt;Źródło:&lt;/b&gt; &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1617"/>
        <location filename="unetbootin.cpp" line="2421"/>
        <source>&lt;b&gt;Destination:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Miejsce docelowe:&lt;/b&gt; %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1618"/>
        <source>&lt;b&gt;Copied:&lt;/b&gt; 0 bytes</source>
        <translation>&lt;b&gt;Skopiowano:&lt;/b&gt; 0 bajtów</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1656"/>
        <source>Extracting files, please wait...</source>
        <translation>Rozpakowuję pliki, proszę czekać...</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1657"/>
        <source>&lt;b&gt;Archive:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;Archiwum:&lt;/b&gt; %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1658"/>
        <source>&lt;b&gt;Source:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Źródło:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1659"/>
        <source>&lt;b&gt;Destination:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Miejsce docelowe:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1660"/>
        <source>&lt;b&gt;Extracted:&lt;/b&gt; 0 of %1 files</source>
        <translation>&lt;b&gt;Rozpakowano:&lt;/b&gt; 0 z %1 plików</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1663"/>
        <source>&lt;b&gt;Source:&lt;/b&gt; %1 (%2)</source>
        <translation>&lt;b&gt;Źródło:&lt;/b&gt; %1 (%2)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1664"/>
        <source>&lt;b&gt;Destination:&lt;/b&gt; %1%2</source>
        <translation>&lt;b&gt;Miejsce docelowe:&lt;/b&gt; %1%2</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="1665"/>
        <source>&lt;b&gt;Extracted:&lt;/b&gt; %1 of %2 files</source>
        <translation>&lt;b&gt;Rozpakowano:&lt;/b&gt; %1 z %2 plików</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2419"/>
        <source>Downloading files, please wait...</source>
        <translation>Pobieram pliki, proszę czekać...</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2422"/>
        <source>&lt;b&gt;Downloaded:&lt;/b&gt; 0 bytes</source>
        <translation>&lt;b&gt;Pobrano:&lt;/b&gt; 0 bajtów</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2499"/>
        <location filename="unetbootin.cpp" line="2514"/>
        <source>&lt;b&gt;Downloaded:&lt;/b&gt; %1 of %2</source>
        <translation>&lt;b&gt;Pobrano:&lt;/b&gt; %1 z %2</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2529"/>
        <source>&lt;b&gt;Copied:&lt;/b&gt; %1 of %2</source>
        <translation>&lt;b&gt;Skopiowano:&lt;/b&gt; %1 z %2</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2605"/>
        <source>Searching in &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</source>
        <translation>Szukam w &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2609"/>
        <source>%1/%2 matches in &lt;a href=&quot;%3&quot;&gt;%3&lt;/a&gt;</source>
        <translation>%1/%2 pasuje w &lt;a href=&quot;%3&quot;&gt;%3&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2882"/>
        <source>%1 not found</source>
        <translation>Nie znaleziono %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="2883"/>
        <source>%1 not found. This is required for %2 install mode.
Install the &quot;%3&quot; package or your distribution&apos;s equivalent.</source>
        <translation>%1 nie znaleziono. Wymagane, gdy tryb instalacji to: %2.
Zainstaluj pakiet &quot;%3&quot; lub odpowiednik dla Twojej dystrybucji.</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3166"/>
        <source>(Current)</source>
        <translation>(Bieżący)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3167"/>
        <source>(Done)</source>
        <translation>(Zrobiony)</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3449"/>
        <source>Configuring grub2 on %1</source>
        <translation>Konfiguruję grub2 na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3461"/>
        <source>Configuring grldr on %1</source>
        <translation>Konfiguruję grldr na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3489"/>
        <source>Configuring grub on %1</source>
        <translation>Konfiguruję grub na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3726"/>
        <source>Installing syslinux to %1</source>
        <translation>Instaluję syslinux na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3761"/>
        <source>Installing extlinux to %1</source>
        <translation>Instaluję extlinux na %1</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3921"/>
        <source>Syncing filesystems</source>
        <translation>Synchronizacja systemów plików</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3926"/>
        <source>Setting up persistence</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3964"/>
        <source>After rebooting, select the </source>
        <translation>Po ponownym uruchomieniu komputera wybierz </translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3969"/>
        <source>After rebooting, select the USB boot option in the BIOS boot menu.%1
Reboot now?</source>
        <translation>Po ponownym uruchomieniu komputera wybierz opcję bootowania z USB w menu bootowania znajdującym się w BIOSie.%1
Uruchomić ponownie komputer?</translation>
    </message>
    <message>
        <location filename="unetbootin.cpp" line="3972"/>
        <source>The created USB device will not boot off a Mac. Insert it into a PC, and select the USB boot option in the BIOS boot menu.%1</source>
        <translation></translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="41"/>
        <source>
*IMPORTANT* Before rebooting, place an Ubuntu alternate (not desktop) install iso file on the root directory of your hard drive or USB drive. These can be obtained from cdimage.ubuntu.com</source>
        <translation>
*WAŻNE* Przed ponownym uruchomieniem systemu umieść plik instalacyjny obrazu iso Ubuntu w wersji alternate (nie desktop) w katalogu root Twojego dysku twardego lub napędu usb. Może on zostać pobrany ze strony cdimage.ubuntu.com</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="232"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;mirrors.kernel.org&apos; when prompted for a server, and enter &apos;/centos/%1/os/%2&apos; when asked for the folder.</source>
        <translation>
*WAŻNE* Po restarcie zignoruj wszystkie komunikaty błędów i wybierz powrót jeśli pojawi się pytanie o płytę CD. Później przejdź do głównego menu, wybierz opcję &apos;Uruchom instalację&apos;, wybierz &apos;Sieć&apos; jako źródło, wybierz &apos;HTTP&apos; jako protokół, wpisz &apos;mirrors.kernel.org&apos; przy pytaniu o serwer oraz wpisz &apos;/centos/%1/os/%2&apos; gdy zostaniesz zapytany o katalog.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="288"/>
        <source>
*IMPORTANT* Before rebooting, place a Debian install iso file on the root directory of your hard drive or USB drive. These can be obtained from cdimage.debian.org</source>
        <translation>
*WAŻNE* Przed ponownym uruchomieniem systemu umieść plik instalacyjny obrazu iso Debiana w katalogu root Twojego dysku twardego lub napędu usb. Może on zostać pobrany ze strony cdimage.debian.org</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="381"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.fedora.redhat.com&apos; when prompted for a server, and enter &apos;/pub/fedora/linux/development/%1/os&apos; when asked for the folder.</source>
        <translation>
*WAŻNE* Po restarcie zignoruj wszystkie komunikaty błędów i wybierz powrót jeśli pojawi się pytanie o płytę CD. Później przejdź do głównego menu, wybierz opcję &apos;Uruchom instalację&apos;, wybierz &apos;Sieć&apos; jako źródło, wybierz &apos;HTTP&apos; jako protokół, wpisz &apos;download.fedora.redhat.com&apos; przy pytaniu o serwer oraz wpisz &apos;/pub/fedora/linux/development/%1/os&apos; gdy zostaniesz zapytany o katalog.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="387"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.fedora.redhat.com&apos; when prompted for a server, and enter &apos;/pub/fedora/linux/releases/%1/Fedora/%2/os&apos; when asked for the folder.</source>
        <translation>
*WAŻNE* Po restarcie zignoruj wszystkie komunikaty błędów i wybierz powrót jeśli pojawi się pytanie o płytę CD. Później przejdź do głównego menu, wybierz opcję &apos;Uruchom instalację&apos;, wybierz &apos;Sieć&apos; jako źródło, wybierz &apos;HTTP&apos; jako protokół, wpisz &apos;download.fedora.redhat.com&apos;&apos; przy pytaniu o serwer oraz wpisz &apos;/pub/fedora/linux/releases/%1/Fedora/%2/os&apos; gdy zostaniesz zapytany o katalog.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="747"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.opensuse.org&apos; when prompted for a server, and enter &apos;/factory/repo/oss&apos; when asked for the folder.</source>
        <translation>
*WAŻNE* Po restarcie zignoruj wszystkie komunikaty błędów i wybierz powrót jeśli pojawi się pytanie o płytę CD. Później przejdź do głównego menu, wybierz opcję &apos;Uruchom instalację&apos;, wybierz &apos;Sieć&apos; jako źródło, wybierz &apos;HTTP&apos; jako protokół, wpisz &apos;download.opensuse.org&apos;&apos; przy pytaniu o serwer oraz wpisz &apos;/factory/repo/oss&apos; gdy zostaniesz zapytany o katalog.</translation>
    </message>
    <message>
        <location filename="distrolst.cpp" line="753"/>
        <source>
*IMPORTANT* After rebooting, ignore any error messages and select back if prompted for a CD, then go to the main menu, select the &apos;Start Installation&apos; option, choose &apos;Network&apos; as the source, choose &apos;HTTP&apos; as the protocol, enter &apos;download.opensuse.org&apos; when prompted for a server, and enter &apos;/distribution/%1/repo/oss&apos; when asked for the folder.</source>
        <translation>
*WAŻNE* Po restarcie zignoruj wszystkie komunikaty błędów i wybierz powrót jeśli pojawi się pytanie o płytę CD. Później przejdź do głównego menu, wybierz opcję &apos;Uruchom instalację&apos;, wybierz &apos;Sieć&apos; jako źródło, wybierz &apos;HTTP&apos; jako protokół, wpisz &apos;download.opensuse.org&apos;&apos; przy pytaniu o serwer oraz wpisz &apos;/distribution/%1/repo/oss&apos; gdy zostaniesz zapytany o katalog.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="23"/>
        <location filename="unetbootin.cpp" line="685"/>
        <source>== Select Distribution ==</source>
        <translation>== Wybierz dystrybucję ==</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="23"/>
        <location filename="distrover.cpp" line="27"/>
        <source>== Select Version ==</source>
        <translation>== Wybierz wersję ==</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="24"/>
        <source>Welcome to &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;, the Universal Netboot Installer. Usage:&lt;ol&gt;&lt;li&gt;Select a distribution and version to download from the list above, or manually specify files to load below.&lt;/li&gt;&lt;li&gt;Select an installation type, and press OK to begin installing.&lt;/li&gt;&lt;/ol&gt;</source>
        <translation>Witaj w &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;, Universal Netboot Installer. Użycie:&lt;ol&gt;&lt;li&gt;Wybierz dystrybucję i wersję do pobrania z listy powyżej, albo określ poniżej ręcznie pliki do załadowania.&lt;/li&gt;&lt;li&gt;Wybierz typ instalacji i naciśnij OK aby rozpocząć instalację.&lt;/li&gt;&lt;/ol&gt;</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="29"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.archlinux.org/&quot;&gt;http://www.archlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Arch Linux is a lightweight distribution optimized for speed and flexibility.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for installation over the internet (FTP).</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.archlinux.org/&quot;&gt;http://www.archlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Arch Linux jest lekką dystrybucją zoptymalizowaną pod kątem szybkości i elastyczności.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Domyślna wersja umożliwia instalację poprzez Internet (FTP).</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="34"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.backtrack-linux.org/&quot;&gt;http://www.backtrack-linux.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; BackTrack is a distribution focused on network analysis and penetration testing.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; BackTrack is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.backtrack-linux.org/&quot;&gt;http://www.backtrack-linux.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; BackTrack jest dystrybucją skupioną na analizie sieci i testach przepływu danych.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; BackTrack uruchamiany jest w trybie live; aby z niego korzystać nie jest konieczna instalacja.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="39"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.centos.org/&quot;&gt;http://www.centos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; CentOS is a free Red Hat Enterprise Linux clone.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.centos.org/&quot;&gt;http://www.centos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; CentOS jest darmowym klonem Linux Red Hat Enterprise.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja domyślna pozwala zarówno na instalację przez Internet (FTP), jak i z uprzednio pobranych instalacyjnych plików ISO.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="44"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://clonezilla.org/&quot;&gt;http://clonezilla.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; CloneZilla is a distribution used for disk backup and imaging.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; CloneZilla is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://clonezilla.org/&quot;&gt;http://clonezilla.org/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; CloneZilla jest dystrybucją  używaną do backupów/klonowania dysków.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; CloneZilla uruchamia się i działa w trybie live, czyli aby jej używać nie jest wymagana instalacja.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="49"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://damnsmalllinux.org/&quot;&gt;http://damnsmalllinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Damn Small Linux is a minimalist distribution designed for older computers.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://damnsmalllinux.org/&quot;&gt;http://damnsmalllinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Damn Small Linux to minimalistyczna dystrybucja zaprojektowana z myślą o starszych komputerach.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live ładuje cały system do pamięci RAM i z niej się uruchamia, dlatego instalacja nie jest wymagana, chociaż jest możliwa.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="54"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.debian.org/&quot;&gt;http://www.debian.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Debian is a community-developed Linux distribution that supports a wide variety of architectures and offers a large repository of packages.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The NetInstall version allows for installation over FTP. If you would like to use a pre-downloaded install iso, use the HdMedia option, and then place the install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.debian.org/&quot;&gt;http://www.debian.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Debian jest dystrybucją Linuksa rozwijaną przez społeczność, odznaczającą się wsparciem dla wielu architektur i oferującą duże repozytoria z pakietami oprogramowania.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja NetInstall umożliwia instalację poprzez FTP. Jeśli chcesz użyć pobrane instalacyjne obrazy iso, użyj opcji HdMedia, a następnie umieść plik instalacyjny iso w katalogu root Twojego dysku twardego lub napędu USB.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="60"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.dreamlinux.com.br/&quot;&gt;http://www.dreamlinux.com.br&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Dreamlinux is a user-friendly Debian-based distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.dreamlinux.com.br/&quot;&gt;http://www.dreamlinux.com.br&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Dreamlinux jest przyjazną użytkownikowi dystrybucją Linuksa, opartą na Debianie.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie live, w którym można opcjonalnie uruchomić instalatora.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="65"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.freedrweb.com/livecd&quot;&gt;http://www.freedrweb.com/livecd&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Dr.Web AntiVirus is an anti-virus emergency kit to restore a system that broke due to malware.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which malware scans can be launched.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.freedrweb.com/livecd&quot;&gt;http://www.freedrweb.com/livecd&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Dr.Web AntiVirus to antywirusowe narzędzie przywracające do działania systemy dotknięte złośliwym oprogramowaniem.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie live, w którym można przeprowadzić skanowanie.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="70"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Elive is a Debian-based distribution featuring the Enlightenment window manager.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Elive jest dystrybucją opartą na Debianie zawierającą menedżer okien Enlightenment.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja live umożliwia uruchomienie systemu w trybie live, z poziomu którego może zostać uruchomiony program instalujący.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="75"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://fedoraproject.org/&quot;&gt;http://fedoraproject.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Fedora is a Red Hat sponsored community distribution which showcases the latest cutting-edge free/open-source software.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://fedoraproject.org/&quot;&gt;http://fedoraproject.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Fedora to sponsorowana przez Red Hata dystrybucja tworzona przez społeczność, która prezentuje najnowsze i najnowocześniejsze darmowe/otwarte oprogramowanie.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie live, w którym, opcjonalnie, można uruchomić instalatora. Wersja NetInstall pozwala zarówno na instalację przez Internet (FTP), jak i z uprzednio pobranych plików instalacyjnych ISO.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="80"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.freebsd.org/&quot;&gt;http://www.freebsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; FreeBSD is a general-purpose Unix-like operating system designed for scalability and performance.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.freebsd.org/&quot;&gt;http://www.freebsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; FreeBSD jest Unixopodobnym systemem operacyjnym przeznaczonym do ogólnego użytku, zaprojektowanym pod kątem skalowalności i wydajności.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Domyślna wersja pozwala zarówno na instalację poprzez Internet (FTP), jak i na instalację w trybie off-line za pośrednictwem pobranych plików instalacyjnych ISO.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="85"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.freedos.org/&quot;&gt;http://www.freedos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; FreeDOS is a free MS-DOS compatible operating system.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; See the &lt;a href=&quot;http://fd-doc.sourceforge.net/wiki/index.php?n=FdDocEn.FdInstall&quot;&gt;manual&lt;/a&gt; for installation details.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.freedos.org/&quot;&gt;http://www.freedos.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; FreeDOS jest darmowym systemem operacyjnym kompatybilnym z MS-DOS.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Zobacz &lt;a href=&quot;http://fd-doc.sourceforge.net/wiki/index.php?n=FdDocEn.FdInstall&quot;&gt;podręcznik&lt;/a&gt; zawierający szczegóły dotyczące instalacji.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="90"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://freenas.org/&quot;&gt;http://www.freenas.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; FreeNAS is an embedded open source NAS (Network-Attached Storage) distribution based on FreeBSD.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The LiveCD version creates a RAM drive for FreeNAS, and uses a FAT formatted floppy disk or USB key for saving the configuration file. The embedded version allows installation to hard disk.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://freenas.org/&quot;&gt;http://www.freenas.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; FreeNAS jest osadzoną dystrybucją opartą na FreeBSD otwartoźródłowego NAS (Network-Attached Storage).&lt;br/&gt;&lt;b&gt;Informacje instalacyjne:&lt;/b&gt; Wersja LiveCD tworzy napęd RAM dla FreeNAS i używa dyskietki sformatowanej w trybie FAT lub klucza USB do zapisywania pliku konfiguracyjnego. Osadzona wersja umożliwia instalację na dysku twardym.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="95"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://frugalware.org/&quot;&gt;http://frugalware.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Frugalware is a general-purpose Slackware-based distro for advanced users.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default option allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://frugalware.org/&quot;&gt;http://frugalware.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Frugalware jest opartą na Slackware dystrybucją przeznaczoną do ogólnych zadań dla zaawansowanych użytkowników.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Domyślne rozwiązanie przewiduje zarówno instalację poprzez Internet (FTP), jak również instalację za pomocą wcześniej już pobranej wersji instalacyjnej zawartej w pliku ISO.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="100"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.f-secure.com/linux-weblog/&quot;&gt;http://www.f-secure.com/linux-weblog/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; F-Secure Rescue CD detects and removes malware from your Windows installation.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which malware scans can be launched.</source>
        <translation>&lt;b&gt;Strona internetowa:&lt;/b&gt; &lt;a href=&quot;http://www.f-secure.com/linux-weblog/&quot;&gt;http://www.f-secure.com/linux-weblog/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; F-Secure Rescue CD wykrywa i usuwa złośliwe oprogramowanie z Twojego Windowsa.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie bezinstalacyjnym, w którym można przeprowadzić skanowanie pod kątem złośliwego oprogramowania.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="105"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.gentoo.org/&quot;&gt;http://www.gentoo.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Gentoo is a flexible source-based distribution designed for advanced users.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona internetowa:&lt;/b&gt; &lt;a href=&quot;http://www.gentoo.org/&quot;&gt;http://www.gentoo.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Gentoo to elastyczna, oparta na kompilacji kodu z pakietów źródłowych, dystrybucja przewidziana dla zaawansowanych użytkowników.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie bezinstalacyjnym, w którym można, opcjonalnie, uruchomić instalatora.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="115"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; gNewSense is an FSF-endorsed distribution based on Ubuntu with all non-free components removed.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona internetowa:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; gNewSense to, mająca poparcie FSF, dystrybucja oparta na Ubuntu, zawierająca tylko wolne oprogramowanie.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie bezinstalacyjnym, w którym można, opcjonalnie, uruchomić instalatora.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="120"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://gujin.sourceforge.net/&quot;&gt;http://gujin.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Gujin is a graphical boot manager which can bootstrap various volumes and files.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Gujin simply boots and runs; no installation is required to use it.</source>
        <translation>&lt;b&gt;Strona internetowa:&lt;/b&gt; &lt;a href=&quot;http://gujin.sourceforge.net/&quot;&gt;http://gujin.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Gujin to graficzny menedżer uruchamiania, który potrafi zainicjować rozruch z różnych typów partycji i plików.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Gujin, po prostu, się uruchamia i działa i instalacja nie jest konieczna by go używać.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="125"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://ftp.kaspersky.com/devbuilds/RescueDisk/&quot;&gt;http://ftp.kaspersky.com/devbuilds/RescueDisk/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Kaspersky Rescue Disk detects and removes malware from your Windows installation.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which malware scans can be launched.</source>
        <translation>&lt;b&gt;Strona internetowa:&lt;/b&gt; &lt;a href=&quot;http://ftp.kaspersky.com/devbuilds/RescueDisk/&quot;&gt;http://ftp.kaspersky.com/devbuilds/RescueDisk/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Kaspersky Rescue Disk wykrywa i usuwa złośliwe oprogramowanie z twojej instalacji Windows.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie bezinstalacyjnym, w którym można przeprowadzić skanowanie pod kątem złośliwego oprogramowania.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="130"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.kubuntu.org/&quot;&gt;http://www.kubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Kubuntu is an official Ubuntu derivative featuring the KDE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.kubuntu.org/&quot;&gt;http://www.kubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Kubuntu jest oficjalną pochodną Ubuntu zawierającą pulpit KDE.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live umożliwia uruchomienie systemu w trybie live, z poziomu którego można uruchomić program instalacyjny. Wersja NetInstall umożliwia instalacje poprzez FTP, i może zainstalować zarówno Kubuntu, jak i inne oficjalne pochodne Ubuntu. Jeśli chcesz użyć pobrane instalacyjne obrazy iso (w wersji alternate, nie desktop!), użyj opcji HdMedia, a następnie umieść plik instalacyjny iso w wersji alternate w katalogu root Twojego dysku twardego lub napędu USB.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="135"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://linuxconsole.org/&quot;&gt;http://linuxconsole.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; LinuxConsole is a desktop distro to play games, easy to install, easy to use and fast to boot .&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The 1.0.2009 is latest 1.0 release.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://linuxconsole.org/&quot;&gt;http://linuxconsole.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; LinuxConsole jest dystrybucją biurkową przeznaczoną dla graczy komputerowych, łatwą do instalacji, używania i szybko się uruchamiającą.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja 1.0.2009 jest ostatnią z serii 1.0.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="140"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://linuxmint.com/&quot;&gt;http://linuxmint.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Linux Mint is a user-friendly Ubuntu-based distribution which includes additional proprietary codecs and other software by default.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona internetowa:&lt;/b&gt; &lt;a href=&quot;http://linuxmint.com/&quot;&gt;http://linuxmint.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Linux Mint to przyjazna użytkownikowi, oparta na Ubuntu, dystrybucja, która zawiera domyślnie dodatkowe, własnościowe kodeki i inne oprogramowanie.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie bezinstalacyjnym, w którym można, opcjonalnie, uruchomić instalatora.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="145"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.mandriva.com/&quot;&gt;http://www.mandriva.com/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Mandriva is a user-friendly distro formerly known as Mandrake Linux.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over the internet (FTP) or via pre-downloaded &lt;a href=&quot;http://www.mandriva.com/en/download&quot;&gt;&quot;Free&quot; iso image files&lt;/a&gt;.</source>
        <translation>&lt;b&gt;Strona internetowa:&lt;/b&gt; &lt;a href=&quot;http://www.mandriva.com/&quot;&gt;http://www.mandriva.com/&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Mandriva to przyjazna użytkownikowi dystrybucja, wcześniej znana jako Mandrake Linux.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie bezinstalacyjnym, w którym można, opcjonalnie, uruchomić instalatora. Wersja NetInstall umożliwia instalację przez Internet (FTP) lub z uprzednio pobranych&lt;a href=&quot;http://www.mandriva.com/en/download&quot;&gt;obrazów iso wersji &quot;Free&quot;&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="151"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.mepis.org/&quot;&gt;http://www.mepis.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; MEPIS is a Debian-based distribution. SimplyMEPIS is a user-friendly version based on KDE, while AntiX is a lightweight version for older computers.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; MEPIS supports booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.mepis.org/&quot;&gt;http://www.mepis.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; MEPIS jest dystrybucją opartą na Debianie. SimplyMEPIS to przyjazna użytkownikowi wersja z KDE, natomiast AntiX to lekka dystrybucja dla starszych komputerów.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; MEPIS-a można uruchomić w trybie live, w którym można, opcjonalnie, uruchomić instalatora.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="156"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.netbsd.org/&quot;&gt;http://www.netbsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; NetBSD is a Unix-like operating system which focuses on portability.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt;The default version allows for both installation over the internet (FTP), or using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.netbsd.org/&quot;&gt;http://www.netbsd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; NetBSD to uniksopodobny system operacyjny, który koncentruje się na przenośności.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt;Wersja domyślna umożliwia zarówno instalację przez Internet (FTP), jak również z uprzednio pobranych plików ISO.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="161"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; NimbleX is a small, versatile Slackware-based distribution. It is built using the linux-live scripts, and features the KDE desktop. It can be booted from CD or flash memory (USB pens or MP3 players), and can easily be customized and extended.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NimbleX boots in Live mode.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; NimbleX jest małą, uniwersalną dystrybucją opartą na Slackware. Jest tworzona przy użyciu Linuxowych skryptów live i zawiera pulpit KDE. Może być uruchamiana z CD lub pamięci flash (klucze USB lub odtwarzacze MP3), w łatwy sposób konfigurowana i rozbudowywana.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; NimbleX uruchamia się w trybie live.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="166"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://home.eunet.no/pnordahl/ntpasswd/bootdisk.html&quot;&gt;http://home.eunet.no/pnordahl/ntpasswd/bootdisk.html&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; The Offline NT Password and Registry Editor can reset Windows passwords and edit the registry on Windows 2000-Vista.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NTPasswd is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://home.eunet.no/pnordahl/ntpasswd/bootdisk.html&quot;&gt;http://home.eunet.no/pnordahl/ntpasswd/bootdisk.html&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Offline NT Password and Registry Editor to narzędzie do resetowania hasła Windowsa oraz edytowania rejestru w Windowsach wersji od 2000 do Visty.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; NTPasswd uruchamia się w trybie live, bez konieczności instalacji.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="171"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.opensuse.org/&quot;&gt;http://www.opensuse.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; openSUSE is a user-friendly Novell sponsored distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The default version allows for both installation over the internet (FTP), or offline installation using pre-downloaded installation ISO files.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.opensuse.org/&quot;&gt;http://www.opensuse.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; OpenSUSE to łatwa w użyciu dystrybucja, sponsorowana przez firmę  Novell.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersję domyślną można zainstalować bądź przez internet (FTP), bądź z uprzednio pobranych plików instalacyjnych ISO.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="176"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://ophcrack.sourceforge.net/&quot;&gt;http://ophcrack.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Ophcrack can crack Windows passwords.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Ophcrack is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://ophcrack.sourceforge.net/&quot;&gt;http://ophcrack.sourceforge.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Ophcrack służy do łamania haseł Windowsa.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Ophcrack działa w trybie live; aby móc z niego korzystać nie jest konieczna instalacja.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="181"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://partedmagic.com/&quot;&gt;http://partedmagic.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Parted Magic includes the GParted partition manager and other system utilities which can resize, copy, backup, and manipulate disk partitions.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Parted Magic is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://partedmagic.com/&quot;&gt;http://partedmagic.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Parted Magic składa się z menedżera partycji GParted i innych narzędzi systemowych. Można za jego pomocą zmienić rozmiar, skopiować, utworzyć kopię zapasową lub w inny sposób manipulować partycją dysku.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Parted Magic działa w trybie live; aby móc z niego korzystać nie jest konieczna instalacja..</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="186"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.pclinuxos.com/&quot;&gt;http://www.pclinuxos.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; PCLinuxOS is a user-friendly Mandriva-based distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.pclinuxos.com/&quot;&gt;http://www.pclinuxos.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; PCLinuxOS to łatwa w użyciu, oparta na Mandrivie, dystrybucja.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live działa w trybie bezinstalacyjnym, w którym można uruchomić instalatora.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="191"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.puppylinux.com/&quot;&gt;http://www.puppylinux.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Puppy Linux is a lightweight distribution designed for older computers.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.puppylinux.com/&quot;&gt;http://www.puppylinux.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Puppy Linux to lekka dystrybucja przeznaczona dla starszych komputerów.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live ładuje cały system do pamięci RAM i stamtąd się uruchamia, tak więc instalacja nie jest wymagana, choć opcjonalna.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="196"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.sabayonlinux.org/&quot;&gt;http://www.sabayonlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Sabayon Linux is a Gentoo-based Live DVD distribution which features the Entropy binary package manager in addition to the source-based Portage.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The LiteMCE edition is 2 GB, while the full edition will need an 8 GB USB drive</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.sabayonlinux.org/&quot;&gt;http://www.sabayonlinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Sabayon Linux to oparta na Gentoo dystrybucja Live DVD, która oprócz bazującego na plikach źródłowych systemu Portage, zawiera menedżera pakietów skompilowanych Entropy.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live umożliwia uruchomienie w trybie bezinstalacyjnym, w którym można uruchomić instalatora. Wersja LiteMCE zajmuje 2 GB, podczas gdy pełna wersja wymaga pamięci USB o pojemności 8 GB.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="201"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.slax.org/&quot;&gt;http://www.slax.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Slax is a Slackware-based distribution featuring the KDE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.slax.org/&quot;&gt;http://www.slax.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Slax to oparta na Slackware dystrybucja ze środowiskiem graficznym KDE.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live uruchamia się w trybie bezinstalacyjnym, w którym jest możliwość uruchomienia instalatora.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="206"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; SliTaz is a lightweight, desktop-oriented micro distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; SliTaz to lekka, przeznaczona dla komputerów biurkowych mikrodystrybucja.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live ładuje cały system do pamięci RAM skąd się uruchamia, tak więc instalacja nie jest wymagana, choć opcjonalna.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="211"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://btmgr.sourceforge.net/about.html&quot;&gt;http://btmgr.sourceforge.net/about.html&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Smart Boot Manager is a bootloader which can overcome some boot-related BIOS limitations and bugs.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; SBM simply boots and runs; no installation is required to use it.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://btmgr.sourceforge.net/about.html&quot;&gt;http://btmgr.sourceforge.net/about.html&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Smart Boot Manager to program rozruchowy, który pozwala obejść niektóre problemy z uruchomieniem komputera, wynikające z ograniczeń i błędów BIOS-u.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; SBM po prostu się uruchamia i działa bez instalowania.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="216"/>
        <location filename="distrovercust.cpp" line="12"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.supergrubdisk.org&quot;&gt;http://www.supergrubdisk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Super Grub Disk is a bootloader which can perform a variety of MBR and bootloader recovery tasks.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; SGD simply boots and runs; no installation is required to use it.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.supergrubdisk.org&quot;&gt;http://www.supergrubdisk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Super Grub Disk jest bootloaderem, który służy do wykonania wielu zadań przy odzyskiwaniu MBR oraz bootloadera.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; SGD się po prostu uruchamia; do jego użycia nie jest wymagana instalacja.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="221"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://hacktolive.org/wiki/Super_OS&quot;&gt;http://hacktolive.org/wiki/Super_OS&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Super OS is an unofficial derivative of Ubuntu which includes additional software by default. Requires a 2GB USB drive to install.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://hacktolive.org/wiki/Super_OS&quot;&gt;http://hacktolive.org/wiki/Super_OS&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Super OS jest nieoficjalną pochodną Ubuntu zawierającą domyślnie dodatkowe oprogramowanie. Wymaga 2GB na napędzie USB, aby móc zostać zainstalowaną.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja live umożliwia uruchomienie w trybie live, z którego może zostać uruchomiony program instalacyjny.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="226"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.sysresccd.org&quot;&gt;http://www.sysresccd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; SystemRescueCD includes various partition management and data recovery and backup tools.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; SystemRescueCD is booted and run in live mode; no installation is required to use it.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.sysresccd.org&quot;&gt;http://www.sysresccd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; SystemRescueCD zawiera różne narzędzia do zarządzania partycjami, odzyskiwania danych i tworzenia kopii zapasowych.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; SystemRescueCD działa w trybie live - bez konieczności instalacji.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="231"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu.com/&quot;&gt;http://www.ubuntu.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Ubuntu is a user-friendly Debian-based distribution. It is currently the most popular Linux desktop distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu.com/&quot;&gt;http://www.ubuntu.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Ubuntu jest przyjazną użytkownikowi dystrybucją opartą na Debianie. Jest obecnie najbardziej popularną pulpitową dystrybucją Linuksa.&lt;br/&gt;&lt;b&gt;Informacje instalacyjne:&lt;/b&gt; Wersja Live umożliwia uruchomienie w trybie Live, z poziomu którego opcjonalnie może zostać uruchomiony instalator. Wersja NetInstall umożliwia przeprowadzenie instalacji poprzez FTP, i umożliwia zainstalowanie Kubuntu i pozostałych oficjalnych pochodnych dystrybucji Ubuntu. Jeśli potrzebujesz użyć pobraniowego obrazu instalacyjnego alternate (nie desktop), użyj opcji HdMedia, i umieść następnie plik obrazu instalacyjnego alternate do swojego katalogu głównego na dysku twardym lub do napędu USB.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="236"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; xPUD is a lightweight distribution featuring a simple kiosk-like interface with a web browser and media player.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; xPUD jest lekką dystrybucją z prostym interfejsem typu &quot;kiosk&quot;, zawierającą przeglądarkę internetową i odtwarzacz multimediów.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja live ładuje się w całości do pamięci RAM i z niej się uruchamia.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="241"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.xubuntu.org/&quot;&gt;http://www.xubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Xubuntu is an official Ubuntu derivative featuring the XFCE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched. The NetInstall version allows for installation over FTP, and can install Kubuntu and other official Ubuntu derivatives. If you would like to use a pre-downloaded alternate (not desktop) install iso, use the HdMedia option, and then place the alternate install iso file on the root directory of your hard drive or USB drive</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.xubuntu.org/&quot;&gt;http://www.xubuntu.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Xubuntu jest oficjalną pochodną dystrybucji Ubuntu zawierającą środowisko pulpitowe XFCE.&lt;br/&gt;&lt;b&gt;Informacje instalacyjne:&lt;/b&gt; Wersja Live umożliwia uruchomienie w trybie Live, z poziomu którego opcjonalnie może zostać uruchomiony instalator. Wersja NetInstall umożliwia przeprowadzenie instalacji poprzez FTP, i umożliwia zainstalowanie Kubuntu i pozostałych oficjalnych pochodnych dystrybucji Ubuntu. Jeśli potrzebujesz użyć pobraniowego obrazu instalacyjnego alternate (nie desktop), użyj opcji HdMedia, i umieść następnie plik obrazu instalacyjnego alternate do swojego katalogu głównego na dysku twardym lub do napędu USB.</translation>
    </message>
    <message>
        <location filename="distrover.cpp" line="246"/>
        <source>&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.zenwalk.org/&quot;&gt;http://www.zenwalk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Zenwalk is a Slackware-based distribution featuring the XFCE desktop.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.zenwalk.org/&quot;&gt;http://www.zenwalk.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Zenwalk jest opartą na Slackware dystrybucją zawierającą środowisko graficzne XFCE.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja Live pozwala na uruchomienie w trybie bezinstalacyjnym, w którym można, ewentualnie, uruchomić instalatora.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="33"/>
        <source>&lt;img src=&quot;:/eeepclos.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.eeepclinuxos.com/&quot;&gt;http://www.eeepclinuxos.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; EeePCLinuxOS is a user-friendly PCLinuxOS based distribution for the EeePC.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation>&lt;img src=&quot;:/eeepclos.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.eeepclinuxos.com/&quot;&gt;http://www.eeepclinuxos.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; EeePCLinuxOS jest przyjazną użytkownikowi, opartą na  PCLinuxOS dystrybucją przeznaczoną dla komputerów EeePC.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Zanim zaczniesz instalację upewnij się, że napęd docelowy jest pusty i sformatowany.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="41"/>
        <source>&lt;img src=&quot;:/eeeubuntu.png&quot; style=&quot;float:left;&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu-eee.com/&quot;&gt;http://www.ubuntu-eee.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Ubuntu Eee is not only Ubuntu optimized for the Asus Eee PC. It&apos;s an operating system, using the Netbook Remix interface, which favors the best software available instead of open source alternatives (ie. Skype instead of Ekiga).&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation>&lt;img src=&quot;:/eeeubuntu.png&quot; style=&quot;float:left;&quot; /&gt;&lt;br/&gt;&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.ubuntu-eee.com/&quot;&gt;http://www.ubuntu-eee.com&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Ubuntu Eee to nie tylko Ubuntu zoptymalizowane dla Asus&apos;a Eee PC. Jest to system operacyjny używający interfejsu Netbook Remix, który faworyzuje najlepsze dostępne oprogramowanie w miejscu alternatyw Open Source (np. Skype zamiast Ekiga).&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Zanim zaczniesz instalację upewnij się, że napęd docelowy jest pusty i sformatowany.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="53"/>
        <source>&lt;img src=&quot;:/elive.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Elive is a Debian-based distribution featuring the Enlightenment window manager.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version allows for booting in Live mode, from which the installer can optionally be launched.</source>
        <translation>&lt;img src=&quot;:/elive.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.elivecd.org/&quot;&gt;http://www.elivecd.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Elive jest bazującą na Debianie dystrybucją zawierającą menedżer okien Enlightenment.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja live umożliwia uruchomienie w trybie live, z którego może zostać uruchomiony program instalacyjny.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="61"/>
        <source>&lt;img src=&quot;:/kiwi_logo_ro.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.kiwilinux.org/&quot;&gt;http://www.kiwilinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; Kiwi Linux is an Ubuntu derivative primarily made for Romanian, Hungarian and English speaking users.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation>&lt;img src=&quot;:/kiwi_logo_ro.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.kiwilinux.org/&quot;&gt;http://www.kiwilinux.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; Kiwi Linux wywodzi się z Ubuntu i tworzony jest przede wszystkim dla rumuńsko-, węgiersko- i anglojęzycznych użytkowników&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Przed przystąpieniem do instalacji upewnij się, że partycja docelowa jest pusta i sformatowana.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="69"/>
        <source>&lt;img src=&quot;:/gnewsense.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; gNewSense is a high-quality GNU/Linux distribution that extends and improves Ubuntu to create a completely free operating system without any binary blobs or package trees that contain proprietary software.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; Make sure install media is empty and formatted before proceeding with install.</source>
        <translation>&lt;img src=&quot;:/gnewsense.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.gnewsense.org/&quot;&gt;http://www.gnewsense.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; gNewSense jest wysokiej jakości dystrybucją GNU/Linux, rozbudowaną i ulepszoną w stosunku do Ubuntu, która jest całkowicie wolnym i darmowym systemem operacyjnym, wolnym kompletnie od własnościowego, zamkniętego kodu obecnego czy to w jądrze, czy też w drzewie pakietów.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Przed przystąpieniem do instalacji upewnij się, że partycja docelowa jest pusta i sformatowana.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="77"/>
        <source>&lt;img src=&quot;:/nimblex.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; NimbleX is a small, versatile Slackware-based distribution. It is built using the linux-live scripts, and features the KDE desktop. It can be booted from CD or flash memory (USB pens or MP3 players), and can easily be customized and extended.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; NimbleX boots in Live mode.</source>
        <translation>&lt;img src=&quot;:/nimblex.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.nimblex.net/&quot;&gt;http://www.nimblex.net&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; NimbleX jest małą, uniwersalną dystrybucją opartą na Slackware. Jest zbudowana za pomocą samowykonalnych skryptów linuksowych i zawiera środowisko pulpitowe KDE. Może zostać uruchomione z płyty CD lub pamięci przenośnej (klucze USB lub odtwarzacz MP3) i w prosty sposób dostosowane do potrzeb i rozbudowane.&lt;br/&gt;&lt;b&gt;Informacja instalacyjne:&lt;/b&gt; NimbleX uruchamia się w trybie Live.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="85"/>
        <source>&lt;img src=&quot;:/slitaz.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; SliTaz is a lightweight, desktop-oriented micro distribution.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory, so installation is not required but optional. This installer is based on &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;.</source>
        <translation>&lt;img src=&quot;:/slitaz.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.slitaz.org/en/&quot;&gt;http://www.slitaz.org/en&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; SliTaz jest lekką mikrodystrybucją przeznaczoną do komputerów biurkowych.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja live ładuje się w całości do pamięci RAM i z niej się uruchamia, tak więc instalacja nie jest wymagana, chociaż jest możliwa. Ten instalator stworzony został na podstawie programu &lt;a href=&quot;http://unetbootin.sourceforge.net/&quot;&gt;UNetbootin&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="distrovercust.cpp" line="93"/>
        <source>&lt;img src=&quot;:/xpud.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Homepage:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Description:&lt;/b&gt; xPUD is a lightweight distribution featuring a simple kiosk-like interface with a web browser and media player.&lt;br/&gt;&lt;b&gt;Install Notes:&lt;/b&gt; The Live version loads the entire system into RAM and boots from memory.</source>
        <translation>&lt;img src=&quot;:/xpud.png&quot; /&gt;&lt;br/&gt;&lt;b&gt;Strona domowa:&lt;/b&gt; &lt;a href=&quot;http://www.xpud.org/&quot;&gt;http://www.xpud.org&lt;/a&gt;&lt;br/&gt;&lt;b&gt;Opis:&lt;/b&gt; xPUD jest lekką dystrybucją z prostym interfejsem typu &quot;kiosk&quot;, zawierającą przeglądarkę internetową i odtwarzacz multimediów.&lt;br/&gt;&lt;b&gt;Uwagi instalacyjne:&lt;/b&gt; Wersja live ładuje się w całości do pamięci RAM i z niej się uruchamia.</translation>
    </message>
</context>
<context>
    <name>unetbootinui</name>
    <message>
        <location filename="unetbootin.ui" line="20"/>
        <source>Unetbootin</source>
        <translation>Unetbootin</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="44"/>
        <location filename="unetbootin.ui" line="65"/>
        <source>Select from a list of supported distributions</source>
        <translation>Wybierz z listy wspieranych dystrybucji</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="47"/>
        <source>&amp;Distribution</source>
        <translation>&amp;Dystrybucja</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="131"/>
        <source>Specify a disk image file to load</source>
        <translation>Określ plik obrazu dysku do wczytania</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="134"/>
        <source>Disk&amp;image</source>
        <translation>Obraz dysku</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="147"/>
        <source>Manually specify a kernel and initrd to load</source>
        <translation>Ręcznie określ jądro i initrd do wczytania</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="150"/>
        <source>&amp;Custom</source>
        <translation>&amp;Własny</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="414"/>
        <location filename="unetbootin.ui" line="430"/>
        <source>Space to reserve for user files which are preserved across reboots. Works only for LiveUSBs for Ubuntu and derivatives. If value exceeds drive capacity, the maximum space available will be used.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="417"/>
        <source>Space used to preserve files across reboots (Ubuntu only):</source>
        <translation>Przestrzeń używana do zachowywania plików pomiędzy rebootami (tylko Ubuntu):</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="440"/>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="503"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="506"/>
        <source>Return</source>
        <translation>Powróŧ</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="513"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="516"/>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="561"/>
        <source>Reboot Now</source>
        <translation>Uruchom ponownie</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="568"/>
        <source>Exit</source>
        <translation>Zakończ</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="660"/>
        <source>1. Downloading Files</source>
        <translation>1. Pobieranie plików</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="667"/>
        <source>2. Extracting and Copying Files</source>
        <translation>2. Rozpakowywanie i kopiowanie plików</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="674"/>
        <source>3. Installing Bootloader</source>
        <translation>3. Instalowanie bootloadera</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="681"/>
        <source>4. Installation Complete, Reboot</source>
        <translation>4. Instalacja zakończona, ponowne uruchamianie</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="477"/>
        <location filename="unetbootin.ui" line="496"/>
        <source>Select the target drive to install to</source>
        <translation>Wybierz docelowy napęd, na który nastąpi instalacja</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="480"/>
        <source>Dri&amp;ve:</source>
        <translation>&amp;Napęd:</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="451"/>
        <location filename="unetbootin.ui" line="470"/>
        <source>Select the installation target type</source>
        <translation>Wybierz rodzaj miejsca docelowego instalacji</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="454"/>
        <source>&amp;Type:</source>
        <translation>&amp;Typ:</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="81"/>
        <source>Select the distribution version</source>
        <translation>Wybierz wersję dystrybucji</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="347"/>
        <source>Select disk image file</source>
        <translation>Wybierz plik obrazu dysku</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="286"/>
        <location filename="unetbootin.ui" line="350"/>
        <location filename="unetbootin.ui" line="375"/>
        <location filename="unetbootin.ui" line="400"/>
        <source>...</source>
        <translation>…</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="188"/>
        <source>Select the disk image type</source>
        <translation>Wybierz typ pliku obrazu</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="243"/>
        <source>Specify a floppy/hard disk image, or CD image (ISO) file to load</source>
        <translation>Określ obraz dyskietki/dysku twardego lub plik obrazu płyty (ISO) do wczytania</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="207"/>
        <location filename="unetbootin.ui" line="258"/>
        <source>Specify a kernel file to load</source>
        <translation>Określ plik jądra do wczytania</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="283"/>
        <source>Select kernel file</source>
        <translation>Wybierz plik jądra</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="293"/>
        <location filename="unetbootin.ui" line="312"/>
        <source>Specify an initrd file to load</source>
        <translation>Wybierz plik initrd do wczytania</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="372"/>
        <source>Select initrd file</source>
        <translation>Wskaż plik initrd</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="397"/>
        <source>Select syslinux.cfg or isolinux.cfg file</source>
        <translation>Wskaż plik syslinux.cfg lub isolinux.cfg</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="226"/>
        <location filename="unetbootin.ui" line="321"/>
        <source>Specify parameters and options to pass to the kernel</source>
        <translation>Określ parametry i opcje dla jądra</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="210"/>
        <source>&amp;Kernel:</source>
        <translation>&amp;Jądro</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="296"/>
        <source>Init&amp;rd:</source>
        <translation>Init&amp;rd:</translation>
    </message>
    <message>
        <location filename="unetbootin.ui" line="229"/>
        <source>&amp;Options:</source>
        <translation>&amp;Opcje:</translation>
    </message>
</context>
<context>
    <name>uninstaller</name>
    <message>
        <location filename="main.cpp" line="156"/>
        <source>Uninstallation Complete</source>
        <translation>Proces odinstalowania zakończony</translation>
    </message>
    <message>
        <location filename="main.cpp" line="157"/>
        <source>%1 has been uninstalled.</source>
        <translation>%1 został odinstalowany.</translation>
    </message>
    <message>
        <location filename="main.cpp" line="319"/>
        <source>Must run as root</source>
        <translation>Musi zostać uruchomione w trybie administratora</translation>
    </message>
    <message>
        <location filename="main.cpp" line="321"/>
        <source>%2 must be run as root. Close it, and re-run using either:&lt;br/&gt;&lt;b&gt;sudo %1&lt;/b&gt;&lt;br/&gt;or:&lt;br/&gt;&lt;b&gt;su - -c &apos;%1&apos;&lt;/b&gt;</source>
        <translation>%2 musi być uruchomiony w trybie administratora. Zamknij go i uruchom ponownie używając dowolnie:&lt;br/&gt;&lt;b&gt;sudo %1&lt;/b&gt;&lt;br/&gt;lub:&lt;br/&gt;&lt;b&gt;su - -c &apos;%1&apos;&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="main.cpp" line="353"/>
        <source>%1 Uninstaller</source>
        <translation>Odinstaluj %1</translation>
    </message>
    <message>
        <location filename="main.cpp" line="354"/>
        <source>%1 is currently installed. Remove the existing version?</source>
        <translation>%1 jest obecnie zainstalowane. Usunąć istniejącą wersję?</translation>
    </message>
</context>
</TS>
