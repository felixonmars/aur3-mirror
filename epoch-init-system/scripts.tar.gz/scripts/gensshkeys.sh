#!/usr/bin/bash

ssh-keygen -t ecdsa -f /etc/ssh/ssh_host_ecdsa_key -N '' > /dev/null 2>&1
ssh-keygen -t dsa -f /etc/ssh/ssh_host_dsa_key -N '' > /dev/null 2>&1
ssh-keygen -t rsa -f /etc/ssh/ssh_host_rsa_key -N '' > /dev/null 2>&1

