#!/bin/sh
#Used to fire up networking. Called by Epoch during boot.
#ifconfig eth0 192.168.0.14 255.255.255.0 up
#route add default gw 192.168.0.1 eth0
dhcpcd eth0
