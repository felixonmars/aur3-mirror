#!/bin/sh
#Used to shut down networking. Called by Epoch during halt.
#killall dhclient
ifconfig eth0 down
