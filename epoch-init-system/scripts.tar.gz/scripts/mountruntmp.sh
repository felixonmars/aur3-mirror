#!/bin/sh

mount -t tmpfs tmpfs /run
mount -t tmpfs tmpfs /tmp