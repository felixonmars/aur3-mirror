#!/bin/sh
/usr/bin/udevd --daemon
/usr/bin/udevadm trigger --action=add --type=subsystems
/usr/bin/udevadm trigger --action=add --type=devices
/usr/bin/udevadm settle
