sudo apt-get -y install build-essential libncurses-dev libssl-dev 

wget "http://www.erlang.org/download/otp_src_R14B03.tar.gz"
tar xvfz otp_src_R14B03.tar.gz
cd otp_src_R14B03/
./configure --prefix=/usr
sudo make install

