// gcc -o upnp  upnp.c  -lminiupnpc
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
//#include <sys/ioctl.h>
#include <fcntl.h>
#include <stdlib.h>
#define UPNPCOMMAND_SUCCESS (0)

#ifdef WIN32
#include "miniupnpc/miniupnpc.h"
#include <winsock2.h>
#define snprintf _snprintf
#else
#include <miniupnpc/miniupnpc.h>
#endif

typedef unsigned char byte;
int read_cmd(byte *buf);
int write_cmd(byte *buf, int len);

typedef struct portp
{
	char port[10];
	char type[5];
	char used;
}portp;

int main() 
{
#ifdef WIN32
	WSADATA wsaData;
	int nResult = WSAStartup(MAKEWORD(2,2), &wsaData);
	if(nResult != NO_ERROR)
	{
		fprintf(stderr, "WSAStartup() failed.\n");
		return -1;
	}
#endif

	byte bufin[100];
	byte bufout[100];
	memset(bufin,0,100);
	memset(bufout,0,100);
	
	portp ports[10];
	int nports = 0;
	int i;
	for (i = 0; i < 10; i++)
		memset(&(ports[i]),0,sizeof(portp));
	
	char lanaddr[64];
	struct UPNPDev * devlist = 0;
	const char * minissdpdpath = 0;
	const char * multicastif = 0;
	int error = 0;
	devlist = upnpDiscover(2000, multicastif, minissdpdpath,
		0/*sameport*/, 0, &error);
	
	if (devlist == NULL)
	{
		strcpy(bufout,"noupnp");
		write_cmd(bufout, strlen(bufout));
		return 0;
	}
	
	struct UPNPUrls urls;
	struct IGDdatas data;
	int r = UPNP_GetValidIGD(devlist, &urls, &data, lanaddr, sizeof(lanaddr));
	
	if (r == 0)
	{
		strcpy(bufout,"noupnp");
		write_cmd(bufout, strlen(bufout));
		return 0;
	}
	
	while (read_cmd(bufin) > 0)
	{
		memset(bufout,0,100);
		char type[5];
		char internalip[40];
		char intport[10];
		char extport[10];
		
		if (strncmp("extip",bufin,strlen("extip")) == 0) 
		{
			r = UPNP_GetExternalIPAddress(urls.controlURL, data.first.servicetype, bufout);
			if(r != UPNPCOMMAND_SUCCESS)
			{
				bufout[0] = 0;
			}
		}
		else if (sscanf(bufin, "openport %s %s %s %s", type, internalip, intport, extport) == 4)
		{
			r = UPNP_AddPortMapping(urls.controlURL, data.first.servicetype,
			                        extport,intport,internalip, NULL,type, NULL, "0");
			if(r!=UPNPCOMMAND_SUCCESS)
				bufout[0] = 0;
			else
			{
				if (ports[nports].used)
				{
					UPNP_DeletePortMapping(urls.controlURL, data.first.servicetype, ports[nports].port, ports[nports].type, 0);
				}
				strcpy(ports[nports].port,extport);
				strcpy(ports[nports].type,type);
				ports[nports].used = 1;
				nports++;
				nports = nports % 10;
				strcpy(bufout,"ok");
			}
				
		}
		else
		{
			fprintf(stderr,"No match for command %s", bufin);
			bufout[0] = 0;
		}
		
		memset(bufin,0,100);
		
		if (strlen(bufout) == 0)
			write_cmd(bufout,1);
		else
			write_cmd(bufout, strlen(bufout));
	}
	
	for (i = 0; i < 10; i++)
	{
		if (ports[i].used)
			UPNP_DeletePortMapping(urls.controlURL, data.first.servicetype, ports[i].port, ports[i].type, 0);
	}
	
	FreeUPNPUrls(&urls);
	freeUPNPDevlist(devlist);
	
	return 0;
}

int read_cmd(byte *buf)
{
	int len;
	if (read_exact(buf, 2) != 2)
		return(-1);
	len = (buf[0] << 8) | buf[1];
	if (len < 100)
  		return read_exact(buf, len);
	else
		return -1;
}
int write_cmd(byte *buf, int len)
{
  byte li;
  li = (len >> 8) & 0xff;
  write_exact(&li, 1);
  
  li = len & 0xff;
  write_exact(&li, 1);
  return write_exact(buf, len);
}
int read_exact(byte *buf, int len)
{
  int i, got=0;
  do {
    if ((i = read(0, buf+got, len-got)) <= 0)
      return(i);
    got += i;
  } while (got<len);
  return(len);
}
int write_exact(byte *buf, int len)
{
  int i, wrote = 0;
  do {
    if ((i = write(1, buf+wrote, len-wrote)) <= 0)
      return (i);
    wrote += i;
  } while (wrote<len);
  return (len);
}
