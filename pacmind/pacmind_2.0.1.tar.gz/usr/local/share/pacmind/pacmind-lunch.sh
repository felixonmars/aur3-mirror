#!/bin/sh

img=/usr/share/pixmaps/pacmind.png

fuction_belong () {
	text=`zenity --title="Appartenenza file" --entry --text="Cerca pacchetto contenente il file: 'yaourt -Qo'"` 
	case $? in
		-1)
			echo "" 
		;;
		0)
		;;
		1)
			exit 0 
		;;
		5)
			echo ""
		;;
	esac
	echo $text | xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Appartenenza file" -e "yaourt -Qo $text
	read -sp \"Premere Invio per chiudere la finestra. \"
	"
}

fuction_clear () {
	zenity --question --title="Pulizia cache" --text="Pulisci la cache:
	'yaourt -Scc'" --ok-label="Rimuovi" --cancel-label="Esci"
	case $? in
		-1)
			echo "" 
		;;
		0)
			xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Pulizia cache" -e "yaourt -Scc
			read -sp \"Premere Invio per chiudere la finestra. \"
			"
		;;
		1)
			exit 0 
		;;
		5)
			echo ""
		;;
	esac
}

fuction_db_upgrade () {
	xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Pacman DB Upgrade" -e "sudo pacman-db-upgrade
	read -sp \"Aggiornamento Riuscito.
	Premere Invio per chiudere la finestra. \"
	"
}

fuction_dep () {
	zenity --question --title="Rimozione dipendenze inutili" --text="Rimuove le dipendenze inutili:
	'yaourt -R $(yaourt -Qdtq)'" --ok-label="Rimuovi" --cancel-label="Esci"
	case $? in
		-1)
			echo "" 
		;;
		0)
			xterm -bg black -fg white -T "Rimuovi dipendenze inutili" -e "yaourt -R $(yaourt -Qdtq)
			read -sp \"Premere Invio per chiudere la finestra. \"
			"
		;;
		1)
			exit 0 
		;;
		5)
			echo ""
		;;
	esac
}

fuction_force () {
	zenity --question --title="Forza aggiornamento" --text="Forza l'aggiornamento: 'yaourt -Syuaf'" --ok-label="Aggiorna" --cancel-label="Esci"
	case $? in
		-1)
			echo "" 
		;;
		0)
			xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Aggiorna Sistema" -e "yaourt -Syuaf
			read -sp \"Premere Invio per chiudere la finestra. \"
			"
		;;
		1)
			exit 0 
		;;
		5)
			echo ""
		;;
	esac
}

fuction_info_pkg () {
	text=`zenity --title="Informazioni su pacchetti" --entry --text="Cerca pacchetti: 'yaourt -Qi'"` 
	case $? in
		-1)
			echo "" 
		;;
		0)
		;;
		1)
			exit 0 
		;;
		5)
			echo ""
		;;
	esac
	echo $text | xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Info pacchetti" -e "yaourt -Qi $text
	read -sp \"Premere Invio per chiudere la finestra. \"
	"
}

fuction_info () {
	info_img=/usr/share/pixmaps/pacmind.png
	export MAIN_DIALOG='
	 <window title="Informazioni"  window_position="1">
	 <vbox>
	  <pixmap>
	      <input file>'$info_img'</input>
	    </pixmap>
	  <text use-markup="true">
	    <label>"<b>Pacmind 2.0.1</b>"</label>
	  </text>
	  <text wrap="true" width-chars="50">
	    <label>Pacmind è un gestore grafico per Yaourt, basato su gtkdialog ed ispirato a Yaourt-gui</label>
	  </text>
	  <hbox>
	   <button ok></button>
	  </hbox>
	 </vbox>
	</window>
	'
	gtkdialog --program=MAIN_DIALOG
}


fuction_install () {
	if text=`zenity --title="Installa pacchetto/i" --entry --text="Installa uno o più pacchetti: 'yaourt -S'
	In caso di scelta multipla inserire uno spazio tra l'uno e l'altro" --entry-text="Inserisci nome pacchetto/i"` 
	then echo $text
	xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Installa pacchetto" -e "yaourt -S $text
	read -sp \"Premere Invio per chiudere la finestra. \"
	"
	fi
}

fuction_optimize () {
	xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Ottimizza Pacman" -e "sudo pacman-optimize
	read -sp \"
	Premere Invio per chiudere la finestra. \"
	"
}

fuction_pacdiff () {
	xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "PacDiffViewer" -e "yaourt -C
	read -sp \"Premere Invio per chiudere la finestra. \"
	"
}

fuction_remove () {
	if text=`zenity --title="Rimuovi pacchetto/i" --entry --text="Rimuovi uno o più pacchetti: 'yaourt -R'
	In caso di scelta multipla, lascia uno spazio tra un pacchetto e l'altro" --entry-text="Inserisci il nome pacchetto/i"` 
	then echo $text
	xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Rimuovi pacchetti" -e "yaourt -R $text
	read -sp \"Premere Invio per chiudere la finestra. \"
	"
	fi
}

fuction_find_install () {
	text=`zenity --title="Cerca e installa pacchetti" --entry --text="Cerca e installa pacchetti: 'yaourt'"` 
	case $? in
		-1)
			echo "" 
		;;
		0)
		;;
		1)
			exit 0 
		;;
		5)
			echo ""
		;;
	esac
	echo $text | xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Cerca e installa pacchetto" -e "yaourt $text
	read -sp \"Premere Invio per chiudere la finestra. \"
	"
}

fuction_find () {
	text=`zenity --title="Cerca pacchetti" --entry --text="Cerca pacchetti con il nome o una parola chiave: 'yaourt -Ss'
	Ad esempio per cercare un lettore di pdf digitare 'pdf'" --entry-text="Inserisci la parola chiave"` 
	case $? in
		-1)
			echo "" 
		;;
		0)
		;;
		1)
			exit 0 
		;;
		5)
			echo ""
		;;
	esac
	echo $text | xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Cerca pacchetto" -e "yaourt -Ss $text
	read -sp \"Premere Invio per chiudere la finestra. \"
	"
}

fuction_update () {
	zenity --question --title="Aggiornamento del sistema" --text="Aggiorna i pacchetti: 'yaourt -Syua'" --ok-label="Aggiorna" --cancel-label="Esci"
	case $? in
		-1)
			echo "" 
		;;
		0)
			xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Aggiorna Sistema" -e "yaourt -Syua
			read -sp \"Premere Invio per chiudere la finestra. \"
			"
		;;
		1)
			exit 0 
		;;
		5)
			echo ""
		;;
	esac
}

fuction_sync () {
	zenity --question --title="Sincronizza i data base" --text="Aggiorna i repo: 'yaourt -Sy'" --ok-label="Aggiorna" --cancel-label="Esci"
	case $? in
		-1)
			echo "" 
		;;
		0)
			xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Aggiorna repo" -e "yaourt -Sy
			read -sp \"premi invio per chiudere la finestra\"
			"
		;;
		1)
			exit 0 
		;;
		5)
			echo ""
		;;
	esac
}

fuction_inman () {
	if text=`zenity --title="Aggiorna pacchetto/i" --entry --text="Installa manualmente uno o più pacchetti: 'yaourt -U'
	In caso di scelta multipla, lascia uno spazio tra un pacchetto e l'altro" --entry-text="Inserisci il nome pacchetto/i"` 
	then echo $text
	xterm -fn *-*-fixed-medium-r-normal--*-140-*-*-*-*-iso8859-7 -bg black -fg white -T "Installa manualmente pacchetti" -e "yaourt -U $text
	read -sp \"Premere Invio per chiudere la finestra. \"
	"
	fi
}



case $1 in
	1)
		fuction_sync
	;;
	2)
		fuction_update
	;;
	3)
		fuction_force
	;;
	4)
		fuction_install
	;;
	5)
		fuction_remove
	;;
	6)
		fuction_find
	;;
	7)
		fuction_find_install
	;;
	8)
		fuction_belong
	;;
	9)
		fuction_info_pkg
	;;
	10)
		fuction_inman
	;;
	11)
		fuction_dep
	;;
	12)
		fuction_clear
	;;
	13)
		fuction_pacdiff
	;;
	14)
		fuction_db_upgrade
	;;
	15)
		fuction_optimize
	;;
	16)
		fuction_info
	;;
	17)
esac
