#!/bin/bash

rm Makefile.in
rm src/Makefile.in
rm src/wallbox/Makefile.in
rm data/Makefile.in
rm data/images/Makefile.in

touch Makefile.in
touch src/Makefile.in
touch src/wallbox/Makefile.in
touch data/Makefile.in
touch data/images/Makefile.in

