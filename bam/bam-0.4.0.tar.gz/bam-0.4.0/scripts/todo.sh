#!/bin/sh
fgrep -n TODO src/*.c src/*.lua
