#include <iostream> 
 
using namespace std; 
 
int shared_func() 
{ 
        cout << "Hello world!" << endl;
        return 0; 
} 
