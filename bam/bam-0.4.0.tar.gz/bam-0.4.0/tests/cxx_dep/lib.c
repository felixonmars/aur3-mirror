#include <stdio.h>

extern int hello()
{
	printf("hello world\n");
	return 0;
}
