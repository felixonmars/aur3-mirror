class getBat{
	public:
	int bat();
};
size_t strpos(const string &haystack, const string &needle);

int getBat::bat()
{
	string data;
	 FILE *stream;
       	char buffer[2400];
        	stream = popen("acpi", "r");
       	while ( fgets(buffer, 2400, stream) != NULL )
       		 data.append(buffer);
       	pclose(stream);
	int centpos = strpos(data, "%");
	string level = data.substr(centpos - 3, 3);
	return atoi (level.c_str());
}

size_t strpos(const string &haystack, const string &needle)
{
	int sleng = haystack.length();
	int nleng = needle.length();

	if (sleng==0 || nleng==0)
   		return string::npos;

	for(int i=0, j=0; i<sleng; j=0, i++ )
	{
   		while (i+j<sleng && j<nleng && haystack[i+j]==needle[j])
   		    	j++;
   		if (j==nleng)
       			return i;
	}
	return string::npos;
}
