#include "ConfigFile/ConfigFile.cpp"

class Config
{
	public:
		Config();
		int interval[3];
		bool verbose;
		string lockas;
		string logfile;
};

Config::Config()
{
	ConfigFile configf("/etc/hiberbat.conf");
	configf.readInto(Config::interval[0], "int5010");
	configf.readInto(Config::interval[1], "int2049");
	configf.readInto(Config::interval[2], "int020");
	configf.readInto(Config::verbose, "logging");
	configf.readInto(Config::lockas, "lockas");
	configf.readInto(Config::logfile, "logfile");
}
