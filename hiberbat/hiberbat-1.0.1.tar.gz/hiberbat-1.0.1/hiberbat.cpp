#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include <vector>
#include <stdlib.h>
#include <unistd.h>
#include <fstream>
#include <time.h>
#include <stdlib.h>

using namespace std;

#include "config.cpp"
#include "getbat.cpp"

void wait (long seconds);
void log  (string txt, bool write, string logfile);
int intlen  (float start);
string convert (int number);

int main(){
	Config conf;
	getBat batGetter;

	while(true)
	{
		int bat = batGetter.bat();
		if(bat >= 50)
		{
			char logmess[42 + intlen(conf.interval[0]) + intlen(bat)];
			strcpy(logmess, convert(bat).c_str());
			strcat(logmess, "% ");
			strcat(logmess, "Bat over 50, sleeping for ");
			strcat(logmess, convert(conf.interval[0]).c_str());
			strcat(logmess, " seconds");
			log(logmess, conf.verbose, conf.logfile);
			sleep(conf.interval[0]);
		}
		else if((bat <= 49) && (bat >= 20))
		{
			char logmess[47 + intlen(conf.interval[1]) + intlen(bat)];
			strcpy(logmess, convert(bat).c_str());
			strcat(logmess, "% ");
			strcat(logmess, "Bat between 20 and 49, sleeping for ");
			strcat(logmess, convert(conf.interval[1]).c_str());
			strcat(logmess, " seconds");
			log(logmess, conf.verbose, conf.logfile);
			sleep(conf.interval[1]);
		}
		else if((bat <= 20) && (bat >= 2))
		{
			char logmess[42 + intlen(conf.interval[2]) + intlen(bat)];
			strcpy(logmess, convert(bat).c_str());
			strcat(logmess, "% ");
			strcat(logmess, "Bat under 20, sleeping for ");
			strcat(logmess, convert(conf.interval[2]).c_str());
			strcat(logmess, " seconds");
			log(logmess, conf.verbose, conf.logfile);
			sleep(conf.interval[2]);
		}else{
			log("Bat is 1 or 0, going into hibernate", conf.verbose, conf.logfile);
			if(conf.lockas.empty()){
				system("hibernate");
			}else{
				char str[27 + conf.lockas.size()];
				strcpy (str, "hibernate --lock-console-as ");
				strcat (str, conf.lockas.c_str());
				system(str);
			}
			break;
		}
	}



	return 0;
}


void log(string txt, bool write, string logfile){
	if(write){
		time_t rawtime;
  		struct tm * timeinfo;

  		time ( &rawtime );
  		timeinfo = localtime ( &rawtime );

		ofstream output;
	        output.open (logfile.c_str(), ios::out | ios::app );
		string time = asctime(timeinfo);
		char str[time.length() + 1 + sizeof(txt.c_str())];
		strcpy(str, time.substr(0, time.length() - 1).c_str());
		string tmp = ": ";
		strcat(str, tmp.c_str());
		strcat(str, txt.c_str());
		output << str << endl;

		output.close();
	}
}

int intlen(float start)
{
    int end = 0;
    while(start > 0) {
        start = start/10;
        end++;
    }
    return end;
}


string convert(int number)
{
	ostringstream sin;
   	sin << number;
   	return sin.str();
}
