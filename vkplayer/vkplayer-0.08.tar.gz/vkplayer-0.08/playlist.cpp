#include "playlist.h"


playList::playList(QWidget *parent) :
    QTreeView(parent)
{
}
