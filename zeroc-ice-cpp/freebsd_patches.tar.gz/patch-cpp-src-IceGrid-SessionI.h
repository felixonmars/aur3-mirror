--- cpp.orig/src/IceGrid/SessionI.h	2011-06-15 21:43:59.000000000 +0200
+++ cpp/src/IceGrid/SessionI.h	2012-03-04 20:14:53.000000000 +0100
@@ -35,7 +35,7 @@
 class SessionI;
 typedef IceUtil::Handle<SessionI> SessionIPtr;
 
-class BaseSessionI : virtual Ice::Object, public IceUtil::Mutex
+class BaseSessionI : virtual public Ice::Object, public IceUtil::Mutex
 {
 public:
 
