--- cpp.orig/include/Ice/ObjectF.h	2011-06-15 21:43:58.000000000 +0200
+++ cpp/include/Ice/ObjectF.h	2012-03-04 20:14:52.000000000 +0100
@@ -17,19 +17,8 @@
 {
 
 class Object;
-
-}
-
-namespace IceInternal
-{
-
 ICE_API IceUtil::Shared* upCast(::Ice::Object*);
 
-}
-
-namespace Ice
-{
-
 typedef IceInternal::Handle< Object > ObjectPtr;
 
 void ICE_API __patch__ObjectPtr(void*, ObjectPtr&);
