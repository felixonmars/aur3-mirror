--- cpp.orig/src/Ice/OutgoingAsync.cpp	2011-06-15 21:43:59.000000000 +0200
+++ cpp/src/Ice/OutgoingAsync.cpp	2012-03-04 20:14:52.000000000 +0100
@@ -30,7 +30,7 @@
 using namespace Ice;
 using namespace IceInternal;
 
-IceUtil::Shared* IceInternal::upCast(AsyncResult* p) { return p; }
+IceUtil::Shared* Ice::upCast(AsyncResult* p) { return p; }
 
 IceUtil::Shared* IceInternal::upCast(OutgoingAsyncMessageCallback* p) { return p; }
 IceUtil::Shared* IceInternal::upCast(OutgoingAsync* p) { return p; }
