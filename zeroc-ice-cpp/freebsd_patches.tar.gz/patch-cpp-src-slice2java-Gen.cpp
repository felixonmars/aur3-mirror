--- cpp.orig/src/slice2java/Gen.cpp	2011-06-15 21:43:59.000000000 +0200
+++ cpp/src/slice2java/Gen.cpp	2012-03-04 20:14:53.000000000 +0100
@@ -1246,7 +1246,7 @@
     {
         BuiltinPtr bp;
         EnumPtr ep;
-        if(bp = BuiltinPtr::dynamicCast(type))
+        if((bp = BuiltinPtr::dynamicCast(type)))
         {
             switch(bp->kind())
             {
@@ -1349,7 +1349,7 @@
             }
 
         }
-        else if(ep = EnumPtr::dynamicCast(type))
+        else if((ep = EnumPtr::dynamicCast(type)))
         {
             string val = value;
             string::size_type pos = val.rfind(':');
