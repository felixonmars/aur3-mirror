--- cpp.orig/src/IceStorm/NodeI.cpp	2011-06-15 21:43:59.000000000 +0200
+++ cpp/src/IceStorm/NodeI.cpp	2012-03-04 20:14:53.000000000 +0100
@@ -18,11 +18,6 @@
 namespace
 {
 
-bool operator==(const GroupNodeInfo& info, int id)
-{
-    return info.id == id;
-}
-
 class CheckTask : public IceUtil::TimerTask
 {
     const NodeIPtr _node;
