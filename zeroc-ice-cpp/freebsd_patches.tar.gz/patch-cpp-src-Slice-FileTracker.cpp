--- cpp.orig/src/Slice/FileTracker.cpp	2011-06-15 21:43:59.000000000 +0200
+++ cpp/src/Slice/FileTracker.cpp	2012-03-04 20:14:53.000000000 +0100
@@ -17,6 +17,10 @@
 #   include <direct.h>
 #endif
 
+#ifdef __linux
+#   include <unistd.h>
+#endif
+
 using namespace std;
 
 Slice::FileException::FileException(const char* file, int line, const string& r) :
