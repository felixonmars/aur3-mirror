--- cpp.orig/src/Slice/CPlusPlusUtil.cpp	2011-06-15 21:43:59.000000000 +0200
+++ cpp/src/Slice/CPlusPlusUtil.cpp	2012-03-04 20:14:53.000000000 +0100
@@ -631,7 +631,7 @@
         string scope = fixKwd(cl->scope());
         if(marshal)
         {
-            out << nl << stream << deref << "write(::Ice::ObjectPtr(::IceInternal::upCast(" << fixedParam 
+            out << nl << stream << deref << "write(::Ice::ObjectPtr(" << scope << "upCast(" << fixedParam 
                 << ".get())));";
         }
         else
@@ -649,7 +649,7 @@
         string scope = fixKwd(px->_class()->scope());
         if(marshal)
         {
-            out << nl << stream << deref << "write(::Ice::ObjectPrx(::IceInternal::upCast(" << fixedParam 
+            out << nl << stream << deref << "write(::Ice::ObjectPrx(::IceProxy" << scope << "upCast(" << fixedParam 
                 << ".get())));";
         }
         else
