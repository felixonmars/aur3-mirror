--- cpp.orig/src/Glacier2/Blobject.cpp	2011-06-15 21:43:58.000000000 +0200
+++ cpp/src/Glacier2/Blobject.cpp	2012-03-04 19:39:27.000000000 +0100
@@ -171,6 +171,15 @@
 }
 
 void
+Glacier2::Blobject::destroy()
+{
+    if(_requestQueue)
+    {
+        _requestQueue->destroy();
+    }
+}
+
+void
 Glacier2::Blobject::invoke(ObjectPrx& proxy, const AMD_Object_ice_invokePtr& amdCB, 
                            const std::pair<const Ice::Byte*, const Ice::Byte*>& inParams, const Current& current)
 {
