--- cpp.orig/src/slice2cs/Gen.cpp	2011-06-15 21:43:59.000000000 +0200
+++ cpp/src/slice2cs/Gen.cpp	2012-03-04 20:14:53.000000000 +0100
@@ -1281,7 +1281,7 @@
         {
             _out << value << "F";
         }
-        else if(ep = EnumPtr::dynamicCast(type))
+        else if((ep = EnumPtr::dynamicCast(type)))
         {
             string enumName = fixId(ep->scoped());
             string::size_type colon = value.rfind(':');
@@ -3914,16 +3914,6 @@
     ClassDefPtr cl = ClassDefPtr::dynamicCast(p->container());
     string name = fixId(p->name(), DotNet::ICloneable, true);
     vector<string> params = getParams(p);
-    bool hasOutParams = false;
-    ParamDeclList paramList = p->parameters();
-    for(ParamDeclList::const_iterator pli = paramList.begin(); pli != paramList.end(); ++pli)
-    {
-        if((*pli)->isOutParam())
-        {
-            hasOutParams = true;
-            break;
-        }
-    }
 
     _out << sp;
 
