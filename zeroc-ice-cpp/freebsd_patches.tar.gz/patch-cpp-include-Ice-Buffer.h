--- cpp.orig/include/Ice/Buffer.h	2011-06-15 21:43:58.000000000 +0200
+++ cpp/include/Ice/Buffer.h	2012-03-04 20:14:52.000000000 +0100
@@ -10,6 +10,7 @@
 #ifndef ICEE_BUFFER_H
 #define ICEE_BUFFER_H
 
+#include <cstddef>
 #include <Ice/Config.h>
 
 namespace IceInternal
