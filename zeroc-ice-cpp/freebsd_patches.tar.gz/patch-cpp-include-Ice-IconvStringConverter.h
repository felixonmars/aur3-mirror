--- cpp.orig/include/Ice/IconvStringConverter.h	2011-06-15 21:43:58.000000000 +0200
+++ cpp/include/Ice/IconvStringConverter.h	2012-03-04 20:14:52.000000000 +0100
@@ -225,10 +225,16 @@
 template<typename charT> /*static*/ void
 IconvStringConverter<charT>::close(std::pair<iconv_t, iconv_t> cdp)
 {
-    int rs = iconv_close(cdp.first);
+#ifndef NDEBUG
+    int rs = 
+#endif
+    iconv_close(cdp.first);
     assert(rs == 0);
 
-    rs = iconv_close(cdp.second);
+#ifndef NDEBUG
+    rs = 
+#endif
+    iconv_close(cdp.second);
     assert(rs == 0);
 }
  
