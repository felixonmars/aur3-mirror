--- cpp.orig/src/Freeze/MapDb.cpp	2011-06-15 21:43:58.000000000 +0200
+++ cpp/src/Freeze/MapDb.cpp	2012-03-04 20:14:52.000000000 +0100
@@ -229,7 +229,11 @@
 #ifndef NDEBUG
                 bool inserted = 
 #endif
-                    _indices.insert(IndexMap::value_type(indexBase->name(), indexI.get())).second;
+                    _indices.insert(IndexMap::value_type(indexBase->name(), indexI.get()))
+#ifndef NDEBUG                    
+                    .second
+#endif
+                ;
                 assert(inserted);
                 
                 indexBase->_impl = indexI.release();
