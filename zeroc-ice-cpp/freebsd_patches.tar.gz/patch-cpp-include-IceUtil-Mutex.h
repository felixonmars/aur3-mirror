--- cpp.orig/include/IceUtil/Mutex.h	2011-06-15 21:43:58.000000000 +0200
+++ cpp/include/IceUtil/Mutex.h	2012-03-04 20:14:52.000000000 +0100
@@ -251,8 +251,11 @@
 inline
 Mutex::~Mutex()
 {
+#ifndef NDEBUG
     int rc = 0;
-    rc = pthread_mutex_destroy(&_mutex);
+    rc = 
+#endif    
+    pthread_mutex_destroy(&_mutex);
     assert(rc == 0);
 }
 
