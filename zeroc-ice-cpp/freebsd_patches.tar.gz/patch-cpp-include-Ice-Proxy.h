--- cpp.orig/include/Ice/Proxy.h	2011-06-15 21:43:58.000000000 +0200
+++ cpp/include/Ice/Proxy.h	2012-03-04 20:14:52.000000000 +0100
@@ -38,6 +38,8 @@
 
 class Locator;
 class Router;
+ICE_API ::IceProxy::Ice::Object* upCast(::IceProxy::Ice::Locator*);
+ICE_API ::IceProxy::Ice::Object* upCast(::IceProxy::Ice::Router*);
 
 }
 
@@ -46,8 +48,6 @@
 namespace IceInternal
 {
 
-ICE_API ::IceProxy::Ice::Object* upCast(::IceProxy::Ice::Locator*);
-ICE_API ::IceProxy::Ice::Object* upCast(::IceProxy::Ice::Router*);
 
 class LocalExceptionWrapper;
 
@@ -1172,7 +1172,7 @@
 
     TwowayCallbackNC(const TPtr& instance, bool cb, Exception excb, Sent sentcb) : CallbackNC<T>(instance, excb, sentcb)
     {
-        checkCallback(instance, cb || excb != 0);
+        this->checkCallback(instance, cb || excb != 0);
     }
 };
 
@@ -1188,7 +1188,7 @@
 
     TwowayCallback(const TPtr& instance, bool cb, Exception excb, Sent sentcb) : Callback<T, CT>(instance, excb, sentcb)
     {
-        checkCallback(instance, cb || excb != 0);
+        this->checkCallback(instance, cb || excb != 0);
     }
 };
 
@@ -1209,7 +1209,7 @@
     OnewayCallbackNC(const TPtr& instance, Response cb, Exception excb, Sent sentcb) : 
         CallbackNC<T>(instance, excb, sentcb), response(cb)
     {
-        checkCallback(instance, cb != 0 || excb != 0);
+        this->checkCallback(instance, cb != 0 || excb != 0);
     }
 
     virtual void __completed(const ::Ice::AsyncResultPtr& result) const
@@ -1254,7 +1254,7 @@
     OnewayCallback(const TPtr& instance, Response cb, Exception excb, Sent sentcb) : 
         Callback<T, CT>(instance, excb, sentcb),  response(cb)
     {
-        checkCallback(instance, cb != 0 || excb != 0);
+        this->checkCallback(instance, cb != 0 || excb != 0);
     }
 
     virtual void __completed(const ::Ice::AsyncResultPtr& result) const
