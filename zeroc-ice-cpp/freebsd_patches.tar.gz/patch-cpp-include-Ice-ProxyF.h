--- cpp.orig/include/Ice/ProxyF.h	2011-06-15 21:43:58.000000000 +0200
+++ cpp/include/Ice/ProxyF.h	2012-03-04 20:14:52.000000000 +0100
@@ -22,6 +22,11 @@
 {
 
 class Object;
+inline ::IceProxy::Ice::Object* 
+upCast(::IceProxy::Ice::Object* o)
+{
+    return o;
+}
 
 }
 
@@ -34,6 +39,11 @@
 {
 
 class Object;
+inline ::IceDelegate::Ice::Object*
+upCast(::IceDelegate::Ice::Object* o)
+{
+    return o;
+}
 
 }
 
@@ -47,6 +57,12 @@
 
 class Object;
 
+inline ::IceDelegateM::Ice::Object*
+upCast(::IceDelegateM::Ice::Object* o)
+{
+    return o;
+}
+
 }
 
 }
@@ -58,36 +74,12 @@
 {
 
 class Object;
-
-}
-
-}
-
-namespace IceInternal
-{
-
-inline ::IceProxy::Ice::Object* 
-upCast(::IceProxy::Ice::Object* o)
-{
-    return o;
-}
-
-inline ::IceDelegate::Ice::Object*
-upCast(::IceDelegate::Ice::Object* o)
-{
-    return o;
-}
-
 inline ::IceDelegateD::Ice::Object*
 upCast(::IceDelegateD::Ice::Object* o)
 {
     return o;
 }
 
-inline ::IceDelegateM::Ice::Object*
-upCast(::IceDelegateM::Ice::Object* o)
-{
-    return o;
 }
 
 }
