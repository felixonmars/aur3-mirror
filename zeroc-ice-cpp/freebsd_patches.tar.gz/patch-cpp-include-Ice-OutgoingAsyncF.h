--- cpp.orig/include/Ice/OutgoingAsyncF.h	2011-06-15 21:43:58.000000000 +0200
+++ cpp/include/Ice/OutgoingAsyncF.h	2012-03-04 20:14:52.000000000 +0100
@@ -19,13 +19,13 @@
 
 class AsyncResult;
 typedef IceInternal::Handle<AsyncResult> AsyncResultPtr;
+ICE_API IceUtil::Shared* upCast(::Ice::AsyncResult*);
 
 }
 
 namespace IceInternal
 {
 
-ICE_API IceUtil::Shared* upCast(::Ice::AsyncResult*);
 
 class OutgoingAsync;
 ICE_API IceUtil::Shared* upCast(OutgoingAsync*);
