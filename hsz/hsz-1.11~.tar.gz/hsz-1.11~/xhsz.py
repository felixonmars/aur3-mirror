#!/usr/bin/python2 


def lookfor(File):
	from os.path import isfile
	from sys import path
	from os import getcwd
#	if isfile(File):
#		pass
#	elif isfile('libs/%s' % File):
#		path.append('libs/')
	if path.count(getcwd()) > 0:
		path.remove(getcwd())
	if isfile('/usr/lib/hsz/modules/%s' % File):
		path.append('/usr/lib/hsz/modules/')

lookfor('info.so')
lookfor('transcode.so')
'''
import Tkinter

class App:
	def __init__(self, master):
		mode = Tkinter.IntVar()
		# Label

		# radio buttons
		Rabbit0 = Tkinter.Radiobutton(master, text='Encode', variable=mode, value=0)
		Rabbit1 = Tkinter.Radiobutton(master, text='Decode', variable=mode, value=1)
		# clear button
		Clbutton = Tkinter.Button(master, text="Clear")
		# transcode button
		Trbutton = Tkinter.Button(master, text="Transcode")
		# Text Area 
		Tarea = Tkinter.Entry(master, width=10)

		Clbutton.grid(row=1, column=0, sticky=('N', 'W'))
		Trbutton.grid(row=3, column=3, sticky=('S', 'E'))
		Tarea.grid(row=1, column=2)
		Rabbit0.grid(row=2, column=0)
		Rabbit1.grid(row=3, column=0)

if __name__ == '__main__':
	root = Tkinter.Tk()
	root.title('X Html SymboliZe')
	app = App(root)
	root.mainloop()
'''


import wx 
class MainWindow(wx.Frame):
	def __init__(self, parent, id, title):
		wx.Frame.__init__(self, parent, id, title=title, size=(255,154))
#		panel = wx.Panel(self, -1)
		panel = wx.Panel(self, -1)
		vbox = wx.BoxSizer(wx.VERTICAL)
		vbox3 = wx.BoxSizer(wx.VERTICAL)
		vbox4 = wx.BoxSizer(wx.VERTICAL)
		vbox2 = wx.BoxSizer(wx.VERTICAL)
		hbox = wx.BoxSizer(wx.HORIZONTAL)
#		self.CreateStatusBar() # status bar at bottom of window
		# setting up the window menu
		filemenu = wx.Menu()
		aboutmenu = wx.Menu()
#
		# wx.ID_ABOUT and wx.ID_EXIT are standard IDs provided by wxWidgets.
		menuAbout = aboutmenu.Append(wx.ID_ABOUT, "&About", "Information about this program.")
		menuExit = filemenu.Append(wx.ID_EXIT, "E&xit", "Terminate this program")
#
#
		# create the menubar
		menuBar = wx.MenuBar()
		menuBar.Append(filemenu, "&File")
		menuBar.Append(aboutmenu, '&Help')
		self.SetMenuBar(menuBar)

		# events
		self.Bind(wx.EVT_MENU, self.OnAbout, menuAbout)
		self.Bind(wx.EVT_MENU, self.OnExit, menuExit)

		# text control area
		self.tc = wx.TextCtrl(panel, style=wx.TE_MULTILINE, pos=(50, 50))

		# buttons
		b_encode = wx.Button(panel, label="Encode")
		b_decode = wx.Button(panel, label="Decode")
		self.Bind(wx.EVT_BUTTON, self.One, b_encode)
		self.Bind(wx.EVT_BUTTON, self.Ond, b_decode)

		b_clear = wx.Button(panel, wx.ID_CLEAR, "Clear")
		self.Bind(wx.EVT_BUTTON, self.OnClear, b_clear)

		#vbox.Add(self.rb_encode, 0, 0)
		#vbox.Add(self.rb_decode, 0, 0)
		vbox.Add(self.tc, 1, wx.EXPAND)
		vbox.Add(hbox,1)
		hbox.Add(vbox2, proportion=1)
		hbox.Add(vbox3, 1, wx.EXPAND)
		hbox.Add(vbox4, 1, wx.EXPAND)
		vbox2.Add(b_clear, 1,0,0)
		#vbox3.AddSpacer(1)
		vbox3.Add(b_encode, 1, 0, 0)
		vbox4.Add(b_decode, 1, 0, 0)
		panel.SetSizer(vbox)


		self.Show(True)
		

	# OnAbout 
	def OnAbout(self,e):
		# a message dialog box with an OK button.  wx.OK is the standard, I believe.  
		dlg = wx.MessageDialog(self, "X Html SymboliZe\n\n\tv%s" % self.Version(), "About XHSZ", wx.OK)
		dlg.ShowModal()
		dlg.Destroy()
#
	# OnExit
	def OnExit(self,e):
		self.Close(True) # Close the frame, what else.  

	# On Transcode
	def One(self,e):
		import transcode
		a = transcode.encode(self.tc.GetValue())
		self.tc.SetValue(a.printout())

	def Ond(self,e):
		import transcode
		a = transcode.decode(self.tc.GetValue())
		d = ''
		c = ''
		if False :
			print a.printout() # FIXME, I only return integers!!!!
		for items in a.printout():
			if False:
				print 'items: %s' % items
			d += items
			if items == ' ':
				c += unichr(int(d))
				d = ''
				continue
		self.tc.SetValue(c)
		#self.tc.SetValue(unichr(int(a.printout())))

	# On Clear
	def OnClear(self,e):
		self.tc.SetValue('')
	def Version(self):
		lookfor('info.so')
		from info import version
		a = version()
		return a.printout()

class App(wx.App):
	def OnInit(self):
		frame = MainWindow(None, -1, "X Html SymboliZe")
		frame.Show(True)
		frame.Center()
		return True

class test(wx.App):
	def __init__(self):
		wx.App.__init__(self, redirect=False)

	def OnInit(self):
		frame = wx.Frame(None, -1, 
			"Test",
			pos=(50,50), size=(100,40),
			style=wx.DEFAULT_FRAME_STYLE)
		button = wx.Button(frame, -1, "Hello World!", (20, 20))
		self.frame = frame
		self.frame.Show()
		return True


if __name__ == '__main__':
#	app = test()
#	app.MainLoop()
	app = App(0)
#	frame = MainWindow(None, "X Html SymboliZe")
	app.MainLoop()

