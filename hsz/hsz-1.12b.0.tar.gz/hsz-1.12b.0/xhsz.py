#!/usr/bin/python2 
# vim: set softtabstop=8:

def lookfor(File):
	from os.path import isfile
	from sys import path
	from os import getcwd
#	if isfile(File):
#		pass
#	if isfile('libs/%s' % File):
#		path.append('libs/')
	if path.count(getcwd()) > 0:
		path.remove(getcwd())
	if isfile('/usr/lib/hsz/modules/%s' % File):
		path.append('/usr/lib/hsz/modules/')

lookfor('info.so')
lookfor('transcode.so')

import wx 

from wx.lib.embeddedimage import PyEmbeddedImage

hsz = PyEmbeddedImage("iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAAG0OVFdAAAABGdBTUEAALGPC/xhBQAAAAZi"
    "S0dEAP8A/wD/oL2nkwAAAAlwSFlzAABibQAAYm0B2SZdSAAAAAd0SU1FB90FHRU5CvxboFwA"
    "AAAdaVRYdENvbW1lbnQAAAAAAENyZWF0ZWQgd2l0aCBHSU1QZC5lBwAAEY1JREFUeNrtXXuw"
    "VlUV/333xeUC98OLcAkDKVORMsRrSD5SUocZdTTNxBclFtpjxpgmK5vKxgodLUtscmpSh9TK"
    "IivLLDVLExHwWZqv0jBQETDFB9x7wdMfe23P+va3n+fxve5ZM2fO952z9z5rr7P22mv/9tr7"
    "ABlSRIekbs09fv8eAOXMnn4S+/0I+/0840DSTDpfDgOLZQAr6ZDURdd5QQerBdj+G6mN/ZYC"
    "maikeVPhMNIJ1XSj2+PNVbH8CPuve30zddVUhRgpibqUgiJfIZY117QC7leEGNE1NQPnMluS"
    "JT7Mrl1A517GxaCasUP5/xBLXCI9eYV+A8AoVpUSGobU19PG/m8zvInFIQU76TpD5lmWgits"
    "wRQA7ZYnbgewgu736dQ4tT24lX6/YBBqZGidXvYgArDEZcWvM1RhpsYW6Mw/pmguRg4hnu8r"
    "xPnKtZJOwP0aIZbp+l4GCxX0ppa4Esh2P0FjI7aQkrWzJm7kIAJwk8YeDgMYIsNyr8FSp6fr"
    "lA6WVyMCsAPAQcQNp0GLZYpYPyJ/zwPwoC6x1KV2TRUfZ+kWst+9dL7X0Inp3ng/05rGosji"
    "TUll2MTO8l4P/e4BsK+lDHmeRoeXi+d7/31ZSGCN8oAJSh/LGdgMYJHBLJiUGQB2AjgLwCG6"
    "ikzQiGw5a5cmkcprC0mBv6gYPddRNnlYToeQfL9I41yEevPWh3MllNe6DVKIHB2TPN6ZtxLq"
    "HNoIwDM2sdwcoIQ3A1jKrKTtNZVDdEDt/HRKyNP2amyIzaKWk/SFNaUyO7/Ark/UiKwMYAyr"
    "zenUGk5jtdvmYRlzN+vedDnzV1XlsFm3QUUSoV11Y/aGpja9EcCRivl+2OKnlTXowZBOKr5d"
    "qTp+9VFUft5gUsLtNJJeoRiOPrp/Mp1/rpGOzVaoDPyNzm808itvPI64R8ubKm9+rqb6iOs5"
    "of5cr8ZehPqUFSPUlwA8wZQQhqHOVDq2smuv0Hk31gmZ6EnlrB2AlC39hO7+kqx0ICkDqamN"
    "xPaypx2fy97tcgB/9VTmReQVg3nVb9HpGq94mwUOfBe7d47Gy7kkwMkty+EvF7FtzFdm48Iv"
    "0LXXyRQPAnhMwS19PWzvDGVDRxUyOtpO+cZkyYAvXWjCjkxg6kxFpMcz63aKwtxShyWUerZV"
    "Zwnfb3h30FxXezrXO1YHNlpL+C8FdNBZQgAYr/yXeO5u9H+ro68p1cISBulKRwojpkOuz1b6"
    "CPngdhcDOkvYbeCcP1h3/1gDNqCjErd6L3pYQjXt3ixNiG+pfdW/9ES/ZNpISe/yLZ0MpPHV"
    "MsGJGson9BlW9RIYLEGutQkGLVWFhoxsOVZ4K4DbEgxatBLwhWD5VNEExXL6DlqaYMBQayU0"
    "TdPoaBbiuXI+aEmkhCOe+pikTUM82bJ0kl0N4OPM6+JvTzebPwxgEv0eq7l/EbXuGzQdts4r"
    "UAMd9gdwR4gAriSVigC8jfyeW9j9XxMj92vs454EvKi0EsACQwccAfgTgGfp2g6l3L+TB/EH"
    "D3dHJ4AhAMcw5+B+lwDmUl/aSW0kAvBu5rHcCGA0G/LY3KLvAviyg/EIwIcgZq8ixUm8j87r"
    "LfbCJYBR5LB00XmOJW9BBaU0gqr6nQlgGf1eBuBjqI7QiOrAQ25GUGeA+lh/PMQqfSgdkTIA"
    "rRUPuRhB9eGj2Qgpov8A8CsySssBfE6TtxY8eMOESaPO0uavObWNdOMnBfAagN0daX28t9EO"
    "f38sgHGk5iAQYV1GBnGcxtCOM/CghVIeUwaPXIV9vbc+Q/45Gst/G/wDJSI24OUGMUpxVDTP"
    "swjE3NWS0Md7e07JeyMEDDxfGUDzNEd5GsQDPQxiBGA2gAFW1g3Eg1MIPmBrKikbnpE3rVae"
    "995G6AVUQZ2fQ8UPVZ5xu48naKuAjxem06BuQ9pPemrR/oE8tGvKCPIEdQLw9cJUASxyOCwq"
    "DwdaBLHeg4dNSp7dQj3BXTUCCPHCXE2gDH1clc0T5OVNMPCwREl3TSt5gry8TuVeDywzn43q"
    "CapC2gzg8/S2O0gLP6Gp0D6ojGEuQ0wRuwysVw91D0FItjfo4wlOVvKvVqCpU5nHttGDyd9Y"
    "PMGNyLCLns8gpOdRHS2eFMczlRuRszJgUNssh8bwgcN6Iaa49kT1DGQaHM9Wruqx5TU09hJA"
    "QQW51STLyQwdPsiH5NMBvJozD0ECyHIyo1cjgF42JO+CWD1zTI48vEUdHgIZjzju40oAq+j6"
    "U6wi99Eoaz2AtzvK3Aoxmy4DYtfStUkQ4RyyzEk58lBQQQqdCf1EgstwJMHuTJMkJh5qagQL"
    "Gqk0ASI26mH4r13XDS5KEDM/EapDmjnJ1cwnBfA4E5W7IEi6wKDet9P1E30KT9O2eJvOC/MP"
    "9fOD1xi+gMrgNEkTPYaS5wK4U5P3JCYAzrgEMfYNGMuHCEDOC66l8zwXHJeFhzVZuTbWgf3l"
    "OdTVeZpWbeAZlkNECN7k+Ua6NAx1OaCp7RBLHmW6FSRc05xEX6AA2uCeItMWkCRm50KIxaVQ"
    "Hm57c7UY69+JOBbhTVcTqAUtQf1jihuBh4IKaiVP0OSFyUj6LagMhJKr9pfWkYdcPEEfuOse"
    "VM8P1JqH3DxB/n+M5uE9VLbc1KUfYq5AzZs3D0aqBd6X18RLCA+5eII+Xpg6/zgf8SKpevGQ"
    "mSeoa39rIADPk+m3rGAeM08hPBjVHxaDEbqvXWj+uu+dV+9AybpvHFhEihYCEMS3GsgSx7ue"
    "8tzPnnUQRHDDMCo3iUnrFbYj3qhsLf0vGXioIB5ja+pqfHE8U/7piBeY57WqzDW5ynnQWuO9"
    "LP1tEhyPr5z/HapD5lx5I9YdznJ4hUmPCkYGLAl8cTxd/naI2d4FGq0LOVyB2Ykr3+vRBEJx"
    "PDW/GqyoprsGImSmi9Q4AvBj2Heqy+zty4JnWxL64nhq3nl0fT15eSB/X8eIzSt83cMrlBHv"
    "naRxi+jlzgPwWeWZF5lGiVGeUiZax+4PhA5bE5AabbrGhg/WQgA72f1JOXfz6jqBQR9fPm8B"
    "PAvPEPYM3OzgMNpUcbee+U9T0ryE6pmlLEjlZZQPJhgqgAs0xsuUn6e1ac2LvjieBRN8Wilz"
    "D19M0FQBXzxOzb/OkLbk2YR+m4CHHyXRZInHqRlD8ThfAfD/jyN9sLP8f4KSZkUoJmiSnC8e"
    "55K8Kw5xraEpRh487KOk35gEE0xi3bMQgA4TXBPIQ2RxsLwxQV0hIXhcqABcmOBXFOO43tPi"
    "r/XFBOvRDSLA++M7Hg4b0qi2a9dWwgRnsN9PaO6vUvCEIyCW4GTmPOSRP6I23hZY3gGG/l8e"
    "l+bhPeUlAHVd0Aep7XfQAGmFkmYoB7e9gmZ5eII+mKCaX5b7PCq3xA45hnIat1SAiXlhgrpZ"
    "2jdQucG97TjEgglmJgDdZGIP0sf2mco9HWIDvA6IPQFO03SJWc0USzIGSLUxpFRGVUmUh38G"
    "6jsA9iNvTMUES9SOOwE8QGWWHOVOpXRTES+EKLFn9gO4C9UzxZvo/A8q6xaWL9NhpEppYvvU"
    "cocR7z6oW9ic5UyxUwMk5bXFja5cHXbn4xW6MMFUAtBRrePqRu52kgUVVH8yrcYI9QR9y70c"
    "1R8GlDPU8jNRefNQRTZLmfdWdz67QOWx0sSaKK9VHpsQfwZtGuJN3+UM9d7QL6nPY6WJt5Rq"
    "td9grTdV8E6U5SqPlYi/6Xkw/fcJbsxjpYl3E6jFZof12FWioTzBRuWhoIJGAulWWPjs+5d0"
    "lYdu9YjPKo/cPEHTB+ZcljNJPJ9p9UgtN14uqKCCClKoHfGeC0tpqPFRCHDbd+sRuSGm3AX0"
    "OBrd++zqs5jyrkL8daoyxNLnewEcTo7uAQD+SWlPbcC6lSEmDy4G8AG499f1TQuInRoi6gv3"
    "ggj7mkvDwN60CjCDMXBygvxdEPtgXcv6xC0AvuaRdzo9dyfij7fZSEZzDSkVLxuEWK+6leG/"
    "t6gr7S/o3nwPfkOe+xZNoaGm3KZyCyq/G14mp+d/BofnLLovozMuIaekx/HcTgAP0TPP8OCz"
    "n/G4uMHrlpUCSP5k4Ndh1PoPQ7yN8BFpWv9YiG/+SRBlNMSMVgTgUbr2HlRuyAIF39gA4Hv0"
    "fxeIid3PeDz7S4g3jrcFjHQD+D2lPaVJ6paVAvQg/sRhv6ZByE8hJu4GOhBH5C1Urn+fmed3"
    "GPKfBxHuLFvPVRDhTF0eY7SIWudEC29XUbpPNVHdsu4CzqB7RyvXj9b4TolpNkSs7A7EUYlX"
    "Q4Dw5zIGF7OB/xRK/xH6L1vTXMezRiEO5z7eQyimg/sMU+nas6jeSLxWdfPhuZwgLSACrC5m"
    "XdkwRMzwfgoPNjm0LHXR6ODTI3w0V8ihoIIKKqigRkYCQxCw0Yj3D19AjtAC5vnyRRJzCDnc"
    "pBkr/9nTc28FOTQVEmgb/rRBBI1EiANJJB1M11dSunEQ0fe2sfJdDGtoJtQwRA6JqRHRsl4I"
    "uFcXcy7XkEk4uAPAg46x8qAHWNLscmg6JNBW8TGIoc5pyr1piL+oxoV7FCo/KvgggHPo9wbH"
    "uLiV5NAyaNkiurdMub4M+k/46eom+/SBESyHREig7RifM1o21XH/hxpBlQB8mHUFwwDugH6L"
    "smZDDWX6K6j7ieh8BXL6Ukg5gLFme36BljHTNhJpCGIiasRTWyGCQgEKKhQAJQCXIQ7MmIHq"
    "zxnXGk2c5Uh3M4CzyZnrIJMun30Jc86aLa7Q9C72Yc+/jNL1Qny7y0cOVuLjzN0DPNQ8UbQk"
    "TuA0Bt6McTyLxxUeA+AbpFRPG57HNya6G8BXCWDqyxgh1L0LSdPZmN9WP5McnAEqh0NsOBT8"
    "ieocUDQfBVDTvIrqj7Kq1AmBvUc5HS9nULc8D+2L7wbwH8U8hbbArFG03RNURO4AvF4ztu8C"
    "8McaCPjYDOpWFwWQu/rOTqgAWaNo1yaoyFzEXx3mW6VOZli67jgP9tk0U932gFjq5eIrBCHU"
    "vQtJcvHwOgO/baRkpnrutPkrJXJK7vZEAmuBotmOEyHWyMsX+xr14Yco/IxH88UV6t7FDvp/"
    "HCu7BLFO4BbEYeOm46fU+LxjBevZTyU2ZRri08S6nXGbHSGcTN2LSU7PUZrgurWSAmyDeUe+"
    "ZkZxf5bAH8FIU4ASmUhTOVd7DBkbjRY6ZPODLEC+VpoMKrOxtetYA7Fj8xw03lzJHgQ8mXh/"
    "KgCXcCJd0xK8gCxj4Xws0KkB5bYB+GYGlmc1xOaPk1Mifr5ykCODvzj4OjKtdqkoXmgLzDoW"
    "zkcBbGFQNtRrGsRHLbPqjn7CnpG1HM7zeHYuMYEvBSpA1rFwPgqwOEG5JuqHWHS6nOYOkijC"
    "Boi9rbKQw4BjOP4AObi5xQTeFKAAecTCpfUBkqyRt6GZj1Nr/LenRUgjh0ctZQ8rAFFuMYEh"
    "LyCPWLh6KEAImjmDLKapdbYHymEXTytTxARaULyQGLssEL+vW3yTuRnJIYKY8u1GERPYcDGB"
    "/YEzgipNAvBfSx1fh9gLqC7UKgrQS635CGT7De82iB1adbxd4THkvj6Fg1soQMDzdeVsBvBt"
    "xNvthlAfIW0mvu50AEhlVH5OVPfpwE40ALWyAuR1nNAEEHtZNWOSdCtr06KJecYEDsBvJXAp"
    "Z0XdQY5vCWK/PlfdXm7EyYVmW1kbwq8uxq4PYg3htxAvGn2SXo46AhqEiJZaxa4tzLFuaYaz"
    "5aQWutlW1ibh93BUxztuJquRBClttr0GvajZVtb68KuLd5S0P11/BvaQsFbYazAxQtgMK2tt"
    "/KaJsWuEutVMAZptZW0Iv74xdo1Stzz3GkxNrbyytlg1XFBBBRVU0Eik0K9X5I0E1mOPvZCV"
    "uc0ohyBlcH3qpBX32AtdmdvMXyjJpaBW2WNvJKCGmRfUCnvsjSTUMPOCWmGPvZGEGqZCn1p5"
    "j71WRg0LtKyQQ0EFFVRQQQUlRsuyGm7UEi0L+ZJIFl/maEokMOSLFFkEKTRi/GBbRnJoGiTw"
    "/8hZJkG7sO3wAAAAAElFTkSuQmCC")
gethszData = hsz.GetData
gethszImage = hsz.GetImage
gethszBitmap = hsz.GetBitmap


stockUndo = []
stockRedo = []

class AuxWindow(wx.Frame): # TODO, finish writing me, please.  
	def __init__(self, parent, id, title):
		wx.Frame.__init__(self, parent, id, title=title, size=(253, 175))
		self.SetMaxSize(179)
		panel = wx.Panel(self, -2)

		self.st1 = wx.StaticText(panel, label="", style=wx.ALIGN_CENTRE)
		a = ""
		for index in range(len(stockUndo)):
			a += "\tL%s: %s\n" % (index, stockUndo[index])
		self.st1.SetLabel(a)

class MainWindow(wx.Frame):
	def __init__(self, parent, id, title):
		wx.Frame.__init__(self, parent, id, title=title, size=(259, 201))

		panel = wx.Panel(self, -1)

		self.SetIcon(hsz.GetIcon())

		sizer = wx.GridBagSizer(4, 4)

		self.statusbar = self.CreateStatusBar() # status bar at bottom of window
		self.statusbar.SetStatusText('Ready')

		# setting up the window menu
		filemenu = wx.Menu()
		viewmenu = wx.Menu()
		editmenu = wx.Menu()
		aboutmenu = wx.Menu()
		debugmenu = wx.Menu()
		self.uIndex = 1
		self.rIndex = 0

		# wx.ID_ABOUT and wx.ID_EXIT are standard IDs provided by wxWidgets.
		m_About = aboutmenu.Append(wx.ID_ABOUT, "&About", "Information about this program.")
		m_Debug = aboutmenu.AppendMenu(wx.ID_HELP, '&Debug', debugmenu)
		m_Stat = debugmenu.Append(wx.ID_PREVIEW, '&Stats', 'Print statistical information to the terminal')
		m_Exit = filemenu.Append(wx.ID_EXIT, "&Quit", "Quit program.")

		self.m_Undo = editmenu.Append(wx.ID_UNDO, "&Undo\tCtrl+Z", "Undo changes.")
		self.m_Redo = editmenu.Append(wx.ID_REDO, "&Redo\tCtrl+Shift+Z", "Redo changes.")
		editmenu.AppendSeparator()

		self.m_Clear = editmenu.Append(wx.ID_CLEAR, "C&lear\tCtrl+M", "Clear text area.")
		editmenu.AppendSeparator()
	#	self.m_Encode = editmenu.Append(wx.ID_ANY, "&Encode\tCtrl+S", "Encode text area.")
	#	self.m_Decode = editmenu.Append(wx.ID_ANY, "&Decode\tCtrl+D", "Decode text area.")
	#	editmenu.AppendSeparator()
		self.m_Cut = editmenu.Append(wx.ID_CUT, "Cu&t", "Cut from text area.")
		self.m_Copy = editmenu.Append(wx.ID_COPY, "Cop&y", "Copy from text area.")
		self.m_Paste = editmenu.Append(wx.ID_PASTE, "P&aste", "Paste into text area.")
		self.m_Redo.Enable(False)

		
		self.show_status = viewmenu.Append(wx.ID_ANY, 'Hide &statusbar', 'Display or hide Statusbar', kind=wx.ITEM_CHECK)
	#	self.show_buttons = viewmenu.Append(wx.ID_ANY, 'Hide &buttons', 'Display or hide buttons', kind=wx.ITEM_CHECK)
		
		
#############################################################################################

		# create the menubar
		menuBar = wx.MenuBar()
		menuBar.Append(filemenu, "&File")
		menuBar.Append(editmenu, "&Edit")
		menuBar.Append(viewmenu, "&View")
		menuBar.Append(aboutmenu, '&Help')

		self.SetMenuBar(menuBar)

		# events
		self.Bind(wx.EVT_MENU, self.OnStat, m_Stat)
		self.Bind(wx.EVT_MENU, self.OnAbout, m_About)
		self.Bind(wx.EVT_MENU, self.OnExit, m_Exit)
		self.Bind(wx.EVT_MENU, self.OnUndo, self.m_Undo)
		self.Bind(wx.EVT_MENU, self.OnRedo, self.m_Redo)
		self.Bind(wx.EVT_MENU, self.ToggleStatusBar, self.show_status)
	#	self.Bind(wx.EVT_MENU, self.ToggleButtons, self.show_buttons)
		self.Bind(wx.EVT_MENU, self.OnClear, self.m_Clear)
	#	self.Bind(wx.EVT_MENU, self.One, self.m_Encode)
	#	self.Bind(wx.EVT_MENU, self.Ond, self.m_Decode)
		self.Bind(wx.EVT_MENU, self.OnCut, self.m_Cut)
		self.Bind(wx.EVT_MENU, self.OnCopy, self.m_Copy)
		self.Bind(wx.EVT_MENU, self.OnPaste, self.m_Paste)

		# text control area 
		self.tc = wx.TextCtrl(panel, style=wx.TE_MULTILINE, pos=(0, 0), size=(150, 62))

		#self.st = wx.StaticText(panel, label='%s\n%s' % (self.uIndex, self.rIndex), style=wx.ALIGN_LEFT)
		# buttons
		self.b_encode = wx.Button(panel, label="E&ncode", pos=(75, 63), size=(75, 62))
		self.b_decode = wx.Button(panel, label="&Decode", pos=(150, 62), size=(75, 62))
		self.Bind(wx.EVT_BUTTON, self.One, self.b_encode)
		self.Bind(wx.EVT_BUTTON, self.Ond, self.b_decode)

		self.b_clear = wx.Button(panel, wx.ID_CLEAR, "Clear", pos=(0, 62))
		self.Bind(wx.EVT_BUTTON, self.OnClear, self.b_clear)

		sizer.Add(self.tc, pos=(0, 0), span=(3, 3), flag=wx.EXPAND, border=6)
		sizer.AddGrowableCol(1)
		sizer.AddGrowableRow(0)
		sizer.AddGrowableRow(1)
		sizer.AddGrowableCol(2)
		sizer.Add(self.b_clear, pos=(3, 0), flag=wx.LEFT, border=6)
		#sizer.Add(self.st, pos=(3, 0), flag=wx.LEFT, border=6)
		sizer.Add(self.b_encode, pos=(3, 1), flag=wx.EXPAND|wx.RIGHT, border=2)
		sizer.Add(self.b_decode, pos=(3, 2), flag=wx.EXPAND|wx.RIGHT, border=6)

		panel.SetSizer(sizer)

		# initial value for stockUndo
		stockUndo.append(self.tc.GetValue())

		self.Show(True)

	def OnCut(self,e):
		dataObj = wx.TextDataObject()
		if False:
			print self.tc.Selection
		if self.tc.Selection[0] is self.tc.Selection[1]:
			dataObj.SetText(self.tc.GetValue())
			self.tc.SetValue('')
		else :
			if False:
				print self.tc.Cut()
			else :
				self.tc.Cut()

	def OnCopy(self,e):
		dataObj = wx.TextDataObject()
		if self.tc.Selection[0] is self.tc.Selection[1]:
			dataObj.SetText(self.tc.GetValue())
		else :
			dataObj.SetText(self.tc.GetStringSelection())

		if wx.TheClipboard.Open():
			wx.TheClipboard.SetData(dataObj)
			wx.TheClipboard.Close()
		else :
			wx.MessageBox("Unable to open clipboard", "Error")
	def OnPaste(self,e):
		dataObj = wx.TextDataObject()
		if wx.TheClipboard.Open():
			wx.TheClipboard.GetData(dataObj)
			wx.TheClipboard.Close()
			self.tc.SetValue(dataObj.GetText())

	def OnStat(self,e):
		print 'b_encode.GetPosition(): %s' % self.b_encode.GetPosition()
		print 'b_decode.GetPosition(): %s' % self.b_decode.GetPosition()
		print 'b_clear.GetPosition(): %s' % self.b_clear.GetPosition()
		print 'self.tc.GetPosition(): %s' % self.tc.GetPosition()
		print 'self.GetPosition(): %s\n' % self.GetPosition()
		print 'b_encode.GetSize(): %s' % self.b_encode.GetSize()
		print 'b_decode.GetSize(): %s' % self.b_decode.GetSize()
		print 'b_clear.GetSize(): %s' % self.b_clear.GetSize()
		print 'self.tc.GetSize(): %s' % self.tc.GetSize()
		print 'self.GetSize(): %s\n' % self.GetSize()

	def ToggleButtons(self,e):
		if self.show_buttons.IsChecked():
			self.b_clear.Hide()
			from time import sleep
			sleep(1)
			self.b_encode.Hide()
			self.b_decode.Hide()
			print self.tc.Update()
		else:
			self.b_clear.Show()
			self.b_encode.Show()
			self.b_decode.Show()

	def ToggleStatusBar(self,e):
		if self.show_status.IsChecked():
			self.statusbar.Hide()
		else :
			self.statusbar.Show()

	# OnAbout 
	def OnAbout(self,e):
		# a message dialog box with an OK button.  wx.OK is the standard, I believe.  
		info = wx.AboutDialogInfo()
		info.SetName('Html SymboliZe')
		info.SetVersion('%s' % self.Version())
		info.SetCopyright('(C) 2013, Alexej Magura')
		info.SetWebSite('http://sourceforge.net/projects/htmlsymbolize/')
		info.AddDeveloper('Alexej Magura')
		info.SetLicense('%s' % self.License())
		wx.AboutBox(info)
#		dlg = wx.MessageDialog(self, "Html SymboliZe\n\n\tv%s" % self.Version(), "About HSZ", wx.OK)
#		dlg.ShowModal()
#		dlg.Destroy()
#
	# OnProcess
	def Processing(self, mode, debug=False):
		if mode is 1 or mode is True:
			self.statusbar.SetStatusText('Processing...')
			if debug:
				print 'mode: %s' % 1
		elif mode is 0 or mode is False:
			self.statusbar.SetStatusText('Ready')
			if debug:
				print 'mode: %s' % 0
		else :
			self.statusbar.SetStatusText('Ready')
	# OnExit
	def OnExit(self,e):
		self.Close(True) # Close the frame, what else.  

	def OnUndo(self,e):
		self.Processing(1)
		if True:
			print 'stockUndo: %s\n' % stockUndo
		self.Add2Redo(self.tc.GetValue())
		self.rIndex += 1
		if len(stockUndo) is 1:
			self.tc.SetValue(stockUndo[0])
			self.m_Undo.Enable(False)
			self.uIndex -= 1
		else :
			self.tc.SetValue(stockUndo.pop())
			self.uIndex -= 1
		self.Processing(0)

	def OnRedo(self,e):
		self.Processing(1)
		if True:
			print 'stockRedo: %s\n' % stockRedo
		self.Add2Undo(self.tc.GetValue())
		if len(stockRedo) is 1:
			self.tc.SetValue(stockRedo[0])
			self.m_Redo.Enable(False)
		elif len(stockRedo) is 0:
			self.m_Redo.Enable(False) # do nothing
		else :
			self.tc.SetValue(stockRedo.pop())
		self.Processing(0)

	def Add2Redo(self, what):
		stockRedo.append(what)
		if self.m_Redo.IsEnabled() is False:
			self.m_Redo.Enable(True)


	def Add2Undo(self, what):
		stockUndo.append(what)
		if self.m_Undo.IsEnabled() is False:
			self.m_Undo.Enable(True)

	# OnChange
#	def OnChange(self):
#		while self.tc.GetValue() is stockUndo[0]:
#			pass # do nothing
#		self.Add2Undo(self.tc.GetValue())

	# On Encode
	def One(self,e):
		self.Processing(1)
		import transcode
		self.Add2Undo(self.tc.GetValue())
		a = transcode.encode(self.tc.GetValue())
		self.tc.SetValue(a.printout())
		self.Processing(0)
	# On Decode
	def Ond(self,e):
		self.Processing(1)
		import transcode
		self.Add2Undo(self.tc.GetValue())
		a = transcode.decode(self.tc.GetValue())
		d = ''
		c = ''
		if False :
			print a.printout() # FIXME, I only return integers!!!!
		for items in a.printout():
			if False:
				print 'items: %s' % items
			d += items
			if items == ' ':
				c += unichr(int(d))
				d = ''
				continue
		self.tc.SetValue(c)
		self.Processing(0)

		#self.tc.SetValue(unichr(int(a.printout())))
#	def Watch(self):
#		while self.tc.GetValue() is '' and len(stockUndo) is 1:
#			
	# On Clear
	def OnClear(self,e):
		self.Add2Undo(self.tc.GetValue())
		self.m_Undo.Enable(True)
		self.tc.SetValue('')

	def License(self):
		from info import license
		a = license()
		return a.printout()

	def Version(self):
		from info import version
		a = version()
		return a.printout()

class App(wx.App):
	def OnInit(self):
		frame = MainWindow(None, -1, "Html SymboliZe")
		frame.Show(True)
		frame.Center()
		return True
'''
class test(wx.App):
	def __init__(self):
		wx.App.__init__(self, redirect=False)

	def OnInit(self):
		frame = wx.Frame(None, -1, 
			"Test",
			pos=(50,50), size=(100,40),
			style=wx.DEFAULT_FRAME_STYLE)
		button = wx.Button(frame, -1, "Hello World!", (20, 20))
		self.frame = frame
		self.frame.Show()
		return True
'''

if __name__ == '__main__':
#	app = test()
#	app.MainLoop()
	app = App(0)
#	frame = MainWindow(None, "Html SymboliZe")
	app.MainLoop()

