/***
   (filename) 
   
   regex.cpp

   (copyright)

   Copyright (c) 2013 Alexej Magura
   
   This file is part of Regex-gen.

   Regex-gen is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   Regex-gen is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with Regex-gen.  If not, see <http://www.gnu.org/licenses/>.

   ***/
#include <iostream> // std::cout 
#include <string> // std::string 
#include <cstring> // std::strlen
#include <string.h> // getopt 
#include <stdbool.h> // true, false
#include <sstream> // std::stringstream 
#include <unistd.h> // getopt
#include <getopt.h> // getopt_long
#include <algorithm> // std::remove

char __version__[] = "0.1c.rev24";

char __copying__[] = "  Copyright (c) 2013 Alexej Magura\
		     \
		     \n\n  This file is part of Regex-gen.\
		     \
		     \n\n  Regex-gen is free software: you can redistribute it and/or modify\
		     \n  it under the terms of the GNU General Public License as published by\
		     \n  the Free Software Foundation, either version 3 of the License, or\
		     \n  (at your option) any later version.\
		     \n\n  Regex-gen is distributed in the hope that it will be useful,\
		     \n  but WITHOUT ANY WARRANTY; without even the implied warranty of\
		     \n  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\
		     \n  GNU General Public License for more details.\
		     \n\n  You should have received a copy of the GNU General Public License\
		     \n  along with Regex-gen.  If not, see <http://www.gnu.org/licenses/>.\n";



struct def_t
{
    char* bracket;	/* -b option, [<optarg>] */
    int debug;		/* --debug option */
    int nobrackets;     /* --no-brackets option */
    int addstart;
    int addend;
    char* notbracket;   /* -n option, [^<optarg>]*/
    char* start_c;
    char* end_c;


} def;

static const char* short_opts = "seVch";

static const struct option long_opts[] =
{
//    { "bracket-first", required_argument, NULL, 'b'},
    { "debug", no_argument, &def.debug, true},
    { "no-brackets", no_argument, &def.nobrackets, true},
    { "add-start", no_argument, &def.addstart, true},
    { "add-end", no_argument, &def.addend, true},
    { "version", no_argument, NULL, 'V'},
    { "copying", no_argument, NULL, 'c'},
    { "help", no_argument, NULL, 'h'},
    { "start", required_argument, NULL, 3},
    { "end", required_argument, NULL, 4}

//    { "not-bracket", required_argument, NULL, 'n'}
};

void std_regex(std::string str)
{
    std::stringstream ss_a;


    if ( def.addstart == true)
    {
	if ( def.start_c != NULL)
	{
	    ss_a << def.start_c;
	}
	else
	{
	    ss_a << "^";
	}
    }

    for ( char& c : str)
    {
	if ( def.debug == true)
	{
	    std::cout << "c: " << c << std::endl;
	}
	
	if ( def.nobrackets)
	{
	    ss_a << c;
	}
	else
	{
	    ss_a << "[" << c << "]";
	}
    }

    if ( def.addend)
    {
	if ( def.end_c != NULL)
	{
	    ss_a << def.end_c;
	}   
	else 
	{
	    ss_a << "$";
	}
    }
    std::cout << ss_a.str();
}

int main(int argc, char** argv)
{

    if ( argc == 1)
    {
	fprintf(stderr, "%s: missing string operand\n", argv[0]);
	return 1;
    }

    int c;
    int* optc = 0;

    // Initialize def

//    def.bracket = NULL;
    def.debug = false;
    def.nobrackets = false;
    def.addstart = false;
    def.addend = false;
    def.start_c = NULL;
    def.end_c = NULL;
//    def.notbracket = NULL;


    // process args
    while (( c = getopt_long(argc, argv, short_opts, long_opts, optc)) != -1) // while #{stuff} does not equal EOF, do
    {
	switch(c)
	{
//	    case 'b':
//		if ( def.debug == true)
//		{
//		    std::cout << "optarg: " << optarg << std::endl;
//		}
//
//		def.bracket = optarg;
//
//		if ( def.debug == true)
//		{
//		std::cout << "length of def.bracket: " << strlen(def.bracket) << std::endl;
//		}
//		break;
//
//	    case 'n':
//		def.notbracket = optarg;
//		break;

	    case 's':
		def.addstart = true;
		break;

	    case 'e':
		def.addend = true;
		break;

	    case 'V':
		printf("%s\n", __version__);
		return 0;
		break;

	    case 'c':
		printf("%s\n", __copying__);
		return 0;
		break;

	    case 'h':
		std::cout << "usage: " << argv[0] << " [option] string\n\n";
		std::cout << "  -h, --help\t\tprint this message and exit\n";
		std::cout << "  -c, --copying\t\tprint copyright information and exit\n";
		std::cout << "  -V, --version\t\tprint version and exit\n";
		std::cout << "  -s, --add-start\tprepend regex with start_character (default: '^')\n";
		std::cout << "  -e, --add-end\t\tappend regex with end_character (default: '$')\n";
		std::cout << "      --debug\t\tprint program internals while running\n";
		std::cout << "      --no-brackets\tdo not use brackets ('[', ']') in the regex\n";
		std::cout << "      --start=STRING\tset start_character as STRING (implies -s)\n";
		std::cout << "      --end=STRING\tset end_character as STRING (implies -e)\n";
		break;

	    case 3:
		def.start_c = optarg;
		def.addstart = true;
		break;
	    case 4:
		def.end_c = optarg;
		def.addend = true;
		break;

		
	}
    }



    std::string arga;
    int argi;

    for ( argi = optind; argi < argc; argi++)
    {
	// don't pass switches to regex()
	    arga += argv[argi];
    }
    
    std_regex(arga);
    
    return 0;
}
