## Включаем функции VirtualBox. Если не VirtualBox ничего страшного не произойдет
#/usr/bin/VBoxClient-all 2>/dev/null &
