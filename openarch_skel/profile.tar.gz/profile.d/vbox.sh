## Включаем функции VirtualBox. Если не VirtualBox ничего страшного не произойдет
/usr/bin/VBoxClient-All 2>/dev/null &
