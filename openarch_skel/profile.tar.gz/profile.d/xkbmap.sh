# Установим переключалку на русский
setxkbmap us -option
setxkbmap us,ru -option "grp_led:scroll,grp:alt_shift_toggle,terminate:ctrl_alt_bksp"
