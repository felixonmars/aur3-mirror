/* 
 *
 * Copyright (C) 2007  Diego Pérez Montes
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Class: Scanner Implementation
 * Author: Diego Pérez Montes
 * E-mail: kabute@gulo.org
 */

#define MAX_SIZE 600

#include <ulysses.h>

/*
Method: Scanner constructor
*/
Scanner::Scanner()
{
host = new hostent;
n_ports=0; //Not open ports when we start
ssh_open=false;
smb_open=false;
};

/*
Method: Scanner destructor
*/
Scanner::~Scanner()
{
//delete serv_name;
//delete host;
}

/*
Method: Set host "attributes"
*/
void Scanner::set_he(struct hostent *he_tmp)
{
*host=*he_tmp;
}

/*
Method: Port scanner
*/
string Scanner::scan_ports(int end_port) 
{ 
        int num_ports=0;
	int serv_port=0;
        string buffer="";
	string scan_result="<table  border=\"1\" cellpadding=\"3\" cellspacing=\"0\" width=\"100%\"> <tr><td><b>Port</b></td><td><b>Service</b></td><td><b>Version</b></td><td><b>Security</b></td></tr>";
	stringstream tmp;
        string service;
	string webs;
  	char buf[MAX_SIZE+1]="";
        
	struct servent *servname=new servent;//Servent to get the service name (see /etc/services)
  	servname=getservbyport(port,"tcp"); //Service Name
	setservent(0);
	servname=getservent();

  
	for(port=1; port<=end_port; port++) //Port scanning
	{
	 //cout<<"Port:"<<port<<endl;


	 //Get service name by port number
	 struct sockaddr_in their_addr; // Connector's address information
         if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) { 
             perror("socket"); 
             exit(1);
         }

         their_addr.sin_family = AF_INET;    // Host byte order 
         their_addr.sin_port = htons(port);  // Short, network byte order 
         their_addr.sin_addr = *((struct in_addr *)host->h_addr);
         memset(&(their_addr.sin_zero), '\0', 8);  // Zero the rest of the struct 

         if (connect(sock, (struct sockaddr *)&their_addr, sizeof(struct sockaddr)) == -1) 
         {
          close(sock);
         }
	 else 
         { 
	  tmp.str("");
  	  tmp<<port;
	  strcpy(buf,"                                                                ");
	  buffer="";
          num_ports++;
     
          //Formation of the scanner result for the final report
          scan_result+="<tr><td bgcolor=\"#FFFFFF\"><table cellpadding=\"4\"cellspacing=\"0\"><tr><td bgcolor=\"#FFFFFF\" width=\"100%\">"+tmp.str()+"</li></td></tr></table></td>";


          while(ntohs(port)> htons(servname->s_port))
          {
	   servname=getservent();
	  }
	  
	  if(port==(servname->s_port)) 
          {
	   //cout<<port<<endl;
	   service=(string)(servname->s_name); scan_result+="<td>"+service+"</td>";

	  } //Known service
    
	 else  scan_result+="<td>Unknown </td>"; //Unknown service
	 //cout<<"PORT: "<<port<<" "<<htons(port)<<" "<<(servname->s_port)<<" "<<servname->s_name<<endl;

//Identified port version (by now) 21,22,25,80

	   switch(port) //BIG PROBLEM WITH POSTFIX, IT HAS THE HOSTNAME, SO... IT NEEDS TO BE SOLVED ;ALSO DOESN'T WORK WITH FILTERD PORTS!!!
	   {

		case 22: 
		ssh_open=true;
		recv(sock,buf,MAX_SIZE,0); scan_result+=(string)get_version((string)buf,port); break;

                case 21||25: recv(sock,buf,MAX_SIZE,0); scan_result+=(string)get_version((string)buf,port); break;

		case 80: 
 		send(sock,"GET UNKNOWN\n", MAX_SIZE,0); //Let's get the error page!

		recv(sock,buf,MAX_SIZE,0); //Parse this result to get the server version
		//cout<<buf<<endl; //Buffer content
		webs=id_websrv(buf);
                //cout<<"WEB SERVER:"<<webs<<endl;
		//scan_result+=(string)get_version(webs,port);
		scan_result+="<td>"+webs+"</td><td><a href=\"http://www.securiteam.com/cgi-bin/htsearch?config=&restrict=&exclude=%2Fwindowsntfocus%2Farchive%7C%2Ftools%2Farchive%7C%2Fsecuritynews%2Farchive%7C%2Fexploits%2Farchive%7C%2Fsecurityreviews%2Farchive%7C%2Funixfocus%2Farchive&method=and&format=long&sort=score&restrict=&words="+webs+"\"> Info [1] </td>";

		break; 

		case 139: smb_open=true;
	        scan_result+=(string)no_version("Samba",port); break;
		
		default:
		scan_result+=(string)no_version(service,port); //Other ports are not being identified

		break;

	 }

   
	  scan_result+="<br><br></tr>";

         
	  close(sock);
	}
	}

	this->n_ports=num_ports;
	scan_result+="</table>";
	endservent();

	return scan_result; //The report is ready to be shown
}


/*
Method: Get host name
*/
char *Scanner::get_host()
{

	return host->h_name;
}

/*
Method: Get open ports in scanned host
*/
int Scanner::get_num_ports()
{

	return n_ports;
}

/*
Method: Don't scan port version
*/
string Scanner::no_version(string service, int port)
{


	string content_tmp=service;

	return "<td>"+content_tmp+"</td><td><a href=\"http://www.securiteam.com/cgi-bin/htsearch?config=&restrict=&exclude=%2Fwindowsntfocus%2Farchive%7C%2Ftools%2Farchive%7C%2Fsecuritynews%2Farchive%7C%2Fexploits%2Farchive%7C%2Fsecurityreviews%2Farchive%7C%2Funixfocus%2Farchive&method=and&format=long&sort=score&restrict=&words="+content_tmp+"\"> Info [1] </td>";

}

/*
Method: Get the service's version (using the Ulysses "DB")
*/
string Scanner::get_version(string ver_str,int port)
{
	//See if file exists!!!
	char port_file[30]="";
	char tmp[5]="";
	char tmp_cont;
	string content="";
	string content_tmp="";
	string last="";
	string last_tmp="";
        
       /* "DB" query, by now in plain text files, it will be ported to XML files in the future*/
	sprintf(tmp, "%i", port);
	strcat(port_file,"./db/");
	strcat(port_file,tmp);
	strcat(port_file,".db");

	ifstream version_file(port_file);

	if(version_file.is_open())
	{

		while((!version_file.eof())&&(!comp_str(content,ver_str)))
		{

		tmp_cont=version_file.get();
		content_tmp+=tmp_cont;

		if(tmp_cont=='#')
		{ 
   			content=content_tmp; //Change of the strings
   			content_tmp="";
   			content.erase(content.length()-1,1);
   			content.erase(content.length()-1,1);

		}

	
		if(tmp_cont=='\n')  //If the line ends
		{
			content="";
			content_tmp="";
   
		}

		}

	content_tmp.erase(0,1);



	if(comp_str(content,ver_str)) 
	{
	content_tmp="";
	//If it is the same we have to get the version from the "db"
	
	while(tmp_cont!='\n')
	{
		tmp_cont=version_file.get();
		content_tmp+=tmp_cont;
	}


	content_tmp.erase(0,1);
	//cout<<"CONTENT: "<<content_tmp<<endl;
	version_file.close();
	
	return "<td>"+content_tmp+"</td><td><a href=\"http://www.securiteam.com/cgi-bin/htsearch?config=&restrict=&exclude=%2Fwindowsntfocus%2Farchive%7C%2Ftools%2Farchive%7C%2Fsecuritynews%2Farchive%7C%2Fexploits%2Farchive%7C%2Fsecurityreviews%2Farchive%7C%2Funixfocus%2Farchive&method=and&format=long&sort=score&restrict=&words="+content_tmp+"\"> Info [1] </td>";
	}

	
	else 
	{
	
	version_file.close();
	return "<td>Unknown</td>";
	}

       } 
	

      else 

	{

	return "<td>Unknown</td>";
	}

}


/*
Method: Local-Remote string comparisson
*/
bool Scanner::comp_str(string local,string remote)
{
	int i=0;
	int c=0;


	while(i<local.length())
	{
	if(local.at(i)==remote.at(i)) { c++;}

	i++;
	}


	if((local.length()==c)&&(c>0)){ return true; }

	else return false;
}

/*
Method: Web server version identification
*/

string Scanner::id_websrv(char* buf)
{


	int found;
        string ver=(string)buf;
        string res="";
	found=ver.find ("IIS",0);
	if (! (found == string::npos)) {

         res+="Microsoft-";
         while(ver.at(found)!=' ')
         {
         res+=ver.at(found); found++;
	 }
         //cout<<"RESULTS "<<res<<endl;
         return res; }

	found=ver.find ("Apache",0);
	if (! (found == string::npos)) {

         while(ver.at(found)!=' ')
         {
         res+=ver.at(found); found++;
	 }
         //cout<<"RESULTS "<<res<<endl;
         return res; }


        return "Unknown Version";

}

/*
Method: Basic OS Fingerprinting
*/

string Scanner::basic_os_fingerprint()
{

	if(ssh_open) return " *NIX Type";
	else
  	 if(smb_open) return " Microsoft Windows";

	return "Unknown OS";

}
