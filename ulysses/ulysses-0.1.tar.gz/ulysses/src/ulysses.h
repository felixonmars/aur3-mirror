/* 
 *
 * Copyright (C) 2007  Diego Pérez Montes
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Class: Scanner Interface
 * Author: Diego Pérez Montes
 * E-mail: kabute@gulo.org
 */

#ifndef ULYSSES_H
#define ULYSSES_H

#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sstream>
#include <fstream>

using namespace std;

class Scanner
{

private:
 	int sock;
        int port;
        int n_ports; //Number of opened ports;
        bool ssh_open; //Used for get de OS type
        bool smb_open; //Used for get de OS type
        struct hostent *host; //Host data structure
        
        
public:
	Scanner(); 
       ~Scanner();
        void set_he(struct hostent *he_tmp);
	void set_port();
        string scan_ports(int end_port);
        char* get_host();
        int get_num_ports();
        string get_version(string ver_str,int port);
        bool comp_str(string local,string remote);
        string no_version(string service, int port);
        string id_websrv(char* buf);
        string basic_os_fingerprint();

};


#endif
