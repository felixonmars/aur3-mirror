/* 
 *
 * Copyright (C) 2007  Diego Pérez Montes
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Class: Report Generation Implementation
 * Author: Diego Pérez Montes
 * E-mail: kabute@gulo.org
 */

#include "report.h"
#include "ulysses.h"

/*
Method: Report Generation (HTML)
*/

Scan_Report::Scan_Report(char *host_name,char *simple_host, string final_result,int num_ports,string os_type)
{    

    /* Creation of the result directory for this host (if it exists nothing is done)*/


    char *dir=new char[500];
    string temp="";
    strcpy(dir,"./results/");
    mkdir(dir,0777);
    strcat(dir,simple_host);
    mkdir(dir,0777);
    strcat(dir,"/index.html");
    

    /* Creation of the hole report, using templates from the directory "./templates", change the files there if you want to get a new look :) */

    ofstream filed;
    ifstream templates;
    filed.open(dir);

    //Header of the HTML
    temp+="<html><head><title>Report for: ";
    temp+=(string)simple_host;
    temp+="</title></head>";
    filed<<temp;
     
    //First part of template
    templates.open("./templates/1.tpl");

    while(!templates.eof())
    {
     templates>>temp;
     filed<<temp<<endl;
    }
    
    templates.close();
    temp="";
    temp+="Report for "+(string)host_name;
    filed<<temp;

    //Second part of template
    templates.open("./templates/2.tpl");

    while(!templates.eof())
    {
     templates>>temp;
     filed<<temp<<endl; 
    }
    
    templates.close();
    filed<<simple_host<<endl;
    
    filed<<"<br>"<<"OS Type:"<<os_type<<endl;
    //Third part of template
    templates.open("./templates/3.tpl");

    while(!templates.eof())
    {
     templates>>temp;
     filed<<temp<<endl;
    }
    templates.close();
    filed<<"["<<num_ports<<"]";


    //Fourth part of template
    templates.open("./templates/4.tpl");

    while(!templates.eof())
    {
     templates>>temp;
     filed<<temp<<endl;
    }
    templates.close();
    filed<<final_result<<endl;

    //Fifth part of template
    templates.open("./templates/5.tpl");

    while(!templates.eof())
    {
     templates>>temp;
     filed<<temp<<endl;
    }
    templates.close();    
    filed.close();

    
}
