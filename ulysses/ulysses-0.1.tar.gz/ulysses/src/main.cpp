/* 
 *
 * Copyright (C) 2007  Diego Pérez Montes
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 *
 * Class: Main Program
 * Author: Diego Pérez Montes
 * E-mail: kabute@gulo.org
 */

   
#include <string.h>
#include "ulysses.h"
#include "report.h"



    int main(int argc, char *argv[])
    {
    int port;
    char *full_host=new char[500];
    bool quiet=false; //By default verbose mode
    string final_result;
    string os_type;


        if ((argc >= 2) && (*argv[1]=='v'))
        {
	cout<<endl<<"Ulysses Version:0.1-rc1"<<endl;
        cout<<"Author: Diego Perez (kabute (at) gulo (dot) org"<<endl;
        cout<<"Release date: 2007-06-26"<<endl<<endl;
        }
	

	else
	{

        
	if ((argc < 3) || (atoi(argv[2])>65001)) {
            cout<<endl<<"Syntax error!"<<endl<<"Usage: "<<argv[0]<<" hostname max_port [options]"<<endl<<endl;

            cout<<endl<<"[options]:"<<endl<<"q : Quiet mode (perfect for web servers)"<<endl<<"v : Get Ulysses Information (just type ./ulysses v"<<endl<<endl;
            exit(1);
        }


        if ((argc == 4) && (*argv[3]=='q'))
	{
          quiet=true;
           //Quite Mode
	}

	else
	{
           cout<<endl<<"################################"<<endl;
           cout<<"#        Ulysses v0.1          #"<<endl;
           cout<<"################################"<<endl;
	}
	Scanner *scan = new Scanner; //New scanner

        
  

      if(!gethostbyname(argv[1]))
      {
      if (!quiet) cout<<"Error: Unknown host "<<argv[1]<<endl<<endl;
      exit(1);
      }

      scan->set_he(gethostbyname(argv[1])); //Get the host info



      int s_ports=atoi(argv[2]);
            
      final_result=scan->scan_ports(s_ports); 



       strcpy(full_host,argv[1]);
       strcat(full_host,"<br> [ ");
       strcat(full_host,scan->get_host());
       strcat(full_host," ] ");
      
       os_type=scan->basic_os_fingerprint();
       //cout<<full_host<<endl<<endl;
       Scan_Report  *report=new //Generation of the final report
       Scan_Report(full_host,argv[1],final_result,scan->get_num_ports(),os_type);

	
       delete scan;//Destruction of our scanner
       delete report;
       delete full_host;


       system("cd results && ./gen_index"); //Temporary use of BASH scripts
       return 0;
       }

}

