//created by ./configure script
#define PREFIX "/usr"
