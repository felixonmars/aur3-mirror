/***************************************************************************
                          php_dbg.h  -  description
                             -------------------
    begin                : Sun Sep 24 2000
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/

#ifndef _PHP_DBG_H_
#define _PHP_DBG_H_

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef PHP_WIN32
  #if defined(ZEND_ENGINE_2)
  #include <winsock2.h>
  #else
  #include <winsock.h>
  #endif
  #include "config.w32.h"
#else
#include <sys/socket.h>
#include <netinet/in.h>
#if HAVE_ARPA_INET_H
#include <arpa/inet.h>
#endif
#include <netdb.h>
#endif

#if HAVE_STDARG_H
#include <stdarg.h>
#endif

#include "php.h"
#include "php_network.h"

#ifdef HAVE_DBG

#ifdef PHP_WIN32
#ifdef DBG_DEBUG_MEM
  #ifndef	_CRTDBG_MAP_ALLOC
	#define _CRTDBG_MAP_ALLOC
  #endif
  #include <malloc.h>
  #include <stdlib.h>
  #include <crtdbg.h>
#endif
#endif


#include "dbg_net.h"
#include "zend_llist.h"
#include "zend_extensions.h"
#include "zend_API.h"
#include "SAPI.h"

#if ZEND_MODULE_API_NO > 20050922
#define ZEND_ENGINE_2_2
#endif
#if ZEND_MODULE_API_NO > 20050921
#define ZEND_ENGINE_2_1
#endif


extern zend_module_entry dbg_module_entry;
#define phpext_dbg_ptr &dbg_module_entry

/* dbg module functions */
ZEND_MINIT_FUNCTION(dbg);
ZEND_RINIT_FUNCTION(dbg);
ZEND_MINFO_FUNCTION(dbg);



typedef struct tag_ext_compat_item {
	int flg1;
	int flg2;
	int flg3;
	char *compat_ext_name;
} ext_compat_item;

typedef struct tag_ext_compat_info {
	int	ext_api_ver;
	char *ext_name;
	int ext_ver;
	ext_compat_item *compat_list;
} ext_compat_info;

PHP_FUNCTION(debugbreak);
PHP_FUNCTION(outputdebugstring);
#ifdef HAVE_DBG_PROFILER
PHP_FUNCTION(dbg_get_profiler_results);
#endif
PHP_FUNCTION(dbg_get_all_module_names);
PHP_FUNCTION(dbg_get_module_name);
PHP_FUNCTION(dbg_get_all_contexts);
PHP_FUNCTION(dbg_get_context_name);
PHP_FUNCTION(dbg_get_all_source_lines);
PHP_FUNCTION(dbg_get_source_context);


#ifndef PHP_WIN32
#define stricmp strcasecmp
#define strnicmp strncasecmp
#endif


typedef enum tagBPSTATE {
    BPS_DELETED  = 0,
    BPS_DISABLED = 1,
    BPS_ENABLED  = 2,
    BPS_UNRESOLVED = 0x100
} BPSTATE;

/* Log type */
#define LT_ODS			1		/* OutputDebugString */
#define LT_ERROR		2		/* Error/Warning/Notice while executing */
#define LT_OUTPUT		3		/* Any echo(), print() or header() results */
#define LT_FATALERROR	256		/* Fatal error (currently if error occured while evaluating)*/


#define	DBGACTV_ONSTART			(0x001)
#define	DBGACTV_ONERROR			(0x002)
#define	DBGACTV_ONLOG			(0x004)
#define	DBGACTV_ONHTTPGET		(0x008)
#define	DBGACTV_ONHTTPCOOKIE	(0x010)
#define	DBGACTV_ALL				(0x0FF)

/* opt_flags */
#define SOF_BREAKONLOAD				0x00001
#define SOF_BREAKONFINISH			0x00002
#define SOF_MATCHFILESINLOWCASE		0x00004
#define SOF_SEND_LOGS				0x00010
#define SOF_SEND_ERRORS				0x00020
#define SOF_SEND_OUTPUT				0x00040
#define SOF_SEND_OUTPUT_DETAILED	0x00080
#define SOF_ERR_LEVEL_0				0x00100
#define SOF_ERR_LEVEL_1				0x00200
#define SOF_ERR_LEVEL_2				0x00300
#define SOF_ERR_LEVEL_4				0x00400
#define SOF_ERR_LEVEL_MASK			0x00700
#define SOF_ERR_LEVEL_SHIFT			8

#define SOF_DEFAULT					(SOF_BREAKONLOAD | SOF_BREAKONFINISH | SOF_MATCHFILESINLOWCASE | SOF_SEND_LOGS | SOF_SEND_ERRORS | SOF_SEND_OUTPUT)

#define ERR_LEVEL0_MASK				0
#define ERR_LEVEL1_MASK				(E_CORE)
#define ERR_LEVEL2_MASK				(ERR_LEVEL1_MASK | E_ERROR | E_PARSE | E_COMPILE_ERROR | E_USER_ERROR)
#define ERR_LEVEL3_MASK				(E_ALL & ~(E_NOTICE | E_USER_NOTICE))
#define ERR_LEVEL4_MASK				(E_ALL)


#if ZEND_EXTENSION_API_NO >= 20001224 /* 4.0.5 */
#define ZEND_HASH_GET_CURRENT_KEY_EX(a,b,c,d,e) zend_hash_get_current_key_ex(a, b, c, d, 1, e)
#define NOPRM(a) void a(void)
#else
#define ZEND_HASH_GET_CURRENT_KEY_EX zend_hash_get_current_key_ex
#define NOPRM(a) void a()
#endif

#ifndef va_copy
# ifdef __va_copy
#  define va_copy(dest, src)	__va_copy((dest), (src))
# else
#  define va_copy(dest, src)	memcpy(&(dest), &(src), sizeof(va_list))
# endif
#endif


#define CLIENT_HOST "clienthost"

#ifdef PHP_WIN32
/* Win 32 */
#include <windows.h>
#else
/* Linux / Unix */
#include <time.h>
#endif

typedef struct tag_ctxlines_item {
	int ctx_id;	
	int start_line_no;
	int lines_cnt;
	int mod_no;
	char *mod_name;
} ctxlines_item;

typedef struct tag_ctx_item {
	int ctx_id;
	char *function_name;
	char *mod_name;
	zend_op_array *op_array;
} ctx_item;

typedef struct tag_profdata_item {
	int hitcount;
	dbgint64 tm_min;
	dbgint64 tm_max;
	dbgint64 tm_sum;
} profdata_item;

typedef struct tag_bp_item {
	int mod_no;
	int line_no;
	int skiphits;
	int hitcount;
	BPSTATE state;
	int istemp;
	int bp_no;
	char *mod_name;
	char *condition;
	int isunderhit;
} bp_item;

typedef struct tag_bpl_arr_item {
	int line_no;
	bp_item *item;
} bpl_arr_item;

typedef struct tag_bpl_array {
	int count;
	int limit;
	bpl_arr_item *item;
} bpl_array;

typedef struct tag_mod_item {
	char *mod_name;
	int mod_no;
	int rsrv1;
	profdata_item *profdata_arr;
	int profdata_items;
	bpl_array bp_arr;
	int lines_changed;
} mod_item;

typedef struct tag_back_trace_item {
	int mod_no;
	int line_no;
	HashTable *active_sym_table;
	zval *active_this;
	char *descr;
} back_trace_item;


#define LLIST_FOREACH(alist, pitem, code) {		\
	if (alist.size>0) {							\
		zend_llist_element *item = alist.head, *nitem; 	\
		pitem *data; 							\
		while (item) { 							\
			data = (pitem *)(&(item->data)); 		\
			nitem = item->next;					\
			code 								\
			if (item == alist.tail) break; 		\
			item=nitem;		 					\
		} 										\
	}											\
}

#define LLIST_RFOREACH(alist, pitem, code) {	\
	if (alist.size>0) {							\
		zend_llist_element *item = alist.tail, *nitem; 	\
		pitem *data; 							\
		while (item) { 							\
			data = (pitem *)(&(item->data)); 		\
			nitem = item->prev;					\
			code 								\
			if (item == alist.head) break; 		\
			item=nitem; 						\
		} 										\
	}											\
}

#define LLIST_ITEM_AT(alist,idx,ret_item, type) {	\
	int i = idx;								\
	ret_item = NULL;							\
	if (alist.size>0) {							\
		zend_llist_element *item = alist.head; 	\
		while (i > 0) { 						\
			i--;								\
			if (item == alist.tail) break; 		\
			item = item->next; 					\
		} 										\
		if (i==0 && item) 						\
			ret_item = (type)&(item->data);	\
	}											\
}


ZEND_BEGIN_MODULE_GLOBALS(DBG)
/*First!*/
	int is_extension_activated;
	int is_globals_initialized;
	int is_failed_connection;
	long clientversion;
/*INI*/
	long cfgprm_enabled;
	long cfgprm_profiler_enabled;
	long cfgprm_fail_silently;
	long cfgprm_timeout_seconds;
	long cfgprm_ignore_nops;
	long cfgprm_session_cookie;
	long cfgprm_session_nocache;
	char *cfgprm_JIT_host;
	long cfgprm_JIT_port;
	long cfgprm_JIT_enabled;
	long cfgprm_JIT_level;

/*run-time*/
	long sesstype;
	long error_filter;
	long JIT_filter;
	char *req_sess_var;
	char *req_client_ip_address;
	long req_client_port;
	char *client_address;
	long client_port;
	char *session_id;
	int debug_socket;
	int curr_line_no;
	zend_op *last_opline;
	char *curr_mod_name;
	int curr_mod_no;
	mod_item* curr_mod;
	unsigned int debugger_flags;
	long opt_flags;
	int debugger_step_depth;
	int in_eval;
	char *eval_error;
	int pause_cntr;
	int eval_nest;
	int session_cookie_added;
	zend_llist mod_list;
	zend_llist back_trace;
	int back_trace_count;
	zend_llist breakpoint_list;
	int breakpoint_list_inv;
	bpl_array global_bp_arr;
	zend_llist ctxlines_list;
	zend_llist ctx_list;
	int ctx_counter;
	dbgint64 l_time;
	dbgint64 e_time;
	int deactivate_inprocess;
	dbg_packet logpack;
	char *output_str_nd;
	int output_str_nd_len;
	int output_str_nd_limit;
ZEND_END_MODULE_GLOBALS(DBG)

extern zend_DBG_globals *pDBG_globals; /* for debugging purpose only */

#if ZEND_EXTENSION_API_NO >= 20021010
#define DBG_CTX_SAVE_ED		\
	zend_execute_data *dbg_ctx_current_execute_data = EG(current_execute_data);		\
	zend_execute_data dbg_ctx_execute_data;											\
	if (dbg_ctx_current_execute_data)												\
		dbg_ctx_execute_data = *EG(current_execute_data);

#define DBG_CTX_RESTORE_ED	\
	EG(current_execute_data) = dbg_ctx_current_execute_data;	\
	if (dbg_ctx_current_execute_data)							\
		*EG(current_execute_data) = dbg_ctx_execute_data;
#else
#define DBG_CTX_SAVE_ED
#define DBG_CTX_RESTORE_ED
#endif

#if ZEND_EXTENSION_API_NO >= 20010710
#define DBG_CTX_SAVE																\
		zend_op_array *dbg_ctx_active_op_array = EG(active_op_array);				\
		zend_function_state *dbg_ctx_function_state_ptr = EG(function_state_ptr);	\
		zval **dbg_ctx_return_value_ptr_ptr = EG(return_value_ptr_ptr);				\
		HashTable *dbg_ctx_active_sym_table = EG(active_symbol_table);				\
		zend_op **dbg_ctx_opline_ptr = EG(opline_ptr);								\
		int dbg_ctx_handle_op_arrays = CG(handle_op_arrays);						\
		zend_bool dbg_ctx_in_execution = EG(in_execution);							\
		zend_bool dbg_ctx_in_compilation = CG(in_compilation);						\
		zend_bool dbg_ctx_unclean_shutdown = CG(unclean_shutdown);					\
		DBG_CTX_SAVE_ED;

#define DBG_CTX_TRY	zend_try

#define DBG_CTX_CATCH zend_catch

#define DBG_CTX_RESTORE																\
		EG(no_extensions)=0;														\
		CG(handle_op_arrays) = dbg_ctx_handle_op_arrays;							\
		EG(active_symbol_table) = dbg_ctx_active_sym_table;							\
		EG(opline_ptr) = dbg_ctx_opline_ptr;										\
		EG(active_op_array) = dbg_ctx_active_op_array;								\
		EG(function_state_ptr) = dbg_ctx_function_state_ptr;						\
		EG(return_value_ptr_ptr) = dbg_ctx_return_value_ptr_ptr;					\
		EG(in_execution) = dbg_ctx_in_execution;									\
		CG(in_compilation) = dbg_ctx_in_compilation;								\
		CG(unclean_shutdown) = dbg_ctx_unclean_shutdown;							\
		DBG_CTX_RESTORE_ED;

#define DBG_CTX_ENDTRY zend_end_try();

#else

#define DBG_CTX_SAVE
#define DBG_CTX_TRY
#define DBG_CTX_CATCH if (0)
#define DBG_CTX_RESTORE
#define DBG_CTX_ENDTRY
#endif



#ifdef ZTS
#if ZEND_EXTENSION_API_NO >= 20010710
/* 4.0.7 TSRM */
#define TSRMLS_FETCH1(a)			TSRMLS_FETCH();
#define TSRMLS_FETCH2(a, b)			TSRMLS_FETCH();
#define TSRMLS_FETCH3(a, b, c)		TSRMLS_FETCH();
#define TSRMLS_FETCH4(a, b, c, d)	TSRMLS_FETCH();

#define TSRMLS_FETCH1_NOP(a)
#define TSRMLS_FETCH2_NOP(a, b)

#define TSRMLS_DC0				TSRMLS_DC
#define TSRMLS_DC1(a)			TSRMLS_DC
#define TSRMLS_DC2(a, b)		TSRMLS_DC
#define TSRMLS_DC3(a, b, c)		TSRMLS_DC
#define TSRMLS_DC4(a, b, c, d)	TSRMLS_DC

#define TSRMLS_D1(a)			TSRMLS_D
#define TSRMLS_D2(a, b)			TSRMLS_D
#define TSRMLS_D3(a, b, c)		TSRMLS_D

#define TSRMLS_CC0				TSRMLS_CC
#define TSRMLS_CC1(a)			TSRMLS_CC
#define TSRMLS_CC2(a, b)		TSRMLS_CC
#define TSRMLS_CC3(a, b, c)		TSRMLS_CC
#define TSRMLS_CC4(a, b, c, d)	TSRMLS_CC

#define TSRMLS_C0				TSRMLS_C
#define TSRMLS_C1(a)			TSRMLS_C
#define TSRMLS_C2(a, b)			TSRMLS_C
#define TSRMLS_C3(a, b, c)		TSRMLS_C

#define DBG(v) TSRMG(DBG_globals_id, zend_DBG_globals *, v)
extern int DBG_globals_id;
#else
/* 4.0.0 TSRM */
#define TSRMLS_FETCH1(a)		a##LS_FETCH();

#define TSRMLS_FETCH2(a, b)		\
	a##LS_FETCH();				\
	b##LS_FETCH();

#define TSRMLS_FETCH3(a, b, c)	\
	a##LS_FETCH();				\
	b##LS_FETCH();				\
	c##LS_FETCH();

#define TSRMLS_FETCH4(a, b, c, d) \
	a##LS_FETCH();				  \
	b##LS_FETCH();				  \
	c##LS_FETCH();				  \
	d##LS_FETCH();

#define TSRMLS_FETCH1_NOP(a)	\
	a##LS_FETCH();

#define TSRMLS_FETCH2_NOP(a, b)	\
	a##LS_FETCH();				\
	b##LS_FETCH();

#define TSRMLS_DC0
#define TSRMLS_DC1(a)			a##LS_DC
#define TSRMLS_DC2(a, b)		a##LS_DC b##LS_DC
#define TSRMLS_DC3(a, b, c)		a##LS_DC b##LS_DC c##LS_DC
#define TSRMLS_DC4(a, b, c, d)	a##LS_DC b##LS_DC c##LS_DC d##LS_DC

#define TSRMLS_D1(a)			a##LS_D
#define TSRMLS_D2(a, b)			a##LS_D  b##LS_DC
#define TSRMLS_D3(a, b, c)		a##LS_D  b##LS_DC c##LS_DC

#define TSRMLS_CC0
#define TSRMLS_CC1(a)			a##LS_CC
#define TSRMLS_CC2(a, b)		a##LS_CC b##LS_CC
#define TSRMLS_CC3(a, b, c)		a##LS_CC b##LS_CC c##LS_CC
#define TSRMLS_CC4(a, b, c, d)	a##LS_CC b##LS_CC c##LS_CC d##LS_CC
	
#define TSRMLS_C0
#define TSRMLS_C1(a)			a##LS_C
#define TSRMLS_C2(a, b)			a##LS_C b##LS_CC
#define TSRMLS_C3(a, b, c)		a##LS_C b##LS_CC  c##LS_CC

#define DBGLS_D zend_DBG_globals *DBG_globals
#define DBGLS_DC , DBGLS_D
#define DBGLS_C DBG_globals
#define DBGLS_CC , DBGLS_C
#define DBG(v) (DBG_globals->v)
#define DBGLS_FETCH() zend_DBG_globals *DBG_globals = ts_resource(DBG_globals_id)
extern int DBG_globals_id;
#endif
#else
/* NO TSRM */

#define TSRMLS_FETCH1(a)
#define TSRMLS_FETCH2(a, b)
#define TSRMLS_FETCH3(a, b, c)
#define TSRMLS_FETCH4(a, b, c, d)

#define TSRMLS_FETCH1_NOP(a)
#define TSRMLS_FETCH2_NOP(a, b)

#define TSRMLS_DC0
#define TSRMLS_DC1(a)
#define TSRMLS_DC2(a, b)
#define TSRMLS_DC3(a, b, c)
#define TSRMLS_DC4(a, b, c, d)

#define TSRMLS_D1(a)
#define TSRMLS_D2(a, b)
#define TSRMLS_D3(a, b, c)

#define TSRMLS_CC0
#define TSRMLS_CC1(a)
#define TSRMLS_CC2(a, b)
#define TSRMLS_CC3(a, b, c)
#define TSRMLS_CC4(a, b, c, d)

#define TSRMLS_C0
#define TSRMLS_C1(a)
#define TSRMLS_C2(a, b)
#define TSRMLS_C3(a, b, c)


extern zend_DBG_globals DBG_globals;
#define DBG(v) (DBG_globals.v)

#endif


#define TS_ALLOC_CTOR(a) php_##a##_init_globals
#define TS_ALLOC_DTOR(a) php_##a##_uninit_globals


/* TSRM */
#if ZEND_EXTENSION_API_NO >= 20010710
/* TSRM 4.0.7 */
#ifdef ZTS
#define TS_ALLOC_CTOR_FUNCTION(a) void TS_ALLOC_CTOR(a)(zend_##a##_globals * a##_globals TSRMLS_DC1(a))
#define TS_ALLOC_DTOR_FUNCTION(a) void TS_ALLOC_DTOR(a)(zend_##a##_globals * a##_globals TSRMLS_DC1(a))
#else
#define TS_ALLOC_CTOR_FUNCTION(a) void TS_ALLOC_CTOR(a)(zend_##a##_globals * _p##a##_globals TSRMLS_DC1(a))
#define TS_ALLOC_DTOR_FUNCTION(a) void TS_ALLOC_DTOR(a)(zend_##a##_globals * _p##a##_globals TSRMLS_DC1(a))
#endif
#define TS_ALLOC_CTOR_CALL(a) TS_ALLOC_CTOR(a)(NULL TSRMLS_CC1(a))
#define TS_ALLOC_DTOR_CALL(a) TS_ALLOC_DTOR(a)(NULL TSRMLS_CC1(a))
#else
/* OLD TSRM */
#define TS_ALLOC_CTOR_FUNCTION(a) void TS_ALLOC_CTOR(a)(TSRMLS_D1(a))
#define TS_ALLOC_DTOR_FUNCTION(a) void TS_ALLOC_DTOR(a)(TSRMLS_D1(a))
#define TS_ALLOC_CTOR_CALL(a) TS_ALLOC_CTOR(a)(TSRMLS_C1(a))
#define TS_ALLOC_DTOR_CALL(a) TS_ALLOC_DTOR(a)(TSRMLS_C1(a))
#endif

#define DBGF(f) (DBG(debugger_flags) & (f))
#define DBGO(f) (DBG(opt_flags) & (f))

#else
#error YOU HAVE TO RE-RUN buildconf TO GET RIGHT /main/php_config.h
#endif /* HAVE_DBG */

#endif
