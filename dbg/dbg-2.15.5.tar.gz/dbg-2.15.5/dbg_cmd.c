/***************************************************************************
                          dbg_cmd.c  -  description
                             -------------------
    begin                : Sun Sep 24 2000
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/


#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_network.h"

#if HAVE_NETDB_H
#include <netdb.h>
#endif

#include "php_dbg.h"
#include "dbg_net.h"
#include "dbg_cmd.h"
#include "dbg_prof.h"
#include "dbg_ser.h"
#include "dbg_bp.h"
#include "SAPI.h"



typedef int (*framehandler)(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E));

typedef struct tag_cmddef {
	framename name;
	framehandler handler;
} cmddef;

int cmpll(void *element1, void *element2) {
	return (element1 == element2);
}

int dbg_lookup_hostname(const char *addr, struct in_addr *in) {
	struct hostent *host_info;
	
	DBG_TRACE(("dbg_lookup_hostname\n"));
#ifdef PHP_WIN32
	(*in).s_addr = inet_addr(addr);
	if ((*in).s_addr == INADDR_NONE) {
#else
	if (!inet_aton(addr, in)) {
#endif
		host_info = gethostbyname(addr);
		if (!host_info) {
			return FAILURE;
		}
		*in = *((struct in_addr *) host_info->h_addr);
	}
	return SUCCESS;
}

char* get_redirected_address(TSRMLS_D2(DBG, E)) {
	int rv;
	zval **httpvars, **remoteaddr, **forwardedfor;
	char *p, *ret_val = NULL;

	DBG_TRACE(("get_redirected_address\n"));
	rv = zend_hash_find(&EG(symbol_table), "HTTP_SERVER_VARS", sizeof("HTTP_SERVER_VARS"), (void **) &httpvars);
	if (rv != FAILURE && ((*httpvars)->type==IS_ARRAY)) {
		rv = zend_hash_find((*httpvars)->value.ht, "HTTP_X_FORWARDED_FOR", sizeof("HTTP_X_FORWARDED_FOR"), (void **) &forwardedfor);
		if (rv != FAILURE && ((*forwardedfor)->type==IS_STRING) && (*forwardedfor)->value.str.len > 0) {
			p = strchr(Z_STRVAL_P(*forwardedfor), ',');
			if (p == NULL) {
				ret_val = estrndup(Z_STRVAL_P(*forwardedfor),Z_STRLEN_P(*forwardedfor));
			} else {
				ret_val = estrndup(Z_STRVAL_P(*forwardedfor),p-Z_STRVAL_P(*forwardedfor));
			}
		} else {
			rv = zend_hash_find((*httpvars)->value.ht, "REMOTE_ADDR", sizeof("REMOTE_ADDR"), (void **) &remoteaddr);
			if (rv != FAILURE &&  ((*remoteaddr)->type==IS_STRING)) {
				ret_val = estrndup(Z_STRVAL_P(*remoteaddr),Z_STRLEN_P(*remoteaddr));
			}
		}
	}
	return ret_val;
}

/*
 * Connects to a specified host and port, and returns a socket for the connection.
 */

int create_debugger_socket(SESSTYPE sesstype TSRMLS_DC2(DBG, E)) {
	struct sockaddr_in address;
	int err=-1;
	int sockfd;
	int ret_val;

	DBG_TRACE(("create_debugger_socket(%d)\n", sesstype));
	memset(&address, 0, sizeof(address));
	address.sin_family = AF_INET;

	if (DBG(client_address)) {
		efree(DBG(client_address));
		DBG(client_address) = NULL;
	}

	DBG(client_address) = (DBGF(DBGF_REQUESTFOUND)) ? (DBG(req_client_ip_address)) : (DBG(cfgprm_JIT_host));
	if (!DBG(client_address)) DBG(client_address) = CLIENT_HOST;
	DBG(client_address) = estrdup(DBG(client_address));

	if (DBG(client_address) && stricmp(DBG(client_address), CLIENT_HOST) == 0) {
		efree(DBG(client_address));
		DBG(client_address) = get_redirected_address(TSRMLS_C2(DBG, E));
		if (!DBG(client_address)) {
			DBG(client_address) = estrdup("localhost");
		}
	}
	
	DBG_TRACE(("address(%s)\n", SON(DBG(client_address))));

	if (!DBG(client_address) || dbg_lookup_hostname(DBG(client_address), &address.sin_addr) == FAILURE) {
		if (!DBG(cfgprm_fail_silently)) {
			SysError("dbg_lookup() failed (address=\"%s\")\n", DBG(client_address));	
		}
		return ESESS_LOOKUP;
	}

	DBG(client_port) = (DBGF(DBGF_REQUESTFOUND)) ? (DBG(req_client_port)) : (DBG(cfgprm_JIT_port));
	if (DBG(client_port) == 0) DBG(client_port) = DEFAULT_PORT;
	address.sin_port = htons((unsigned short)DBG(client_port));
	

	DBG_TRACE(("conn. allowed to %s:%ld\n", SON(DBG(client_address)), DBG(client_port)));


	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	ret_val = sockfd;
	if (sockfd == SOCK_ERR) {
		if (!DBG(cfgprm_fail_silently)) {
			SysError("socket() failed\n");
		}
		ret_val = ESESS_SOCK;
	} else {
		while ((err = connect(sockfd, (struct sockaddr *) &address,
							  sizeof(address))) == SOCK_ERR && errno == EAGAIN);
		if (err < 0) {
			if (!DBG(cfgprm_fail_silently)) {
				SysError("connect() failed\n");
			}
			SCLOSE(sockfd);
			ret_val = ESESS_CONN;
		} else {
			DBG_TRACE(("socket (%d) opened\n", sockfd));
		}
	}
	return ret_val;
}


/* ************************************************* */

inline int dbg_mod_item_by_name(const char *mod_name, int addifnotfound TSRMLS_DC1(DBG)) {
	mod_item* p_mod = dbg_findmodule(mod_name, addifnotfound TSRMLS_CC1(DBG));
	return (p_mod) ? (p_mod->mod_no) : (0);
}

inline mod_item* dbg_mod_item_by_no(int mod_no TSRMLS_DC1(DBG)) {
	if (mod_no != 0 && DBG(curr_mod) && DBG(curr_mod)->mod_no==mod_no)
		return DBG(curr_mod);
	LLIST_FOREACH(DBG(mod_list), mod_item,
		if (data->mod_no == mod_no) {
			return data;
		}
	);
	return NULL;
}

inline char *dbg_mod_name_by_no(int mod_no TSRMLS_DC1(DBG)) {
	mod_item *src_item;
	src_item = dbg_mod_item_by_no(mod_no TSRMLS_CC1(DBG));
	return (src_item) ? (src_item->mod_name) : NULL;
}

inline int MATCHFILE(const char *name1, const char *name2 TSRMLS_DC1(DBG)) {
	if (DBGO(SOF_MATCHFILESINLOWCASE)) 
		return (stricmp(name1,name2)==0);
	else
		return (strcmp(name1,name2)==0);
}

inline mod_item* dbg_findmodule(const char *mod_name, int addifnotfound TSRMLS_DC1(DBG)) {
	int idx;
	mod_item newitem, *p_mod;

	if (mod_name == DBG(curr_mod_name)) {
		return DBG(curr_mod);
	}
	if (!mod_name)
		return NULL;
	
	idx = 1;
	LLIST_FOREACH(DBG(mod_list), mod_item, {
		if (MATCHFILE(mod_name, data->mod_name TSRMLS_CC1(DBG))) {
			return data;
		}
		idx++;
	});

	if (!addifnotfound) return NULL;

	memset(&newitem, 0, sizeof(newitem));
	newitem.mod_no = idx;
	newitem.mod_name = estrdup(mod_name);
	newitem.rsrv1 = 0;
	zend_llist_add_element(&DBG(mod_list), &newitem);
	p_mod = dbg_mod_item_by_no(newitem.mod_no TSRMLS_CC1(DBG));
	return p_mod;
}

/******** R E P L Y **********/

int handler_add_source_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	char *fn;
	FILE *f = NULL;
	dbg_source_body body;
#if ZEND_EXTENSION_API_NO < 20020903
	int issock = 0, socketd = 0;
#endif
	int ret_val, mod_no, rest_size;
	int error = 0, from_pos = -1, full_size = -1, bufsize = 128*1024;
	void *buf = NULL;
	char ok=0, *mod_name;

	dbg_source_request *req = FRAME_DATA_PTR(dbg_source_request,frame);

	mod_no = req->mod_no;
	from_pos = req->from_filepos;

	if (from_pos >= 0) {
		error = -2;					/* file open error */
		fn = dbg_mod_name_by_no(mod_no TSRMLS_CC1(DBG));
		if (fn && *fn!='-') {
			f = fopen(fn, "rb");	
			if (!f) {
#if ZEND_EXTENSION_API_NO < 20020903
				f = php_fopen_wrapper(fn, "rb", USE_PATH|IGNORE_URL_WIN, &issock, &socketd, NULL TSRMLS_CC0);
#else
				f = php_stream_open_wrapper_as_file(fn, "rb", USE_PATH|IGNORE_URL_WIN, NULL);
#endif
			}
		}
		ok = (f!=NULL);
		if (ok) {
			ret_val = fseek(f, 0, SEEK_END);
			ok = (ret_val == 0);
			if (!ok){
				error = ferror(f); /* seek error */
			}
		}
		if (ok) {
			full_size = ftell(f);
			ret_val = fseek(f, from_pos, SEEK_SET);
			ok = (ret_val == 0);
			if (!ok){
				error = ferror(f); /* seek error */
			}
		}
		if (ok) {
			rest_size = full_size - from_pos; 
			bufsize = (rest_size > bufsize) ? bufsize:rest_size;
			buf = emalloc(bufsize);
			ok = (buf != NULL);
			if (!ok){
				error = -3; /*No memory for buffer*/
			}
		}
		if (ok) {
			ret_val = fread(buf, 1, bufsize, f);
			ok = (ret_val == bufsize) || feof(f);
			if (!ok){
				error = ferror(f); /* read error */
			}
			bufsize = ret_val;
		}
	}

	if (!ok){
		bufsize = 0;
	}


	mod_name = (from_pos <= 0) ? dbg_mod_name_by_no(mod_no TSRMLS_CC1(DBG)) : NULL;
	body.imod_name = (mod_name) ? dbg_packet_add_string(pack, mod_name) : 0;
	body.itext = (from_pos >= 0 && buf) ? dbg_packet_add_rawdata(pack, buf, bufsize) : 0;
	body.error = error;
	body.mod_no = mod_no;
	body.from_filepos = from_pos;
	body.full_size =  full_size;
	
	dbg_packet_add_frame(pack, FRAME_SOURCE, &body, sizeof(body));
	
	if (buf) {
		efree(buf);
	}
	if (f) {
		fclose(f);
	}
	return bufsize;
}

int handler_add_stack_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_stack_body stk;
	char *mod_name, *func_name;
	int depth;
	int line_no, mod_no;
	int sz = 0;
	char descr[256];
									
	if (DBG(deactivate_inprocess)) return 1;

/*current location*/
	if (zend_is_executing(TSRMLS_C0)) {
		mod_name = zend_get_executed_filename(TSRMLS_C1(E));
		line_no = zend_get_executed_lineno(TSRMLS_C1(E));
		func_name = get_active_function_name(TSRMLS_C0);
	} else if (zend_is_compiling(TSRMLS_C0)) {
		TSRMLS_FETCH1_NOP(C);
		mod_name = zend_get_compiled_filename(TSRMLS_C1(C));
		line_no = zend_get_compiled_lineno(TSRMLS_C1(C));
		func_name = NULL;
	}
	else {
		mod_name = DBG(curr_mod_name);
		line_no = DBG(curr_line_no);
		func_name = NULL;
	}

	mod_no = DBG_FINDMODULE_ADD(mod_name);
	depth = CURLOC_SCOPE_ID;
	stk.mod_no = mod_no;
	stk.line_no = line_no;
	stk.scope_id = CURLOC_SCOPE_ID;
	
	if (func_name!=NULL && stricmp(func_name,"main") != 0) {
		snprintf(descr, sizeof(descr)-1, "%s()", func_name);
	} else if (mod_name!=NULL) {
		snprintf(descr, sizeof(descr)-1, "%s::main()", mod_name);
	} else {
		descr[0]='\0';
	}
	stk.idescr = dbg_packet_add_string(pack, descr);

	dbg_packet_add_frame(pack, FRAME_STACK, &stk, sizeof(stk));
	sz = sizeof(stk);

	depth = DBG(back_trace_count);	
	
/*stacked location(s)*/
	LLIST_RFOREACH(DBG(back_trace), back_trace_item,
		depth--;
		stk.line_no = data->line_no;
		stk.mod_no = data->mod_no;
		stk.idescr = dbg_packet_add_string(pack, data->descr);
		stk.scope_id = INC_SCOPEID(depth);
		dbg_packet_add_frame(pack, FRAME_STACK, &stk, sizeof(stk));
		sz+=sizeof(stk);
	);

	return sz;
}						    

int handler_add_mod_list_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_src_tree_body body;
	int idx = 1;

	LLIST_FOREACH(DBG(mod_list), mod_item,
		body.mod_no = idx;
		body.rsrv1 = 0;
		body.rsrv2 = 0;
		body.imod_name = dbg_packet_add_string(pack, data->mod_name);
		dbg_packet_add_frame(pack, FRAME_SRC_TREE, &body, sizeof(body));
		idx++;
	);
	return ((idx-1) * sizeof(body));
}

int handler_add_bpl_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	int cnt = 0;
	dbg_bpl_request *req = FRAME_DATA_PTR(dbg_bpl_request, frame);

	LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
		if (req->bp_no == 0 || data->bp_no == req->bp_no) {
			cnt+=listout_bp_item(pack, data, data->bp_no);
		}
	});
	return (cnt);
}

int handler_set_breakpoint(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_bps_request* req = FRAME_DATA_PTR(dbg_bps_request, frame);
	return dbg_set_breakpoint(req, pack, inpack TSRMLS_CC2(DBG, E));
}

int handler_add_srclinesinfo_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_srclinesinfo_request *req = FRAME_DATA_PTR(dbg_srclinesinfo_request, frame);
	int mod_no = req->mod_no;
	dbg_srclinesinfo_body body;
	int cnt=0;
	
	LLIST_FOREACH(DBG(ctxlines_list), ctxlines_item,		
		if (mod_no==0 || mod_no == data->mod_no) {
			body.ctx_id = data->ctx_id;
			body.mod_no = data->mod_no;
			body.lines_count = data->lines_cnt;
			body.start_line_no = data->start_line_no;
			dbg_packet_add_frame(pack, FRAME_SRCLINESINFO, &body, sizeof(body));
			cnt++;
		}
	);
	return (cnt * sizeof(body));
}

int handler_add_srcctxinfo_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_srcctxinfo_body body;
	int cnt=0, imod_no;
	dbg_srcctxinfo_request *req = FRAME_DATA_PTR(dbg_srcctxinfo_request, frame);
	int mod_no = req->mod_no;
	
	body.mod_no = mod_no;
	LLIST_FOREACH(DBG(ctx_list), ctx_item,
		imod_no = DBG_FINDMODULE(data->mod_name);
		if (mod_no==0 || mod_no == imod_no) {
			body.ctx_id = data->ctx_id;
			body.mod_no = imod_no;
			body.ifunction_name = dbg_packet_add_string(pack, data->function_name);
			dbg_packet_add_frame(pack, FRAME_SRCCTXINFO, &body, sizeof(body));
			cnt++;
		}
	);
	return (cnt * sizeof(body));
}

int handler_add_profdata_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_prof_body body;
	profdata_item *it;
	int i, cnt=0;
	dbg_prof_request *req = FRAME_DATA_PTR(dbg_prof_request, frame);
	int mod_no = req->mod_no;

	LLIST_FOREACH(DBG(mod_list), mod_item,
		if (data->mod_no == mod_no || mod_no==0) {
			body.mod_no = data->mod_no;
			for (i=0; i< data->profdata_items-1; i++) {
				it=&(data->profdata_arr[i]);
				if (it->hitcount > 0) {
					body.hit_count = it->hitcount;
					body.line_no = i;
					body.tm_max_hi = (long)(it->tm_max >> 32);
					body.tm_max_lo = (long)(it->tm_max & 0xFFFFFFFF);
					body.tm_min_hi = (long)(it->tm_min >> 32);
					body.tm_min_lo = (long)(it->tm_min & 0xFFFFFFFF);
					body.tm_sum_hi = (long)(it->tm_sum >> 32);
					body.tm_sum_lo = (long)(it->tm_sum & 0xFFFFFFFF);
					dbg_packet_add_frame(pack, FRAME_PROF, &body, sizeof(body));
					cnt++;
				}
			}
		}
	);
	return 1;
}

int handler_add_proffreq_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_prof_c_body body;
	dbgint64 f;
	dbgint64 v, sum1=0, sum2=0, mv, cnt1=0, cnt2=0, minv, maxv;
	int i, loopc;
	dbg_prof_c_request *req = FRAME_DATA_PTR(dbg_prof_c_request, frame);

	PROF_PERF_FREQ(f);
	body.tm_freq_lo = (unsigned dbgint)(f & 0xFFFFFFFF);
	body.tm_freq_hi = (unsigned dbgint)(f >> 32);

	loopc = req->test_loops;
	if (loopc<2) loopc = 2;
	minv = 0;
	maxv = 0;
	for (i=0; i<loopc/2; i++) {
		PROF_DOUBLE_SNAP(v);
		if (i==0) {
			minv=v;
			maxv=v;
		} else {
			if (v<minv) minv=v;
			if (v>maxv) maxv=v;
		}
		sum1 +=v;
		cnt1++;
	}
	mv=sum1/cnt1;
	for (i = 0; i < loopc/2; i++) {
		PROF_DOUBLE_SNAP(v);
		if (v<minv) minv=v;
		if (v>maxv) maxv=v;
		if (v <= 3*mv) {
			sum2 +=v;
			cnt2++;
		}
	}
	mv=sum2/cnt2;
	if (maxv > MAXINT32T) maxv = MAXINT32T;
	if (minv > MAXINT32T) minv = MAXINT32T;
	if (mv > MAXINT32T) mv = MAXINT32T;
	body.tm_diff_max = (long)maxv;
	body.tm_diff_min = (long)minv;
	body.tm_diff_m = (long)mv;
	dbg_packet_add_frame(pack, FRAME_PROF_C, &body, sizeof(body));
	return 1;
}

int dbg_add_version_reply(dbg_packet *pack TSRMLS_DC1(DBG)) {
	dbg_version_body body;

	body.idescription = dbg_packet_add_string(pack, DBG_API_DESCRIPTION);
	body.major_version = DBG_API_MAJOR_VERSION;
	body.minor_version = DBG_API_MINOR_VERSION;
	dbg_packet_add_frame(pack, FRAME_VER, &body, sizeof(body));
	return sizeof(body);
}

int handler_add_sid_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_sid_body body;

	body.isid = dbg_packet_add_string(pack, DBG(session_id));
	body.sesstype = DBG(sesstype);
	dbg_packet_add_frame(pack, FRAME_SID, &body, sizeof(body));
	return sizeof(body);
}

int handler_add_ver_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_version_body *client_ver = FRAME_DATA_PTR(dbg_version_body, frame); 

	DBG(clientversion) = ((client_ver->major_version & 0xFF) << 8) | (client_ver->minor_version & 0xFF);
	dbg_add_version_reply(pack TSRMLS_CC1(DBG));
	return (sizeof(dbg_version_body));
}


/*         E V A L    E F F O R T        */


static void dbg_get_context_sym_table(long scope_id, HashTable **ht, zval **zthis  TSRMLS_DC2(DBG, E)) {
	back_trace_item *bt_item;
	int depth;
	int scope_count;

	if (scope_id == CURLOC_SCOPE_ID) {
		*ht = EG(active_symbol_table);
		*zthis = EG_THIS;
		return;
	}
	else {
		scope_count	= DBG(back_trace_count);
		if (scope_id == GLOBAL_SCOPE_ID) {
			depth = 0;
			if (scope_count == 0) {
				*ht = EG(active_symbol_table);
				*zthis = EG_THIS;
				return;
			}
		}
		else {
			depth =  DEC_SCOPEID(scope_id);
		}

		if (depth >= 0 && depth < scope_count) {
			LLIST_ITEM_AT(DBG(back_trace), depth, bt_item, back_trace_item*);
			*ht = bt_item->active_sym_table;
			*zthis = bt_item->active_this;
			return;
		}
	}
	*ht = NULL;
	*zthis = NULL;
	return;
}

void dbg_full_eval(char *str, HashTable *active_sym_table, zval *buf) {
	HashTable *ast;
	zval data;
	TSRMLS_FETCH3(DBG, E, C);

	ast = EG(active_symbol_table);
	EG(active_symbol_table) = active_sym_table;
	
	memset(&data, 0, sizeof(data));
	Z_TYPE_P(&data) = IS_STRING;
	data.refcount++;

	if (DBG(eval_error)) {
		efree(DBG(eval_error));
		DBG(eval_error) = NULL;
	}

	if (zend_eval_string(str, &data, "dbg_eval()" TSRMLS_CC2(C, E)) == SUCCESS && !DBG(eval_error)) {
		dbg_serialize_zval(&data, buf, 0 TSRMLS_CC2(DBG, E));
	}
	if (data.value.str.val) zval_dtor(&data);
	EG(active_symbol_table) = ast;
}

int handler_add_eval_reply(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	char *str = NULL;
	int sz = 0, ret_val = 0;
	HashTable *active_sym_table = NULL;
	zval **data;
	zval buf;
	zval *active_this;
	dbg_eval_body body;
	dbg_eval_request *req = FRAME_DATA_PTR(dbg_eval_request, frame);

	memset(&buf, 0, sizeof(buf));
	Z_TYPE_P(&buf) = IS_STRING;
	buf.refcount++;

	if (req->istr!=0 && (!dbg_packet_findstring(inpack, req->istr, &str, &sz) || sz<=0)) return 0;
	if (str && strlen(str)==0) str = NULL;


	DBG(in_eval)++;
	{
		DBG_CTX_SAVE
		DBG_CTX_TRY {
			if (DBG(eval_error)) {
				efree(DBG(eval_error));
				DBG(eval_error) = NULL;
			}
			dbg_get_context_sym_table(req->scope_id, &active_sym_table, &active_this TSRMLS_CC2(DBG, E));
			if (active_sym_table) {
				if (!str) {
					dbg_serialize_hash(active_sym_table, active_this, &buf, DSER_ADD_DSIGN TSRMLS_CC2(DBG, E));
				} 
				else if (str &&
					sz > 1 && 
					str[0]=='$' && 
					zend_hash_find(active_sym_table, &str[1], sz-1, (void **) &data) == SUCCESS) {
					dbg_serialize_zval(*data, &buf, 0 TSRMLS_CC2(DBG, E));
				} 
				else if (str && strcmp(str,"$GLOBALS")==0) {
					dbg_get_context_sym_table(GLOBAL_SCOPE_ID, &active_sym_table, &active_this TSRMLS_CC2(DBG, E));
					dbg_serialize_hash(active_sym_table, active_this, &buf, DSER_ADD_DSIGN TSRMLS_CC2(DBG, E));
				}
				else {
					dbg_full_eval(str, active_sym_table, &buf);
				}
			}

		} DBG_CTX_CATCH {
			DBG_TRACE(("eval: zend_catch\n"));
			DBG_TRACE(("dbg_full_eval(!)<<\n"));
			if (buf.value.str.val) 
				zval_dtor(&buf);
			memset(&buf, 0, sizeof(buf));
			DBG_CTX_RESTORE
		} DBG_CTX_ENDTRY
	}

	DBG(in_eval)--;

	ret_val = buf.value.str.len;
	body.iresult = dbg_packet_add_rawdata(pack, Z_STRVAL(buf), Z_STRLEN(buf)+1);
	body.istr = str ? dbg_packet_add_string(pack, str) : 0;
	body.ierror = DBG(eval_error) ? dbg_packet_add_string(pack, DBG(eval_error)) : 0;
	dbg_packet_add_frame(pack, FRAME_EVAL, &body, sizeof(body));
	if (DBG(eval_error)) {
		efree(DBG(eval_error));
		DBG(eval_error) = NULL;
	}
	if (buf.value.str.val) zval_dtor(&buf);
	return ret_val;
}

int handler_set_options(dbg_packet *pack, dbg_packet *inpack, dbg_frame *frame TSRMLS_DC2(DBG, E)) {
	dbg_set_options_request *req = FRAME_DATA_PTR(dbg_set_options_request, frame);
	DBG(opt_flags) = req->opt_flags;
	switch ((req->opt_flags & SOF_ERR_LEVEL_MASK) >> SOF_ERR_LEVEL_SHIFT) {
		case 0:
			DBG(error_filter) = ERR_LEVEL0_MASK; 
			break;
		case 1:
			DBG(error_filter) = ERR_LEVEL1_MASK; 
			break;
		case 2:
			DBG(error_filter) = ERR_LEVEL2_MASK; 
			break;
		case 4:
			DBG(error_filter) = ERR_LEVEL4_MASK; 
			break;
		default:
			DBG(error_filter) = ERR_LEVEL3_MASK; 
			break;
	}
	return 1;
}

/*     H A N D L E    R E Q U E S T ( S )      */

cmddef cmdlist[] = {
	{FRAME_STACK,			handler_add_stack_reply},
	{FRAME_SRC_TREE,		handler_add_mod_list_reply},
	{FRAME_EVAL,			handler_add_eval_reply},
	{FRAME_BPL,				handler_add_bpl_reply},
	{FRAME_BPS,				handler_set_breakpoint},
	{FRAME_SRCLINESINFO,	handler_add_srclinesinfo_reply},
	{FRAME_SRCCTXINFO,		handler_add_srcctxinfo_reply},
	{FRAME_PROF,			handler_add_profdata_reply},
	{FRAME_PROF_C,			handler_add_proffreq_reply},
	{FRAME_SID,				handler_add_sid_reply},
	{FRAME_VER,				handler_add_ver_reply},
	{FRAME_SET_OPT,			handler_set_options},
	{FRAME_SOURCE,			handler_add_source_reply},
	{0, NULL}
};


void dbg_handle_request(dbg_header_struct *hdr, dbg_packet *inpack  TSRMLS_DC2(DBG, E)) {
	dbg_frame *p;
	dbg_packet outpack;
	cmddef *pcmd;

	if (!hdr->flags & DBGF_WAITACK) return;

	dbg_packet_new(&outpack);

	p = dbg_packet_firstframe(inpack);
	while (p){
		DBG_TRACE(("request %ld\n",p->name));
		pcmd = cmdlist;
		while (pcmd->name != 0) {
			if (pcmd->name == p->name) {
				pcmd->handler(&outpack, inpack, p TSRMLS_CC2(DBG, E));
				break;
			}
			pcmd++;
		}
		p = dbg_packet_nextframe(inpack,p);
	}

	dbg_packet_send(DBGC_REPLY, &outpack, DBG(debug_socket), DBG(debugger_flags));
	dbg_packet_free(&outpack);
}


/* debugger host may ask to provide some information (DBGA_REQUEST) 
  or urge to continue run (DBGA_xxxx) */
/* main way from the Listener to the DBG module */

void dbg_process_ack(dbg_header_struct *hdr, dbg_packet *pack TSRMLS_DC2(DBG, E)) {

	DBG_TRACE(("ack %d\n",hdr->cmd));
	switch (hdr->cmd) {
		case DBGC_PAUSE: /* ignore */
			break;
		case DBGA_CONTINUE:
			DBG(debugger_flags)&=~DBGF_WAITACK;
			break;
		case DBGA_STOP:
			DBG(debugger_flags)&=~DBGF_WAITACK;
			DBG(debugger_flags) |= DBGF_ABORT;
			zend_bailout();
			break;
		case DBGA_STEPINTO:
			DBG(debugger_flags) |= DBGF_STEPINTO;
			DBG(debugger_flags) &= ~DBGF_WAITACK;
			DBG(debugger_step_depth) = DBG(back_trace_count);
			break;
		case DBGA_STEPOVER:
			DBG(debugger_flags) |= DBGF_STEPOVER;
			DBG(debugger_flags) &= ~DBGF_WAITACK;
			DBG(debugger_step_depth) = DBG(back_trace_count);
			break; 
		case DBGA_STEPOUT:
			DBG(debugger_flags) |= DBGF_STEPOUT;
			DBG(debugger_flags) &= ~DBGF_WAITACK;
			DBG(debugger_step_depth) = DBG(back_trace_count);
			break; 
		case DBGA_REQUEST:
			dbg_handle_request(hdr, pack  TSRMLS_CC2(DBG, E));
			break;
		default:
			DBG(debugger_flags)&=~DBGF_WAITACK;
			if (hdr->flags & DBGF_WAITACK) {
				dbg_packet_send(DBGC_REPLY, NULL, DBG(debug_socket), DBG(debugger_flags));
			}
	}
}

/* waiting and looking for debugger host responce */
inline void dbg_ack_loop(TSRMLS_D2(DBG, E)) {
	int ret_val = 0, wcnt = 0;	
	dbg_header_struct hdr;
	dbg_packet pack;

	if (!dbg_packet_new(&pack)) {
		DBG(debugger_flags)&=~DBGF_WAITACK;
		return;
	}
	
	dbg_mark_del_temp_breakpoints(TSRMLS_C1(DBG));

	zend_unset_timeout(TSRMLS_C0);
	while (DBGF(DBGF_WAITACK)) {
		dbg_packet_clear(&pack);
		ret_val = dbg_packet_recv(&hdr, &pack, DBG(debug_socket), DBG(cfgprm_timeout_seconds) * 1000);
		if (ret_val == 0) continue;		/* socket is not closed, but we haven't data received, so continue wait */
		if (ret_val < 0) break;			/*socket just closed*/
		dbg_process_ack(&hdr,&pack TSRMLS_CC2(DBG, E));
		if (DBG(breakpoint_list_inv)) {
			dbg_rebuild_bplist(TSRMLS_C1(DBG));
		}
	}

	zend_set_timeout(EG(timeout_seconds));

	dbg_packet_free(&pack);
	if (ret_val < 0) {
		DBG(debugger_flags)|=DBGF_UNSYNC;
		DBG_TRACE(("session dropped. Closing socket(%d)\n", DBG(debug_socket)));
		SCLOSE(DBG(debug_socket));
		DBG(debug_socket) = ret_val;
	}
	DBG(debugger_flags)&=~DBGF_WAITACK;
	dbg_flush_log(TSRMLS_C2(DBG, E));
}


/* inform the debugger host that it is debugging event has been fired */
inline int dbg_send_command(int cmd, dbg_packet *pack, char bWaitAck TSRMLS_DC2(DBG, E)) {
	int ret_val;

	if (DBG(debug_socket) <= 0 || DBG(is_failed_connection)) return 0; 
	if (DBGF(DBGF_WAITACK)) return 0; /*something wrong, go out*/

	if (!DBGF(DBGF_UNSYNC) && bWaitAck) {
		DBG(debugger_flags)|=DBGF_WAITACK;		
	}	
	
	zend_unset_timeout(TSRMLS_C0);
	ret_val = dbg_packet_send(cmd, pack, DBG(debug_socket), DBG(debugger_flags));
	zend_set_timeout(EG(timeout_seconds));

	if (bWaitAck) {
		DBG(debugger_flags) &= ~(DBGF_STEPINTO | DBGF_STEPOVER | DBGF_STEPOUT);
		if (ret_val <= 0) {
			DBG(debugger_flags)|=DBGF_UNSYNC;
			DBG(debugger_flags)&=~DBGF_WAITACK;
			return 0;
		}
	/* wait for debugger host responce. */
		if (DBGF(DBGF_WAITACK)) {
			dbg_ack_loop(TSRMLS_C2(DBG, E));
		}
	} else {
		if (ret_val <= 0) {
			DBG(debugger_flags)|=DBGF_UNSYNC;
			return 0;
		}
	}
	return ret_val;
}

/* send an event such as startup/breakpoint to the debugger host */
inline int dbg_send_std_action(int cmd, int hitcnt TSRMLS_DC2(DBG, E)) {
	dbg_packet pack;
	int ret_val;
	
	if (cmd != DBGC_STARTUP) dbg_flush_log(TSRMLS_C2(DBG, E));

	if (!dbg_packet_new(&pack)) return 0;

	ret_val = handler_add_stack_reply(&pack, NULL, NULL TSRMLS_CC2(DBG, E));
	if (cmd == DBGC_STARTUP && ret_val)
		ret_val = dbg_add_version_reply(&pack TSRMLS_CC1(DBG));
	
	if (ret_val) {
		dbg_add_bp_reply(&pack TSRMLS_CC1(DBG));
		ret_val = dbg_send_command(cmd, &pack, 1 TSRMLS_CC2(DBG, E));
	}
	
	dbg_packet_free(&pack);

	dbg_reset_bp_isunderhit(TSRMLS_C1(DBG));
	return ret_val;
}

inline int dbg_send_error(char *message, int type, const char *mod_name, int line_no TSRMLS_DC2(DBG, E)) {
	dbg_packet pack;
	dbg_error_body body;
	int ret_val = 0;
	
	
	dbg_flush_log(TSRMLS_C2(DBG, E));

	if (!dbg_packet_new(&pack)) return 0;
	body.imessage = dbg_packet_add_string(&pack, message);
	body.type = type;
	if (dbg_packet_add_frame(&pack, FRAME_ERROR, &body, sizeof(body)) &&
		handler_add_stack_reply(&pack, NULL, NULL TSRMLS_CC2(DBG, E))) {
		ret_val = dbg_send_command(DBGC_ERROR, &pack, 1 TSRMLS_CC2(DBG, E));
	}
	dbg_packet_free(&pack);
	return ret_val;
}


void dbg_flush_log(TSRMLS_D2(DBG, E)) {

	if (DBG(output_str_nd_len) > 0 && DBG(output_str_nd)) {
		dbg_log_body body;
		body.ext_info = 0;
		body.ilog = dbg_packet_add_stringlen(&DBG(logpack), DBG(output_str_nd), DBG(output_str_nd_len));
		body.imod_name = 0;
		body.line_no = 0;
		body.mod_no = 0;
		body.type = LT_OUTPUT;
		dbg_packet_add_frame(&DBG(logpack), FRAME_LOG, &body, sizeof(body));		
		DBG(output_str_nd_len) = 0;
	}	

	if (DBG(logpack).size <= 0 || DBG(debug_socket)<=0) return;

	if (dbg_send_command(DBGC_LOG, &DBG(logpack), 0 TSRMLS_CC2(DBG, E))!=0) {
		DBG(logpack).size = 0;
		DBG(logpack).lastrawid = 0;
	}
}

inline int dbg_send_log(char *log, int len, int type, const char *mod_name, const int line_no, int ext_info TSRMLS_DC2(DBG, E)) {
	dbg_log_body body;
	int ret_val = 0;
	char const *amod_name;
	int aline_no;

	if (DBG(deactivate_inprocess)) return 0;  /* should not activate connection by dbg_send_log() */
	{

		body.type = type;
		body.ext_info = ext_info;

		if (type!=LT_OUTPUT || DBGO(SOF_SEND_OUTPUT_DETAILED)) {
			amod_name = mod_name;
			aline_no = line_no;
			if (amod_name == NULL) {
				if (zend_is_executing(TSRMLS_C0)) {
					amod_name = zend_get_executed_filename(TSRMLS_C1(E));
					aline_no = zend_get_executed_lineno(TSRMLS_C1(E));
				} else if (zend_is_compiling(TSRMLS_C0)) {
					TSRMLS_FETCH1_NOP(C);
					amod_name = zend_get_compiled_filename(TSRMLS_C1(C));
					aline_no = zend_get_compiled_lineno(TSRMLS_C1(C));
				} else {
					amod_name = NULL;
					aline_no = 0;
				}
			}
			body.line_no = aline_no;
			body.mod_no = DBG_FINDMODULE_ADD(amod_name);
			body.imod_name = dbg_packet_add_string(&DBG(logpack), amod_name);
			body.ilog = dbg_packet_add_stringlen(&DBG(logpack), log, len);
			dbg_packet_add_frame(&DBG(logpack), FRAME_LOG, &body, sizeof(body));
			if (DBG(logpack).size >= 16300 || DBG(logpack).lastrawid > 512 || type == LT_FATALERROR)
				dbg_flush_log(TSRMLS_C2(DBG, E));
		} else { /* non-detailed output */
			int newlen;
			if (!DBG(output_str_nd)) {
				newlen = len;
				DBG(output_str_nd_len) = 0;
				DBG(output_str_nd_limit) = (len > 8192) ? len : 8192;
				DBG(output_str_nd) = emalloc(DBG(output_str_nd_limit));
			} else {
				newlen = DBG(output_str_nd_len) + len;
			}
			if (newlen > DBG(output_str_nd_limit)) {
				DBG(output_str_nd_limit) = (newlen + 4096) & (~4095);
				DBG(output_str_nd) = erealloc(DBG(output_str_nd), DBG(output_str_nd_limit));
			}
			if (DBG(output_str_nd)) {
				memcpy((char*)DBG(output_str_nd)+DBG(output_str_nd_len), log, len);
			} else {
				newlen = 0;
				DBG(output_str_nd_limit) = 0;
			}
			DBG(output_str_nd_len) = newlen;
			if (newlen > 4096 || type == LT_FATALERROR) 
				dbg_flush_log(TSRMLS_C2(DBG, E));
		}
		ret_val = 1;
	}
	return ret_val;
}

void add_session_cookie(TSRMLS_D2(DBG, S)) {
	char buf[256];
	if (SG(headers_sent) || SG(request_info).no_headers) return;
	if (DBG(cfgprm_session_cookie) && 
		!DBG(session_cookie_added) && 
		DBG(req_sess_var) != NULL && 
		strlen(DBG(req_sess_var)) != 0) {
		DBG(session_cookie_added) = 1;
		snprintf(buf, sizeof(buf) - 1, "Set-Cookie: %s;path=/;", DBG(req_sess_var));
		buf[sizeof(buf) - 1] = 0;
		DBG_TRACE(("adding '%s'\n", buf));
		ADD_HDR(buf);
	}
}

int hex2digits_toi(char *s2) {
	int ret_val;
	int c;

	c = s2[0];
	if (isupper(c))
		c = tolower(c);
	ret_val = ((c >= '0' && c <= '9') ? (c - '0') : (c - 'a' + 10)) * 16;

	c = s2[1];
	if (isupper(c))
		c = tolower(c);
	ret_val += (c >= '0' && c <= '9') ? (c - '0') : (c - 'a' + 10);

	return (ret_val);
}

int urldecode(char *str, int len) {
	char *dest = str, *src = str;

	while (len--) {
		if (*src == '+')
			*dest = ' ';
		else if (*src == '%' && len >= 2 && isxdigit((int) *(src + 1)) && isxdigit((int) *(src + 2))) {
			*dest = (char) hex2digits_toi(src + 1);
			src += 2;
			len -= 2;
		} else
			*dest = *src;
		src++;
		dest++;
	}
	*dest = '\0';
	return (dest - str);
}

int parse_session_request(char *str, int len, char delimiter TSRMLS_DC1(DBG)) {
	char *psid, *phost, *pport = NULL, *p;
	int nsid, nhost, nport;
	char numbuf[10], reqbuf[512];


	DBG_TRACE(("parse_session_request '%s'\n", SON(str)));
	if (str == NULL || len < 1) return 0;

	if (len > sizeof(reqbuf)-1) len = sizeof(reqbuf)-1;
	strncpy(reqbuf, str, len);
	reqbuf[len] = 0;
	p = strchr(reqbuf, delimiter);
	if (p) p[0] = 0;
	len = urldecode(reqbuf, strlen(reqbuf));

	str = reqbuf;

	DBG_TRACE(("req '%s'\n", SON(str)));

	if (DBG(req_sess_var)) {
		efree(DBG(req_sess_var));
		DBG(req_sess_var) = NULL;
	}
	if (DBG(req_client_ip_address)) {
		efree(DBG(req_client_ip_address));
		DBG(req_client_ip_address) = NULL;
	}
	if (DBG(session_id)) {
		efree(DBG(session_id));
		DBG(session_id) = NULL;
	}

	
	phost = strchr(str, '@');
	if (phost!=NULL) {
		psid = str;
		nsid = phost - psid;
		phost++;
		pport = strchr(phost, ':');
		if (pport) {
			nhost = pport - phost;
			if ((p = strchr(phost, ',')) != NULL && p < pport) {
				nhost = p - phost;
			}
			pport++;
			nport = strlen(pport);
		} else {
			nhost = strlen(phost);
			nport = 0;
		}
		DBG(req_client_ip_address) = nhost > 0 ? estrndup(phost, nhost) : NULL;
		DBG(session_id) = estrndup(psid, nsid);
		if (pport != NULL && nport > 0) {
			if (nport >= sizeof(numbuf)) nport = sizeof(numbuf) - 1;
			strncpy(numbuf, pport, nport);
			numbuf[nport]='\0';
			DBG(req_client_port) = atol(numbuf);
			if (DBG(req_client_port) <= 0 || DBG(req_client_port) > 32767) DBG(req_client_port) = DEFAULT_PORT;
		}
		snprintf(reqbuf, sizeof(reqbuf), DBGSESSVAR "=%s@%s:%d", DBG(session_id), DBG(req_client_ip_address), DBG(req_client_port));
		DBG(req_sess_var) = estrdup(reqbuf);
		DBG_TRACE(("parsed req IP=%s, PORT=%ld (%s), SID=%s\n", SON(DBG(req_client_ip_address)), DBG(req_client_port), numbuf, SON(DBG(session_id))));
	} else {
		DBG(session_id) = estrndup(str, len);
		DBG(req_client_port) = 0;
		snprintf(reqbuf, sizeof(reqbuf), DBGSESSVAR "=%s", DBG(session_id));
		DBG(req_sess_var) = estrdup(reqbuf);
		DBG_TRACE(("parsed req SID=%s\n", SON(DBG(session_id))));
		return -1;
	}
	return 1;
}

int chk_session_request(char *str, int len, char delimiter TSRMLS_DC1(DBG)) {
	char *p, *e;
	int ret_val;

	if (str == NULL) {
		DBG_TRACE(("chk_session_request NULL\n"));
		return 0;
	}
	DBG_TRACE(("chk_session_request '%s'\n", SON(str)));
	if (len == -1) len = strlen(str);
	p = str;
	e = p + len;
	while (p < e) {
		while (p < e && (p[0] == ' ' || p[0] == '\t')) p++;
		if ((e-p) < sizeof(DBGSESSVAR)-1) break;
		if (strncmp(p, DBGSESSVAR, sizeof(DBGSESSVAR)-1) == 0) {
			p += sizeof(DBGSESSVAR)-1;
			if (p >= e-1) return 0;
			if (*p == '=') {
				p++;
				ret_val = parse_session_request(p, e-p, delimiter TSRMLS_CC1(DBG));
				DBG_TRACE(("parsed result=%d\n", ret_val));
				return (ret_val);
			}
		}
		while (p < e && p[0] != delimiter) p++;
		if (p[0] != delimiter) return 0;
		p++;
	}
	return 0;
}

int dbg_send_sid(TSRMLS_D2(DBG, E)) {
	dbg_packet pack;
	int ret_val;

	if (!dbg_packet_new(&pack)) return 0;

	ret_val = handler_add_sid_reply(&pack, NULL, NULL TSRMLS_CC2(DBG, E));
	if (ret_val) ret_val = dbg_send_command(DBGC_SID, &pack, 0 TSRMLS_CC2(DBG, E));
	
	dbg_packet_free(&pack);
	return ret_val;
}


int dbg_start_session(SESSTYPE sesstype TSRMLS_DC3(DBG, E, S)) {
	int ret_val;

	DBG_TRACE(("dbg_start_session req %d\n", sesstype));


	if ((DBGF(DBGF_REJECTIONFOUND) && (sesstype != DBG_EMB)) ||
	    DBG(debug_socket) != 0 ||
		DBG(is_failed_connection) ||
		!DBG(cfgprm_enabled) ||
		DBG(deactivate_inprocess)) return ESESS_NOREASON;

	add_session_cookie(TSRMLS_C2(DBG, S));
	DBG(debug_socket) = create_debugger_socket(sesstype TSRMLS_CC2(DBG, E));
	DBG(is_failed_connection) = (DBG(debug_socket) > 0) ? 0:1;
	if (DBG(is_failed_connection)) return DBG(debug_socket);

	DBG(debugger_flags) = DBGF_STARTED;
	DBG(sesstype) = sesstype;

	ret_val = dbg_send_sid(TSRMLS_C2(DBG, E));
	if (ret_val > 0)
		ret_val = dbg_send_std_action(DBGC_STARTUP, 0 TSRMLS_CC2(DBG, E));
	if (ret_val > 0 && DBG(session_id) && strlen(DBG(session_id)) > 0) {
		if (DBG(cfgprm_session_nocache) &&
			!SG(headers_sent) && 
			!SG(request_info).no_headers) {
			ADD_HDR("Expires: Thu, 19 Nov 1981 08:52:00 GMT");
			ADD_HDR("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
			ADD_HDR("Pragma: no-cache");
		}
	}

	DBG_TRACE(("dbg_start_session ret_val=%d\n", ret_val));
	return ret_val;
}

int dbg_stop_session(TSRMLS_D2(DBG, E)) {
	int ret_val = 0;
	
	if (!DBG(is_failed_connection) && DBG(debug_socket) > 0) {
		ret_val = dbg_send_std_action(DBGC_END, 0 TSRMLS_CC2(DBG, E));
	}
	DBG(debugger_flags) = DBGF_FINISHED;
	DBG(sesstype) = 0;
	return ret_val;
}


inline int dbg_checkpausereq(TSRMLS_D1(DBG)) {
	fd_set rset, eset;
	struct timeval timeout;
	int ret_val;
	dbg_header_struct hdr;
	dbg_packet pack;
	int socket = DBG(debug_socket);

	if (socket <= 0) {
		return 0;
	}
	FD_ZERO(&rset);
	FD_SET((unsigned int)socket, &rset);
	FD_ZERO(&eset);
	FD_SET((unsigned int)socket, &eset);
	timeout.tv_sec = 0;
	timeout.tv_usec = 0;
	ret_val = select(socket + 1, &rset, NULL, &eset, &timeout);
	if (ret_val != 1 || !FD_ISSET((unsigned int)socket, &rset)) 
		return 0;
	
	if (!dbg_packet_new(&pack)) return 0;
	ret_val = dbg_packet_recv(&hdr, &pack, socket, 0);
	if (ret_val > 0) {
		ret_val = (hdr.cmd == DBGC_PAUSE);
	}
	dbg_packet_free(&pack);
	return ret_val;
}

