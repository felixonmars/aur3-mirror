/***************************************************************************
                          dbg_bp.c  -  description
                             -------------------
    begin                : Wed Sep 12 2001
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/

#include "php.h"

#include "php_dbg.h"
#include "dbg_cmd.h"

int bp_no_cmp(const void *p1, const void *p2) {
	int bp_no1 = ((bp_item *)  ((*(zend_llist_element **)(p1))->data)  )->bp_no;
	int bp_no2 = ((bp_item *)  ((*(zend_llist_element **)(p2))->data)  )->bp_no;
	if (bp_no1 > bp_no2) return 1;
		else if (bp_no1 == bp_no2) return 0;
	return -1;
}

bp_item *find_bp_item_by_no(int bp_no TSRMLS_DC1(DBG)) {
	LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
		if (data->bp_no == bp_no) return data;
	});
	return NULL;	
}

void bp_array_free(bpl_array* arr) {
	if (arr->item) {
		efree(arr->item);
		arr->item = NULL;
	}
	memset(arr, 0, sizeof(*arr));
}

inline void bp_array_clear(bpl_array* arr) {
	arr->count = 0;
}

void bp_array_add(bpl_array* arr, bp_item* item) {
	if (arr->count >= arr->limit) {
		arr->limit += 4;
		arr->item = erealloc(arr->item, arr->limit * sizeof(*(arr->item)));
	}
	if (!arr->item) return;
	arr->item[arr->count].item = item;
	arr->item[arr->count].line_no = item->line_no;
	arr->count += 1;
}

int bp_array_cmp(const void *elem1, const void *elem2) {
	int l1 = ((bpl_arr_item *)elem1)->line_no;
	int l2 = ((bpl_arr_item *)elem2)->line_no;
	if (l1 > l2) return 1;
		else if (l1 == l2) return 0;
	return -1;
}

void bp_array_sort(bpl_array* arr) {
	if (arr->count <= 1) return;
	qsort(arr->item, arr->count, sizeof(*(arr->item)), bp_array_cmp);
}

inline int bp_array_find(bpl_array* bp_arr, int line_no, bpl_arr_item ** start_item) {
	int L, H, i, c, cnt, lno;
	bpl_arr_item *bpit, *p;

	*start_item = NULL;
	if (!bp_arr || !(bpit = bp_arr->item)) return 0;
	
	L = 0;
	cnt = bp_arr->count;
	H = cnt - 1;

	while (L <= H) {
		i = (L + H) >> 1;
		lno = bpit[i].line_no;
		if (lno < line_no) {
			L = i + 1;
		} else {
			H = i - 1;
			if (lno == line_no) {
				p = &bpit[i];
				while (i > 0) {
					p--;i--;
					if (p->line_no != line_no) {
						p++;i++;
						break;
					}
				}
				*start_item = p;
				c = 1;
				p++;i++;
				while (i < cnt && p->line_no == line_no) {
					p++;i++;
					c++;
				}
				return c;
			};
		}
	}
	return 0;
}

void dbg_do_resolve_bp(bp_item* bp TSRMLS_DC1(DBG)) {
	int mod_no;
	int l_no = bp->line_no;
	int found = 0;

	if (bp->mod_no == 0 && bp->mod_name != NULL) {
		bp->mod_no = DBG_FINDMODULE(bp->mod_name);
	}
	mod_no = bp->mod_no;
	if (mod_no == 0) return;

	LLIST_FOREACH(DBG(ctxlines_list), ctxlines_item,
		if (data->mod_no == mod_no && l_no >= data->start_line_no && l_no < data->start_line_no + data->lines_cnt) {
			DBG_TRACE(("found %d:%d:%d\n", mod_no, data->start_line_no, data->lines_cnt));
			found = 1;
			break;
		}
	);
	if (found) {
		DBG_TRACE(("resolved %d:%d\n", mod_no, l_no));
		bp->state &= ~BPS_UNRESOLVED;
	}
}

void dbg_resolve_bp(TSRMLS_D1(DBG)) {

	DBG_TRACE(("dbg_resolve_bp\n"));
	LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
		if (data->state & BPS_UNRESOLVED)
			dbg_do_resolve_bp(data TSRMLS_CC1(DBG));
	});
}

void dbg_rebuild_bplist_mod(mod_item* mod TSRMLS_DC1(DBG)) {
	int mod_no = (mod) ? (mod->mod_no) : 0;
	if (mod_no == 0) return;

	bp_array_clear(&mod->bp_arr);
	LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
		if (data->mod_no == mod_no && (data->state & ~BPS_UNRESOLVED)==BPS_ENABLED) {
			bp_array_add(&mod->bp_arr, data);
		}
	});
	bp_array_sort(&mod->bp_arr);
	DBG(breakpoint_list_inv) = 0;
}

void dbg_rebuild_bplist(TSRMLS_D1(DBG)) {
	DBG_TRACE(("dbg_rebuild_bplist()\n"));
	LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
		if ((data->state & ~BPS_UNRESOLVED) == BPS_DELETED) {
			DBG_TRACE(("removing deleted bp.%d\n", data->bp_no));
			zend_llist_del_element(&DBG(breakpoint_list), data, cmpll);
		}
	});
	dbg_resolve_bp(TSRMLS_C1(DBG));
	LLIST_FOREACH(DBG(mod_list), mod_item,
		dbg_rebuild_bplist_mod(data TSRMLS_CC1(DBG));
	);
	bp_array_clear(&DBG(global_bp_arr));
	LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
		if (data->mod_no == 0 && data->mod_name == NULL) {
			bp_array_add(&DBG(global_bp_arr), data);
		}
	});
	bp_array_sort(&DBG(global_bp_arr));
}

static inline int chk_hit_bp(bp_item *bpit TSRMLS_DC3(DBG, E, C)) {
	int is_hit = 1, is_failed, failedtocompile = 0;

	if (bpit->state != BPS_ENABLED) return 0;

	if (bpit->condition) {
		zval buf, *pbuf;

		is_hit = 0;
		memset(&buf, 0, sizeof(buf));
		Z_TYPE_P(&buf) = IS_STRING;
		buf.refcount++;
		DBG(in_eval)++;
		is_failed = 1;
		{
			DBG_CTX_SAVE
			DBG_CTX_TRY {

				if (DBG(eval_error)) {
					efree(DBG(eval_error));
					DBG(eval_error) = NULL;
				}
				if (zend_eval_string(bpit->condition, &buf, "dbg_bp_condition()" TSRMLS_CC2(C, E)) == SUCCESS && !DBG(eval_error)) {
					pbuf = &buf;
					convert_to_boolean_ex(&pbuf);
					is_hit = (*pbuf).value.lval;
				}
			} DBG_CTX_CATCH {				
				DBG_CTX_RESTORE
			} DBG_CTX_ENDTRY
		}
		DBG(in_eval)--;
	}
	if (is_hit) {
		DBG_TRACE(("bp#%d hit\n", bpit->bp_no));
		bpit->hitcount++;
		bpit->isunderhit = 1;
		if (bpit->hitcount <= bpit->skiphits) is_hit = 0;
		if (bpit->istemp) bpit->state = BPS_DELETED;
	}
	return is_hit;
}

inline int dbg_chk_bp_hits(TSRMLS_D2(DBG, E)) {
	int mod_bpcnt, i, hitc;
	bpl_arr_item *mod_bpit, *p;
	mod_item* mod = DBG(curr_mod);

	TSRMLS_FETCH1_NOP(C);

	if (!mod) return 0;
	mod_bpcnt = bp_array_find(&mod->bp_arr, DBG(curr_line_no), &mod_bpit);
	hitc = 0;
	for (i=0, p=mod_bpit; i<mod_bpcnt; i++,p++) {
		if (chk_hit_bp(p->item TSRMLS_CC3(DBG, E, C))) hitc++;
	}
	for (i=0, p=DBG(global_bp_arr).item; i<DBG(global_bp_arr).count; i++, p++) {
		if (chk_hit_bp(p->item TSRMLS_CC3(DBG, E, C))) hitc++;
	}
	return hitc; 
}

inline void dbg_reset_bp_isunderhit(TSRMLS_D1(DBG)) {
	LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
		data->isunderhit = 0;
	});
}

inline void dbg_mark_del_temp_breakpoints(TSRMLS_D1(DBG)) {
	DBG_TRACE(("dbg_mark_del_temp_breakpoints()\n"));
	LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
		if (data->istemp) {
			DBG_TRACE(("mark bp.%d as deleted\n",data->bp_no));
			data->state = BPS_DELETED;
			DBG(breakpoint_list_inv) = 1;
		}
	});
}

inline int listout_bp_item(dbg_packet *pack, bp_item *bpitem, int bp_no) {
	dbg_bpl_body body;
	if (bpitem) {
		body.bp_no = bp_no;
		body.hitcount = bpitem->hitcount;
		body.icondition = dbg_packet_add_string(pack, bpitem->condition);
		body.imod_name = dbg_packet_add_string(pack, bpitem->mod_name);
		body.istemp = bpitem->istemp;
		body.line_no = bpitem->line_no;
		body.mod_no = bpitem->mod_no;
		body.skiphits = bpitem->skiphits;
		body.state = bpitem->state;
		body.isunderhit = bpitem->isunderhit;
		DBG_TRACE(("list bp.%d, state=%d\n", bpitem->bp_no, bpitem->state));
	} else {
		memset(&body, 0, sizeof(body));
		body.bp_no = bp_no;
	}
	dbg_packet_add_frame(pack, FRAME_BPL, &body, sizeof(body));
	return sizeof(body);
}

void dbg_add_bp_reply(dbg_packet *pack TSRMLS_DC1(DBG)) {
	dbg_mark_del_temp_breakpoints(TSRMLS_C1(DBG));
	LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
		listout_bp_item(pack, data, data->bp_no);
	});
}


typedef int (*qsort_func_t)(const void *, const void *);

void dbg_llist_sort(zend_llist *l, qsort_func_t comp_func) {
	int list_size=0, i;

	zend_llist_element **elements;
	zend_llist_element *element, **ptr;

	for (element=l->head; element; element=element->next) {
		list_size++;
	}

	if (list_size == 0) {
		return;
	}

	elements = (zend_llist_element **) emalloc(list_size*sizeof(zend_llist_element *));

	ptr = &elements[0];

	for (element=l->head; element; element=element->next) {
		*ptr++ = element;
	}

	qsort(elements, list_size, sizeof(zend_llist_element *), (int (*)(const void *, const void *)) comp_func);

	l->head = elements[0];
	elements[0]->prev = NULL;

	for (i=1; i<list_size; i++) {
		elements[i]->prev = elements[i-1];
		elements[i-1]->next = elements[i];
	}
	elements[i - 1]->next = NULL;
	l->tail = elements[i - 1];
	efree(elements);
}

int dbg_set_breakpoint(dbg_bps_request* req, dbg_packet *pack, dbg_packet *inpack TSRMLS_DC2(DBG, E)) {
	bp_item *pitem = NULL, item;
	char *mod_name = NULL, *condition = NULL;
	int sz, prev_bp_no1, bp_no;
	/* UPDATE | DELETE */	
	if (req->bp_no != 0) {
		DBG_TRACE(("updating bp#%d, st:%d, line:%d, skip:%d\n", req->bp_no, req->state, req->line_no, req->skiphits));
		bp_no = req->bp_no;
		pitem = find_bp_item_by_no(bp_no TSRMLS_CC1(DBG));
		if (pitem) {			
			pitem->state = req->state | BPS_UNRESOLVED;
			if ((req->state & ~BPS_UNRESOLVED) != BPS_DELETED) {
				pitem->line_no = req->line_no;
				pitem->skiphits = req->skiphits;
				if (pitem->condition) {
					efree(pitem->condition);
					pitem->condition = NULL;
				}
				if (dbg_packet_findstring(inpack, req->icondition , &condition, &sz)) {
					pitem->condition = estrdup(condition);
					DBG_TRACE(("updating condition bp#%d, cond:'%s'\n", req->bp_no, SON(condition)));
				}
			}
		}
	} else {
		/* SET */
		if (!dbg_packet_findstring(inpack, req->icondition, &condition, &sz))
			condition = NULL;

		if (req->imod_name!=0 || req->mod_no!=0 || req->line_no!=0) {
			dbg_packet_findstring(inpack, req->imod_name, &mod_name, &sz);

			if (req->mod_no==0) { /* by mod_name */
				if (mod_name==NULL || strlen(mod_name) == 0) 
					return listout_bp_item(pack, NULL, 0);
				req->mod_no = DBG_FINDMODULE(mod_name);
			}

			if (req->mod_no!=0) { /* by mod_no */
				mod_name = dbg_mod_name_by_no(req->mod_no TSRMLS_CC1(DBG));
				if (mod_name == NULL) 
					return listout_bp_item(pack, NULL, 0);
			}
		}


		prev_bp_no1 = 1;
		bp_no = 1;
		LLIST_FOREACH(DBG(breakpoint_list), bp_item, {
			if (data->bp_no > prev_bp_no1) {
				bp_no = prev_bp_no1;
				break;
			}
			prev_bp_no1 = data->bp_no + 1;
			bp_no = prev_bp_no1;
		});

		DBG_TRACE(("set bp#%d mod:'%s'(%d), line:%d, cond:'%s', tmp:%d, st:%d\n", bp_no, SON(mod_name), req->mod_no, req->line_no, condition, req->istemp, req->state));

		item.bp_no = bp_no;
		item.condition = (condition && strlen(condition) > 0) ? estrdup(condition) : NULL;
		item.hitcount = 0;
		item.istemp = req->istemp;
		item.isunderhit = 0;
		item.line_no = req->line_no;
		item.mod_name = (mod_name && strlen(mod_name) > 0) ? estrdup(mod_name) : NULL;
		item.skiphits = req->skiphits;
		item.mod_no = req->mod_no;
		item.state = req->state | BPS_UNRESOLVED;		
		zend_llist_add_element(&DBG(breakpoint_list), &item);
	}

	DBG(breakpoint_list_inv) = 1;
	dbg_rebuild_bplist(TSRMLS_C1(DBG));
	dbg_llist_sort(&DBG(breakpoint_list), bp_no_cmp);
	

	pitem = find_bp_item_by_no(bp_no TSRMLS_CC1(DBG));
	return listout_bp_item(pack, pitem, bp_no);
}
