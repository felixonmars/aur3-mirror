/***************************************************************************
                          dbg_bp.h  -  description
                             -------------------
    begin                : Wed Sep 12 2001
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/

#ifndef _DBG_BP_H_
#define _DBG_BP_H_

#include "php_dbg.h"

void bp_array_free(bpl_array* arr);

int dbg_set_breakpoint(dbg_bps_request* req, dbg_packet *pack, dbg_packet *inpack TSRMLS_DC2(DBG,E));
inline int listout_bp_item(dbg_packet *pack, bp_item *bpitem, int bp_no);
inline int dbg_chk_bp_hits(TSRMLS_D2(DBG,E));
inline void dbg_reset_bp_isunderhit(TSRMLS_D1(DBG));
inline void dbg_mark_del_temp_breakpoints(TSRMLS_D1(DBG));

void dbg_rebuild_bplist_mod(mod_item* mod TSRMLS_DC1(DBG));
void dbg_rebuild_bplist(TSRMLS_D1(DBG));
void dbg_resolve_bp(TSRMLS_D1(DBG));

void dbg_add_bp_reply(dbg_packet *pack TSRMLS_DC1(DBG));


#endif
