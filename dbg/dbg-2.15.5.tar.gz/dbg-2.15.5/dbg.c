/***************************************************************************
                          dbg.c  -  description
                             -------------------
    begin                : Sun Sep 24 2000
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/


#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_compat.h"
#include "php_network.h"
#include "php_logos.h"
#include "SAPI.h"

#if PHP_WIN32 || defined WIN32
#include "config.w32.h"
#endif

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif


#include "php_dbg.h"
#include "dbg_cmd.h"
#include "dbg_prof.h"
#include "dbg_ser.h"
#include "dbg_bp.h"

#include "zend_extensions.h"

#ifdef ZTS
#include "TSRM.h"
#endif

#define php_module_dbg_name "dbg"
#define zend_ext_dbg_name "DBG"

/*ZEND_DECLARE_MODULE_GLOBALS(dbg); */
#ifdef ZTS
int DBG_globals_id;
#else
zend_DBG_globals DBG_globals;
#endif

zend_DBG_globals *pDBG_globals;

static int dbg_module_id;
static int is_dbg_ext_started;

static void (*orig_zend_error_cb)(int type, const char *err_mod_name, const uint err_line_no, const char *format, va_list args);

#if ZEND_EXTENSION_API_NO >= 20010710
static int (*orig_sapi_module_ub_write)(const char *str, unsigned int str_length TSRMLS_DC);
#else
static int (*orig_sapi_module_ub_write)(const char *str, unsigned int str_length);
#endif

/************************
         
	INI Settings

*************************/

#define JIT_LEVEL_STR "debugger.JIT_level"
#define DEFAULT_JIT_LEVEL "3"

static PHP_INI_MH(on_update_JIT_level) {
	TSRMLS_FETCH1_NOP(DBG);
	if (!new_value) {
		DBG(cfgprm_JIT_level) = 3;
	} else {
		DBG(cfgprm_JIT_level) = atoi(new_value);
		if (DBG(cfgprm_JIT_level) < 0 || DBG(cfgprm_JIT_level) > 4) DBG(cfgprm_JIT_level) = 3;
	}
	switch (DBG(cfgprm_JIT_level)) {
		case 0:
			DBG(JIT_filter) = ERR_LEVEL0_MASK;
			break;
		case 1:
			DBG(JIT_filter) = ERR_LEVEL1_MASK;
			break;
		case 2:
			DBG(JIT_filter) = ERR_LEVEL2_MASK;
			break;
		case 3:
			DBG(JIT_filter) = ERR_LEVEL3_MASK;
			break;
		case 4:
			DBG(JIT_filter) = ERR_LEVEL4_MASK;
			break;
	}
	return SUCCESS;
}

#if defined(ZEND_ENGINE_2)
#define OnUpdateInt OnUpdateLong
#endif

#define DBG_INI_BOOLEAN(name, dflt, fld) \
	STD_PHP_INI_BOOLEAN(name, dflt, PHP_INI_ALL &~PHP_INI_USER, OnUpdateInt, fld, zend_DBG_globals, DBG_globals)
#define DBG_INI_STRING(name, dflt, fld) \
	STD_PHP_INI_ENTRY(name,	dflt, PHP_INI_ALL &~PHP_INI_USER, OnUpdateString, fld, zend_DBG_globals, DBG_globals)
#define DBG_INI_INT(name, dflt, fld) \
	STD_PHP_INI_ENTRY(name,	dflt, PHP_INI_ALL &~PHP_INI_USER, OnUpdateInt, fld, zend_DBG_globals, DBG_globals)

PHP_INI_BEGIN()
	DBG_INI_BOOLEAN(	"debugger.enabled",					"0",	cfgprm_enabled)
	DBG_INI_BOOLEAN(	"debugger.JIT_enabled",				"0",	cfgprm_JIT_enabled)
	DBG_INI_STRING(		"debugger.JIT_host",		CLIENT_HOST,		cfgprm_JIT_host)
	DBG_INI_INT(		"debugger.JIT_port",		DEFAULT_PORT_STR,	cfgprm_JIT_port)
	DBG_INI_BOOLEAN(	"debugger.fail_silently",			"1",	cfgprm_fail_silently)
	DBG_INI_INT(		"debugger.timeout_seconds",			"300",	cfgprm_timeout_seconds)
	DBG_INI_BOOLEAN(	"debugger.ignore_nops",				"0",	cfgprm_ignore_nops)
	DBG_INI_BOOLEAN(	"debugger.enable_session_cookie",	"1",	cfgprm_session_cookie)
	DBG_INI_BOOLEAN(	"debugger.session_nocache",			"1",	cfgprm_session_nocache)
	DBG_INI_BOOLEAN(	"debugger.profiler_enabled",		"0",	cfgprm_profiler_enabled)
	PHP_INI_ENTRY(		JIT_LEVEL_STR,	DEFAULT_JIT_LEVEL, PHP_INI_ALL,	on_update_JIT_level)
PHP_INI_END()


/************************
         
	Destructors

*************************/

void bp_dtor(void *data) {
	bp_item *item = data;
	if (item->mod_name) {
		efree(item->mod_name);
		item->mod_name = NULL;
	}
	if (item->condition) {
		efree(item->condition);
		item->condition = NULL;
	}
}

void back_trace_dtor(void *data) {
	back_trace_item *item = data;
	if (item->descr) {
		efree(item->descr);
		item->descr = NULL;
	}
}

static void mod_list_dtor(void *data) {
	mod_item *item = data;
	if (item->profdata_arr) efree(item->profdata_arr);
	item->profdata_arr = NULL;
	if (item->mod_name) {
		efree(item->mod_name);
		item->mod_name = NULL;
	}
}

static void ctxlines_dtor(void *data) {
	ctxlines_item *item = data;
	item->mod_name = NULL;
}

static void ctx_dtor(void *data) {
	ctx_item *item = data;
	if (item->mod_name) {
		efree(item->mod_name);
		item->mod_name = NULL;
	}
	if (item->function_name) {
		efree(item->function_name);
		item->function_name = NULL;
	}
}


/************************
         
	TSRM Memory (e.g. TLS)

*************************/

static void php_dbg_clearruntimeglobals(TSRMLS_D1(DBG)) {
	DBG_TRACE(("php_dbg_clearruntimeglobals\n"));
	DBG(clientversion) = 0;
	DBG(curr_line_no) = 0;
	DBG(curr_mod_name) = NULL;
	DBG(curr_mod_no) = 0;
	DBG(curr_mod) = NULL;
	DBG(last_opline) = NULL;
	DBG(debugger_flags) = 0;
	DBG(debugger_step_depth) = 0;
	DBG(in_eval) = 0;
	DBG(eval_nest) = 0;
	DBG(pause_cntr) = 0;
	DBG(breakpoint_list_inv) = 0;
	DBG(back_trace_count) = 0;
	DBG(ctx_counter) = 0;
	DBG(e_time) = 0;
	DBG(l_time) = 0;
	DBG(deactivate_inprocess) = 0;
	DBG(session_cookie_added) = 0;
}

TS_ALLOC_CTOR_FUNCTION(DBG) {
/*void php_dbg_init_globals(TSRMLS_D1(DBG)) { */

	DBG_TRACE(("TS_ALLOC_CTOR_FUNCTION(DBG)\n"));
#ifdef ZTS
	pDBG_globals = DBG_globals;
#else
	pDBG_globals = &DBG_globals;
#endif
		
	DBG(is_extension_activated) = 0;
	DBG(is_failed_connection) = 0;

	DBG(sesstype) = 0;
	DBG(error_filter) = ERR_LEVEL3_MASK;
	DBG(debug_socket) = 0;
	DBG(req_client_port) = 0;
	DBG(req_client_ip_address) = NULL;
	DBG(client_port) = 0;
	DBG(client_address) = NULL;
	DBG(session_id) = NULL;
	DBG(req_sess_var) = NULL;
	DBG(eval_error) = NULL;
	DBG(opt_flags) = SOF_DEFAULT;
	DBG(output_str_nd) = NULL;
	DBG(output_str_nd_len) = 0;
	DBG(output_str_nd_limit) = 0;
	php_dbg_clearruntimeglobals(TSRMLS_C1(DBG));

	DBG(JIT_filter) = ERR_LEVEL3_MASK;

	memset(&DBG(global_bp_arr), 0, sizeof(DBG(global_bp_arr)));
	memset(&DBG(back_trace), 0, sizeof(DBG(back_trace)));
	memset(&DBG(mod_list), 0, sizeof(DBG(mod_list)));
	memset(&DBG(breakpoint_list), 0, sizeof(DBG(breakpoint_list)));
	memset(&DBG(ctxlines_list), 0, sizeof(DBG(ctxlines_list)));
	memset(&DBG(ctx_list), 0, sizeof(DBG(ctx_list)));

	zend_llist_init(&DBG(back_trace), sizeof(back_trace_item), back_trace_dtor, 0);
	zend_llist_init(&DBG(mod_list),sizeof(mod_item),mod_list_dtor, 0);
	zend_llist_init(&DBG(breakpoint_list), sizeof(bp_item), bp_dtor, 0);
	zend_llist_init(&DBG(ctxlines_list), sizeof(ctxlines_item), ctxlines_dtor, 0);
	zend_llist_init(&DBG(ctx_list), sizeof(ctx_item), ctx_dtor, 0);
	dbg_packet_new(&DBG(logpack));

	DBG(is_globals_initialized) = 1;
}

static void module_cleanup(TSRMLS_D1(DBG)) {
	DBG_TRACE(("module_cleanup\n"));
	DBG(is_globals_initialized) = 0;
	DBG(is_extension_activated) = 0;
	DBG(is_failed_connection) = 0;
	if (DBG(req_client_ip_address)) {
		efree(DBG(req_client_ip_address));
		DBG(req_client_ip_address) = NULL;
	}
	if (DBG(client_address)) {
		DBG_TRACE(("client_address = %x\n", SON(DBG(client_address))));
		efree(DBG(client_address));
		DBG(client_address) = NULL;
	}
	if (DBG(session_id)) {
		efree(DBG(session_id));
		DBG(session_id) = NULL;
	}

	if (DBG(debug_socket) > 0) {
		DBG_TRACE(("close dbg socket(%d)\n", DBG(debug_socket)));
		SCLOSE(DBG(debug_socket));		
	} else {
		DBG_TRACE(("socket = (%d)\n", DBG(debug_socket)));		
	}
	DBG(debug_socket) = 0;

	if (DBG(req_sess_var)) {
		efree(DBG(req_sess_var));
		DBG(req_sess_var) = NULL;
	}
	if (DBG(mod_list).size) {		
		zend_llist_destroy(&DBG(mod_list));
		memset(&DBG(mod_list), 0, sizeof(DBG(mod_list)));
	}
	if (DBG(breakpoint_list).size) {
		zend_llist_destroy(&DBG(breakpoint_list));
		memset(&DBG(breakpoint_list), 0, sizeof(DBG(breakpoint_list)));
	}
	if (DBG(back_trace).size) {		
		zend_llist_destroy(&DBG(back_trace));
		memset(&DBG(back_trace), 0, sizeof(DBG(back_trace)));
		DBG(back_trace_count) = 0;
	}
	if (DBG(eval_error)) {
		efree(DBG(eval_error));
		DBG(eval_error) = NULL;
	}
	if (DBG(ctxlines_list).size) {
		zend_llist_destroy(&DBG(ctxlines_list));
		memset(&DBG(ctxlines_list), 0, sizeof(DBG(ctxlines_list)));
	}
	if (DBG(ctx_list).size) {
		zend_llist_destroy(&DBG(ctx_list));
		memset(&DBG(ctx_list), 0, sizeof(DBG(ctx_list)));
	}
	bp_array_free(&DBG(global_bp_arr));
	dbg_packet_free(&DBG(logpack));
	if 	(DBG(output_str_nd)) {
		efree(DBG(output_str_nd));
		DBG(output_str_nd) = NULL;
		DBG(output_str_nd_len) = 0;
	}
	php_dbg_clearruntimeglobals(TSRMLS_C1(DBG));
}

TS_ALLOC_DTOR_FUNCTION(DBG) {
	DBG_TRACE(("TS_ALLOC_DTOR_FUNCTION\n"));
	module_cleanup(TSRMLS_C1(DBG));
}


/**********************

S T E P   B Y   S T E P

**********************/

static inline int dbg_step( TSRMLS_D3(DBG,E,S) ) {
	int ret_val = 0, hitcnt;

	DBG_TRACE(("step: flags: %d\n", DBG(debugger_flags)));

	hitcnt = dbg_chk_bp_hits(TSRMLS_C2(DBG,E));
	if (DBGF(DBGF_STEPINTO)) {
		ret_val = dbg_send_std_action(DBGC_STEPINTO_DONE, hitcnt TSRMLS_CC2(DBG, E));
	} else if (DBGF(DBGF_STEPOVER) && 
		     DBG(back_trace_count) <= DBG(debugger_step_depth)) {
		ret_val = dbg_send_std_action(DBGC_STEPOVER_DONE, hitcnt TSRMLS_CC2(DBG, E));
	} else if (DBGF(DBGF_STEPOUT) && 
		     DBG(back_trace_count) < DBG(debugger_step_depth)) {
		ret_val = dbg_send_std_action(DBGC_STEPOUT_DONE, hitcnt TSRMLS_CC2(DBG, E));
	} else if (hitcnt > 0) {
		ret_val = dbg_send_std_action(DBGC_BREAKPOINT, hitcnt TSRMLS_CC2(DBG, E));
	}
	return ret_val;
}

/**********************

	P R O F I L E R

**********************/

static inline void dbg_store_prof_data(dbgint64 t TSRMLS_DC1(DBG)) {
	mod_item* item;
	profdata_item* pr_item;
	dbgint line_no;

	if (!DBG(cfgprm_profiler_enabled)) return;
	item = dbg_mod_item_by_no(DBG(curr_mod_no) TSRMLS_CC1(DBG));
	line_no = DBG(curr_line_no);
	if (!item || !item->profdata_arr || 
		line_no <= 0 || line_no >= item->profdata_items) return;
	if (t < 0) 
		t=0;
	pr_item = &(item->profdata_arr[line_no]);
	if (pr_item->hitcount == 0) {
		pr_item->tm_max = t;
		pr_item->tm_min = t;
		pr_item->tm_sum = t;
	} else {
		if (t > pr_item->tm_max) pr_item->tm_max = t;
		if (t < pr_item->tm_min) pr_item->tm_min = t;
		pr_item->tm_sum += t;
	}
	pr_item->hitcount++;	
}


static void on_dbg_ub_write(const char *str, unsigned int str_length TSRMLS_DC2(DBG, E)) {
	if (DBGO(SOF_SEND_OUTPUT) && DBGF(DBGF_STARTED) && !DBG(is_failed_connection)) {
		dbg_send_log((char *)str, str_length, LT_OUTPUT, NULL, 0, 0 TSRMLS_CC2(DBG, E));
	}
}


int dbg_ub_write(const char *str, unsigned int str_length TSRMLS_DC0) {
	PROF_ENTER {
		TSRMLS_FETCH2_NOP(DBG, E);
		on_dbg_ub_write(str, str_length TSRMLS_CC2(DBG, E));
		PROF_LEAVE;
	}
	if (orig_sapi_module_ub_write) {
		return orig_sapi_module_ub_write(str,str_length TSRMLS_CC0);
	} else {
		return 0;
	}
}

/**********************

E R R O R   H A N D L I N G

**********************/

static int on_dbg_error_cb(int type, const char *err_mod_name, const uint err_line_no, const char *format, va_list args TSRMLS_DC4(DBG, E, C, S)) {
	char buffer[2048];
	int ret_val;
	int can_send;
	int is_started = 0;
	int can_be_ignored = 0;

	DBG_TRACE(("error_cb\n"));
	can_send = (DBG(cfgprm_enabled) && !DBG(is_failed_connection));
	if (!DBG(cfgprm_JIT_enabled) && !DBGF(DBGF_STARTED | DBGF_REQUESTPENDING)) return 1;

	{
		va_list args_copy;
		va_copy(args_copy, args);
		vsnprintf(buffer, sizeof(buffer)-1, format, args_copy);
		va_end(args_copy);
	}

	
	buffer[sizeof(buffer)-1]=0;
	/*strncat(buffer,"\n",sizeof(buffer));*/
	DBG_TRACE(("err:\"%s\"\n",buffer));

	if (!can_send) return 1;

	if (DBG(in_eval)) {
/*		zend_op *end=EG(active_op_array)->opcodes + EG(active_op_array)->last;*/
/*		zend_op **opline_ptr = EG(opline_ptr);*/
		
		if (!DBG(eval_error)) 
			DBG(eval_error) = estrdup(buffer);


		switch (type) {
			case E_CORE_ERROR:
			case E_ERROR:
			case E_COMPILE_ERROR:
			case E_USER_ERROR:
#if ZEND_EXTENSION_API_NO >= 20010710
				zend_bailout();
#else
				dbg_send_log(buffer, strlen(buffer), LT_FATALERROR, err_mod_name, err_line_no, type TSRMLS_CC2(DBG, E));
#endif
			return 1;
		}		
/*		if (!CG(in_compilation)) {
			while ((*opline_ptr) < end && (*opline_ptr)->opcode != ZEND_RETURN) (*opline_ptr)++;
			if ((*opline_ptr) >= end) {
				(*opline_ptr)--;
				(*opline_ptr)->opcode = ZEND_RETURN;
			}
		} */
		return 0;
	}

	can_be_ignored = (DBG(error_filter) & type) == 0;
/* log */
	if (DBGO(SOF_SEND_ERRORS)) {
		dbg_send_log(buffer, strlen(buffer), LT_ERROR, err_mod_name, err_line_no, type TSRMLS_CC2(DBG, E));
	}

	DBG_FINDMODULE_ADD(err_mod_name); /* put file into the mod_list */
	if (
		((DBG(cfgprm_JIT_enabled) && (DBG(JIT_filter) & type)) || (DBGF(DBGF_REQUESTPENDING) && !can_be_ignored)) &&
		!DBGF(DBGF_STARTED) && 
		can_send
	    ) {
		is_started = 1;
		if (!DBGF(DBGF_REQUESTPENDING)) {
			dbg_start_session(DBG_JIT TSRMLS_CC3(DBG, E, S));
		} else {
			dbg_start_session(DBG_REQ TSRMLS_CC3(DBG, E, S));
		}
	}
	if (DBGF(DBGF_STARTED) == 0) return 1;

/* error */
	if (is_started || !can_be_ignored)
		ret_val = dbg_send_error(buffer, type, err_mod_name, err_line_no TSRMLS_CC2(DBG, E));
	return 1;
}

void dbg_error_cb(int type, const char *err_mod_name, const uint err_line_no, const char *format, va_list args) {
	int ret_val = 1;
	PROF_ENTER {
		TSRMLS_FETCH4(DBG, E, C, S);
		ret_val = on_dbg_error_cb(type, err_mod_name, err_line_no, format, args TSRMLS_CC4(DBG, E, C, S));
		PROF_LEAVE;
	}
	if (ret_val) {
		if (orig_zend_error_cb) /* standard handler */
			orig_zend_error_cb(type, err_mod_name, err_line_no, format, args);
		switch (type) {	/* terminate in certain cases */
			case E_CORE_ERROR:
			case E_ERROR:
			case E_COMPILE_ERROR:
			case E_USER_ERROR:
				zend_bailout(); /* terminate anyway, PHP/Zend can not recover on such errors */
		}
	}
}

/*************************
         
	DBG ZEND EXTENSION

*************************/


int dbg_startup(zend_extension *extension) {
/*	int module_number; */
	TSRMLS_FETCH1(P);
	
	DBG_TRACE(("dbg_startup Zend extension\n"));
	if (is_dbg_ext_started) return FAILURE;
	is_dbg_ext_started = 1;
/*	module_number = (dbg_module_id) ? dbg_module_id : (int)extension->handle; */
/*	ZEND_INIT_MODULE_GLOBALS(dbg, php_dbg_init_globals, php_dbg_uninit_globals);*/

	orig_zend_error_cb = zend_error_cb;
	zend_error_cb = dbg_error_cb;
	orig_sapi_module_ub_write = sapi_module.ub_write;
	sapi_module.ub_write = dbg_ub_write;
	return SUCCESS;
}

void dbg_shutdown(zend_extension *extension) {
/*	int module_number; */
/*	TSRMLS_FETCH1(P); */

	DBG_TRACE(("dbg_shutdown Zend extension\n"));
/*	module_number = (dbg_module_id) ? dbg_module_id : (int)extension->handle; */
	zend_error_cb = orig_zend_error_cb;
	sapi_module.ub_write = orig_sapi_module_ub_write;
	is_dbg_ext_started = 0;

	return;
}

NOPRM(dbg_activate) {
	TSRMLS_FETCH2(DBG, C);

	DBG_TRACE(("dbg_activate Zend extension\n"));
	if (!DBG(is_globals_initialized)) {
		TS_ALLOC_CTOR_CALL(DBG);
	}
	DBG(is_extension_activated) = 1;
	if (DBG(cfgprm_enabled)) {
		CG(extended_info) = 1;
	}
}

NOPRM(dbg_deactivate) {
	TSRMLS_FETCH1(C);

	DBG_TRACE(("dbg_deactivate Zend extension\n"));
	CG(extended_info) = 0;

/*	TS_ALLOC_DTOR_CALL(DBG); */
}

void dbg_op_array_handler(zend_op_array *op_array) {
	zend_op *op, *op_end;
	unsigned int line_no, max_line_no;
	dbgint mod_no;
	ctxlines_item lines_item;
	ctx_item item;
	mod_item *pmod;

	PROF_ENTER {
		TSRMLS_FETCH2(DBG, C);
		DBG_TRACE(("dbg_op_array_handler %s:%s\n", SON(op_array->filename), SON(op_array->function_name)));

		if (!DBG(is_extension_activated) || DBG(is_failed_connection)) return;
		if (!DBG(cfgprm_JIT_enabled) && !DBGF(DBGF_STARTED | DBGF_REQUESTPENDING)) return;

		op = op_array->opcodes;
		op_end = op + op_array->last;

		pmod = dbg_findmodule(op_array->filename, 1 TSRMLS_CC1(DBG));
		mod_no = (pmod) ? (pmod->mod_no) : 0;

		DBG(ctx_counter)++;
		item.ctx_id = DBG(ctx_counter);
		item.op_array = op_array;
		if (op_array->function_name) {
			if (CG(active_class_entry)) {
				char fnname[256];
				snprintf(fnname, sizeof(fnname)-1, "%s::%s", CG(active_class_entry)->name, op_array->function_name);
				fnname[sizeof(fnname)-1] = 0;
				item.function_name = estrdup(fnname);
			} else 
				item.function_name = estrdup(op_array->function_name);
		} else
			item.function_name = NULL;
		item.mod_name = estrdup(op_array->filename);
		zend_llist_add_element(&DBG(ctx_list), &item);

		max_line_no = 0;
		while (op < op_end) {
	/*		if (op_array->function_name != NULL) */
			if (DBG(cfgprm_ignore_nops)) {
				while (op < op_end && (op->opcode==ZEND_NOP || op->opcode==ZEND_EXT_STMT)) op++;
				if (op >= op_end) break;
			}			
			lines_item.start_line_no = op->lineno;
			op++;
			line_no = lines_item.start_line_no;
			while (op < op_end) {
				if (op->lineno==line_no) {
				} else if (op->lineno==line_no+1) {
					line_no++;
				} else break;
				op++;
			}
			lines_item.lines_cnt = line_no - lines_item.start_line_no + 1;
			if (lines_item.lines_cnt > 0) {
				
				if (line_no > max_line_no) max_line_no = line_no;

				lines_item.ctx_id = DBG(ctx_counter);
				lines_item.mod_name = pmod->mod_name;
				lines_item.mod_no = mod_no;
				zend_llist_add_element(&DBG(ctxlines_list), &lines_item);
			}
		}

		if (DBG(cfgprm_profiler_enabled) && max_line_no) {
			int sz, items, oldsz;
			items = (max_line_no + 1 + 64) & ~63;
			if (items > pmod->profdata_items) {
				oldsz = sizeof(profdata_item) * pmod->profdata_items;
				pmod->profdata_items = items;
				sz = sizeof(profdata_item) * items;
				pmod->profdata_arr = erealloc(pmod->profdata_arr, sz);
				memset((char *)pmod->profdata_arr + oldsz, 0, sz - oldsz);
			}
		}

		pmod->lines_changed = 1;

		PROF_LEAVE;
	}
}

inline int on_dbg_statement_handler(zend_op_array *op_array TSRMLS_DC3(DBG, E, S)) {
	dbgint line_no;
	int ret_val = 0, mod_changed=0;
	zend_op *opline;

	DBG_TRACE(("statement:%s file:%s:%d\n", SON(op_array->function_name), SON(op_array->filename), zend_get_executed_lineno(TSRMLS_C1(E))));

/* track the tree of source files */
/* we must add new module even if it contains only NOPs, that is why this check is performed here */
	if (op_array->filename!=DBG(curr_mod_name)) {
		DBG(curr_mod) = dbg_findmodule(op_array->filename, 1 TSRMLS_CC1(DBG));
		DBG(curr_mod_no) = (DBG(curr_mod)) ? (DBG(curr_mod)->mod_no) : 0;
		DBG(curr_mod_name) = op_array->filename;

		if (DBG(curr_mod)->lines_changed) {
			dbg_resolve_bp(TSRMLS_C1(DBG));
			dbg_rebuild_bplist_mod(DBG(curr_mod) TSRMLS_CC1(DBG));
		}
		mod_changed = 1;
	}

/*ignore NOPs*/
	opline = *EG(opline_ptr);
	line_no = opline->lineno;
	if (DBG(cfgprm_ignore_nops)) {
		opline++;
		switch (opline->opcode) {
			case ZEND_EXT_NOP:
			case ZEND_NOP:
				return 0;
			case ZEND_INCLUDE_OR_EVAL:
	/*			if (opline->op2.u.constant.value.lval == ZEND_EVAL) {
					opline = opline;
				}*/
				break;
		}
	}

/* ignore if the same line is hit again */	
	if (line_no != DBG(curr_line_no) || 
		(opline == DBG(last_opline) && !DBGF(DBGF_STEPOVER)) || 
		mod_changed) 
	{
		DBG(last_opline) = opline;
		DBG(curr_line_no) = line_no;
		DBG_TRACE(("step\n"));
		ret_val = dbg_step(TSRMLS_C3(DBG, E, S));
	} else {
		DBG_TRACE(("the same line\n"));
	}
	if (!ret_val) {
		if (DBG(pause_cntr)-- <= 0) {
			DBG(pause_cntr) = 100;
			if (dbg_checkpausereq(TSRMLS_C1(DBG))) {
				dbg_send_std_action(DBGC_BREAKPOINT, 0 TSRMLS_CC2(DBG, E));
			}
		}
	}
	return ret_val;
}

void dbg_onsessfailed(int rslt) {
	char buf[512];
	TSRMLS_FETCH3(DBG, E, S);

	switch (rslt) {
		case ESESS_LOOKUP:
			snprintf(buf, sizeof(buf), "client host address [%s] lookup failed", DBG(client_address)?DBG(client_address):"NULL");
			break;
		case ESESS_SOCK:
			snprintf(buf, sizeof(buf), "failed to create TCP/IP socket");
			break;
		case ESESS_CONN:
			snprintf(buf, sizeof(buf), "failed to establish connection to client host on <i>%s:%d</i>", DBG(client_address), DBG(client_port));
			break;
		default:
			snprintf(buf, sizeof(buf), "internal error");
	}
	buf[sizeof(buf)-1] = '\0';

	DBG_TRACE(("Failed to start debug session\n", buf));
	php_printf("<html><body><h2>DBG</h2><br>Failed to start debug session<br><br>reason:<br>%s<br></body></html>", buf);
	zend_bailout();
}

void dbg_statement_handler(zend_op_array *op_array) {
	int is_new_line;
	zend_op *opline;
	int ret_val;

	TSRMLS_FETCH3(DBG, E, S);
	if (!DBGF(DBGF_STARTED | DBGF_REQUESTPENDING)) return;

	{
		PROF_ENTER {
			DBG_TRACE(("statement\n"));

			if (!DBG(cfgprm_enabled) || DBG(is_failed_connection)) return;

			opline = *EG(opline_ptr);
			is_new_line = ((int)opline->lineno != DBG(curr_line_no) || 
							op_array->filename!=DBG(curr_mod_name)
						  );
			if (DBG(cfgprm_ignore_nops)) {
				opline++;
				is_new_line = (
					opline->opcode!=ZEND_EXT_NOP &&
					opline->opcode!=ZEND_NOP);
			}

			if (is_new_line) {
				PROF_STORE_TIME(dbg_store_prof_data);
			}



#ifdef DBG_204COMPAT
			if (!DBGF(DBGF_STARTED)) {
				DBG(debugger_flags) &= ~DBGF_REQUESTPENDING;
				ret_val = dbg_start_session(DBG_COMPAT TSRMLS_CC3(DBG, E, S));
				if (ret_val < 0)
					dbg_onsessfailed(ret_val);
			}
#else
			if (DBGF(DBGF_STARTED | DBGF_REQUESTPENDING) == DBGF_REQUESTPENDING) {
				DBG(debugger_flags) &= ~DBGF_REQUESTPENDING;
				ret_val = dbg_start_session(DBG_REQ TSRMLS_CC3(DBG, E, S)); /* by request */
				if (ret_val < 0)
					dbg_onsessfailed(ret_val);
			}
#endif

			if (!DBGF(DBGF_STARTED)) return;

			on_dbg_statement_handler(op_array TSRMLS_CC3(DBG, E, S));

			PROF_LEAVE;
		}
	}
}

void dbg_fcall_begin_handler(zend_op_array *op_array) {
	back_trace_item bt_item;
	char descr[256];
	mod_item *mod;
	
	TSRMLS_FETCH2(DBG, E);

	DBG_TRACE(("begin fcall function:%s file:%s:%d\n", SON(op_array->function_name), SON(op_array->filename), zend_get_executed_lineno(TSRMLS_C1(E))));

/*	if (!DBG(cfgprm_JIT_enabled) && DBGF(DBGF_STARTED) == 0) return; */
	if (!DBG(is_extension_activated) || DBG(is_failed_connection)) return;

	bt_item.active_sym_table = EG(active_symbol_table);
	bt_item.line_no = (*EG(opline_ptr))->lineno;
	if (EG(active_op_array)->function_name) {
		snprintf(descr, sizeof(descr)-1, "%s()", EG(active_op_array)->function_name);
	} else if (EG(active_op_array)->filename) {
		snprintf(descr, sizeof(descr)-1, "%s::main()", EG(active_op_array)->filename);
	} else descr[0]=0;
	descr[sizeof(descr)-1]=0;
	bt_item.descr = estrdup(descr);
	
	mod = dbg_findmodule(EG(active_op_array)->filename, 1 TSRMLS_CC1(DBG));
	bt_item.mod_no = (mod) ? (mod->mod_no) : (0);
	zend_llist_add_element(&DBG(back_trace), &bt_item);
	DBG(back_trace_count)++;
	DBG_TRACE(("exit fcall\n"));
}

void dbg_fcall_end_handler(zend_op_array *op_array) {
/*	back_trace_item *bt_item;*/
	TSRMLS_FETCH2(DBG, E);

	DBG_TRACE(("end fcall function:%s file:%s:%d\n", SON(op_array->function_name), SON(op_array->filename), zend_get_executed_lineno(TSRMLS_C1(E))));

/*	if (!DBG(cfgprm_JIT_enabled) && DBGF(DBGF_STARTED) == 0) return; */
	if (!DBG(is_extension_activated) || DBG(is_failed_connection)) return;

	DBG(back_trace_count)--;
	/*LLIST_ITEM_AT(DBG(back_trace), DBG(back_trace_count), bt_item);
	zend_llist_del_element(&DBG(back_trace), bt_item, cmpll);*/
	zend_llist_del_element(&DBG(back_trace), DBG(back_trace).tail->data, cmpll);
}

void dbg_op_array_ctor(zend_op_array *op_array) {
	DBG_TRACE(("dbg_op_array_ctor\n"));
}

void dbg_op_array_dtor(zend_op_array *op_array) {
	DBG_TRACE(("dbg_op_array_dtor\n"));
}

int dbg_api_no_check(int api_no) {
	return ((ZEND_EXTENSION_API_NO==api_no)?SUCCESS:FAILURE);
}


#ifdef COMPILE_DL_DBG
#define DBG_EXT ZEND_DLEXPORT 
#else
#define DBG_EXT
#endif

ext_compat_info dbg_compat_info = {
	2001050101,
	DBG_PROD_NAME,
	2,
	NULL
};

DBG_EXT zend_extension zend_extension_entry = {
	zend_ext_dbg_name,										/* name			*/
	DBG_API_FULL_VERSION_STR,								/* version		*/
	"Dmitri Dmitrienko",									/* author		*/
	"www.nusphere.com",	 								/* URL			*/
	"(C) 2000,2007",									/* copyright	*/
	dbg_startup, dbg_shutdown,
	dbg_activate, dbg_deactivate,
	NULL, 
	dbg_op_array_handler, dbg_statement_handler,
	dbg_fcall_begin_handler, dbg_fcall_end_handler,
	dbg_op_array_ctor, dbg_op_array_dtor,
	dbg_api_no_check,
	NULL,													/* reserved2	*/
	NULL,													/* reserved3	*/
	NULL,													/* reserved4	*/
	NULL,													/* reserved5	*/
	NULL,													/* reserved6	*/
	NULL,													/* reserved7	*/
	&dbg_compat_info,										/* reserved8	*/
	NULL,													/* handle		*/
	-1														/* resource_number	*/
};


/*************************
         
	DBG ZEND MODULE

*************************/

int cmp_ext(void *element1, void *element2) {
	return (element1==element2) ? 1:0;
}

PHP_MINIT_FUNCTION(dbg) {
	DBG_TRACE(("module init\n"));
#if defined(PHP_WIN32) && defined(DBG_DEBUG_MEM)
	_crtDbgFlag |= _CRTDBG_CHECK_ALWAYS_DF;
#endif
	ZEND_INIT_MODULE_GLOBALS(DBG, TS_ALLOC_CTOR(DBG), NULL);
	REGISTER_INI_ENTRIES();

/*	dbg_module_id = module_number; */
	if (!zend_get_extension(zend_ext_dbg_name)) {
		if (zend_register_extension(&zend_extension_entry,(DL_HANDLE)0)!=SUCCESS) {
			return FAILURE;
		}
	}
	return SUCCESS;
}

PHP_MSHUTDOWN_FUNCTION(dbg) {
	zend_extension *ext;

#if ZEND_EXTENSION_API_NO < 20010710
	TSRMLS_FETCH1_NOP(DBG);
#endif

	DBG_TRACE(("module shutdown\n"));

	ext = zend_get_extension(zend_ext_dbg_name);
	if (ext) {
		if (ext->shutdown) {
		    ext->shutdown(ext);
		}
		zend_llist_del_element(&zend_extensions, ext, cmp_ext);
	}
	UNREGISTER_INI_ENTRIES();
	return SUCCESS;
}

int chk_scan_post(char *name, int name_length TSRMLS_DC1(DBG)) {
	zval **data, **tmp;
	char *string_key;
	ulong num_key;
	int ret_val;

	TSRMLS_FETCH1_NOP(E);
	
	DBG_TRACE(("chk_scan_post '%s'\n", SON(name)));
	
	if (zend_hash_find(&EG(symbol_table), name, name_length+1, (void **) &data)!=FAILURE
		&& ((*data)->type==IS_ARRAY)) {
		zend_hash_internal_pointer_reset((*data)->value.ht);
		while (zend_hash_get_current_data((*data)->value.ht, (void **) &tmp) == SUCCESS) {
			if (zend_hash_get_current_key((*data)->value.ht, &string_key, &num_key, 0) == HASH_KEY_IS_STRING &&
				strcmp(string_key, DBGSESSVAR) == 0 &&
				(*tmp)->type == IS_STRING) {
					ret_val = parse_session_request((*tmp)->value.str.val, (*tmp)->value.str.len, '\0' TSRMLS_CC1(DBG));
					DBG_TRACE(("chk_scan_post -> ret='%d'\n", ret_val));
					if (ret_val) return ret_val;					
			}
			zend_hash_move_forward((*data)->value.ht);
		}
	}
	return 0;
}

int chk_session_request_post(TSRMLS_D2(DBG, S)) {
	int ret_val;
	ret_val = chk_scan_post("_POST", sizeof("_POST")-1 TSRMLS_CC1(DBG));
	if (!ret_val) ret_val = chk_scan_post("HTTP_POST_VARS", sizeof("HTTP_POST_VARS")-1 TSRMLS_CC1(DBG));
	if (!ret_val) ret_val = chk_scan_post("_COOKIE", sizeof("_COOKIE")-1 TSRMLS_CC1(DBG));
	if (!ret_val) ret_val = chk_scan_post("HTTP_COOKIE_VARS", sizeof("HTTP_COOKIE_VARS")-1 TSRMLS_CC1(DBG));
	return (ret_val);
}

PHP_RINIT_FUNCTION(dbg) {
	int isreq;
	TSRMLS_FETCH2_NOP(DBG, S);

	DBG_TRACE(("RINIT q='%s'\n", SON(SG(request_info).query_string)));

	if (!DBG(is_extension_activated) || DBG(is_failed_connection) || !DBG(cfgprm_enabled)) return SUCCESS;

	isreq = chk_session_request(SG(request_info).query_string, -1, '&' TSRMLS_CC1(DBG));
	if (isreq == 0) isreq = chk_session_request_post(TSRMLS_C2(DBG, S));
	if (isreq == 0) isreq = chk_session_request(SG(request_info).cookie_data, -1, ';' TSRMLS_CC1(DBG));
	DBG_TRACE(("RINIT isreq='%d'\n", isreq));
	if (isreq) {
		DBG(debugger_flags) |= DBGF_REQUESTFOUND;
		if (isreq > 0) {
			DBG_TRACE(("DBGF_REQUESTPENDING(%d)\n", isreq));
			if (!DBGF(DBGF_STARTED)) 
				DBG(debugger_flags) |= DBGF_REQUESTPENDING;
		} else {
			DBG(debugger_flags) |= DBGF_REJECTIONFOUND;
		}
		add_session_cookie(TSRMLS_C2(DBG, S));
	}
	return SUCCESS;
}

PHP_RSHUTDOWN_FUNCTION(dbg) {

#if ZEND_EXTENSION_API_NO < 20010710
	TSRMLS_FETCH2_NOP(DBG, E);
#endif

	DBG_TRACE(("PHP_RSHUTDOWN_FUNCTION\n"));
	DBG(debugger_flags) &= ~DBGF_WAITACK;

	dbg_flush_log(TSRMLS_C2(DBG, E));
	dbg_stop_session(TSRMLS_C2(DBG, E));

	module_cleanup(TSRMLS_C1(DBG));
	return SUCCESS;
}

PHP_MINFO_FUNCTION(dbg)	{
	int is_ext_ok = 0, is_text = 0;
	DBG_TRACE(("module info\n"));
#ifdef ZTS
	is_ext_ok = (is_dbg_ext_started && (DBG_globals_id!=0));
	if (is_ext_ok) {
		TSRMLS_FETCH1_NOP(DBG);
		is_ext_ok = DBG(is_extension_activated) != 0;
	}
#else
	is_ext_ok = is_dbg_ext_started &&  (DBG(is_extension_activated) != 0);
#endif	

/*
	4.2.3 and before
    4.3.0, 4.3.1 PG()
    4.3.2 and higher */
#if (PHP_MAJOR_VERSION > 4) || ((PHP_MAJOR_VERSION == 4) && (PHP_MINOR_VERSION > 3)) || ((PHP_MAJOR_VERSION == 4) && (PHP_MINOR_VERSION == 3) && (PHP_RELEASE_VERSION >= 2))
	is_text = sapi_module.phpinfo_as_text;
#elif ((PHP_MAJOR_VERSION == 4) && (PHP_MINOR_VERSION == 3) && (PHP_RELEASE_VERSION >= 0))
	is_text = PG(html_errors);
#else
	is_text = 0;
#endif

	if (!is_text) {
		php_printf("\n<table border=0 style=\"border: 1px solid #000000;\" cellpadding=3 cellspacing=0 width=600 bgcolor=#33CCFF align=\"center\">");
		php_printf("<tr valign=\"top\" align=\"center\"><td style=\"border: 0px none; vertical-align: top;\">");
		php_printf("<b><a href=\"http://www.nusphere.com\" style='color: #660880; background-color: #33CCFF'>" DBG_API_DESCRIPTION "</a></b></td></tr>");
		php_printf("</table><br>\n");
	}

	if (!is_ext_ok) {
		if (!is_text) {
			php_printf("<table border=1 cellpadding=0 cellspacing=0 width=600 bgcolor=red align=\"center\">\n");
			php_printf("<tr valign='middle' align='center'><td><font color=#ffff00>");
			php_printf("<b>PHP DBG ZExtension is not activated, yet.<br>Check configuration parameters in the php.ini file.</b>");
			php_printf("</font></td></tr>");
			php_printf("</table><br>\n");
		} else {
			php_printf("PHP DBG ZExtension is not activated, yet.\nCheck configuration parameters in the php.ini file.");
		}
	}

	php_info_print_table_start();
	php_info_print_table_row(2, "Version", DBG_API_FULL_VERSION_STR);
#ifdef COMPILE_DL_DBG
	php_info_print_table_row(2, "Linked", "as a shared library.");
#else
	php_info_print_table_row(2, "Linked", "statically.");
#endif


#ifdef HAVE_DBG_PROFILER
	{
	        int prof_enabled = 0;
		if (is_ext_ok) {
			TSRMLS_FETCH1_NOP(DBG);
			prof_enabled = DBG(cfgprm_profiler_enabled);
		}
		if (prof_enabled) {
			php_info_print_table_row(2, "Profiler", "compiled, enabled");
		} else {
			php_info_print_table_row(2, "Profiler", "compiled, disabled");
		}
	}
#else
	php_info_print_table_row(2, "Profiler", "not compiled");
#endif
	php_info_print_table_end();
	DISPLAY_INI_ENTRIES();
}

/* {{{ proto bool DebugBreak()
   Breaks execution and starts Debug Session */
PHP_FUNCTION(debugbreak){
	PROF_ENTER {
		int ok = 1;
		TSRMLS_FETCH2_NOP(DBG, S);

		DBG_TRACE(("debugbreak()\n"));
		if (ZEND_NUM_ARGS()!=0) {
			WRONG_PARAM_COUNT;
			ok = 0;
		} else
			ok = (DBG(is_extension_activated) && !DBG(is_failed_connection) && DBG(cfgprm_enabled));

		if (ok) {
			if (DBGF(DBGF_STARTED) == 0) {
				dbg_start_session(DBG_EMB TSRMLS_CC3(DBG, E, S));
			}
			ok = (DBGF(DBGF_STARTED) != 0);
		}
		
		if (ok) {
			dbg_send_std_action(DBGC_EMBEDDED_BREAK, 0 TSRMLS_CC2(DBG,E));			
			ok = !DBG(is_failed_connection);
		}

		PROF_LEAVE;
		if (!ok) RETURN_FALSE;
		RETURN_TRUE;
	}
}
/* }}} */

/* {{{ proto bool OutputDebugString(string logstr)
   Outputs a message into Debugging Log if Debug Session is started */
PHP_FUNCTION(outputdebugstring){
	pval *str;
	int ret_val;

	TSRMLS_FETCH1_NOP(DBG);
	if (ZEND_NUM_ARGS()!=1) {
		WRONG_PARAM_COUNT;
		RETURN_FALSE;
	}
	if (!DBG(is_extension_activated) || 
		DBG(is_failed_connection) || 
		!DBG(cfgprm_enabled) ||
		!DBGO(SOF_SEND_LOGS)) RETURN_FALSE;
	getParameters(ht, 1, &str);
	convert_to_string(str);
	ret_val = dbg_send_log(Z_STRVAL_P(str), Z_STRLEN_P(str), LT_ODS, NULL, 0, 0 TSRMLS_CC2(DBG, E));
	RETURN_LONG(ret_val);
}
/* }}} */

function_entry dbg_functions[] = {
	PHP_FE(debugbreak,								NULL)
	PHP_FE(outputdebugstring,						NULL)
#ifdef HAVE_DBG_PROFILER
	PHP_FE(dbg_get_profiler_results,				NULL)
#endif
	PHP_FE(dbg_get_all_module_names,				NULL)
	PHP_FE(dbg_get_module_name,						NULL)
	PHP_FE(dbg_get_all_contexts,					NULL)
	PHP_FE(dbg_get_context_name,					NULL)
	PHP_FE(dbg_get_all_source_lines,				NULL)
	PHP_FE(dbg_get_source_context,					NULL)
	{NULL, NULL, NULL}
};


zend_module_entry dbg_module_entry = {
#if ZEND_EXTENSION_API_NO >= 20010710
	STANDARD_MODULE_HEADER,
#endif
	php_module_dbg_name,
	dbg_functions,
	PHP_MINIT(dbg),
	PHP_MSHUTDOWN(dbg),
	PHP_RINIT(dbg),
	PHP_RSHUTDOWN(dbg),
	PHP_MINFO(dbg),
#if ZEND_EXTENSION_API_NO >= 20010710
	DBG_API_FULL_VERSION_STR, 
#endif
	STANDARD_MODULE_PROPERTIES
};

#ifdef COMPILE_DL_DBG
ZEND_GET_MODULE(dbg)
ZEND_DLEXPORT zend_extension_version_info extension_version_info = { ZEND_EXTENSION_API_NO, ZEND_VERSION, ZTS_V, ZEND_DEBUG };
#endif

/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
