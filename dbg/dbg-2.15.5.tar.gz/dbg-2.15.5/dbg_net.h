/***************************************************************************
                          dbg_net.h  -  description
                             -------------------
    begin                : Sun Sep 24 2000
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/

#ifndef _DBG_NET_H_
#define _DBG_NET_H_

#if PHP_WIN32 || defined WIN32
#include <windows.h>
#include <windef.h>
/* on Win32 int is always 32bit */
#define int_32t int
#define int_64t __int64
#endif

#ifndef int_32t
#if SIZEOF_INT == 4
# define int_32t int
#elif SIZEOF_LONG == 4
# define int_32t long
#elif SIZEOF_SHORT == 4
# define int_32t short
#endif
#endif

#ifndef int_64t
#if SIZEOF_LONG_LONG == 8
# define int_64t long long
#elif SIZEOF_OFF64_T == 8
# define int_64t off64_t
#elif SIZEOF_OFF_T == 8
# define int_64t off_t
#elif SIZEOF_INT == 8
# define int_64t int
#elif SIZEOF_LONG == 8
# define int_64t long
#elif SIZEOF_SHORT == 8
# define int_64t short
#endif
#endif


#ifndef int_32t
#error "could not compile without knowing a native type of 32bit integer for this platform (int_32t)"
#endif
#ifndef int_64t
#error "could not compile without knowing a native type of 64bit integer for this platform (int_64t)"
#endif

#define DBG_API_MAJOR_VERSION			0x02
#define DBG_API_MINOR_VERSION			0x15
#define DBG_API_RELEASE_STAGE			0x3   /* 0-dev, 1-beta, 2-prerelease, 3-release */
#define DBG_API_MINOR_SUB_VERSION		0x5

#define DBG_API_MAJOR_VERSION_STR		"2"
#define DBG_API_MINOR_VERSION_STR		"15"
#define DBG_API_RELEASE_STAGE_STR		""
#define DBG_API_MINOR_SUB_VERSION_STR	".5"

#define DBG_API_MAJOR_VERSION_STR_L		L"2"
#define DBG_API_MINOR_VERSION_STR_L		L"15"
#define DBG_API_RELEASE_STAGE_STR_L		L""
#define DBG_API_MINOR_SUB_VERSION_STR_L	L".5"


#define DBG_API_FULL_VERSION (DBG_API_MAJOR_VERSION << 8 | DBG_API_MINOR_VERSION)
#define DBG_API_FULL_VERSION_STR DBG_API_MAJOR_VERSION_STR "." DBG_API_MINOR_VERSION_STR DBG_API_RELEASE_STAGE_STR DBG_API_MINOR_SUB_VERSION_STR
#define DBG_API_FULL_VERSION_STR_L DBG_API_MAJOR_VERSION_STR_L L"." DBG_API_MINOR_VERSION_STR_L DBG_API_RELEASE_STAGE_STR_L DBG_API_MINOR_SUB_VERSION_STR_L

#define DBG_PROD_NAME			 "DBG php debugger"
#define DBG_PROD_NAME_L			L"DBG php debugger"
#define DBG_API_DESCRIPTION		DBG_PROD_NAME    ", version " DBG_API_FULL_VERSION_STR    ", Copyright 2001, 2007, Dmitri Dmitrienko, www.nusphere.com"
#define DBG_API_DESCRIPTION_L	DBG_PROD_NAME_L L", version " DBG_API_FULL_VERSION_STR_L L", Copyright 2001, 2007, Dmitri Dmitrienko, www.nusphere.com"

#define DEFAULT_PORT 7869
#define DEFAULT_PORT_STR "7869"

#define DBGSESSVAR "DBGSESSID"

typedef enum tagSESSTYPE {
    DBG_COMPAT		= 0x0001,
    DBG_JIT			= 0x0002,
    DBG_REQ			= 0x0003,
	DBG_EMB			= 0x0004,
} SESSTYPE;


#define dbgint int_32t	/* this must be 32-bit signed integer only! */
#define dbgint64 int_64t /* this must be 64-bit signed integer only! */

#ifdef HAVE_SOCKLEN_T
	#define NET_SIZE_T socklen_t
#else
	#if defined(AIX) && (AIX >= 42)
	#define NET_SIZE_T size_t
	#endif

	#if defined(SEQUENT) && (SEQUENT >= 44)
	#define NET_SIZE_T size_t
	#endif

	#if defined(__GLIBC__) && (__GLIBC__ > 2 || (__GLIBC__ == 2 && __GLIBC_MINOR__ > 0))
	#define NET_SIZE_T socklen_t
	#endif
	#if (defined(__FreeBSD_version) && (__FreeBSD_version >= 400000))
	#define NET_SIZE_T socklen_t
	#endif

	#if defined(SVR4) || defined(UW) || defined(OS390)
	#define NET_SIZE_T size_t
	#endif
#endif

#ifndef NET_SIZE_T
#define NET_SIZE_T int
#endif

#if PHP_WIN32 || defined WIN32
  #ifdef DBG_EXPORTS
    #define DBGAPI __declspec(dllexport)
  #else
    #ifdef DBG_IMPORTS
      #define DBGAPI __declspec(dllimport)
    #endif
  #endif
#endif

#ifndef DBGAPI
  #define DBGAPI
#endif

#ifndef MAXINT32T
#define MAXINT32T (0x7FFFFFFF)
#endif


#if PHP_WIN32 || defined WIN32
  #define SCLOSE(a) closesocket(a)
#else
  #define SCLOSE(a) close(a)
#endif

#define SSEND(a,b,c) send(a,b,c,0)
#define SREAD(a,b,c) recv(a,b,c,0)

#if (PHP_WIN32 || defined WIN32) && !defined(vsnprintf)
  #define vsnprintf _vsnprintf
#endif


/*********** C O M M A N D   I N T E R F A C E ******************************************/


/* debugger_flags */
/* state: */
#define DBGF_STARTED		0x0001		/* debugger has been started */
#define DBGF_FINISHED		0x0002		/* DBGC_END notification has been sent */		
#define DBGF_WAITACK		0x0004		/* awaiting replay|request */
#define	DBGF_UNSYNC			0x0008		/* protocol has been unsynchronized */
#define DBGF_REQUESTPENDING	0x0010		/* Debug session request pending */
#define DBGF_REQUESTFOUND	0x0020		/* Debug session request found */
#define DBGF_REJECTIONFOUND 0x0040      /* DBGSESSID=-1 found - session rejection */
/* execution:  */
#define DBGF_STEPINTO		0x0100		/* break on next script instruction */
#define DBGF_STEPOVER		0x0200		/* break on next script instruction on the same context */
#define DBGF_STEPOUT		0x0400		/* break on next script instruction on the outer context */
#define DBGF_ABORT			0x0800		/* stop instruction passed */

/* standard header */
/*  WARNING! All numbers are in TCP/IP network byte order (which is big-endian) */
#define DBG_SYNC			0x00005953
#define MAX_PACKET_SIZE		10*1024*1024		/* size of packet would never exceed 1M */
#define CHUNKSIZE			128*1024			/* data is transmitted by relatively small portions which size is CHUNKSIZE */

typedef struct {
	dbgint sync;
	dbgint cmd;					/* command one of DBGC_xxxx, DBGR_xxxx, DBGA_xxxx */
	dbgint flags;				/* combination of DBGF_xxxx */
	dbgint bodysize;			/* size of the rest packet body (pack of all frames) */
} dbg_header_struct;

typedef int framename;

/* packet frame structure. All packets must have a header, 
  also they may have a body that consists of one ore more frames packed all together */

typedef struct {
	framename name;
	dbgint size;				/* size of pure data */
} dbg_frame;

#define FRAME_DATA_PTR(type,frame) ((type*)((char*)frame+sizeof(dbg_frame)))

/*
  PHP ENGINE to DEBUGGER CLIENT WAY:
*/

/* php-engine commands/events */
#define DBGC_REPLY			0x0000		/* reply to previous DBGA_REQUEST request */
#define DBGC_STARTUP		0x0001		/* script startup */
#define	DBGC_END			0x0002		/* script done */
#define	DBGC_BREAKPOINT		0x0003		/* user definded breakpoint occured */
#define	DBGC_STEPINTO_DONE	0x0004		/* step to the next statement is completed */
#define	DBGC_STEPOVER_DONE	0x0005		/* step to the next statement is completed */
#define	DBGC_STEPOUT_DONE	0x0006		/* step to the next statement is completed */
#define	DBGC_EMBEDDED_BREAK	0x0007		/* breakpoint caused by DebugBreak() function */
#define	DBGC_ERROR			0x0010		/* error occured */
#define	DBGC_LOG			0x0011		/* logging support */
#define DBGC_SID			0x0012		/* send SID */
#define DBGC_PAUSE			0x0013		/* pause current session as soon as possible */

#define	FRAME_STACK			100000		/* "call:stack" - e.g. backtrace */
#define FRAME_SOURCE		100100		/* source text */
#define FRAME_SRC_TREE		100200		/* tree of source files */
#define FRAME_RAWDATA		100300		/* raw data or string */
#define FRAME_ERROR			100400		/* error notification */
#define FRAME_EVAL			100500		/* evaluating/watching */
#define FRAME_BPS			100600		/* set/remove breakpoint */
#define FRAME_BPL			100700		/* breakpoint(s) request = get the list */
#define FRAME_VER			100800		/* version request */
#define FRAME_SID			100900		/* session id info*/
#define FRAME_SRCLINESINFO	101000		/* source lines info */
#define FRAME_SRCCTXINFO	101100		/* source contexts info */
#define FRAME_LOG			101200		/* logging */
#define FRAME_PROF			101300		/* profiler */
#define FRAME_PROF_C		101400		/* profiler counter/accuracy */
#define FRAME_SET_OPT		101500		/* set/update options */



#define CURLOC_SCOPE_ID	1		/* nested locations are 2,3... and so on in backward order, so 2 represents most out-standing stack context*/
#define GLOBAL_SCOPE_ID	-1		/* it is global context, not stacked */

/* responces: */

typedef struct tag_dbg_version_body {			/*FRAME_VER*/
	dbgint major_version;
	dbgint minor_version;
	dbgint idescription;
} dbg_version_body;

typedef struct tag_dbg_sid_body {				/*FRAME_SID*/
	dbgint isid;				/* session ID */
	dbgint sesstype;
} dbg_sid_body;

typedef struct tag_dbg_stack_body {				/* FRAME_STACK */
	dbgint line_no;
	dbgint mod_no;
	dbgint scope_id;			/*-1 means current location, 0 never used, +1 first depth*/
	dbgint idescr;				/*ID of description string*/
} dbg_stack_body;

typedef struct tag_dbg_source_body {			/*FRAME_SOURCE*/
	dbgint mod_no;		
	dbgint from_filepos;		/* file offset */
	dbgint error;				/* 0 = ok */	
	dbgint full_size;
	dbgint imod_name;			/* ID of mod_name string */
	dbgint itext;				/* ID of text rawdata */
} dbg_source_body;

typedef struct tag_dbg_src_tree_body {			/* FRAME_SRC_TREE */
	dbgint rsrv1;
	dbgint rsrv2;		/* NOT USED */
	dbgint mod_no;
	dbgint imod_name;
} dbg_src_tree_body;

typedef struct tag_dbg_rawdata_body {			/* FRAME_RAWDATA */
	dbgint rawid;
	dbgint datasize;
} dbg_rawdata_body;

typedef struct tag_dbg_error_body {				/* FRAME_ERROR */
	dbgint type;				/* type of error */
	dbgint imessage;			/* ID of error message */
} dbg_error_body;

typedef struct tag_dbg_eval_body {				/*FRAME_EVAL*/
	dbgint istr;
	dbgint iresult;	
	dbgint ierror;	
} dbg_eval_body;

typedef struct tag_dbg_bpl_body {				/* FRAME_BPL */
	dbgint mod_no;
	dbgint line_no;
	dbgint imod_name;
	dbgint state;					
	dbgint istemp;
	dbgint hitcount;
	dbgint skiphits;
	dbgint icondition;
	dbgint bp_no;
	dbgint isunderhit;
} dbg_bpl_body;

typedef struct tag_dbg_srclinesinfo_body {		/* FRAME_SRCLINESINFO */
	dbgint mod_no;
	dbgint start_line_no;
	dbgint lines_count;
	dbgint ctx_id;
} dbg_srclinesinfo_body;

typedef struct tag_dbg_srcctxinfo_body {		/* FRAME_SRCCTXINFO */
	dbgint mod_no;
	dbgint ctx_id;
	dbgint ifunction_name;
} dbg_srcctxinfo_body;

typedef struct tag_dbg_log_body {				/* FRAME_LOG */
	dbgint ilog;
	dbgint type;
	dbgint mod_no;
	dbgint line_no;
	dbgint imod_name;
	dbgint ext_info;
} dbg_log_body;

typedef struct tag_dbg_prof_body {				/* FRAME_PROF */
	dbgint mod_no;
	dbgint line_no;
	dbgint hit_count;
	dbgint tm_min_lo;
	dbgint tm_min_hi;
	dbgint tm_max_lo;
	dbgint tm_max_hi;
	dbgint tm_sum_lo;
	dbgint tm_sum_hi;
} dbg_prof_body;

typedef struct tag_dbg_prof_c_body {			/* FRAME_PROF_C */
	dbgint tm_freq_lo;
	dbgint tm_freq_hi;
	dbgint tm_diff_min;
	dbgint tm_diff_max;
	dbgint tm_diff_m;
} dbg_prof_c_body;



/* requests: */


typedef struct tag_dbg_source_request {			/*FRAME_SOURCE*/
	dbgint mod_no;
	dbgint from_filepos;		/* file offset */
} dbg_source_request;

/* FRAME_STACK, FRAME_VER and FRAME_SRC_TREE must be requested without any additional parameters (by frame name)*/
/* FRAME_ERROR can not be rerequested at all */

typedef struct tag_dbg_bpl_request {			/* FRAME_BPL */
	dbgint bp_no;
} dbg_bpl_request;

typedef struct tag_dbg_eval_request {			/* FRAME_EVAL */
	dbgint istr;
	dbgint scope_id;
} dbg_eval_request;

typedef struct tag_dbg_bpl_body dbg_bps_request;/* FRAME_BPS */

typedef struct tag_dbg_srclinesinfo_request {	/* FRAME_SRCLINESINFO */
	dbgint mod_no;
} dbg_srclinesinfo_request;

typedef struct tag_dbg_srcctxinfo_request {		/* FRAME_SRCCTXINFO */
	dbgint mod_no;
} dbg_srcctxinfo_request;

typedef struct tag_dbg_prof_request {			/* FRAME_PROF */
	dbgint mod_no;
} dbg_prof_request;

typedef struct tag_dbg_prof_c_request {			/* FRAME_PROF_C */
	dbgint test_loops;
} dbg_prof_c_request;

typedef struct tag_dbg_set_options_request {	/* FRAME_SET_OPT */
	dbgint opt_flags;			/* OF_xxxx */
} dbg_set_options_request;

/*
  DEBUGGER CLIENT to DBG SERVER WAY:
*/

/* debugger client makes acknowledgement */
#define DBGA_CONTINUE		0x8001		/* php should continue run */
#define DBGA_STOP			0x8002
#define DBGA_STEPINTO		0x8003
#define DBGA_STEPOVER		0x8004
#define DBGA_STEPOUT		0x8005
#define DBGA_IGNORE			0x8006
#define DBGA_REQUEST		0x8010		/* debugger client requests some information from PHP engine */


/*********** S O F T W A R E   I N T E R F A C E ******************************************/


/* buffer to hold frames */
typedef struct {
	dbg_frame *buf;
	int limit;  /* size of buffer in memory */
	int size;   /* actual data size in the buffer */
	int lastrawid;
} dbg_packet;

/* Let packet buffer grows by 128byte-inctrements. 
   It reduces reallocation frequency if we add a lot of small frames to one packet. */

#define PACKET_LIMIT_ROUND(s) \
	((s+127) & ~127) /* round to nearest upper value 128*n */

#define ALIGN8(s) \
	((s+7) & ~7) /* round to nearest upper value 8*n */

#ifdef __cplusplus
extern "C"{
#endif

DBGAPI int dbg_packet_new(dbg_packet *pack);
DBGAPI void dbg_packet_free(dbg_packet *pack);
DBGAPI void dbg_packet_clear(dbg_packet *pack);
DBGAPI int dbg_packet_add_frame(dbg_packet *pack, framename frname, void *data, int datasize);
DBGAPI int dbg_packet_add_rawdata(dbg_packet *pack, const char *data, int datasize);
DBGAPI int dbg_packet_add_stringlen(dbg_packet *pack, const char *str, int len);

DBGAPI dbg_frame* dbg_packet_firstframe(dbg_packet *pack);
DBGAPI dbg_frame* dbg_packet_nextframe(dbg_packet *pack, dbg_frame *frame);
DBGAPI dbg_frame* dbg_packet_findfirstframe(dbg_packet *pack, framename frname);
DBGAPI dbg_frame* dbg_packet_findnextframe(dbg_packet *pack, framename frname, dbg_frame *frame);
DBGAPI int dbg_packet_findrawdata(dbg_packet *pack, int rawid, char **data, int *datasize);

DBGAPI int dbg_packet_recv(dbg_header_struct *hdr, dbg_packet *pack, int socket, int timeoutsec);
DBGAPI int dbg_packet_send(int cmd , dbg_packet *pack, int socket, int flags);

#define dbg_packet_findstring(pack,rawid,data,datasize) dbg_packet_findrawdata(pack,rawid,data,datasize)
#define dbg_packet_add_string(pack,str) ((str) ? (dbg_packet_add_stringlen(pack,str,strlen(str))) : 0)


/*** TRACING/DEBUGGING ***/

void SysError(const char *msg,...);
#define SON(s) ((s) ? (s) : ("(null)"))

#ifdef DBG_DEBUG
void _dbg_trace(const char *str,...);
#define DBG_TRACE(a) _dbg_trace a
#else
#define DBG_TRACE(a)
#endif


#ifdef __cplusplus
}
#endif

#endif
