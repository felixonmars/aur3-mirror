/***************************************************************************
                          dbg_ser.h  -  description
                             -------------------
    begin                : Sun Sep 24 2000
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 1.01 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://dd.cron.ru/license
 ***************************************************************************/


#ifndef _DBG_SER_H_
#define _DBG_SER_H_

#include "zend.h"

#define DSER_CORR_REF  0x001
#define DSER_ADD_DSIGN 0x002
#define DSER_DEMANGLE  0x004


void dbg_serialize_zval(zval *data, zval *buf, unsigned int Flags TSRMLS_DC2(DBG, E));
void dbg_serialize_hash(HashTable *ht, zval *zthis, zval *buf, unsigned int Flags TSRMLS_DC2(DBG, E));


#endif
