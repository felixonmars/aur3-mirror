/***************************************************************************
                          dbg_prof.h  -  description
                             --------------------
    begin                : Sun Sep 24 2000
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/

#ifndef _DBG_PROF_H_
#define _DBG_PROF_H_

#include "php.h"

#ifdef HAVE_DBG_PROFILER

#if PROF_TRACING
#define PROF_TRACE(a) DBG_TRACE(a)
#else
#define PROF_TRACE(a)
#endif

#define PROF_ENTER \
	dbgint64 snapped_time = dbgTimeTicks(); \
	PROF_TRACE(("snapped=%I64d\n",snapped_time));

#define PROF_LEAVE \
	DBG(l_time) += dbgTimeTicks() - snapped_time; \
	PROF_TRACE(("lost=%I64d\n",DBG(l_time)));


#define PROF_STORE_TIME(func)					\
	if (DBG(e_time)!=0) {						\
		func((snapped_time - DBG(e_time)) - DBG(l_time) TSRMLS_CC1(DBG));	\
		PROF_TRACE(("save=%I64d\n",(snapped_time - DBG(e_time)) - DBG(l_time))); \
	}											\
	DBG(e_time) = snapped_time;					\
	DBG(l_time) = 0;

#define PROF_DOUBLE_SNAP(a)	{	\
	dbgint64 t = dbgTimeTicks();	\
	a = dbgTimeTicks() - t;		\
}								\

#define PROF_PERF_FREQ(a)	a=dbgTimeFreq()

inline dbgint64 dbgTimeTicks();
inline dbgint64 dbgTimeFreq();

#else

#define PROF_ENTER
#define PROF_LEAVE
#define PROF_STORE_TIME(func)
#define PROF_DOUBLE_SNAP(a)	 a=0
#define PROF_PERF_FREQ(a) a=1

#endif

#endif
