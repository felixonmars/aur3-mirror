/***************************************************************************
                          dbg_net.c  -  description
                             -------------------
    begin                : Sun Sep 24 2000
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef DBG_USE_STDALLOCA
  #define _MALLOC malloc
  #define _FREE free
#else
  #include "php.h"
  #include "php_network.h"
  #include "zend.h"
  #include "zend_alloc.h"
  #define _MALLOC emalloc
  #define _FREE efree
#endif



#if PHP_WIN32 || defined WIN32
  #if defined(ZEND_ENGINE_2) || defined(DBG_LISTENER)
  #include <windows.h>
  #include <winsock2.h>
  #else
  #include <winsock.h>
  #endif
#else
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>
#endif


#include "dbg_net.h"
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C"{
#endif

DBGAPI int dbg_packet_new(dbg_packet *pack) {
	memset(pack,0,sizeof(dbg_packet));
	return 1;
}

DBGAPI void dbg_packet_free(dbg_packet *pack) {
	if (pack->buf) _FREE(pack->buf);
	memset(pack,0,sizeof(dbg_packet));
}

DBGAPI void dbg_packet_clear(dbg_packet *pack) {
	pack->size = 0;
	pack->lastrawid = 0;
}

int dbg_packet_update_limit(dbg_packet *pack, int space) {
	int alimit;
	void *p;
	
	if (!pack->limit) {
		alimit = PACKET_LIMIT_ROUND(space);
		pack->size = 0;
		pack->buf = _MALLOC(alimit);
		if (!pack->buf) return 0;
		pack->limit = alimit;
	} else if (pack->limit < (pack->size + space)) {
		alimit = PACKET_LIMIT_ROUND(pack->size + space);
		p = _MALLOC(alimit);
		if (!p) return 0;
		memcpy(p, pack->buf, pack->size);
		_FREE(pack->buf);
		pack->buf = p;
		pack->limit = alimit;
	}
	return 1;
}

DBGAPI int dbg_packet_add_frame(dbg_packet *pack, framename frname, void *data, int datasize) {
	dbg_frame *p;
	int asize;

	datasize = ALIGN8(datasize);
	asize = datasize + sizeof(dbg_frame);
	if (!dbg_packet_update_limit(pack, asize)) {
		return 0;
	}
	p = (dbg_frame *) ((char *) (pack->buf) + pack->size);
	p->size = datasize;
	p->name = frname;
	
	if (data) memcpy(FRAME_DATA_PTR(char,p), data, datasize);
	pack->size += asize;
	return FRAME_DATA_PTR(char,p) - (char*)pack->buf;
}

int dbg_sock_read(char *buf, int bufsize, int socket, int timeoutms) {
	fd_set rset, eset;
	struct timeval timeout;
	int ret_val;

	if (socket <= 0) {
		return 0;
	}
	
	FD_ZERO(&rset);
	FD_SET((unsigned int)socket, &rset);
	FD_ZERO(&eset);
	FD_SET((unsigned int)socket, &eset);
	if (timeoutms >= 0) {
		timeout.tv_sec = timeoutms / 1000;
		timeout.tv_usec = (timeoutms>1000) ? 0 : timeoutms * 1000;
	} else {
		timeout.tv_sec = 0;
		timeout.tv_usec = 0;
	}
	
	do {
		ret_val = select(socket + 1, &rset, NULL, &eset, &timeout);
	} while (ret_val == -1 && errno == EINTR);
	
	if (ret_val != 1 || !FD_ISSET((unsigned int)socket, &rset)) {	
		return ((ret_val < 0) ? (-1) : (0));
	}
	
	if (ret_val >= 0) {
		ret_val = SREAD(socket, buf, bufsize);
		if (ret_val == 0) return (-1); /* most probably peer has been terminated */
	}
	return (ret_val);
}

DBGAPI dbg_frame *dbg_packet_firstframe(dbg_packet *pack) {
	return (pack->size ? (pack->buf):(NULL));
}

DBGAPI dbg_frame *dbg_packet_nextframe(dbg_packet *pack, dbg_frame *frame) {
	dbg_frame *p;
	int s;

#ifdef _DEBUG
	int frsize;
	char is_eq;

	p = pack->buf;
	s = pack->size;
	while (s >= sizeof(dbg_frame)) {
		frsize = p->size + sizeof(dbg_frame);
		is_eq = (p == frame);
		p = (dbg_frame *)((char *)p + frsize);
		s -= frsize;
		if (is_eq) {
			if (s < sizeof(dbg_frame)) return NULL;
			return p;
		}
	}
	return NULL;
#else
	p = frame;
	s = pack->size - ((char*)frame + frame->size + sizeof(dbg_frame) - (char*)pack->buf);
	if (s >= sizeof(dbg_frame)) {
		p = (dbg_frame *)((char *) p + p->size + sizeof(dbg_frame));
		return p;
	}
	return NULL;
#endif
}

DBGAPI dbg_frame* dbg_packet_findfirstframe(dbg_packet *pack, framename frname) {
	dbg_frame *p;
	int s,frsize;

	s = pack->size;
	p = pack->buf;
	while (s >= sizeof(dbg_frame)) {
		if (p->name == frname) {
			return p;
		}
		frsize = p->size + sizeof(dbg_frame);
		p =(dbg_frame *)((char *)p + frsize);
		s -= frsize;
	}
	return NULL;
}

DBGAPI dbg_frame* dbg_packet_findnextframe(dbg_packet *pack, framename frname, dbg_frame *frame) {
	dbg_frame *p;
	int s,frsize;

	p = dbg_packet_nextframe(pack, frame);

	s = (p) ? pack->size - ((char*)p - (char*)pack->buf) : 0;
	while (s >= sizeof(dbg_frame)) {
		if (p->name == frname) {
			return p;
		}
		frsize = p->size + sizeof(dbg_frame);
		p = (dbg_frame *) ((char *)p + frsize);
		s -= frsize;
	}
	return NULL;
}

DBGAPI int dbg_packet_send(int cmd , dbg_packet *pack, int socket, int flags) {
	dbg_header_struct *packetbuf;
	dbg_frame *p;
	int packsize, frsize, *v, i;
	int ret_val, sz, tosend, chunksz, sentsz, icnt;
	char *pchunk;

	if (socket <= 0) {
		return -1;
	}	
	packsize = sizeof(dbg_header_struct) + ((pack!=NULL)? pack->size:0);
	if (!(packetbuf = _MALLOC(packsize))) {
		return 0;
	}
	packetbuf->sync = htonl(DBG_SYNC);
	packetbuf->cmd = htonl(cmd);
	packetbuf->flags = htonl(flags);
	packetbuf->bodysize = htonl(pack!=NULL?pack->size:0);
	if (pack && pack->size) {
		p = (dbg_frame*)((char *)packetbuf + sizeof(dbg_header_struct));
		sz = pack->size;
		memcpy(p, pack->buf, pack->size); /* copy data */
		while (sz > 0) {
			if (p->name != FRAME_RAWDATA) { 
				v = (int *)((char *)p + sizeof(*p));
				icnt = p->size / (int)sizeof(*v);
				for (i=0; i < icnt; i++) {
					*v = htonl(*v);
					v++;
				}
			} else {
				dbg_rawdata_body *body = FRAME_DATA_PTR(dbg_rawdata_body, p);
				body->datasize = htonl(body->datasize);
				body->rawid = htonl(body->rawid);
			}
			frsize = p->size + sizeof(dbg_frame);
			p->size = htonl(p->size);
			p->name = htonl(p->name);
			p = (dbg_frame *)((char *)p + frsize);
			sz-=frsize;
		}
	}
	tosend = packsize;
	pchunk = (char *)packetbuf;
	sentsz = 0;
	ret_val = 0;
	while  (tosend > 0) {
		chunksz = (tosend > CHUNKSIZE) ? CHUNKSIZE:tosend;
		ret_val = SSEND(socket, pchunk, chunksz);
		if (ret_val <= 0) break;
		sentsz+=ret_val;
		pchunk+=ret_val;
		tosend-=ret_val;
	}	
	_FREE(packetbuf);
	if (ret_val < 0) return -1;
	if (sentsz == packsize) return sentsz;
	return 0;
}

int dbg_packet_recv_body(dbg_packet *pack, int bodysize, int socket, int timeoutms) {
	dbg_frame *p;
	int *v, i;
	int ret_val = 0;
	int restsize, chunksz, recvsz, is_first, icnt;
	int frsize;
	char *pchunk;

	if (!dbg_packet_update_limit(pack, bodysize)) {
		return 0;
	}
	pchunk = (char *) (pack->buf) + pack->size;
	restsize = bodysize;
	recvsz = 0;
	is_first = 1;
	while (restsize > 0) {
		if (is_first) {
			chunksz = (restsize>(CHUNKSIZE-sizeof(dbg_header_struct))) ? CHUNKSIZE-sizeof(dbg_header_struct):restsize;
			is_first = 0;
		} 
		else {
			chunksz = (restsize>CHUNKSIZE) ? CHUNKSIZE:restsize;
		}
		ret_val = dbg_sock_read(pchunk, chunksz, socket, timeoutms);
		if (ret_val < 0 || (recvsz == 0 && ret_val == 0)) 
			break;
		restsize -= ret_val;
		recvsz += ret_val;
		pchunk += ret_val;
	}
	if (recvsz!=bodysize) {
		dbg_packet_clear(pack);
		if (ret_val < 0) return -1;
		return 0;
	}
	p = (dbg_frame *)((char *) (pack->buf) + pack->size);
	restsize = bodysize;
	while (restsize > 0) {
		p->size = ntohl(p->size);
		p->name = ntohl(p->name);
		if (p->name != FRAME_RAWDATA) { /* make all ints back system-depended Big- or Little- Endian*/
			v = (int *)((char *)p + sizeof(*p));
			icnt = p->size/(int)sizeof(*v);
			for (i=0; i < icnt; i++) {
				*v = ntohl(*v);
				v++;
			}
		} else {
			dbg_rawdata_body *body = FRAME_DATA_PTR(dbg_rawdata_body,p);
			body->datasize = ntohl(body->datasize);
			body->rawid = ntohl(body->rawid);
		}
		frsize = p->size + (int)sizeof(dbg_frame);
		if ((p->size > MAX_PACKET_SIZE) || (frsize > restsize)) {
			dbg_packet_clear(pack);
			return 0;
		}
		p = (dbg_frame *)((char *)p + frsize);
		restsize -= frsize;
		if (restsize < 0) {
			dbg_packet_clear(pack);
			return 0;
		}
	}
	pack->size += bodysize;
	return bodysize;
}

DBGAPI int dbg_packet_recv(dbg_header_struct *hdr, dbg_packet *pack, int socket, int timeoutms) {
	int ret_val;

	if (!pack || !hdr) return 0;
	dbg_packet_clear(pack);
	ret_val = dbg_sock_read((char *) hdr, sizeof(dbg_header_struct), socket, timeoutms);
	if ((ret_val != sizeof(dbg_header_struct)) || 
		(hdr->sync != (int)ntohl(DBG_SYNC))) {		
		memset(hdr,0,sizeof(dbg_header_struct));
		if (ret_val < 0) return -1;
		return 0;		
	}
	
	hdr->bodysize = ntohl(hdr->bodysize);
	hdr->cmd = ntohl(hdr->cmd);
	hdr->flags = ntohl(hdr->flags);
	
	if ((hdr->bodysize<0) || (hdr->bodysize > MAX_PACKET_SIZE)) {
		memset(hdr,0,sizeof(dbg_header_struct));
		return 0;
	}
	if (hdr->bodysize) {
		if (!dbg_packet_recv_body(pack, hdr->bodysize, socket, timeoutms)) {
			memset(hdr,0,sizeof(dbg_header_struct));
			return 0;
		}
	}
	return hdr->bodysize + sizeof(dbg_header_struct);
}


int add_rawdata(dbg_packet *pack, const char *data, int datasize, char **presult) {
	dbg_rawdata_body *body;
	char *p;
	int id, bodyofs;
	
	if (presult) *presult = NULL;
	if (!data && datasize) return 0;
	bodyofs = dbg_packet_add_frame(pack, FRAME_RAWDATA, NULL, datasize + sizeof(dbg_rawdata_body));
	if (!bodyofs) {
		return 0;
	}
	id = ++pack->lastrawid;
	body = (dbg_rawdata_body *)((char *)pack->buf + bodyofs);
	body->rawid = id;
	body->datasize = datasize;
	p = (char*)body + sizeof(dbg_rawdata_body);
	if (presult) *presult = p;
	if (data) memcpy(p, data, datasize);

	return id;
}


DBGAPI int dbg_packet_add_rawdata(dbg_packet *pack, const char *data, int datasize) {
	return add_rawdata(pack, data, datasize, NULL);
}

DBGAPI int dbg_packet_add_stringlen(dbg_packet *pack, const char *str, int len) {
	char *rslt;
	int ret_val;

	if (len == 0) return 0;
	ret_val = add_rawdata(pack, str, len+1, &rslt);
	if (rslt && ret_val) {
		rslt[len]='\0';
	}
	return ret_val;
}


DBGAPI int dbg_packet_findrawdata(dbg_packet *pack, int rawid, char **data, int *datasize) {
	dbg_frame *fr;
	dbg_rawdata_body *body;

	*datasize = 0;
	*data = NULL;
	if (rawid <= 0) return 0;
	fr = dbg_packet_findfirstframe(pack, FRAME_RAWDATA);
	while (fr) {
		body = FRAME_DATA_PTR(dbg_rawdata_body,fr);
		if ((int)body->rawid == rawid) {
			*data = (char*)body + sizeof(dbg_rawdata_body);
			*datasize = body->datasize;
			return sizeof(dbg_rawdata_body) + (*datasize);
		}
		fr = dbg_packet_findnextframe(pack, FRAME_RAWDATA, fr);
	}
	return 0;
}






/********************************\
         
	DEBUGGING/TRACING\FACILITY

\********************************/

#if defined(DBG_TRACEFILE)
#ifdef WIN32
#define OPENLOG(f) f = fopen(DBG_TRACEFILE,"a+")
#else
#define OPENLOG(f) f = fopen(DBG_TRACEFILE,"a")
#endif

#define LOG(msg) {						\
	FILE *log;							\
	OPENLOG(log);						\
	if (log) {							\
		fprintf(log, "%s", msg);		\
		fclose(log);					\
	}									\
}
#else
#define LOG(msg)
#endif


void SysError(const char *msg,...) {
	va_list args;
	char buf[512];
	
    va_start(args, msg);
    vsnprintf(buf, sizeof(buf)-1, msg, args);
    va_end(args);

	fprintf(stderr, buf);

#ifdef WIN32
	{
		int err;
		err = WSAGetLastError();
		if (err) {
			int i;
			FormatMessage( 
				FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				err,
				MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), /* Default language */
				buf,
				sizeof(buf),
				NULL 
			);
			i=strlen(buf);
			while (--i>0 && buf[i]<32);
			buf[i+1] = 0;
			fprintf(stderr, "\nOSERR:%d:\"%s\"\n", err, buf);
			DBG_TRACE(("OSERR: %d \"%s\"\n", err, buf));
		}
	}
#else
	if (errno) {
		fprintf(stderr, "\nOSERR:%d:\"%s\"\n", errno, strerror(errno));
		DBG_TRACE(("OSERR: %d \"%s\"\n", errno, buf));
	}
#endif
}

/************************

		TRACE

*************************/


#ifdef DBG_DEBUG
void _dbg_trace(const char *str,...) {
	va_list args;
	char buf[1024];

	if (!str) return;
	va_start(args, str);	
	vsnprintf(buf, sizeof(buf)-1, str, args);
#ifdef PHP_WIN32
	OutputDebugString("[DBG] ");
	OutputDebugString(buf);
#endif
	LOG(buf);
	fprintf(stderr, "[DBG] ");
	fprintf(stderr, buf);
	va_end(args);
}
#endif

#ifdef __cplusplus
}
#endif
