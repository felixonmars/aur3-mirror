/***************************************************************************
                          dbg_cmd.h  -  description
                             -------------------
    begin                : Sun Sep 24 2000
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/

#ifndef _DBG_CMD_H_
#define _DBG_CMD_H_

#include "php.h"
#include "php_dbg.h"
#include "dbg_net.h"

inline mod_item* dbg_mod_item_by_no(int mod_no TSRMLS_DC1(DBG));
inline mod_item* dbg_findmodule(const char *mod_name, int addifnotfound TSRMLS_DC1(DBG));

int dbg_start_session(SESSTYPE sesstype TSRMLS_DC3(DBG, E, S));
int dbg_stop_session(TSRMLS_D2(DBG, E));
inline int dbg_checkpausereq(TSRMLS_D1(DBG));

inline int dbg_send_std_action(int cmd, int hitcnt TSRMLS_DC2(DBG,E));
inline int dbg_send_log(char *log, int len, int type, const char *mod_name, const int line_no, int ext_info TSRMLS_DC2(DBG, E));
inline int dbg_send_error(char *message, int type, const char *mod_name, int line_no TSRMLS_DC2(DBG, E));


void dbg_flush_log(TSRMLS_D2(DBG,E));

int cmpll(void *element1, void *element2);

int chk_session_request(char *str, int len, char delimiter TSRMLS_DC1(DBG));
int parse_session_request(char *str, int len, char delimiter TSRMLS_DC1(DBG));

inline char *dbg_mod_name_by_no(int mod_no TSRMLS_DC1(DBG));

inline int dbg_mod_item_by_name(const char *mod_name, int addifnotfound TSRMLS_DC1(DBG));

#define DBG_FINDMODULE(mod_name) dbg_mod_item_by_name(mod_name, 0 TSRMLS_CC1(DBG))
#define DBG_FINDMODULE_ADD(mod_name) dbg_mod_item_by_name(mod_name, 1 TSRMLS_CC1(DBG))

#define INC_SCOPEID(v)	v+2
#define DEC_SCOPEID(v)	v-2

void add_session_cookie(TSRMLS_D2(DBG, S));

#define ADD_HDR(a) sapi_add_header(a, strlen(a), 1)

#define ESESS_NOREASON	0
#define ESESS_LOOKUP	-1
#define ESESS_SOCK		-2
#define ESESS_CONN		-3

#if defined(ZEND_ENGINE_2)
#define EG_THIS EG(This)
#else
#define EG_THIS NULL
#endif


#endif
