/***************************************************************************
                          dbg_prof.c  -  description
                             -------------------
    begin                : Sun Sep 24 2000
    copyright            : (C) 2001 by Dmitri Dmitrienko
                         : (C) 2002, 2007 NuSphere Corp.
    www                  : http://dd.cron.ru
                         : http://www.nusphere.com/
    author               : written by Dmitri Dmitrienko
    license              : This source file is subject to version 3.0 of 
                           the License,  that is bundled with this package 
                           in the file LICENSE, and is available at through 
                           the world-wide-web at http://www.nusphere.com/dbg
 ***************************************************************************/

#include "php.h"
#include "php_network.h"

#include "php_dbg.h"
#include "dbg_cmd.h"

#ifdef HAVE_DBG_PROFILER

#ifdef PHP_WIN32
/* Win 32 */
inline dbgint64 dbgTimeTicks() {
	LARGE_INTEGER qpc;
	QueryPerformanceCounter(&qpc);
	return qpc.QuadPart;
}

inline dbgint64 dbgTimeFreq() {
	LARGE_INTEGER qpf;
	QueryPerformanceFrequency(&qpf);
	return qpf.QuadPart;
}

#else

/* Linux / Unix */
inline dbgint64 dbgTimeTicks() {
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_usec + ((dbgint64)tv.tv_sec) * 1000000;
}

inline dbgint64 dbgTimeFreq() {
	return 1000000;
}

#endif


void dbgTESTTIMER() {
	dbgint64 v,v2,fv, mv=0, cnt=0, minv=0,maxv=0;
	int i;
	for (i=0; i<100000; i++) {
		v=dbgTimeTicks();
		v2=dbgTimeTicks();
		v=v2-v;
		if (i==0) {
			minv=v;
			maxv=v;
			fv=10*v;
		} else {
			if (v<minv) minv=v;
			if (v>maxv) maxv=v;
			fv=((v+fv) * 10) / 11;
		}
		mv +=v;
		cnt++;
	}
	mv/=cnt;
	DBG_TRACE(("minv=%ld\n",minv));
	DBG_TRACE(("maxv=%ld\n",maxv));
	DBG_TRACE(("mv=%ld\n",mv));
	DBG_TRACE(("fv=%ld\n",fv));
}

#endif

void init_rslt_array(zval **array, zval **outarray[], int count, char *names[]) {
	int i;
	zval *tmp;

	zval_dtor(*array);
	array_init(*array);
	for (i=0; i < count; i++) {
		MAKE_STD_ZVAL(tmp);
		array_init(tmp);
		zend_hash_update((*array)->value.ht, 
			names[i], 
			strlen(names[i])+1, 
			(void *) &tmp, 
			sizeof(zval*), 
			(void **) &(outarray[i]));
	}
}

#ifdef HAVE_DBG_PROFILER

#define cprofdata_columns 6
char *profdata_columns[cprofdata_columns] = {
	"mod_no", "line_no", "hit_count", 
	"tm_max", "tm_min", "tm_sum"};

/* {{{ proto int dbg_get_profiler_results(array &profdata)
		Fetches all profiler results into array 
		Returns number of rows in it */
PHP_FUNCTION(dbg_get_profiler_results) {
	zval **profdata;
	zval **outprofdata[cprofdata_columns];

	zval *element;
	profdata_item *it;
	int i, cnt = 0;
	dbgint64 freq;

	TSRMLS_FETCH1_NOP(DBG);
	if (ZEND_NUM_ARGS()!=1 ||
		zend_get_parameters_ex(1, &profdata) == FAILURE) {
		WRONG_PARAM_COUNT;
		RETURN_LONG(0);
	}

	freq = dbgTimeFreq();
	if (freq <= 1) freq = 1;

	init_rslt_array(profdata, outprofdata, cprofdata_columns, profdata_columns);

	LLIST_FOREACH(DBG(mod_list), mod_item,
		for (i=0; i < data->profdata_items; i++) {
			it=&(data->profdata_arr[i]);
			if (it->hitcount > 0) {

				/* mod_no */
				MAKE_STD_ZVAL(element);
				ZVAL_LONG(element, data->mod_no);
				zend_hash_index_update((*(outprofdata[0]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

				/* line_no */
				MAKE_STD_ZVAL(element);
				ZVAL_LONG(element, i);
				zend_hash_index_update((*(outprofdata[1]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

				/* hitcount */
				MAKE_STD_ZVAL(element);
				ZVAL_LONG(element, it->hitcount);
				zend_hash_index_update((*(outprofdata[2]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

				/* tm_max */
				MAKE_STD_ZVAL(element);
				ZVAL_DOUBLE(element, (double)it->tm_max / freq);
				zend_hash_index_update((*(outprofdata[3]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

				/* tm_min */
				MAKE_STD_ZVAL(element);
				ZVAL_DOUBLE(element, (double)it->tm_min / freq);
				zend_hash_index_update((*(outprofdata[4]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

				/* tm_sum */
				MAKE_STD_ZVAL(element);
				ZVAL_DOUBLE(element, (double)it->tm_sum / freq);
				zend_hash_index_update((*(outprofdata[5]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

				cnt++;
			}
		}
	);

	RETURN_LONG(cnt);
}
/* }}} */
#endif	

#define cmodule_columns 2
char *module_columns[cmodule_columns] = {
	"mod_no", "mod_name"};

/* {{{ proto int dbg_get_all_module_names(array &modules)
		Fetches list of all modules names and their indexes (mod_no)
		Returns number of rows in it */
PHP_FUNCTION(dbg_get_all_module_names) {
	zval **modules;
	zval **outmodules[cmodule_columns];
	zval *element;
	int cnt = 0;

	TSRMLS_FETCH1_NOP(DBG);
	if (ZEND_NUM_ARGS()!=1 ||
		zend_get_parameters_ex(1, &modules) == FAILURE) {
		WRONG_PARAM_COUNT;
		RETURN_LONG(0);
	}
	init_rslt_array(modules, outmodules, cmodule_columns, module_columns);
	LLIST_FOREACH(DBG(mod_list), mod_item,

		/* mod_no */
		MAKE_STD_ZVAL(element);
		ZVAL_LONG(element, data->mod_no);
		zend_hash_index_update((*(outmodules[0]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

		/* mod_name */
		MAKE_STD_ZVAL(element);
		ZVAL_STRING(element, (data->mod_name)?data->mod_name:"", 1);
		zend_hash_index_update((*(outmodules[1]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);
		
		cnt++;
	);
	RETURN_LONG(cnt);
}
/* }}} */


/* {{{ proto int dbg_get_module_name(int mod_no, string &module_name)
   Fetches module name for specified mod_no
   Returns 0 in case of error or 1 in success */
PHP_FUNCTION(dbg_get_module_name) {
	zval **module_name, **zval_mod_no;
	int prm_mod_no;

	TSRMLS_FETCH1_NOP(DBG);

	if (ZEND_NUM_ARGS() != 2 ||
		zend_get_parameters_ex(2, &zval_mod_no, &module_name) == FAILURE) {
		WRONG_PARAM_COUNT;
		RETURN_LONG(0);
	}

	convert_to_long(*zval_mod_no);
	prm_mod_no = (*zval_mod_no)->value.lval;

	LLIST_FOREACH(DBG(mod_list), mod_item,
		if (data->mod_no == prm_mod_no) {
			ZVAL_STRING(*module_name, (data->mod_name) ? data->mod_name : "", 1);
			RETURN_LONG(1);
		}
	);

	ZVAL_STRING(*module_name, "", 1);
	RETURN_LONG(0);
}
/* }}} */

#define ccontext_columns 3
char *context_columns[ccontext_columns] = {
	"ctx_no", "mod_no", "ctx_name"};

/* {{{ proto int dbg_get_all_context_names(int mod_no, array &contexts)
   Fetches list of contexts (function names) for given mod_no or all contexts if mod_no is zero 
   Returns number of resulting rows */
PHP_FUNCTION(dbg_get_all_contexts) {
	zval **contexts, **zval_mod_no;
	zval **outcontexts[ccontext_columns];
	zval *element;
	int cnt = 0, prm_mod_no, mod_no;

	TSRMLS_FETCH1_NOP(DBG);

	if (ZEND_NUM_ARGS()!=2 ||
		zend_get_parameters_ex(2, &zval_mod_no, &contexts) == FAILURE) {
		WRONG_PARAM_COUNT;
		RETURN_LONG(0);
	}
	convert_to_long(*zval_mod_no);
	prm_mod_no = (*zval_mod_no)->value.lval;
	init_rslt_array(contexts, outcontexts, ccontext_columns, context_columns);
	LLIST_FOREACH(DBG(ctx_list), ctx_item,		
		mod_no = DBG_FINDMODULE(data->mod_name);
		if (prm_mod_no == 0 || prm_mod_no == mod_no) {

			/* mod_no */
			MAKE_STD_ZVAL(element);
			ZVAL_LONG(element, mod_no);
			zend_hash_index_update((*(outcontexts[0]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

			/* ctx_id */
			MAKE_STD_ZVAL(element);
			ZVAL_LONG(element, data->ctx_id);
			zend_hash_index_update((*(outcontexts[1]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

			/* function_name */
			MAKE_STD_ZVAL(element);
			ZVAL_STRING(element, (data->function_name)?data->function_name : "", 1);
			zend_hash_index_update((*(outcontexts[2]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

			cnt++;
		}
	);
	RETURN_LONG(cnt);
}
/* }}} */

/* {{{ proto int dbg_get_context_name(int ctx_id, string &function_name)
   Fetches function name for given ctx_id 
   Returns 0 in case of error or 1 in success */
PHP_FUNCTION(dbg_get_context_name) {
	zval **zval_ctx_id, **function_name;
	int prm_ctx_id;

	TSRMLS_FETCH1_NOP(DBG);

	if (ZEND_NUM_ARGS() != 2 ||
		zend_get_parameters_ex(2, &zval_ctx_id, &function_name) == FAILURE) {
		WRONG_PARAM_COUNT;
		RETURN_LONG(0);
	}
	
	convert_to_long(*zval_ctx_id);
	prm_ctx_id = (*zval_ctx_id)->value.lval;

	LLIST_FOREACH(DBG(ctx_list), ctx_item,
		if (data->ctx_id == prm_ctx_id) {
			ZVAL_STRING(*function_name, (data->function_name) ? data->function_name : "", 1);
			RETURN_LONG(1);
		}
	);
	RETURN_LONG(0);
}
/* }}} */

#define csrcline_columns 3
char *srcline_columns[csrcline_columns] = {
	"ctx_no", "mod_no", "line_no"};

/* {{{ proto int dbg_get_all_source_lines(int mod_no, array &source_lines)
		Fetches list of lines for all contexts in given mod_no or all lines for all contexts if mod_no is zero
		Returns number of resulting rows */
PHP_FUNCTION(dbg_get_all_source_lines) {
	zval **srclines, **zval_mod_no;
	zval **outsrclines[csrcline_columns];
	zval *element;
	int cnt = 0, prm_mod_no, mod_no;

	TSRMLS_FETCH1_NOP(DBG);

	if (ZEND_NUM_ARGS()!=2 ||
		zend_get_parameters_ex(2, &zval_mod_no, &srclines) == FAILURE) {
		WRONG_PARAM_COUNT;
		RETURN_LONG(0);
	}
	convert_to_long(*zval_mod_no);
	prm_mod_no = (*zval_mod_no)->value.lval;
	init_rslt_array(srclines, outsrclines, csrcline_columns, srcline_columns);

	LLIST_FOREACH(DBG(ctxlines_list), ctxlines_item,
		mod_no = DBG_FINDMODULE(data->mod_name); 
		if (prm_mod_no == 0 || prm_mod_no == mod_no) {
			int ctx_id = data->ctx_id;
			int line_no = data->start_line_no;
			int lines_cnt = data->lines_cnt;
			int i;
			for (i = 0; i < lines_cnt; i++) {

				/* ctx_id */
				MAKE_STD_ZVAL(element);
				ZVAL_LONG(element, ctx_id);
				zend_hash_index_update((*(outsrclines[0]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

				/* mod_no */
				MAKE_STD_ZVAL(element);
				ZVAL_LONG(element, mod_no);
				zend_hash_index_update((*(outsrclines[1]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

				/* line_no */
				MAKE_STD_ZVAL(element);
				ZVAL_LONG(element, line_no + i);
				zend_hash_index_update((*(outsrclines[2]))->value.ht, cnt, (void *)&element, sizeof(zval*), NULL);

				cnt++;
			}			
		}
	);
	RETURN_LONG(cnt);
}
/* }}} */

/* {{{ proto int dbg_get_source_context(int mod_no, int line_no, int &ctx_id)
		Fetches ctx_id for given mod_no, line_no pair
		Returns 0 in case of error or 1 in success */
PHP_FUNCTION(dbg_get_source_context) {
	zval **zval_mod_no, **zval_line_no;
	zval **zval_ctx_id;
	int prm_mod_no, prm_line_no;

	TSRMLS_FETCH1_NOP(DBG);

	if (ZEND_NUM_ARGS() != 3 ||
		zend_get_parameters_ex(3, &zval_mod_no, &zval_line_no, &zval_ctx_id) == FAILURE) {
		WRONG_PARAM_COUNT;
		RETURN_LONG(0);
	}

	convert_to_long(*zval_mod_no);
	prm_mod_no = (*zval_mod_no)->value.lval;
	convert_to_long(*zval_line_no);
	prm_line_no = (*zval_line_no)->value.lval;
	

	LLIST_FOREACH(DBG(ctxlines_list), ctxlines_item,
		if (prm_mod_no == DBG_FINDMODULE(data->mod_name) && 
			prm_line_no >= data->start_line_no && 
			prm_line_no < data->lines_cnt + data->start_line_no) {

			ZVAL_LONG(*zval_ctx_id, data->ctx_id);
			RETURN_LONG(1);
		}
	);

	RETURN_LONG(0);
}
/* }}} */
