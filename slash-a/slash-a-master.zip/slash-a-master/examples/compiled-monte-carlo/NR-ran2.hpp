
namespace NumericalRecipes {
  float ran2(long *idum);
};
