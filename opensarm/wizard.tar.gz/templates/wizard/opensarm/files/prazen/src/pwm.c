/*
 Osnovna PWM knjižnica.
 Avtor: Jernej Sorta
 Različica: 1.0
 V tej različici še ni neposredno omogočen PWM z dvojnim bokom

 
 */

/*
	    \                         
     PWMMR0 \------------------------*
            \                      * :
            \                    *   :
            \                  *     :
            \                *       :
     PWMMRx \--------------*         :
            \            * :         :
            \          *   :         :
            \        *     :         :	      .....
            \      *       :         :      *
            \    *         :         :    *
            \  *           :         :  *
            \*             :         :*
            \______________:_________:____________________________> t
			   :	     :
	PWMx izhod	   :	     :
	    |		   :	     :
	    |		   :	     :
	    |		   :	     :
	    |		   :	     :
	"1" |//////////////|	     |///////.....
	    |		   |	     |
	    |		   |	     |
	    |		   |	     |		
	    |		   |	     |
	    |		   |	     |
	"0" |______________|/////////|______________________________> t

 
 
 
 
 
 
 */

#include "pwm.h"
#include "io.h"

void Casovnik_Stanje(unsigned char stanje)
{
  switch (stanje)
  {
    case UGASNI_STEVEC:
      PWM_TCR &= ~((1<<COUNTER_ENABLE)||(1<<PWM_ENABLE));	//Counter enable, PWM enable pobrisana
    break;

    case ZAZENI_STEVEC:
      PWM_TCR |= (1<<COUNTER_ENABLE)||(1<<PWM_ENABLE);		// postavljena Counter Enable in PWM Enable
      PWM_TCR &= ~(1<<COUNTER_RESET);				//pobrisan counter reset
    break;

    case PONASTAVI_STEVEC:					//števec ponastavimo in ga nato spet poženemo
      PWM_TCR |= (1<<COUNTER_RESET);
      
      unsigned char pwmreset_stevc;
      for(pwmreset_stevc=0;pwmreset_stevc<10; pwmreset_stevc++ );//kratka zakasnitev...verjetno ni nujno potrebna

      PWM_TCR &= ~(1<<COUNTER_RESET);
    break;

    default:
    break;
  }
}





void PWM_NastaviFrekvenco(unsigned int frekvenca)//unsigned long? potrebno za številke načeloma do 60M->do kje gre unsigned int? 32bit?
{
  PWMMR0 = (CPU_FREQ*1000/frekvenca);//Zaenkrat še ni podpore za preddelilnik takta za PWM. CPU_FREQ je določen v lpc214x.h
  PWMMCR |= (1<<PWMMR0R);//Ko štecev prešteje do PWMMR0 se ponastavi, s tem dolčimo frekvenco
  PWM_LER |= (1<<PWM0);//V latch enable registru omogočimo, da se vrednost iz PWMMR0 prenese iz senčnega registra v pravi register, ko se števec ponastavi
}







void PWM_NastaviKanal(unsigned char kanal/*od PWM1-PWM6*/, unsigned char prevajalno_razmerje/*od 0-100%*/, unsigned char vklop/*0 ali 1*/)//vklop je samo, če ne bi hoteli speljati PWM na izhode
{
 unsigned char stevilka_kanala = kanal;
  if(kanal>6)		//V primeru, da bi bila številka kanala neveljavna
  {
    stevilka_kanala=6;
  }
  else if(kanal<1)
  {
    stevilka_kanala=1;
  }
  
  /*
   Preverjanje, če je prevajalno razmerje večje od 100 ni potrebno, ker je popravek že strojno opravljen.
   V tem primeru je izhod vedno na "1"   
   */
  
  
  switch(stevilka_kanala)
  {
    case PWM1:
      if(vklop)				//Če je vklop=="1", potem je PWM fja omogočena in speljana na izhod
      {
	PWM_MR1 = (PWMMR0/100)*prevajalno_razmerje;
	PWM_LER = (1<<PWM1);		//ALI operacija ni potrebna, saj določimo vsakič posebej, kateri kanal želimo. Potem se vsakič vsi biti samodejno pobrišejo
	PWM_PCR |= (1<<PWMENA1);	//omogočimo PWM1 izhod
	IODIR0 |=(IZHOD<<PIN0);		//Določimo P0.0 kot izhod
	PINSEL0 |=(FUN_2<<(PIN0*2));	//Sponki P0.0 določimo fjo PWM, ki ima številko 2 (tretja po vrsti)
      }
      else				//če je vklop=="0", potem je PWM fja onemogočena, vendar utegne še vedno biti speljana na izhod, če smo to kdaj storili
      {
	PWM_PCR &= ~(1<<PWMENA1);	//onemogočimo PWM1 izhod
      }
    break;
    
    case PWM2:
      if(vklop)
      {
	PWM_MR2 = (PWMMR0/100)*prevajalno_razmerje;
	PWM_LER = (1<<PWM2);
	PWM_PCR |= (1<<PWMENA2);
	IODIR0 |=(IZHOD<<PIN7);
	PINSEL0 |=(FUN_2<<(PIN7*2));
      }
      else
      {
	PWM_PCR &= ~(1<<PWMENA2);
      }
    break;
    
    case PWM3:
      if(vklop)
      {
	PWM_MR3 = (PWMMR0/100)*prevajalno_razmerje;
	PWM_LER = (1<<PWM3);
	PWM_PCR |= (1<<PWMENA3);
	IODIR0 |=(IZHOD<<PIN1);
	PINSEL0 |=(FUN_2<<(PIN1*2));
      }
      else
      {
	PWM_PCR &= ~(1<<PWMENA3);
      }
    break;
    
    case PWM4:
      if(vklop)
      {
	PWM_MR4 = (PWMMR0/100)*prevajalno_razmerje;
	PWM_LER = (1<<PWM4);
	PWM_PCR |= (1<<PWMENA4);
	IODIR0 |=(IZHOD<<PIN8);
	PINSEL0 |=(FUN_2<<(PIN8*2));
      }
      else
      {
	PWM_PCR &= ~(1<<PWMENA4);
      }
    break;
    
    case PWM5:
      if(vklop)
      {
	PWM_MR5 = (PWMMR0/100)*prevajalno_razmerje;
	PWM_LER = (1<<PWM5);
	PWM_PCR |= (1<<PWMENA5);
	IODIR0 |=(IZHOD<<PIN21);
	PINSEL1 |=(FUN_1<<10);
      }
      else
      {
	PWM_PCR &= ~(1<<PWMENA5);
      }
    break;
    
    case PWM6:
      if(vklop)
      {
	PWM_MR6 = (PWMMR0/100)*prevajalno_razmerje;
	PWM_LER = (1<<PWM6);
	PWM_PCR |= (1<<PWMENA6);
	IODIR0 |=(IZHOD<<PIN9);
	PINSEL0 |=(FUN_2<<(PIN9*2));
      }
      else
      {
	PWM_PCR &= ~(1<<PWMENA6);
      }
    break;
    
    default:
    break;
  }
}







void PWM_PonastaviPrekinitev(unsigned char kanal)	//ponastavimo prekinitev
{
  //Za ponastavitev prekinitve moramo v PWM_IR vpisat "1" na željeno mesto
  unsigned char stevilka_kanala = kanal;
  if(kanal>6)		//V primeru, da bi bila številka kanala neveljavna
  {
    stevilka_kanala=6;
  }

  
  
  
  if(stevilka_kanala<4)
  {
    PWM_IR |= (1<<stevilka_kanala);
  }
  else
  {
    PWM_IR |= (1<<(stevilka_kanala+4));		//V registru biti ne gredo po vrsti, ampak je med PWMMR3 in PWMMR4 praznina za 4 bite.
  }

}





/*S to fjo lahko nastavimo dogodek, ki se zgodi, ko vrednost števca doseže vrednost v PWMMRx. 
Za običajno rabo ni potreno nastavljati ničesar.
Izbiramo lahko med prekinitvijo, ustavitvijo števca, ali ponastavitvijo števca->števec gre na 0 in tam ostane?
Če števec ustavimo ali ponastavimo, ga je potrebno spet zagnat s fjo Casovnik_Stanje(ZAZENI_STEVEC)
*/
void PWM_NastaviDogodek(unsigned char kanal, unsigned char dogodek)
{
  unsigned char stevilka_kanala = kanal;
  if(kanal>6)		//V primeru, da bi bila številka kanala neveljavna
  {
    stevilka_kanala=6;
  }

  unsigned char pravi_dogodek = dogodek;
  
  //V primeru neveljavnega dogodka:
  if(dogodek<=(PREKINITEV|USTAVITEV|PONASTAVITEV)) pravi_dogodek = dogodek;	//Z fjo ALI lahko izberemo več dogodkov, npr: Za ponastavitev in ustavitev damo za argument "dogodek": USTAVITEV|PONASTAVITEV
  else pravi_dogodek = 0;
  
      PWMMCR &= ~((PREKINITEV|USTAVITEV|PONASTAVITEV)<<stevilka_kanala);//najprej pobrišemo prejšnje stanje
      PWMMCR |= (pravi_dogodek<<stevilka_kanala);			//in nato zapišemo novega
}




