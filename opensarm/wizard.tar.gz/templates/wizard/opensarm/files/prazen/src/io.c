#include "io.h"


/* Function is called from crt.s. It initializes cpu clock, MAM settings and fast GPIO */
void Initialize(void)  {
#define PLOCK 0x400

	SCS |= 0x03; // We will use the fast interface...

        // Setting Multiplier and Divider values
        PLLCFG=PLL_CONF;

        PLLFEED=0xAA;
        PLLFEED=0x55;

        // Enabling the PLL */
        PLLCON=0x1;

        PLLFEED=0xAA;
        PLLFEED=0x55;

        // Wait for the PLL to lock to set frequency
        while(!(PLLSTAT & PLOCK)) ;

        // Connect the PLL as the clock source
        PLLCON=0x3;

        PLLFEED=0xAA;
        PLLFEED=0x55;

        // Enabling MAM and setting number of clocks used for Flash memory fetch (4 cclks in this case)
        MAMCR=0x2;
        MAMTIM=0x4;

        // Setting peripheral Clock (pclk) to System Clock (cclk)
        VPBDIV=0x1;

#ifdef USB_CONTROL

#endif
}




/******************************************************************************
 *  Timer functions for OpenSARM that corresponds to S-ARM originals          *
 *                                                                            *
 *  S-ARM version by: Arpad Buerman                                           *
 *  Ported by: OpenSARM Team, August 2011                                     *
 ******************************************************************************/

inline void _TimerInit(void)
{
// Set timer information. For more information take a look in Chapter 15 of LPC214x User's manual
    T0PR    = CPU_FREQ-1;	  // Prescaler to get 1ms clock ticks.
    T0MR0   = 0xFFFFFFFF;
    T0MCR   = 0x0000;         // we want a free running counter
    T0TCR 	= 0x02;	          // Reset counter&prescaler and disable timer
    T0CTCR  = 0x00;           // Timer mode
    T0TCR 	= 0x01;	          // Enable timer
}

unsigned long clock(void)
//return number of milliseconds since _TimerInit() call.
{
    return T0TC;
}

void delay(unsigned long m)
//pause for m milliseconds
//there is a bug in original code, that may cause delay malfunction if the CPU is running more than 49 days (T0TC reaches T0MR0). If delay is called just
//before this happens (unsigned) T0TC-start will always be more than m for almost any m.
{
    unsigned long start = T0TC;
    unsigned long end = start + m;
    if(end>start) // check whether addition overflows.
        while(T0TC<end);
    else
    {
        if(T0TC>start)
            while(T0TC>end);
        else
            while(T0TC<end);
    }
}



/******************************************************************************
 *  LED functions for OpenSARM that corresponds to S-ARM originals            *
 *                                                                            *
 *  S-ARM version by: Arpad Buerman                                           *
 *  Ported by: OpenSARM Team, August 2011                                     *
 ******************************************************************************/

inline void _LEDInit(void)
{
    //define function of pins to GPIO just in case if the function is broken!
   PINSEL2  &= ~LEDPINSELMASK;
   FIO1DIR  |=  LEDMASK;
}

inline void _setleds(int mask)
{
  FIO1SET = (((mask) & 0xf)<<LEDMASKSHIFT); \
}

inline void _clrleds(int mask)
{
  FIO1CLR = (((mask) & 0xf)<<LEDMASKSHIFT); \
}



/******************************************************************************
 *  PINIO functions for OpenSARM that corresponds to S-ARM originals          *
 *                                                                            *
 *  S-ARM version by: Arpad Buerman                                           *
 *  Ported by: OpenSARM Team, August 2011                                     *
 ******************************************************************************/

// TODO: expand to other io pins

void _setpindir(unsigned int pinid, int dir)
//pinid should be between 0 and 15 and corresponds P0.0 - P0.15
//dir = 0: input, dir = 1, output
{
  unsigned int dirmask;
  unsigned int selectpinmask;

  if (pinid > 15) return;

  dirmask = 1 << pinid;
  selectpinmask = ~(0x3 << (pinid <<2));
  PINSEL0 &= selectpinmask;

  if (dir == 0)
  {
    FIO0DIR &= ~dirmask;
  }
  else
  {
    FIO0DIR |= dirmask;
  }

}

void outportp(unsigned int pinid, int value)
{
  if (pinid > 15) return;
  if (value == 0)
  {
    FIO0CLR = 1 << pinid;
  }
  else
  {
    FIO0SET = 1 << pinid;
  }
}

int inportp(unsigned int pinid)
{
  if (pinid > 15) return -1;
  return (FIO0PIN & (1 << pinid)) >> pinid;
}



/******************************************************************************
 *  KEYBOARD functions for OpenSARM that corresponds to S-ARM originals       *
 *                                                                            *
 *  S-ARM version by: Arpad Buerman                                           *
 *  Ported by: OpenSARM Team, August 2011                                     *
 ******************************************************************************/

char _kbdbuffer;


void _KeyInit(void)
{
    PINSEL0 &= ~KEYSELMASK;
    FIO0DIR &= ~KEYMASK;
    _kbdbuffer = 0;
}

int _getkeys(void)
/* Get state of all four keys, non-blocking call */
{
  int i, state, revstate = 0;
  state=(~(FIO0PIN) & KEYMASK);
  state >>= 12;
// (~state)&
  for (i = 0; i < 4; i++)
  {
    revstate |= state & 1;
    state >>= 1;
    revstate <<= 1;
  }
  return revstate >> 1;
}

int kbhit(void)
/* detects keypresss (0->1). if no keypress returns 0, nonzero value otherwise. the code of pressed key is stored in _kbdbuffer*/
{
  int i;
  static int keys = 0;

  int keys1 = _getkeys();
  for (i = 8; i > 0; i >>= 1)
  {
    if ((keys1 & i) > (keys & i)) break;
  }
  keys = keys1;
  switch (i)
  {
  case 8: _kbdbuffer = '0'; break;
  case 4: _kbdbuffer = '1'; break;
  case 2: _kbdbuffer = '2'; break;
  case 1: _kbdbuffer = '3'; break;
  }

  return _kbdbuffer;
}

int getch(void)
{
  char ret;
  while (!kbhit());
  ret = _kbdbuffer;
  _kbdbuffer = 0;
  return ret;
}


/******************************************************************************
 *  ADC and DAC functions for OpenSARM that corresponds to S-ARM originals    *
 *                                                                            *
 *  S-ARM version by: Arpad Buerman                                           *
 *  Ported by: OpenSARM Team, August 2011                                     *
 ******************************************************************************/

void _ADCInit(void)
{
    //TODO: REWRITE AT LEAST LAST COMMAND
    PINSEL1 = (PINSEL1 & ~ADCSELMASK) | ADCSELVAL;
    ADCR = 0x2 | (0x4 << 8) | (0x1 << 21);
}

int _adconvert(void)
{
//  ADC_CONVERT;
//   unsigned int tmp;
   ADCR = 0x2 | (0xD << 8) | (0x1 << 21) | (0x1 << 24);
/*   do {
     tmp = ADDR;
   } while ((tmp & (0x1 << 31)) == 0);
*/
  while((ADDR & (0x1 << 31)) == 0);
  return (ADDR & 0xFFC0) >> 6;
}

int _adconvertExt(int input)
//input: 0 selects AD0.0, 7 selects AD0.7
//Needs no initialization
//Notice: _adconvertExt(0); is equivalent to _ADCInit(); _adconvert();
{
  if(!input)
    input = 1;

  int val = 0x400000 << (input * 2);
  int mask = 0xc00000 << (input * 2);
  int selectpin = 0x1 << input;
  int retval;

  if (input < 0 || input > 7) return 0;

  PINSEL1 = (PINSEL1 & ~mask) | val;

    ADCR = selectpin | (0x4 << 8) | (0x1 << 21) | (0x1 << 24);
    do {
      retval = ADDR;
    } while ((retval & (0x1 << 31)) == 0);
    retval = ((ADDR & 0xffc0) >> 6);

    return retval;
}


void _DACInit(void)
{
    PINSEL1 = (PINSEL1 & ~DACSELMASK) | DACSELVAL;
}

void _dacwrite(int val)
{
  if (val < 0) val = 0;
  if (val > 1023) val = 1023;
  DACR = (((val) & 0x3ff) << 6);
}

