#include "lpc214x.h"                   /* LPC214x definitions */
#include "i2c.h"

#define SCHL 75
//===========================================================================
//================ Common routines ==========================================
//===========================================================================
void i2c0_init(int Mode)
{
  PINSEL0 = (PINSEL0 & ~(3 << 4)) | (1 << 4);
  PINSEL0 = (PINSEL0 & ~(3 << 6)) | (1 << 6);


  I2C0SCLH = (unsigned int)(F_PCLK / (2 * Mode));
  I2C0SCLL = I2C0SCLH;

   I2C0CONCLR = 0xFF;           //-- Clear all flags
   I2C0CONSET = 0x40;           //-- Set Master Mode
   I2C0CONSET |= I2C_FLAG_I2EN; //--- Enable I2C
}

//---------------------------------------------------------------------------
void i2c0_writ_byte(int byte)
{
   I2C0DAT = byte;
   I2C0CONCLR = I2C_FLAG_SI;                //-- Clear SI
   while(!(I2C0CONSET & I2C_FLAG_SI));      //-- End wr POINT
}

//---------------------------------------------------------------------------
void i2c0_stop()
{
    //-- Set STOP condition
   I2C0CONCLR = I2C_FLAG_SI;                  //-- Clear SI
   I2C0CONSET |=  I2C_FLAG_AA | I2C_FLAG_STO; //-- Clear NO ASK
}

//---------------------------------------------------------------------------
int i2c0_start(int adr)
{
   int chk;
   //-- Set START
   I2C0CONCLR = 0xFF; // Clear all bits
   I2C0CONSET |= I2C_FLAG_I2EN | I2C_FLAG_STA;
   while(!(I2C0CONSET & I2C_FLAG_SI));      //--- End START
   //-- Set ADDRESS
   I2C0DAT = adr;
   I2C0CONCLR = I2C_FLAG_STA | I2C_FLAG_SI; //-- Clear START & SI
   if(adr & 1) //-- RD
      chk = 0x40; //-- 40H - SLA+R has been transmitted; ACK has been received
   else
      chk = 0x18; //-- 18H - SLA+W has been transmitted; ACK has been received
   while(!(I2C0CONSET & I2C_FLAG_SI));      //-- End CTRL
   if(I2C0STAT != chk)
   {
    i2c0_stop();
    return I2C_ERR_NO_RESPONSE;
   }
   return I2C_NO_ERR;
}

//---------------------------------------------------------------------------
int i2c0_recieve(char * buf,int num)
{
   int rc;

   if(buf == NULL)
      return I2C_ERR_WRONG_PARAM;

   rc = num;
   if(rc > 1)
   {
      I2C0CONCLR = I2C_FLAG_SI;
      I2C0CONSET |= I2C_FLAG_AA;
      for(;;)
      {
         while(!(I2C0CONSET & I2C_FLAG_SI));  //-- End Data from slave;
         *buf++ = (unsigned char)I2C0DAT;
         rc--;
         if(rc <= 0)
            break;
         else if(rc == 1)
            I2C0CONCLR = I2C_FLAG_AA | I2C_FLAG_SI;  //-- After next will NO ASK
         else
         {
            I2C0CONCLR = I2C_FLAG_SI;
            I2C0CONSET |= I2C_FLAG_AA;
         }
      }
   }
   else if(rc == 1)
   {
      I2C0CONCLR = I2C_FLAG_AA | I2C_FLAG_SI;  //-- After next will NO ASK
      while(!(I2C0CONSET & I2C_FLAG_SI));  //-- End Data from slave;
      *buf = (unsigned char)I2C0DAT;
   }
   else //err
      return I2C_ERR_WRONG_PARAM;

   return I2C_NO_ERR;
}
