#ifndef _I2C_H_
#define _I2C_H_

#define F_PCLK 40579000

//-----define for compatibility between Keil and Opensarm header files
#define I2C0CONSET		I2CONSET
#define I2C0STAT		I2STAT
#define I2C0DAT			I2DAT
#define I2C0ADR			I2ADR
#define I2C0SCLH		I2SCLH
#define I2C0SCLL		I2SCLL
#define I2C0CONCLR		I2CONCLR


//---  LPC21XX I2C flags --------------------

#define  I2C_FLAG_AA    (1<<2)
#define  I2C_FLAG_SI    (1<<3)
#define  I2C_FLAG_STO   (1<<4)
#define  I2C_FLAG_STA   (1<<5)
#define  I2C_FLAG_I2EN  (1<<6)

//---- I2C Speed
#define  I2C_SPEED_100   0
#define  I2C_SPEED_400   1

//--- Errors

#define  I2C_NO_ERR                    0
#define  I2C_ERR_NO_RESPONSE           1
#define  I2C_ERR_WRONG_PARAM           2
#define  I2C_ERR_24XX_WR_TIMEOUT       3
#define  I2C_ERR_24XX_BAD_ADDR         4
#define  I2C_ERR_24XX_BAD_TYPE         5
#define  I2C_ERR_24XX_BAD_PAGESIZE     6
#define  I2C_ERR_24XX_WRONG_NUM        7
#define  I2C_ERR_LM75_WRONG_REGISTER   8


#define NULL 0
void i2c0_init(int Mode);
void i2c0_writ_byte(int byte);
void i2c0_stop();
int i2c0_start(int adr);
int i2c0_recieve(char * buf,int num);



#endif
