

#define AD0CR			(*((volatile unsigned long *) 0xE0034000))
#define AD0GDR			(*((volatile unsigned long *) 0xE0034004))
#define AD0STAT			(*((volatile unsigned long *) 0xE0034030))
#define ADGSR			(*((volatile unsigned long *) 0xE0034008))
#define AD0INTEN		(*((volatile unsigned long *) 0xE003400C))
#define AD0DR0			(*((volatile unsigned long *) 0xE0034010))
#define AD0DR1			(*((volatile unsigned long *) 0xE0034014))
#define AD0DR2			(*((volatile unsigned long *) 0xE0034018))
#define AD0DR3			(*((volatile unsigned long *) 0xE003401C))
#define AD0DR4			(*((volatile unsigned long *) 0xE0034020))
#define AD0DR5			(*((volatile unsigned long *) 0xE0034024))
#define AD0DR6			(*((volatile unsigned long *) 0xE0034028))
#define AD0DR7			(*((volatile unsigned long *) 0xE003402C))


#define AD1CR			(*((volatile unsigned long *) 0xE0060000))
#define AD1GDR			(*((volatile unsigned long *) 0xE0060004))
#define AD1STAT			(*((volatile unsigned long *) 0xE0060030))
//#define ADGSR 			(*((volatile unsigned long *) 0xE0060008))
#define AD1INTEN		(*((volatile unsigned long *) 0xE006000C))
#define AD1DR0			(*((volatile unsigned long *) 0xE0060010))
#define AD1DR1			(*((volatile unsigned long *) 0xE0060014))
#define AD1DR2			(*((volatile unsigned long *) 0xE0060018))
#define AD1DR3			(*((volatile unsigned long *) 0xE006001C))
#define AD1DR4			(*((volatile unsigned long *) 0xE0060020))
#define AD1DR5			(*((volatile unsigned long *) 0xE0060024))
#define AD1DR6			(*((volatile unsigned long *) 0xE0060028))
#define AD1DR7			(*((volatile unsigned long *) 0xE006002C))

#define DONE_FLAGS	0
#define OVERRUN_FLAGS	1
#define BURST_ON	1
#define BURST_OFF	0
#define FALLING_EDGE	1
#define RISING_EDGE	0

#define ADINTEN0	(1<<0)
#define ADINTEN1	(1<<1)
#define ADINTEN2	(1<<2)
#define ADINTEN3	(1<<3)
#define ADINTEN4	(1<<4)
#define ADINTEN5	(1<<5)
#define ADINTEN6	(1<<6)
#define ADINTEN7	(1<<7)
#define ADGINTEN	(1<<8)

#define ADC0		0
#define	ADC1		1
#define EDGE		27
#define ADC_G		2


#define START		24
#define NO_START	0
#define START_NOW	1
#define	START_MAT0_2	2
#define START_P0_16	2
#define START_P0_22	3
#define	START_MAT0_0	3
#define	START_MAT0_1	4
#define	START_MAT0_3	5
#define	START_MAT1_0	6
#define	START_MAT1_1	7


#define PDN		21
#define CLKS		17
#define CLKDIV		8
#define BURST		16

#define	CLKS_10BITS	0
#define	CLKS_9BITS	1
#define	CLKS_8BITS	2
#define	CLKS_7BITS	3
#define	CLKS_6BITS	4
#define	CLKS_5BITS	5
#define	CLKS_4BITS	6
#define	CLKS_3BITS	7

#define ADx_0		0
#define ADx_1		1
#define ADx_2		2
#define ADx_3		3
#define ADx_4		4
#define ADx_5		5
#define ADx_6		6
#define ADx_7		7

#define FUN_0	0
#define FUN_1	1
#define FUN_2	2
#define FUN_3	3


#define PIN0	0x00
#define PIN1	0x01
#define PIN2	0x02
#define PIN3	0x03
#define PIN4	0x04
#define PIN5	0x05
#define PIN6	0x06
#define PIN7	0x07
#define PIN8	0x08
#define PIN9	0x09
#define PIN10	0x0A
#define PIN11	0x0B
#define PIN12	0x0C
#define PIN13	0x0D
#define PIN14	0x0E
#define PIN15	0x0F
#define PIN16	0x10
#define PIN17	0x11
#define PIN18	0x12
#define PIN19	0x13
#define PIN20	0x14
#define PIN21	0x15
#define PIN22	0x16
#define PIN23	0x17
#define PIN24	0x18
#define PIN25	0x19
#define PIN26	0x1A
#define PIN27	0x1B
#define PIN28	0x1C
#define PIN29	0x1D
#define PIN30	0x1E
#define PIN31	0x1F

unsigned char ADC_Init(unsigned char adc_number, unsigned char sampling_resolution);
void ADC_SetInterrupt(unsigned char adc_number, unsigned char adc_channel_mask, unsigned char adc_global_done_flag_interrupt);
unsigned int ADC_GetGlobalStatus(unsigned char adc_number, unsigned char status_type);
unsigned char ADC_StartConversion(unsigned char adc_number, unsigned char adc_channel, unsigned char start_source, unsigned char start_source_edge);
int ADC_GetResult(unsigned char adc_number, unsigned char adc_channel);
unsigned char ADC_IsDone(unsigned char adc_number);
unsigned char ADC_SetIO(unsigned char adc_number, unsigned char adc_channel);




















