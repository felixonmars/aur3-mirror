#ifndef INTERRUPTS_H_INCLUDED
#define INTERRUPTS_H_INCLUDED


void IRQ_Routine (void)   __attribute__ ((interrupt("IRQ")));
void FIQ_Routine (void)   __attribute__ ((interrupt("FIQ")));
void SWI_Routine (void)   __attribute__ ((interrupt("SWI")));
void UNDEF_Routine (void) __attribute__ ((interrupt("UNDEF")));


#endif // INTERRUPTS_H_INCLUDED
