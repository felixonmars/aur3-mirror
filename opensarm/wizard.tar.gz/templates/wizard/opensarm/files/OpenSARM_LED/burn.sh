#!/bin/bash

#
# 2011 OpenSARM
#
# Pomozna skripta namenjena programiranju cipa iz Code::Blocks.
#

FILE=$1

if [ ! $BASH_ARGC ]; then 
	echo "Uporaba: $0 file.elf";
	exit 0;
fi

if [ ! -r $FILE ]; then
	echo "Napaka: datoteka ne obstaja ali pa je ni mogoce prebrati.";
	exit 1;
fi;

echo "Zapisujem $FILE"
lpc21iap $FILE