#include "io.h"
#include "pwm.h"

void Initialize(void);
void feed(void);



int	main (void)
{
    // Initialize the system
	Initialize();
    _TimerInit();
	_LEDInit();
    pwmInit();

    _clrleds(0x02);

	//Turn on the LEDs
	_setleds(0x02);

    // endless loop to toggle the two leds
    while (1)
    {
        delay(500);
        _setleds(0x02);
        delay(100);
		_clrleds(0x02);
    }

    return 0;
}

