#ifndef _LM75_H_
#define _LM75_H_

#define LM75_ADR 0x91
void lm75_init (unsigned int clk);
signed int lm75_get_temp_raw (unsigned char adr);
void lm75_get_temp (unsigned char adr, signed char *w, signed char *d);

#endif
