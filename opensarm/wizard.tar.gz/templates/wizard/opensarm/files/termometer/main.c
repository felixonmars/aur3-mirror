#include "io.h"
#include "pwm.h"
#include "lm75.h"
#include "lcd.h"
#include <stdio.h>
#include <string.h>


void Initialize(void);
void feed(void);



int	main (void)
{
   signed char cela;
   unsigned char decimalna, i;
   unsigned char str[7];
    // Initialize the system
	Initialize();
    _TimerInit();
    lcdInit();
    lm75_init(100000);
    while(1)
    {
        lm75_get_temp(LM75_ADR, &cela, &decimalna);
        sprintf(str, "temp: %d.%d�C", cela, decimalna);
        lcdPutString(str);
        delay(1000);
        lcdGotoXY(0, 0);
    }


    return 0;
}

