/*****************************************************************************
*   i2c0.c:  i2c0 driver for LPC214x microntroller
*	This file is part of openSARM project
*
*	Author. Matja� Tome <matjaz.tome@gmail.com>
*
*   History
*   19. dec. 2011  ver 0.90 initial release.
*
*
******************************************************************************/

/**
 * @file lm75.c
 * @author Matjaz Tome
 * @date 19. dec. 2011
 * @version 0.90
 * @brief i2c drivers for LM75 temperature sensor
 */


#include "i2c.h"


/**
 * Configures i2c0 to work with LM75 sensor
 *
 * @param clk Desired i2c0 clock frequency in hertz
 */
void lm75_init (unsigned int clk)
{
	i2c0_init(clk);
}

/**
 * Returns raw data from sensor
 *
 * @param adr adress of sensor
 * @return Data from sensor
 */
signed int lm75_get_temp_raw (unsigned char adr)
{
	unsigned char a[2];
	i2c0_start(adr);
	i2c0_recieve(a, 2);
	i2c0_stop();
	return ((a[0] << 8) | a[1]) >> 7;

}


/**
 * Returns data from sensor in celsius (whole part and decimal part)
 *
 * @param adr adress of sensor
 * @param *w pointer to variable, tha will hold whole part of temperature
 * @param *d pointer to a variable, the will hold decimal part of temperature
 */
void lm75_get_temp (unsigned char adr, signed char *w, signed char *d)
{
 signed int a = lm75_get_temp_raw(adr);

 if (a % 2)
	 {
	   *d = 5;
	 }
	 else
	 {
	 *d = 0;
	 }
 *w = (a * 10) / 20;
}

