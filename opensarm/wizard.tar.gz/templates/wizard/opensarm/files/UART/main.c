#include "io.h"
#include <stdio.h>
#include <string.h>
#include "uart.h"




int	main (void)
{
    Initialize();
    _KeyInit();
    _TimerInit();
    UART_Init(UART_0, 9600, 8, ONE_STOP_BIT, PARITY_DISABLE, 0);
    
    char niz[40];
    int spremenljivka = 12345;
    
    while(1)
    {
      
      delay(500);
      put_s(UART_0, niz);
      put_s(UART_0, "\n \nOpenSARM \n \n Pozdravljen svet! \n");
      
      
      delay(500);
      sprintf(niz, "Vrednost spremenljivke: %d\n", spremenljivka);
      put_s(UART_0, niz);
      
      delay(500);
      put_char(UART_0, 'c');
      put_char(UART_0, '\n');
      
    }

    return 0;
}

