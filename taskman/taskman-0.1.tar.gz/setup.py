from distutils.core import setup

setup(
    name='taskman',
    version='0.1',
    packages=[''],
    url='',
    license='',
    author='Aurelien Martin',
    author_email='',
    description=''
)
