#!/usr/bin/env python3
# -*- coding: utf-8 -*-



# ----------------
# Prévoir la possibilité de bannir si plus de 400 appels dans la journée
# Recharger les adresses bannies au démarrage
# -------------------------



from multiprocessing import Process, Lock
import socket, sys, logging, os, yaml, re, time




class Ip():
	def __init__(self):
		self.time    = time.time()
		self.number  = 1
		self.counter = 1

	def set_number(self):
		self.number  += 1
		self.counter += 1

	def reset_number(self):
		self.number   = 1
		self.counter += 1




def clean(lock, cfg, ban_file):
	loop   = True
	period = int()

	if cfg['cleanup period'] == 'day':
		period = 3600 * 24
	elif cfg['cleanup period'] == 'week':
		period = 3600 * 24 * 7
	elif cfg['cleanup period'] == 'month':
		period = 3600 * 24 * 7 * 4
	else:
		print("Unknown cleanup period in config file !")
		logging.critical("Unknown cleanup period in config file !")
		sys.exit(2)

	while loop:
		# On crée un dictionnaire
		hash_ip = read_ban_file(lock, ban_file)

		# On récupère l'heure actuelle
		now     = time.time()
		# On récupère le verrou
		lock.acquire()
		# On réouvre le fichier mais en écriture
		with open(ban_file, 'w') as target:
			# On écrit toutes les IP bannies
			for ip, hour in hash_ip.items():
				if hour + period > now:
					# On supprime la règle iptables
					os.system('iptables -D INPUT -s %s -d %s -j DROP' %(ip, socket.gethostbyname(socket.gethostname())))
				else:
					# On écrit les IP avec l'heure des ban
					target.write(ip + ' ' + hour + '\n')

		# On relache le verroux
		lock.release()

		# On s'endort
		try:
			time.sleep(min([val for val in hash_ip.values()]))
		except ValueError:
			time.sleep(period)




def daemon(lock, cfg, ban_file, sock):
	loop     = True # Permet ou non de quitter la boucle
	data     = None # Permet de récupérer les données par le serveur
	string   = ""   # Chaine qui va permettre de découper data correctement
	dic_ip   = {}   # Dictionnaire contenant les IP flashées mais pas encore bannies
	ip_regex = re.compile(r'(([\d]+\.){3}[\d]+)') # Expression régulière pour trouver les IP


	while loop:
		try:
			# On récupère les données sur la socket
			data = sock.recv(4096)
		except socket.timeout:
			logging.critical("Timeout")
			loop = False

		# Si aucune donnée n'est dans data, on coupe la connexion
		if not data:
			loop = False

		# Si la taille est négative, c'est qu'il y a eu une erreur de lecture
		if len(data) < 0:
			logging.critical("Misreading !")
			sys.exit(2)

		# On parcourt toutes les lettres reçues
		for letter in data.decode('utf8', 'ignore'):
			# Si la lettre correspond à '\r', on ne fait rien
			if letter == '\r':
				continue

			# Si la lettre correspond à '\n', on a reçu une ligne complète
			elif letter == '\n':
				if len(string) == 0:
					continue

				# Si la chaine n'est pas vide, on va la traiter
				else:
					# On parcourt toutes les erreurs listées
					for err in cfg['error']:
						# Si l'erreur en court fait partie de la chaine
						if err in string:
							# On récupère l'adresse IP de la chaine
							res = ip_regex.search(string)
							if res:
								# On stocke cette adresse
								the_ip = res.group(1)

								# Si l'IP fait partie des adresses à ne pas bannir, on ne va pas plus loin
								if the_ip in cfg['autorised ip']:
									# On l'indique quand même dans les logs
									logging.warning('User identified bye the IP %s was wrong in the password !' %(the_ip))
									break

								# Si l'IP existe dans le dictionnaire
								if the_ip in dic_ip.keys():
									# On détermine le temps depuis la dernière erreur
									diff = time.time() - dic_ip[the_ip].time

									# Si cela fait moins de 15s on augmente le compteur de 1
									if diff <= cfg['max second']:
										dic_ip[the_ip].set_number()

									# Autrement on remet le compteur à 1 pour éviter de bannir des faux positifs
									else:
										dic_ip[the_ip].reset_number()

									# On réinitialise à l'heure actuelle
									dic_ip[the_ip].time = time.time()

									# Si l'adresse IP a été enregistrée trop souvent, on la banni
									if dic_ip[the_ip].number >= cfg['attempts']:
										os.system('iptables -I INPUT -s %s -d %s -j DROP' %(the_ip, socket.gethostbyname(socket.gethostname())))

										# On demande le verrou
										lock.acquire()
										# On enregistre l'IP avec l'heure à laquelle on l'a banni
										with open(ban_file, 'a') as target:
											target.write(the_ip + " " + str(time.time()).split(',')[0] + "\n")

										# On relache le verrou
										lock.release()
										# On écrit dans le log
										logging.warning(the_ip + " banned !")

										# On supprime la clef du dictionnaire
										del(dic_ip[the_ip])

								# Si l'IP n'existe pas dans le dictionnaire
								else:
									# On rajoute l'IP
									dic_ip[the_ip] = Ip()

							# Vu que l'on a pris l'IP pour cette erreur, pas besoin de chercher avec les autres
							break

				# On réinitialise la chaine de départ
				string = ""

			# La chaine n'est pas une ligne finie
			else:
				# On ajoute le lettre à la fin de la chaine existante
				string += letter

	# On ferme la connexion avec le serveur
	sock.close()




def init_connection(cfg):
	sock   = None # Permet de stocker l'objet socket

	try:
		# Définition de la socket
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	except socket.error as e:
		print("Unable to create socket : %s" %(e))
		logging.critical("Unable to create socket : %s" %(e))
		sys.exit(2)

	try:
		# Connection
		sock.connect((cfg['listen ip'], cfg['listen port']))
	except socket.error as e:
		print("Unable to connect at %s on port %s : %s" %(cfg['listen ip'], cfg['listen port'], str(e)))
		logging.critical("Unable to connect at %s on port %s : %s" %(cfg['listen ip'], cfg['listen port'], str(e)))
		sys.exit(2)

	return sock




def read_ban_file(lock, ban_file):
	# On définit un dictionnaire pour stocker les ip et l'heure a laquelles elles ont été flashées
	hash_ip = {}
	# On récupère le verrou
	lock.acquire()
	# On ouvre le fichier des adresses ip qui ont été bannies
	src = open(ban_file, 'r')
	while 1:
		# On lit le fichier ligne par ligne
		line = src.readline()
		# Si on est arrivé à la fin du fichier (EOF) on s'arrête
		if not line:
			break

		# Si c'est une ligne vide, on passe à la ligne suivante
		if line == '\n':
			continue

		# On récupère l'IP et l'heure en découpant la chaine
		ip, hour = line.split(' ')
		# On converti l'heure et on ajoute la période pour savoir si on débannie l'IP. Si c'est supérieur, on la laisse dans le fichier
		hash_ip[ip] = float(hour)

	# On ferme le fichier
	src.close()
	# On relache le verrou
	lock.release()

	return hash_ip




def read_conf_file(conf):
	data = str()

	try:
		# On charge le fichier de configuration
		file_yaml = open(conf, 'r')
		# On lit le fichier de configuration avec la méthode safe
		data = yaml.safe_load(file_yaml.read())
		# On ferme le fichier
		file_yaml.close()

	# Une exception est levée s'il y a un problème à la lecture
	except yaml.parser.ParserError as e:
		print("Unable to load configuration. Mistake : \"%s\"\nVerify you have start systemd-journal-gatewayd.service" %(e))
		logging.critical("Unable to load configuration. Mistake : \"%s\"\nVerify you have start systemd-journal-gatewayd.service" %(e))
		sys.exit(2)

	# Si aucune donnée n'a été lu, on arrête le programme
	if not data:
		print("\"%s\" is an empty file !" % (conf))
		logging.critical("\"%s\" is an empty file !" %(conf))
		sys.exit(2)

	return data




def load_banned_ip(lock, ban_file):
	# On récupère les adresses ip bannies
	hash_ip = read_ban_file(lock, ban_file)

	# On bannit toutes les ip se trouvant dans le fichier
	for ip in hash_ip.keys():
		os.system('iptables -I INPUT -s %s -d %s -j DROP' %(ip, socket.gethostbyname(socket.gethostname())))




if __name__ == "__main__":
	ban_file  = "/var/log/sshd_autoban/banned_ip"
	conf_file = "/etc/sshd_autoban.conf"
	log_file  = "/var/log/sshd_autoban/main.log"
	logging.basicConfig(filename=log_file, format='%(asctime)s %(message)s', level=logging.WARNING)

	lock = Lock()
	
	# On regarde si le fichier de configuration existe
	if not os.path.exists(conf_file):
		print("File \"%s\" not found !" %(conf_file))
		logging.critical("File \"%s\" not found !" %(conf_file))
		sys.exit(2)

	# On charge la configuration
	conf = read_conf_file(conf_file)
#	# On rebannie les adresses IP qui sont toujours dans ban_file
	load_banned_ip(lock, ban_file)
	# On initialise la connexion
	sock = init_connection(conf)
	# On envoie un message à journalctl
	sock.send("GET /entries?boot&follow HTTP/1.1\r\n\r\n".encode('ascii'))
	
	# Lancement des deux processus en parallèle
	Process(target=daemon, args=(lock, conf, ban_file, sock)).start()
	Process(target=clean, args=(lock, conf, ban_file)).start()
