extern int get_sa_error(SaAisErrorT error, char *str, int len);

extern char *get_sa_error_b (SaAisErrorT error);

extern char *get_test_output (SaAisErrorT result, SaAisErrorT expected);
