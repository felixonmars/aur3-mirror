#ifndef _SERV_MAIN_H
#define _SERV_MAIN_H

#endif	/* _SERV_MAIN_H */
