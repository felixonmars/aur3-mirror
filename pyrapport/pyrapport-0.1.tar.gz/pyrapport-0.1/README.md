pyrapport
====

It create a LaTeX rapport

Depend
======

python3

Installation
============

```
python setup.py install
```

Usage
=====

```
python pyrapport
```
