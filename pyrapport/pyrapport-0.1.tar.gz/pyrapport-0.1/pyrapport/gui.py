#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import os
import shutil
import subprocess

#import pudb

from PyQt4 import QtGui
from PyQt4 import QtCore
from PyQt4.QtCore import pyqtSlot

from functools import partial

from .main_gui import Ui_Dialog
from .about_gui import Ui_aboutWidget


ICONS_PATH = "/usr/share/pyrapport/icons/"
#ICONS_PATH = "icons/"
DATA_PATH = "/usr/share/pyrapport/data/"
#DATA_PATH = "/home/julien/Python/Qt/Rapport_eleve/data/"

ACT_LIST = ["Oublis de matériel répétitif", "Refus d'obéissance", "Insolence",
            "Irrespect", "Insulte", "Insulte à caractère raciste", "Menace",
            "Bagarre", "Violence sexuelle", "Vol", "Racket - trafic",
            "Consommation de produits illicites", "Vandalisme",
            "Tag - graffitis", "Salissure délibérée",
            "Consommation d'alcool et/ou de tabac", "Cours séché",
            "Absentéisme", "Retards répétitifs"]

SANCTION_LIST = ["Heure de colle", "Avertissement", "Exclusion temporaire",
                 "Conseil de discipline"]

FOLLOW_LIST = ["Expulsion du cours", "Rien"]

HOURS_LIST = ["1 heure", "2 heures", "3 heures", "4 heures"]


class About_gui(QtGui.QDialog, Ui_aboutWidget):
    def __init__(self, x, y, width, height, parent=None):
        """Init function. It create the about gui and init some objects."""
        super(About_gui, self).__init__(parent)
        self.setupUi(self)

        # Fenêtre toujours centrée sur la parente
        self.move((x + width / 2) - self.width() / 2,
                  (y + height / 2) - self.height() / 2)

        self.closeButton.setIcon(QtGui.QIcon(os.path.join(ICONS_PATH,
                                                          'close.png')))
        self.logoLabel.setPixmap(QtGui.QPixmap(os.path.join(ICONS_PATH,
                                                            'pyrapport.png')))

    def on_closeButton_clicked(self):
        self.close()


class Gen_thread(QtCore.QThread):
    increment = QtCore.pyqtSignal(int)

    def __init__(self, parent, filename):
        super(Gen_thread, self).__init__(parent)

        self.filename = filename
        self.cancelled = False

    def run(self):
        # Compilation LaTeX
        for i in range(2):
            self.increment.emit(i)
            subprocess.getoutput('pdflatex {0}'.format(self.filename))

        name, _ = os.path.splitext(self.filename)
        file_to_remove = ["Eco_responsable.jpg", "G_Brassens.png",
                          name + '.aux', name + '.log']

        for f in file_to_remove:
            os.remove(f)

    def cancel(self):
        self.cancelled = True
        self.terminate()


class Main_gui(QtGui.QDialog, Ui_Dialog):
    def __init__(self, parent=None):
        """Init function. It create the main gui and init some objects."""

        super(Main_gui, self).__init__(parent)
        self.setupUi(self)

        self.init_location()
        self.init_datetime()
        self.init_list()
        self.init_icons()
        self.init_signals()

    def init_location(self):
        self.location_lineEdit.setText(os.path.expanduser('~'))

    def init_datetime(self):
        """Init date and hour objects Qt."""

        # Mise en place des dates
        self.date_faits.setDate(QtCore.QDate(QtCore.QDate.currentDate()))
        self.date_signalement.setDate(QtCore.QDate(QtCore.QDate.currentDate()))
        # Mise en place de l'heure
        self.heure_faits.setTime(QtCore.QTime(QtCore.QTime.currentTime()))

    def init_list(self):
        """Init combo list."""

        # Mise en place des listes (combobox)
        for act in ACT_LIST:
            self.acte_combo.addItem(act)

        for sanction in SANCTION_LIST:
            self.sanction_combo.addItem(sanction)

        for follow in FOLLOW_LIST:
            self.follow_combo.addItem(follow)

        for hour in HOURS_LIST:
            self.hoursCombo.addItem(hour)

    def init_icons(self):
        """Place all icons on objects."""

        # Mise en place des icônes
        self.aboutButton.setIcon(QtGui.QIcon(os.path.join(ICONS_PATH,
                                                          "about.png")))
        self.quitButton.setIcon(QtGui.QIcon(os.path.join(ICONS_PATH,
                                                         "quit.png")))
        self.okButton.setIcon(QtGui.QIcon(os.path.join(ICONS_PATH, "ok.png")))
        self.toolButton.setIcon(QtGui.QIcon(os.path.join(ICONS_PATH,
                                                         "open.png")))

    def init_signals(self):
        """It connects signals."""

        # Mise en place des signaux
        self.sanction_combo.activated[str].connect(self.on_Activated_sanction)
        self.location_lineEdit.editingFinished.\
            connect(self.handle_editing_finished)
        self.nomLineEdit.editingFinished.connect(self.__modifyLocation)
        self.prenomLineEdit.editingFinished.connect(self.__modifyLocation)
        self.classeLineEdit.editingFinished.connect(self.__modifyLocation)

# events / signals

    def on_Activated_sanction(self, text):
        """Hidden or not hoursCombo list"""

        if text == 'Heure de colle':
            self.hoursCombo.setHidden(False)
        else:
            self.hoursCombo.setHidden(True)

    def handle_editing_finished(self):
        text = self.location_lineEdit.text()

        if text != '':
            if os.path.splitext(text)[1] != '':
                return

            if not os.path.exists(text):
                QtGui.QMessageBox.\
                    warning(self, 'Erreur',
                            "L'emplacement \"{0}\" n'existe pas".format(text))

            elif not os.path.isdir(text):
                QtGui.QMessageBox.\
                    warning(self, 'Erreur',
                            "L'emplacement \"{0}\" n'est pas un répertoire".
                            format(text))

            elif not os.access(text, os.W_OK):
                QtGui.QMessageBox.\
                    warning(self, 'Erreur',
                            "Vous n'avez pas les droits d'écriture sur \"{0}\""
                            .format(text))

    def incProgress(self, val):
        self.progress.setValue(val)

    def keyPressEvent(self, event):
        """Capture event escape key on keyboard and ignore this event since
        it quit programme."""

        if event.key() == QtCore.Qt.Key_Escape:
            event.ignore()

    def on_aboutButton_clicked(self):
        """When aboutButton is clicked."""

        self.about = About_gui(self.geometry().x(), self.geometry().y(),
                               self.width(), self.height())
        self.about.show()

    @pyqtSlot()
    def on_toolButton_clicked(self):
        """When toolButton is clicked."""

        filename = QtGui.\
            QFileDialog.getExistingDirectory(self, 'Choisissez un répertoire')

        if filename != '':
            if not os.path.exists(filename):
                QtGui.QMessageBox.\
                    warning(self, 'Erreur',
                            "L'emplacement \"{0}\" n'existe pas".
                            format(filename))
                return

            elif not os.path.isdir(filename):
                QtGui.QMessageBox.\
                    warning(self, 'Erreur',
                            "L'emplacement \"{0}\" n'est pas un répertoire".
                            format(filename))
                return

            elif not os.access(filename, os.W_OK):
                QtGui.QMessageBox.\
                    warning(self, 'Erreur',
                            "Vous n'avez pas les droits d'écriture sur \"{0}\""
                            .format(filename))
                return

            self.location_lineEdit.setText(filename)
            self.__modifyLocation()

    @pyqtSlot()
    def on_okButton_clicked(self):
        """When okButton is clicked."""

        # On récupère toutes les données
        location = self.location_lineEdit.text()
        dateSignalement = self.date_signalement.date().toPyDate() \
            .strftime('%d/%m/%Y')
        dateFaits = self.date_faits.date().toPyDate().strftime('%d/%m/%Y')
        nom = self.nomLineEdit.text()
        prenom = self.prenomLineEdit.text()
        classe = self.classeLineEdit.text()
        typeActe = self.acte_combo.currentText()
        heureFaits = self.heure_faits.time().toPyTime().strftime('%H h %M')
        explications = self.plainTextEdit.toPlainText()
        suiteImmediate = self.follow_combo.currentText()
        sanctionDemande = self.sanction_combo.currentText()
        heureDeColle = self.hoursCombo.currentText()

        if not self.__test_location(location) \
                or not self.__test_string(nom, 'le nom') \
                or not self.__test_string(prenom, 'le prénom') \
                or not self.__test_string(classe, 'la classe') \
                or not self.__test_explications(explications):
            return

#        explications = explications.replace('\n', '\\\\\\noindent\n')

        # On sauvegarde les données dans le fichier spécifié
        root, filename = os.path.split(location)
        os.chdir(root)

        with open(os.path.join(DATA_PATH, 'src.tex'), 'r') as src:
            with open(filename, 'w') as target:
                for line in src:
                    if '~DATE_SIGNALEMENT~' in line:
                        line = line.replace('~DATE_SIGNALEMENT~',
                                            dateSignalement)
                    if '~DATE_FAITS~' in line:
                        line = line.replace('~DATE_FAITS~', dateFaits)
                    if '~NOM~' in line:
                        line = line.replace('~NOM~', nom)
                    if '~PRENOM' in line:
                        line = line.replace('~PRENOM~', prenom)
                    if '~CLASSE~' in line:
                        line = line.replace('~CLASSE~', classe)
                    if '~TYPE_ACTE~' in line:
                        line = line.replace('~TYPE_ACTE~', typeActe)
                    if '~HEURE~' in line:
                        line = line.replace('~HEURE~', heureFaits)
                    if '~EXPLICATIONS~' in line:
                        line = line.replace('~EXPLICATIONS~', explications)
                    if '~SUITE_IMMEDIATE~' in line:
                        line = line.replace('~SUITE_IMMEDIATE~',
                                            suiteImmediate)
                    if '~SANCTION_DEMANDE~' in line:
                        if sanctionDemande == 'Heure de colle':
                            line = line.replace('~SANCTION_DEMANDE~',
                                                heureDeColle)
                        else:
                            line = line.replace('~SANCTION_DEMANDE~',
                                                sanctionDemande)

                    target.write(line)

        # Copie des images
        self.__copying_picture(root)
        self.__generate_progress(root, filename)

# Private methode

    def __copying_picture(self, root):
        shutil.copy2(os.path.join(DATA_PATH, 'Eco_responsable.jpg'), root)
        shutil.copy2(os.path.join(DATA_PATH, 'G_Brassens.png'), root)

    def __finish(self, r):
        if not self.thread.cancelled:
            QtGui.QMessageBox.information(self, 'Information',
                                          "Opération terminée avec succès !")

            self.location_lineEdit.setText(r)
            self.nomLineEdit.clear()
            self.prenomLineEdit.clear()

    def __generate_progress(self, root, filename):
        self.progress = QtGui.\
            QProgressDialog("Génération du rapport", "Annuler", 0, 1, self)
        self.thread = Gen_thread(self, filename)

        self.thread.increment.connect(self.incProgress)
        self.thread.finished.connect(partial(self.__finish, r=root))
        self.progress.canceled.connect(self.thread.cancel)

        self.progress.show()
        self.thread.start()

    def __modifyLocation(self):
        nom = self.nomLineEdit.text()
        prenom = self.prenomLineEdit.text()
        classe = self.classeLineEdit.text()

        if nom != '' and prenom != '' and classe != '':
            nom = nom.replace(' ', '_')
            prenom = prenom.replace(' ', '_')
            classe = classe.replace(' ', '_')

            text = self.location_lineEdit.text()
            if os.path.isdir(text):
                self.location_lineEdit.\
                    setText(os.path.join(text, nom + prenom + classe + '.tex'))
            else:
                self.location_lineEdit.\
                    setText(os.path.join(os.path.dirname(text),
                                         nom + prenom + classe + '.tex'))

    def __test_location(self, location):
        root, filename = os.path.split(location)

        if not os.path.exists(root):
            QtGui.QMessageBox. \
                warning(self, 'Erreur', "L'emplacement \"{0}\" n'existe pas !".
                        format(root))
            return False

        if not os.access(root, os.W_OK):
            QtGui.QMessageBox. \
                warning(self, 'Erreur',
                        "Vous n'avez pas les droits d'écritures sur \"{0}\" !".
                        format(root))
            return False

        if os.path.exists(location):
            QtGui.QMessageBox. \
                warning(self, 'Erreur',
                        "Le fichier \"{0}\" existe !".format(location))
            return False

        return True

    def __test_string(self, nom, element):
        if nom == '':
            QtGui.QMessageBox.\
                warning(self, 'Erreur',
                        "Vous devez indiquer \"{0}\" de l'élève !".
                        format(element))
            return False

        return True

    def __test_explications(self, explications):
        if explications == '':
            QtGui.QMessageBox.warning(self, 'Erreur',
                                      "Vous devez indiquer des explications !")
            return False

        return True
