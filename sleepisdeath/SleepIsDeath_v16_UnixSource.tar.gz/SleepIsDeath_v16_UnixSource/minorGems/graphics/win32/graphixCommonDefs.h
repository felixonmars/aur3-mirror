// ALifeGUICommonDefs.h


// common definitions for ALifeGui



#define WINDOWS_KEY_CODES