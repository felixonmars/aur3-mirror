// ALifeGUICommonDefs.h


// common definitions for ALifeGui



#define MAC_KEY_CODES