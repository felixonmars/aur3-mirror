// ALifeGUICommonDefs.h


// common definitions for ALifeGui



#define LINUX_KEY_CODES
