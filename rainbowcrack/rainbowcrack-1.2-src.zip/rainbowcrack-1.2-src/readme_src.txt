RainbowCrack 1.2 source

openssl is required to build the source

build the source in windows:
	nmake -f makefile.win

build the source in linux:
	make -f makefile.linux

Zhu Shuanglei <shuanglei@hotmail.com>
http://www.antsight.com/zsl/rainbowcrack/
2003/11/21
