/* root tail compile time defaults */

#define DEF_COLOR       "white"
#define DEF_CONT_COLOR  "grey"


//default font.. -font at runtime should work
#define USE_FONT        "*"

//default positions.. can be changed with -g at runtime
#define STD_WIDTH       730
#define STD_HEIGHT      530
#define LOC_X           30
#define LOC_Y           30

#define VERSION "1.2"

