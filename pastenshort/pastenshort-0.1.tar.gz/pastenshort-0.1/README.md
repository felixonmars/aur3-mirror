pastenshort
====

It paste a file and short the url.

Depend
======

python3

Installation
============

```
git clone https://github.com/Chipsterjulien/pastenshort.git
python setup.py install
```

Usage
=====

```
python pastenshort -h
```
