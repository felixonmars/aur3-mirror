/***************************************************************************
             PosixSerial.cpp - Serial Communictaion in Posix standard
                             -------------------
    begin                : Die Aug 12 10:16:57 CEST 2003
    copyright            : (C) 2003 DLR RM by Jan Grewe
    email                : jan.grewe@dlr.de
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 +   any later version.                                                    *
 *                                                                         *
 ***************************************************************************/

/***************************************************************************
	Ver      date       Author        comment
	--------------------------------------------------------------------------
	1.0   12.08.2003    Jan Grewe     build
 ***************************************************************************/ 
#include <stdio.h>
#include <iostream>
#include <stdlib.h>

#include "PosixSerial.h"

CPosixSerial::CPosixSerial()
{
	
}

CPosixSerial::~CPosixSerial()
{

}

bool CPosixSerial::Open(unsigned int port)
{
	char text[256];
	sprintf(m_portName,"/dev/ttyS%d",port);

	m_portHandle = open ((const char*)m_portName, O_RDWR | O_NOCTTY);
	if (m_portHandle == -1) {
		sprintf(text,"Could not open %s\nAlready in use ?!?!\n",m_portName);
		MyMessageBox(text);
		return false;
	}
	// configure port settings
	tcgetattr(m_portHandle, &CommConfig);

	// 2400 Baud / Data Size 8-Bit / 1 Stop Bit / No Parity / No Flow Control / Zero TimeOut
	CommConfig.c_cflag = CREAD|CLOCAL|B2400|CS8;
	CommConfig.c_lflag = 0;
	CommConfig.c_oflag = 0;
	CommConfig.c_iflag = 0;
	CommConfig.c_cc[VMIN] = 0;
	CommConfig.c_cc[VTIME]= 0;
	
	// Set DTR & RTS
	ioctl(m_portHandle, TIOCMSET, TIOCM_DTR | TIOCM_RTS);

	if (tcsetattr(m_portHandle, TCSAFLUSH, &CommConfig)) {
		sprintf(text,"Can't write port settings on %s\n",m_portName);
		MyMessageBox(text);
		return false;
	}
	return true;
}

void CPosixSerial::Close(void)
{
	close(m_portHandle);
}

void CPosixSerial::ClearBuffer(void)
{
}

int CPosixSerial::Read(char* data, unsigned int length)
{
	int ret;
	char text[256];
	ret = read(m_portHandle,data,length);
	if (ret == -1) {
		sprintf(text,"Can't read from %s",m_portName);
		MyMessageBox(text); 
	} 
	return ret;	
}

int CPosixSerial::Write(char* data, unsigned int length)
{
	int ret;
	char text[256];
	ret = write(m_portHandle,data,length);
	if (ret == -1) {
		sprintf(text,"Can't write to %s",m_portName);
		MyMessageBox(text);
	}
	return ret; 
}

void CPosixSerial::Timeout(unsigned int timeout) //msec
{
	CommConfig.c_cc[VTIME]=timeout/100;
	tcsetattr(m_portHandle, TCSAFLUSH, &CommConfig);
}

void CPosixSerial::MyMessageBox(char* Text)
{
	std::cout << Text << std::endl;
}
	
