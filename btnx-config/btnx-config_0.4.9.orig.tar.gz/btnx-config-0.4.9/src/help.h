
 /* 
  * Copyright (C) 2007  Olli Salonen <oasalonen@gmail.com>
  * see btnx-config.c for detailed license information
  */

#ifndef HELP_H_
#define HELP_H_

#endif /*HELP_H_*/
