
 /* 
  * Copyright (C) 2007  Olli Salonen <oasalonen@gmail.com>
  * see btnx-config.c for detailed license information
  */

#ifndef STATUS_BAR_H_
#define STATUS_BAR_H_

#endif /*STATUS_BAR_H_*/
