
 /* 
  * Copyright (C) 2007  Olli Salonen <oasalonen@gmail.com>
  * see btnx-config.c for detailed license information
  */

#include <gtk/gtk.h>

#include "status_bar.h"

//static int num_messages=0;

enum
{
	STATUS_MSG_DEFAULT=0,
	STATUS_MSG_SAVED,
	STATUS_MSG_BTNX_RESTART
};

void status_set_message(int msg)
{
	
}
