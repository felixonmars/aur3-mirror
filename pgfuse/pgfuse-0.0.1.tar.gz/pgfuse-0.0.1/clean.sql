DROP RULE dir_insert ON dir;
DROP RULE dir_remove ON dir;
DROP TABLE data;
DROP TABLE dir;
