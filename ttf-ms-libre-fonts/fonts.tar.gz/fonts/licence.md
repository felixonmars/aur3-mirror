*Matthan Sans* and *Stanberry* fonts 
by [**Grandos Plex**](http://grandchaos9000.deviantart.com)

Distributed under Creative Commons Attribution-ShareAlike 
[CC BY-SA](https://creativecommons.org/licenses/by-sa/4.0/)

as per note on: [Font Usage Policy](http://grandchaos9000.deviantart.com/journal/Font-Usage-Policy-465400395)
