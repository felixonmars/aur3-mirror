/*
-----------------------------------------------------------------------------
 $Id: pal_stdarg.h,v 1.1 2009/11/20 16:38:53 jasminko Exp $
-----------------------------------------------------------------------------
Copyright (c) 2007 gogo6 Inc. All rights reserved.

  For license information refer to CLIENT-LICENSE.TXT
-----------------------------------------------------------------------------

  Platform abstraction layer for stdarg.

-----------------------------------------------------------------------------
*/
#ifndef __PAL_STDARG_H__
#define __PAL_STDARG_H__

#include <stdarg.h>

#endif
