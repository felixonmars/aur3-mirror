/*
---------------------------------------------------------------------------
 $Id: platform.h,v 1.1 2009/11/20 16:53:23 jasminko Exp $
---------------------------------------------------------------------------
Copyright (c) 2001-2007 gogo6 Inc. All rights reserved.

  For license information refer to CLIENT-LICENSE.TXT
  
---------------------------------------------------------------------------
*/
#ifndef _PLATFORM_H_
#define _PLATFORM_H_

/* FreeBSD */

#include "pal.h"

#define V4V6_SUPPORT

#define SCRIPT_TMP_FILE                   "/tmp/gogoc-tmp.log"

#endif
