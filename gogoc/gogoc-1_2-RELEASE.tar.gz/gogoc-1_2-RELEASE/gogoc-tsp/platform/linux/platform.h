/*
---------------------------------------------------------------------------
 $Id: platform.h,v 1.1 2009/11/20 16:53:24 jasminko Exp $
---------------------------------------------------------------------------
This source code copyright (c) gogo6 Inc. 2002-2007.

  For license information refer to CLIENT-LICENSE.TXT
  
---------------------------------------------------------------------------
*/
#ifndef _PLATFORM_H_
#define _PLATFORM_H_

/* Linux */

#include "pal.h"

#define SCRIPT_TMP_FILE                   "/tmp/gogoc-tmp.log"

#endif
