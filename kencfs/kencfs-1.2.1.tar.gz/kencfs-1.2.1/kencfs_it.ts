<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it_IT">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>KEncFs - (c) 2010 by Felice Murolo - Salerno - Italia</source>
        <oldsource>KEncFs - (ac) 2010 by Felice Murolo - Salerno - Italia</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="27"/>
        <source>Encrypted FileSystem</source>
        <oldsource>Crypted FileSystem</oldsource>
        <translation>FileSystem Criptati</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="88"/>
        <source>&amp;Remove</source>
        <oldsource>&amp;Rimuovi</oldsource>
        <translation>&amp;Rimuovi</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="97"/>
        <source>&amp;Mount</source>
        <oldsource>&amp;Monta</oldsource>
        <translation>&amp;Monta</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="104"/>
        <source>&amp;Umount</source>
        <oldsource>&amp;Smonta</oldsource>
        <translation>&amp;Smonta</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="75"/>
        <source>&amp;Add</source>
        <translation>&amp;Aggiungi</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="111"/>
        <source>&amp;Browse</source>
        <translation>A&amp;pri</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>&amp;Hide</source>
        <translation>&amp;Nascondi</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="138"/>
        <location filename="mainwindow.ui" line="207"/>
        <source>&amp;Exit</source>
        <oldsource>&amp;Esci</oldsource>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="161"/>
        <source>&amp;File</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="183"/>
        <source>&amp;Hide / Show</source>
        <translation>&amp;Nascondi / Mostra</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="186"/>
        <source>Hide / Show</source>
        <translation>&amp;Nascondi / Mostra</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="191"/>
        <source>&amp;Config</source>
        <oldsource>&amp;Configura</oldsource>
        <translation>&amp;Configura</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="194"/>
        <source>Config</source>
        <oldsource>Configura</oldsource>
        <translation>&amp;Configura</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="199"/>
        <source>&amp;About</source>
        <translation>&amp;Informazioni</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="202"/>
        <source>About</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="210"/>
        <source>Exit</source>
        <translation>Esci</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="76"/>
        <source>Mount Point</source>
        <translation>Punto di Mount</translation>
    </message>
    <message>
        <source>Crypted Directory</source>
        <translation type="obsolete">Directory Criptata</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="76"/>
        <source>FileSystem ID</source>
        <translation>ID FileSystem</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="76"/>
        <source>Status</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="76"/>
        <source>Encrypted Directory</source>
        <translation>Directory Criptata</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="91"/>
        <source>Add</source>
        <translation>Aggiungi</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="92"/>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="93"/>
        <source>Mount</source>
        <translation>Monta</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="94"/>
        <source>Umount</source>
        <translation>Smonta</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="95"/>
        <source>Browse</source>
        <oldsource>Browse FS</oldsource>
        <translation>Apri</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="223"/>
        <source>Mounted</source>
        <oldsource>Montato</oldsource>
        <translation>Montato</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="main.cpp" line="33"/>
        <source>I couldn&apos;t detect any system tray on this system.</source>
        <translation>Non ho trovato nessun vassoio di sistema in questo sisistema</translation>
    </message>
</context>
<context>
    <name>configDialog</name>
    <message>
        <location filename="configdialog.ui" line="14"/>
        <source>KEncFS - Confguration</source>
        <oldsource>KEncFS - Configurazione</oldsource>
        <translation>KEncFS - Configurazione</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="32"/>
        <source>&amp;Start in TrayBar</source>
        <oldsource>Start in TrayBar</oldsource>
        <translation>&amp;Avvia nel vassoio di sistema</translation>
    </message>
    <message>
        <location filename="configdialog.ui" line="52"/>
        <source>&amp;Browse after mount</source>
        <translation>A&amp;pri dopo aver montato</translation>
    </message>
</context>
<context>
    <name>fsDialog</name>
    <message>
        <location filename="fsdialog.ui" line="14"/>
        <source>KEncFs - Add FileSystem</source>
        <translation type="unfinished">KEncFs - Aggiungi FileSystem</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="22"/>
        <source>FileSystem ID</source>
        <translation>ID FileSystem</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="36"/>
        <source>Mountpoint</source>
        <oldsource>Punto di mount</oldsource>
        <translation>Punto di Mount</translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="50"/>
        <location filename="fsdialog.ui" line="71"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="fsdialog.ui" line="57"/>
        <source>Encrypted Directory</source>
        <oldsource>Crypted Directory</oldsource>
        <translation>Directory Criptata</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="56"/>
        <source>Select encrypted existing directory or create new</source>
        <oldsource>Select crypted existing directory or create new</oldsource>
        <translation>Seleziona la directory criptata o creane una nuova</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="64"/>
        <source>Select mountpoint existing directory or create new</source>
        <translation>Seleziona la directory per montaggio del FS o creane una nuova</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="81"/>
        <location filename="fsDialog.cpp" line="167"/>
        <source>Mounted</source>
        <oldsource>Montato</oldsource>
        <translation>Montato</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="38"/>
        <location filename="fsDialog.cpp" line="41"/>
        <location filename="fsDialog.cpp" line="44"/>
        <location filename="fsDialog.cpp" line="114"/>
        <location filename="fsDialog.cpp" line="115"/>
        <location filename="fsDialog.cpp" line="141"/>
        <source>Fatal Error</source>
        <oldsource>Errore fatale</oldsource>
        <translation>Errore Fatale</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="38"/>
        <source>Warning! &apos;encfs&apos; is not installed.

Please, install it!

</source>
        <translation>Attenzione! &apos;encfs&apos; non e&apos; installato.

Per piacere, installalo!

</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="41"/>
        <source>Warning! &apos;fusermount&apos; is not installed.

Please, install it!

</source>
        <translation>Attenzione! &apos;fusermount&apos; non e&apos; installato.

Per piacere, installalo!

</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="44"/>
        <source>Warning! &apos;dolphin&apos; is not installed.

Please, install it!

</source>
        <translation>Attenzione! &apos;dolphin&apos; non e&apos; installato.

Per piacere, installalo!

</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="114"/>
        <source>Warning! MountPoint directory doesn&apos;t exists

</source>
        <translation>Attenzione! La directory ove montare il filesystem non esiste

</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="115"/>
        <source>Warning! Encrypted directory doesn&apos;t exists

</source>
        <translation>Attenzione! La directory criptata non esiste

</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="127"/>
        <source>Password for Encrypted FileSystem:</source>
        <translation>Password per il FileSystem Criptato:</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="141"/>
        <source>Mount error!

</source>
        <translation>Errore di montaggio!

</translation>
    </message>
    <message>
        <source>Warning! Crypted directory doesn&apos;t exists

</source>
        <translation type="obsolete">Attenzione! La directory criptata non esiste

</translation>
    </message>
    <message>
        <location filename="fsDialog.cpp" line="127"/>
        <source>Password Request</source>
        <oldsource>Richiesta Password</oldsource>
        <translation>Richiesta password</translation>
    </message>
</context>
</TS>
