aclocal
autoheader
touch stamp-h
autoconf
automake -a -c