#!/bin/bash

recsel -e 'Istmenge < Sollmenge' -p Bezeichnung,Artikelnummer,Istmenge,Sollmenge tools.rec
