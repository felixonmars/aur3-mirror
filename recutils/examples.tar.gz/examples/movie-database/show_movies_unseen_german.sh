#!/bin/bash

recsel -e "Viewed < 1 && Audio = 'German'" -p Id,Title,Audio,Viewed movies.rec
