#!/bin/bash

recsel -c -e "Audio = 'German'" movies.rec

