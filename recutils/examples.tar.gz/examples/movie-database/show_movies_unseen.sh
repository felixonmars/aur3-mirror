#!/bin/bash

recsel -e "Viewed < 1" -p Id,Title,Audio,Viewed movies.rec
