#!/bin/bash

recsel -t movies -e "Amount_of_Media > 2" movies.rec

