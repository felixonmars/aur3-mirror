#!/bin/bash

recsel -c movies.rec

