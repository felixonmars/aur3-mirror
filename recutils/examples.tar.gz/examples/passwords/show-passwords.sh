#!/bin/bash

recsel passwords.rec
