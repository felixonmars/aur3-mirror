#!/bin/bash

recsel -s mypassword passwords.rec
