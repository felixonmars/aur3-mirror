/*
 * WMMail - Window Maker Mail
 *
 * Copyright (c) 1996, 1997, 1998  Per Liden
 * Copyright (c) 1997, 1998  Bryan Chan
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 * global.c: global data
 *
 * $Id: global.c,v 1.1 2000/07/02 20:37:58 bryan.chan Exp $
 *
 */

#include "wmmail.h"

LinkedList *mailbox_list = NULL;
int mailbox_count = 0;

XpmIcon *animations[3] = { NULL, NULL, NULL };

/* status of wmmail */
int wmmail_status   = NO_MAIL;
int overridden      = False;

/* user-specified options */
int always_new_mail_exec = False;
int anim_speed[3]        = { DEFAULT_ANIM_SPEED,
                             DEFAULT_ANIM_SPEED,
                             DEFAULT_ANIM_SPEED };
int double_click_time    = 250;
int keep_quiet           = False;
int num_of_msg_mode      = SHOW_NONE;
int num_of_msg_x         = 0;
int num_of_msg_y         = 10;
int use_appicon_only     = True;
int use_beep             = True;
int display_names        = False;

char *app_name              = NULL;
char *user_specified_domain = NULL;
char *exec_on_click         = NULL;
char *exec_on_new           = NULL;
char *wmmail_color          = DEFAULT_COLOR;

/* X stuff */
Display      *disp;
Pixmap       shape_mask;
GC           shape_mask_gc;
GC           wmmail_gc;
Font         wmmail_font;
XtAppContext wmmail_context;
Widget       wmmail_widget;
Widget       wmmail_appicon;
Window       root;
