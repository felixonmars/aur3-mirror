Imagesat
====

It's a python's script who download some pictures into /tmp directory
(see imagesat_example.conf) and you can display them with conky or conky
 like (dzen2, ...)
This script can search, with regexp, a picture to download on html page,
even name of picture change all the time


Depend
======

yaml-python, python-requests


Installation
============

```
git clone https://github.com/Chipsterjulien/imagesat.git
python setup.py install
```


Usage
=====

```
python imagesat -h
```



License
=======
<a href="http://en.wikipedia.org/wiki/Gplv3#Version_3">GPL v3</a>
