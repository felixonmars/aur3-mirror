#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from sys import exit
from os.path import split, isfile, exists
from os import access, stat, R_OK, W_OK
from time import time, sleep, strftime
from io import BytesIO
from gzip import GzipFile
from Image import open as open_image
from Image import ANTIALIAS
from urllib.request import build_opener
from xml.etree.ElementTree import parse


# Vérifier si le fichier de configuration est vide
# Vérifier si le fichier de configuration est OK



######
# Début de la classe Img
############

class Img:
	def __init__(self):
		self.url         = str()
		self.page        = str()
		self._path       = str()
		self.search      = str()
		self._time       = int()
		self._crop       = []
		self._resize     = []

	def _get_crop(self):
		return self._crop


	def _set_crop(self, c):
		for val in c.split("x"):
			if _isNumber(val):
				self._crop.append(int(val))
			else:
				with open(errorFile, 'a') as ef:
					ef.write(strftime("%d/%m/%Y %H:%M:%S | ") + "Dans \"" + confFile + "\": <crop>" + c + "</crop> est incorrect ! Mettez des nombres compris entre 0 et inf séparés par x. Ex.: 0x110x1274x657\n")
				exit(2)


	def _get_path(self):
		return self._path


	def _set_path(self, e):
		# On découpe l'emplacement
		(path, fl) = split(e)
		# On vérifie qu'on a les droits de lecture sur l'emplacement
		if not access(path, R_OK):
			# Si ce n'est pas le cas, on écrit l'erreur et on arrête tout
			with open(errorFile, "a") as ef:
				ef.write(strftime("%d/%m/%Y %H:%M:%S | ") + " Vous n'avez pas les droits de lecture sur " + path + " !\n")
			exit(2)

		# On vérifie qu'on a les droits d'écriture sur l'emplacement
		elif not access(path, R_OK):
			# Si ce n'est pas le cas, on écrit l'erreur et on arrête tout
			with open(errorFile, "a") as ef:
				ef.write(strftime("%d/%m/%Y %H:%M:%S | ") + " Vous n'avez pas les droits d'écriture sur  " + path + " !\n")
			exit(2)

		self._path = e


	def _get_resize(self):
		return self._resize


	def _set_resize(self, r):
		for val in r.split("x"):
			if _isNumber(val):
				self._resize.append(int(val))
			else:
				with open(errorFile, 'a') as ef:
					ef.write(strftime("%d/%m/%Y %H:%M:%S | ") + "Dans \"" + confFile + "\": <resize>" + r + "</resize> est incorrect ! Mettez des nombres compris entre 0 et inf séparés par x. Ex.: 547x488\n")
				exit(2)


	def _get_time(self):
		return self._time


	def _set_time(self, t):
		# On vérifie que t est bien un nombre
		if not _isNumber(t):
			with open(errorFile, 'a') as ef:
				ef.write(strftime("%d/%m/%Y %H:%M:%S | ") + "Dans \"" + confFile + "\": <update_time>" + t + "</update_time> est incorrect ! Mettez un nombre compris entre 0 et inf.\n")
			exit(2)

		self._time = int(t)


	# Définition des propriétés
	path   = property(_get_path, _set_path)
	time   = property(_get_time, _set_time)
	crop   = property(_get_crop, _set_crop)
	resize = property(_get_resize, _set_resize)




######
# Début de la classe Daemon
############

class Daemon():
	def __init__(self):
		# Définition de la liste qui contiendra les infos sur les images à télécharger
		self.imgList = []
		# Définition d'un objet permettant de télécharger les pages internet et les images en s'identifiant comme mozilla
		# Le démon accepte que les données soient compressées en gzip
		self.opener = build_opener()
		self.opener.addheaders=[('User-agent', 'Mozilla/5.0'), ('Accept-encoding', 'gzip')]

	def readConf(self):
		(path, f) = split(errorFile)
		# On teste les droits de lecture écriture sur errorFile
		# Si on ne les a pas, on arrête tout
		if not (access(path, R_OK) and access(path, W_OK)):
			exit(2)

		# On teste les droits d'écriture sur le fichier confFile
		# Si on ne les a pas, on arrête tout en l'écrivant dans errorFile
		if not(access(confFile, R_OK) and isfile(confFile)):
			with open(errorFile, 'a') as ef:
				ef.write(strftime("%d/%m/%Y %H:%M:%S | ") + " Impossible de charger " + confFile + " !\n")
			exit(2)

		# On récupère le fichier de configuration
		tree = parse(confFile)
		root = tree.getroot()

		# On récupère les données du fichier de configuration
		for image in root:
			# On crée un objet img
			img = Img()

			# On récupère les données pour 1 objet
			img.url    = getData(image.find('url'))
			img.base   = getData(image.find('base_url'))
			img.path   = getData(image.find('path_sav'))
			img.time   = getData(image.find('update_time'))
			img.crop   = getData(image.find('crop'))
			img.resize = getData(image.find('resize'))
			img.search = getData(image.find('search'))


			# si img.search est définie, il faut placer l'url de la page sur img.page
			img.page = img.url

			# On rajoute l'object à la liste
			self.imgList.append(img)


	def start(self):
		# On prend le premier temps donné comme référence
		time2sleep = self.imgList[0].time
		# On cherche le temps le plus court par rapport à la référence pour le sleep
		for i, img in enumerate(self.imgList):
			if img.time < time2sleep:
				time2sleep = img.time

		while 1:
			# On fait une copie de time2sleep
			cpts = time2sleep
			# On parcourt toutes les images récupérées du fichier de configuration
			for img in self.imgList:
				# On regarde si la photo existe déjà
				if exists(img.path) and isfile(img.path):
					# On récupère le temps
					now = time()
					# On récupère quand a été créer l'image
					timePic = stat(img.path)[8]

					# Si l'image est trop vieille, on fait la mise à jour
					if timePic + img.time <= now:
						# Si on n'arrive pas à récupérer l'adresse de l'image, on met le compteur d'attente à 30s et on passe à l'image suivante
						if not searchURL(img, self.opener):
							cpts = 30
							continue
						if not download(img, self.opener):
							cpts = 30
							continue
						modify(img)

					else:
						# On calcule combien de temps il reste jusqu'à la mise à jour
						timeRemaining = timePic + img.time - now
						# Si celui-ci est inférieur au plus petit temps, on le remplace
						if timeRemaining < cpts:
							cpts = timeRemaining

				else:
					# Si la recherche a été définie, on lance la récupération de la page
					if not searchURL(img, self.opener):
						cpts = 30
						continue
					# On télécharge
					if not download(img, self.opener):
						cpts = 30
						continue
					# Si des modifications ont été définies, on les applique
					modify(img)

			# On endort le daemon pendant le plus petit temps trouvé afin de ne pas consommer du CPU inutilement
			sleep(cpts)


######
# Début des fonctions globales
############


def download(img, opener):
	# Téléchargement de l'image
	try:
		imageWeb = opener.open(img.url)
	except urllib.error.URLError as err:
		return False
	# Sauvegarde de l'image
	with open(img.path, "wb") as source:
		source.write(imageWeb.read())

	return True


def modify(img):
	# Si la découpe ou le redimensionnement est défini
	if img.crop or img.resize:
		# On charge l'image
		picSRC = open_image(img.path)
		# Si on découpe l'image
		if img.crop:
			picSRC = picSRC.crop(img.crop)
		# Si on redimensionne l'image
		if img.resize:
			picSRC = picSRC.resize((img.resize), ANTIALIAS)

		# On sauvegarde les modifications de l'image
		picSRC.save(img.path)


def searchURL(img, opener):
	if img.search:
		# On télécharge la page où se trouve l'image
		answer = str()
		dl     = str()
		try:
			answer = opener.open(img.page)
			if answer.info().get('Content-Encoding') == 'gzip':
				bi = BytesIO(answer.read())
				dl = GzipFile(fileobj=bi, mode='rb').read().decode('utf-8', 'ignore')
			else:
				dl = answer.read().decode('utf-8', 'ignore')
		except urllib.error.URLError as err:
			return False
		# On passe en revue toute la page web
		for lecture in dl.split(" "):
			# On recherche la chaine demandé
			if img.search in lecture:
				# Si on l'a trouve, on découpe au niveau du = et on elève les ""
				img.url = lecture.split("=")[1][1:-1]
				# Si une base est définie, on la rajoute
				if img.base:
					img.url = img.base + img.url
				return True
	else:
		return True


def getData(data):
	if data != None:
		return data.text
	else:
		return None


def _isNumber(number):
	try:
		s = int(number)

		if s < 0:
			return False
	
		else:
			return True

	except ValueError:
		return False




######
# Début du programme principal
############

if __name__ == "__main__":
	errorFile = "/var/log/imagesat/error.log"
	confFile  = "/etc/imagesat.cfg"

	demon = Daemon()
	demon.readConf()
	demon.start()
