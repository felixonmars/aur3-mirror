#!/usr/bin/ruby

=begin 
    
    (program name)

    runt
    
    (filename)

    runt.rb

    (copyright)

    Copyright (c) 2013 Alexej Magura
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

=end

 # System requires 
require 'getoptlong' 


 # Function definitions 
def lookup(src_string = String.new, src_aura_flags = '-Ai')

    %x(aura #{src_aura_flags} #{src_string}).each_line do |line|

	if line =~ /.*Maintainer.*/

	    $stdout << line.inspect.sub(%r%(\\e\[m\\e\[1m|\\e\[0m|")%, '').sub(/\\e\[0m/, '').sub(%r%\\e\[1m%, '').sub(%r%\\e\[%, "\033[m\033[").sub(%r%\\e\[m\\e\[1m%, "\033[m\033[32m").gsub(/"|\\n/, '').sub(/\\e\[0;31m/, "\033[m\033[0;31m").sub(/\\e\[0m/, "\033[0m").sub(/Orphaned/, "Orphan")  << "\n"

	elsif line =~/.*Name.*/

	    $stdout << line.inspect.gsub(%r%(\\e\[m\\e\[1m|\\e\[0m|"|\\n)%, '') << "\n"

	elsif line =~ /.*Repository.*/ 

	    $stdout << "\n" << line.inspect.gsub(%r%(\\e\[m\\e\[1m|"|\\n)%, '').sub(%r%\\e\[0m%, '').gsub(%r%\\e\[0;35m%, "\033[m\033[0;35m").sub(/\\e\[0m/, "\033[0m") << "\n"

	elsif line =~ /.*Description.*/
	    
	    $stdout << line.inspect.sub(%r%(\\e\[m\\e\[1m|\\e\[0m|")%, '').sub(/\\e\[0m/, '').sub(%r%\\e\[1m%, '').sub(%r%\\e\[1m|\\e\[m%, "").gsub(/"|\\n/, '').sub(/\\e\[0m/, "\033\[0;0m") << "\n\n"

	elsif line =~ /.*Votes.*/ 

	    $stdout << line.inspect.sub(%r%(\\e\[m\\e\[1m|\\e\[0m|")%, '').sub(/\\e\[0m/, '').sub(%r%\\e\[1m%, '').sub(%r%\\e\[0;33m|\\e\[m%, "").gsub(%r%\\e\[0;33m%, "\033[m\033[33m").gsub(/"|\\n/, '').sub(/\\e\[0m/, "\033\[0;0m") << "\n"

	elsif line =~ /.*AUR URL.*/
	    
	    $stdout << line.inspect.sub(%r%(\\e\[m\\e\[1m|\\e\[0m|")%, '').sub(/\\e\[0m/, '').sub(%r%\\e\[1m%, '').sub(%r%\\e\[0;33m|\\e\[m%, "").gsub(%r%:%, ":\033[m\033[0;36m").gsub(/"|\\n/, '').sub(/$/, "\033\[0;0m") << "\n"

	end

    end

end


def pf(src_string = String.new)

    return "\xE2\x80\x98#{src_string}\xE2\x80\x99"

end

def help

    puts <<-EOF
usage: #$0 [option] \033[0;33mpackage\033[0;0m...


  -h, --help\t\tprint this message and exit
      --version\t\tprint version and exit

EOF

=begin defunct options
 
 note: #$0 assumes that #{pf("package")} is an AUR package, unless otherwise specified using the #{pf("-n")} option
  -n, --no-aur[=\033[0;33mpackage\033[0;0m]\tdo not search the AUR for given \033[0;33mpackage\033[0;0m 
                        \t\033[4;94mnote\033[0m: when no \033[0;33mpacakge\033[0;0m is specified, #$0 assumes that this option applies to \033[0;35mevery\033[0m \033[0;33mpackage\033[0;0m
=end
end

def error(section, float)

    case section

    when 'A'

	case float 

	when 0.1 

	    $stderr.puts "#$0: missing package operand"

	end

	exit 2

    end

end

 # Structure definitions 
opts_struct = GetoptLong.new(

    [ '--help', '-h', GetoptLong::NO_ARGUMENT ],
    [ '--version', GetoptLong::NO_ARGUMENT ],
#    [ '--no-aur', '-n', GetoptLong::OPTIONAL_ARGUMENT ]
)

 # variable definitions 
 version = '0.2.0'
# special_args = Array.new # packages that require a non-aur searching instance of aura

begin 
    
    opts_struct.each do |c, optarg|
	
	case c 

	when '--help'

	    help()

	    exit 0

	when '--version'

	    puts version 

	    exit 0
=begin defunct
	when '--no-aur'

	    if optarg == "" 


		aura_flags = "-Si"

		
	    else

		aura_flags = "-Ai"

	    end

	    special_args = optarg.split(',')
=end 
	end
    end

rescue GetoptLong::MissingArgument

    exit 2

rescue GetoptLong::InvalidOption

    exit 2

end

if ARGV.size < 1 

    error('A', 0.1)

else

    ARGV.each do |o|

	lookup(o)
    
    end
=begin defunct_2
    if special_args !=  

	special_args.each do |o|

	    lookup(o, "-Si")

	end
    end
=end
end





