
---------------------------------------------------------------------------

Release:      UbuntuWin TV 0.7
Date:         25/10/2009
Author:       Roberto Palumbo <palumborobertomail@gmail.com>
License:      GPLv3
Website:      http://www.ubuntuwin.org or http://ubuntuwin.altervista.org

---------------------------------------------------------------------------

INTRO
------------

 With this applet you can show tv and radio channel streaming. A lot of channels are available.
 Streaming list is downloaded by the main server and is frequently updaded. You can add user channels
 too.  
 
 
 Changelog v.0.7:
 - Icon modified
 - Internazionalization. For now are available Italian,English,French,Germany,Brazilian radios and tvs
 other countries may be added soon. 
 - Remote control mode
 - Support for mplayer,kaffeine,totem-xine
 - Language customization
 Webpage:
 	http://www.ubuntuwin.org
	
DIPENDENZE
----------
gtk2+,vlc,zenity,python

on Ubuntu Karmic Koala:
python-gnomeapplet python-wnck


