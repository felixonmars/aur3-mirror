cp -f ubuntuwintv.server usr/lib/bonobo/servers/ubuntuwintv.server
cp -f ubuntuwintv.png usr/share/icons/ubuntuwintv.png
cp -f ./icons/* usr/share/ubuntuwintv/
cp -f ubuntuwintvlingua_it.txt usr/share/ubuntuwintvlingua_it.txt
cp -f ubuntuwintvlingua_en.txt usr/share/ubuntuwintvlingua_en.txt
cp -f ubuntuwintv.py usr/bin/ubuntuwintv.py
chmod +x usr/bin/ubuntuwintv.py

