ip_update
====

If necessary, update your ip for hopper.pw

Depend
======

python3

Installation
============

```
python setup.py install
```

Usage
=====

```
python ip_update
```
