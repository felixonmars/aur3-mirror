Minecraft Skin Editor alpha 3 pre 5
	by: Patrik Swedman
	(preview feature uses external code, the recomended library is made by Notch)

 Compadabillity:
 ---------------
This version has been tested and developed on Windows 7 64-bit Ultimate.
Older versions of this program has been tested under Ubuntu 9.10 64-bit and Max OSX snow leopard.

The program is Java based and should work on any computer that supports Java 6.

 Start the program:
 ------------------
Just double click the .jar 
If it opens as a compressed folder or your operating system says it can't open the file then right click the file and see if you can open with Java.
If you can't open with Java download the latest java runtime from http://www.java.com/

 Changelog:
 ----------
alpha 3 pre 4 -> alpha 3 pre 5
	Added a feedback dialog for when the program is downloading skintest2.jar (the previewer)
	Improved error handling. All errors will now be displayed in a window. (This may require some tweeking)
	Added a extension to the previewer. It will now display your skin as it would look in-game. You can turn this off in settings
	Added a screenshot button to create a screenshot from the preview
	Fixed a bug with the Add Noice tool that slowed it down quite a lot and spammed text to the console (if started from console)
	Fixed the bug that the filename wouldn't update when you loaded a new file or used save as. You will now save to the correct file.
	Lowered the strength on the shading tools. Remember you can hold down CTRL to use increased strength.
	Added the PartPicker. Press CTRL + P or go to Edit > PartPicker to open it. It allows you to easilly add details to your skin.
	Added a hack which makes the previewer work even when you do not have a Internet connection. (This speeds up startup time)
	Settings save to settings.xml (Might be found in working dir, program dir or in <user dir>/.skinedit
	Fixed misspelled "Add Noice" to "Add Noise"

alpha 3 pre 3 -> alpha 3 pre 4
	Fixed shading on transparent
	Fixed middle mouse button not working
	Added a extra powerful dodge and burn
	Added a simple way of using your own backgrounds by placing them in the "backgrounds" folder
	Added a noice tool. This is supposed to be a quick-and-dirty way to get BASIC shading, you should still use burn and dodge to make sure everything looks right.

alpha 3 pre 2 -> alpha 3 pre 3
	Changed the way the program handles the image
	Added flood fill
	Added burn and dodge
	Added another shortcut for copy color
	Added a window that displays some of the controlls (you can see some shortcuts in the menu)
	Added a internal crash handler which removed the usage for Launch.bat

alpha 2 -> alpha 3 pre 2
	Remade the design
	Realtime preview
	Undo and redo system
	Change brushsize
	New file handling system, doesn't ask you where to save a file you edited

alpha 1 -> alpha 2
	Added preview functionallity (requires a library made by Notch which will be downloaded)
	If your filename when you try to save the file doesn't end with .png it will get .png added
	Added color copy
	Added a reset shortcut

 Known bugs:
 -----------
None

 Instructions:
 -------------
Left mouse - Draw the selected color
Right mouse - Erase. Only the hat will support transparent in game
Middle mouse - Copy color. Same as CTRL + Right mouse
CTRL + Left mouse - Flood fill
CTRL + Right mouse - Copy color. Same as Middle mouse
ALT + Left mouse * - Dodge tool. Best effect when dragged
ALT + CTRL + Left mouse * - More powerful dodge tool
ALT + Right mouse * - Burn tool. Best effect when dragged
ALT + CTRL + Right mouse * - More powerful burn tool

(* means that the tool doesn't support the brushsize setting currently)

A lot of other stuff can be found in the menu bar, and a lot of those tools have keyboard shortcuts.
If you find it hard to remember the controlls you can open a window which displayes the controlls under the help menu.

To use a custom background first put it in the "backgroudnds" folder. If it doesn't exist you can create it. Note that it must be in the same place as MCSkinEdit.jar.
Now, you can select your custom background from Settings > Background image > filename.png
The size of the image doesn't matter, the program will change size after the image. The program has support for the wrong aspect ratio but not only does it look funny but officially it is not supported.

To add more parts for PartPicker just put them in the "parts" folder.