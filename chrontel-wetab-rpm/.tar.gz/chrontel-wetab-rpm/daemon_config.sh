#!/bin/bash
# set $DEVICE to "/dev/i2c-0" or "/dev/i2c-14", it depends on the kernel
# see https://wiki.archlinux.org/index.php/WeTab for more information.
# 
# You can basically override any variable that is set in the daemon script
# with your own values, but these are the important ones.

#DEVICE=/dev/i2c-0
#LOGFILE=/tmp/tiitoo-hdmi-$USER.log
