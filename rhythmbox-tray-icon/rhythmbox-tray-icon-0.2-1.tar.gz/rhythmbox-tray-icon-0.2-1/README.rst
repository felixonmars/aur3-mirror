Rhythmbox tray icon plugin
==========================

Restores the tray icon functionality from the 0.x series. Requires 2.9+

Install Procedure
-----------------

Copy this folder into ~/.local/share/rhythmbox/plugins, or install the debian package
