#ifndef UI_H
#define UI_H

#include "choice.h"
#include "choices.h"

struct choice    *get_selected(struct choices *, char *, int);

#endif /* UI_H */
