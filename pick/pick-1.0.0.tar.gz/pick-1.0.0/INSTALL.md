pick installation
=================

1. Download and extract the latest release:

        curl -O https://github.com/thoughtbot/pick/releases/download/v0.0.1/pick-0.0.1.tar.gz
        tar -zxvf pick-0.0.1.tar.gz
        cd pick-0.0.1

2. Configure the distribution.

        ./configure

3. Build and install pick:

        make
        sudo make install
