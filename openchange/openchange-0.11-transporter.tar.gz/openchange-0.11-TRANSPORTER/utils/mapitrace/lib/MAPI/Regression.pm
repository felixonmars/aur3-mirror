#############################################
# EcDoRpc package for mapitrace tool
# Copyright Julien Kerihuel 2007
# <j.kerihuel@openchange.org>
#
# released under the GNU GPL v3 or later
#
package MAPI::Regression;

require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw();
use vars qw($AUTOLOAD $VERSION);
$VERSION = '0.01';

use strict;

1;
