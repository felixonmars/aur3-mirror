#!/bin/sh

/usr/bin/asusoled -f /usr/share/doc/asusoled/example/flash.tiff
sleep 5
/usr/bin/asusoled -s /usr/share/doc/asusoled/example/message.png
sleep 5
/usr/bin/asusoled -r /usr/share/doc/asusoled/example/longrun.png

echo "That's it!"

