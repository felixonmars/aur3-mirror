/*
 * debug.c
 * This file is part of MusicMe
 *
 * Copyright (C) 2010 - Edward
 *
 * MusicMe is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * MusicMe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MusicMe; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */


//HEADER FILES
#include "debug.h"

//FUNCTIONS
//********************************************************************************
//*	
//*	FUNCTION:		de_print
//*	DISCRIPTION:	output information to terminal
//*
//********************************************************************************
void	de_print(int type, const char *func, const char *msg)
{
	if(!func)
		func="UNKNOWN";
	switch(type)
	{
		case __DE_ERROR: printf(_("[MusicMe ERROR] ( in function %s ):\n\t%s\n"),func,msg);break;
		case __DE_WARNNING: printf(_("[MusicMe WARNNING] ( in function %s ):\n\t%s\n"),func,msg);break;
		case __DE_INFORMATION: printf(_("[MusicMe INFORMATION] ( in function %s ):\n\t%s\n"),func,msg);break;
		default: break;
	}
}

//********************************************************************************
//*
//*	FUNCTION:		de_dialog_print
//*	DISCRIPTION:	output information by message_dialog
//*
//********************************************************************************
void	de_dialog_print (GtkWidget *parent, int type, const char *func, const char *msg)
{
	GtkWidget *dialog=NULL;
	
	if(!func)
		func="UNKNOWN";
	switch(type)
	{
		case __DE_ERROR:
			dialog=gtk_message_dialog_new_with_markup(
							GTK_WINDOW(parent),
							GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
							GTK_MESSAGE_ERROR,
							GTK_BUTTONS_OK,
							_("<b>(on function %s )</b>\n%s"),func,msg);
			break;
		case __DE_WARNNING:
			dialog=gtk_message_dialog_new_with_markup(
							GTK_WINDOW(parent),
							GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
							GTK_MESSAGE_WARNING,
							GTK_BUTTONS_OK,
							_("<b>(on function %s )</b>\n%s"),func,msg);
			break;
		case __DE_INFORMATION:
			dialog=gtk_message_dialog_new_with_markup(
							GTK_WINDOW(parent),
							GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
							GTK_MESSAGE_INFO,
							GTK_BUTTONS_OK,
							_("<b>(on function %s )</b>\n%s"),func,msg);
			break;
		default: break;
	}
	if(!dialog)
	{
		return;
	}
	gtk_widget_show_all (dialog);
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
}
