/*
 * configure.h
 * This file is part of MusicMe
 *
 * Copyright (C) 2010 - Edward
 *
 * MusicMe is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * MusicMe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MusicMe; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */

#ifndef CONFIGURE_H
#define CONFIGURE_H

//HEADERS
#include "global.h"
#include "debug.h"
#include "common.h"

//MACROS

//VARIABLES

//FUCTIONS
gboolean cf_free();
gboolean cf_read();
gboolean cf_write();
gboolean cf_write_default();

#endif
