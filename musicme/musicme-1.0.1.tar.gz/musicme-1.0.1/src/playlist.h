/*
 * playlist.h
 * This file is part of MusicMe
 *
 * Copyright (C) 2010 - Edward
 *
 * MusicMe is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * MusicMe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MusicMe; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */

//HEADERS
#include "global.h"
#include "debug.h"
#include "common.h"
#include "configure.h"
#include "metadata.h"
#include "library.h"

//FUNCTIONS
gboolean	pl_read_playlist();
gboolean	pl_write_playlist();
gboolean	pl_read_playinglist();
gboolean	pl_write_playinglist();

gboolean	pl_add_playlist(gchar *name);
gboolean	pl_add_to_playlist(GList *p, _gl_metadata *md);
gboolean	pl_add_to_playinglist(_gl_playinglist *pgl);
gboolean	pl_import_playlist(gchar *path);
gboolean	pl_export_playlist(GList *p, gchar *path);

gboolean	pl_remove_playlist(GList *p);
gboolean	pl_rename_playlist(GList *p, gchar *name);
gboolean	pl_remove_md_from_playlist(GList *p, GList *q);
gboolean	pl_remove_md_from_playinglist(GList *q);

GList*		pl_find_pl_by_playing();
