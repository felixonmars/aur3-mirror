/*
 * gui_lrc.h
 * This file is part of MusicMe
 *
 * Copyright (C) 2010 - Edward
 *
 * MusicMe is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * MusicMe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MusicMe; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */

//HEADERS
#include "global.h"
#include "debug.h"
#include "common.h"
#include "configure.h"
#include "metadata.h"
#include "library.h"
#include "playlist.h"
#include "equalizer.h"
#include "core.h"
#include "theme.h"
#include "gui_window.h"
#include "gui_treeview.h"

//FUNCTIONS
gboolean	gui_lrc_eventbox_expose( GtkWidget * widget, GdkEventExpose * event, gpointer data);
gboolean	gui_lrc_window_expose( GtkWidget * widget, GdkEventExpose * event, gpointer data);

gboolean	gui_lrc_read_lyrics();
gboolean	gui_lrc_analyse_lyrics(FILE *fp);
gboolean	gui_lrc_sort_lyrics();
gboolean	gui_lrc_update_lrc();
gboolean	gui_lrc_download_lyrics();
gboolean	gui_lrc_seek( GtkWidget * widget, GdkEventButton *event, gpointer data);
gboolean	gui_lrc_expose_desktop( GtkWidget * widget, GdkEventExpose * event, gpointer data);
gboolean	gui_lrc_move_desktop( GtkWidget * widget, GdkEvent *event, gpointer data);