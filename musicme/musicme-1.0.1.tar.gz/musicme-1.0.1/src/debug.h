/*
 * debug.h
 * This file is part of MusicMe
 *
 * Copyright (C) 2010 - Edward
 *
 * MusicMe is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * MusicMe is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MusicMe; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */


#ifndef DEBUG_H
#define	DEBUG_H

//HEADER FILES
#include "global.h"

//MACROS

#define __DE_ERROR			0
#define __DE_WARNNING		1
#define __DE_INFORMATION	2


//FUNCTIONS
void	de_print		(int type, const char *func, const char *msg);
void	de_dialog_print	(GtkWidget *parent, int type, const char *func, const char *msg);

#endif
