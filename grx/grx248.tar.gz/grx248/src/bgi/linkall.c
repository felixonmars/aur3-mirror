#include "libbcc.h"

int main(void) {
  printf("Do nothing DUMMY !\n");
  return 0;
}
