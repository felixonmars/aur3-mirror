#!/bin/bash
[[ HOME = "" ]] && HOME="/home/liveuser"
FILE=$(cat ${HOME}/.keybindings)
zenity --title="Key bindings" --timeout=10 --info --text="${FILE}"
