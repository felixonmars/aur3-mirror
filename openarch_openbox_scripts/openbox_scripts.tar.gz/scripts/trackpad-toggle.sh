#!/bin/bash

#Then finally add a key binding to use the script. It is best to call with xbindkeys like so (file ~/.xbindkeysrc):
#"/sbin/trackpad-toggle.sh"
#    m:0x5 + c:65
#    Control+Shift + space

if [ $(synclient -l | grep TouchpadOff | gawk -F '= ' '{ print $2 }') -eq 0 ]; then
    synclient TouchpadOff=1
else
    synclient TouchpadOff=0
fi
