#ifndef MPD_WRAP_H
#define MPD_WRAP_H

# include <unistd.h>

void *Malloc(size_t);

#endif /* MPD_WRAP_H */
