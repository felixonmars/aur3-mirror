#define _X_OPEN_SOURCE_EXTENDED
#ifdef NONW
#include <ncurses.h>
#else
#include <ncursesw/ncurses.h>
#endif
