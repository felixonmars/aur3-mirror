NcursesOfLife
=============

Text based Conway's Game of Life

SIM stage:
p = play/pause
n = step
+ = faster
- = slower
q = quit

WHEN PAUSED:
WASD / arrow keys = move
space = toggle cell

Game starts out paused.  All SIM keystrokes will work when paused (step only works paused).  
