"""ZetaBoards topic fetcher configuration editor module by J.

Licensed under the GNU General Public License, version 3; if this was not
included, you can find it here:
    http://www.gnu.org/licenses/gpl-3.0.txt

"""

import os
from cPickle import load, dump, UnpicklingError

import gtk
import gobject
try:
    from gobject import GError
except ImportError:
    from glib import GError

from ..backend import CONF
from ..gui import ICON, save_config
from ..gtkutil import italic, defaultise, confirm

# create some stock things to reuse other icons but retain accelerator
gtk.stock_add([('duplicate', _('Du_plicate'), 0, 0, None),
               ('forgetpwd', _('_Forget Password'), 0, 0, None)])
factory = gtk.IconFactory()
factory.add_default()
factory.add('duplicate', gtk.widget_get_default_style().lookup_icon_set(gtk.STOCK_COPY))
factory.add('forgetpwd', gtk.widget_get_default_style().lookup_icon_set(gtk.STOCK_CLEAR))

def update_gui ():
    while gtk.events_pending():
        gtk.main_iteration()

class SingleEditor:
    def __init__ (self, editor, transient, edit, finish, alias = '', data = None):
        self.editor = editor
        self.edit_cb = edit
        self.finish_cb = finish
        if data is None:
            data = ['', '', None, None, '']
            self.cal = [[], []]
            self.ignored = [[], []]
        else:
            self.cal = [x[:] for x in data[5]]
            self.ignored = [x[:] for x in data[6]]
        self.data = data
        self.alias = alias

        self.window = gtk.Window()
        self.window.connect('delete_event', self.end)
        self.window.set_title((_('Create Configuration') if data is None else _('Edit Configuration'))
                              + ' - ' + _('ZetaBoards topic fetcher'))
        self.window.set_transient_for(transient)
        try:
            self.window.set_icon_from_file(ICON)
        except GError:
            pass
        self.window.set_border_width(12)
        # close on escape key
        accel = gtk.AccelGroup()
        accel.connect_group(65307, 0, 0, self.esc)
        self.window.add_accel_group(accel)
        outer = gtk.VBox(False, 9)
        self.window.add(outer)
        top = gtk.HBox(False, 9)
        outer.pack_start(top)

        # login details
        self.fields = []
        main = gtk.VBox(False, 6)
        top.pack_start(main)
        login = gtk.VBox(False, 6)
        main.pack_start(login, False)
        hbox = gtk.HBox(False, 6)
        login.pack_start(hbox, False)
        col1 = gtk.VBox(True, 6)
        hbox.pack_start(col1, False)
        col2 = gtk.VBox(True, 6)
        hbox.pack_start(col2)
        indices = (0, 1, 4)
        fields = (_('_Forum:'), _('_Username:'), _('Pass_word:'))
        for i, (index, label) in enumerate(zip(indices, fields)):
            l = gtk.Label(label)
            col1.pack_start(l)
            l.set_use_underline(True)
            # align left
            l.set_alignment(0, 0.5)
            e = gtk.Entry()
            l.set_mnemonic_widget(e)
            # move focus to next entry on activate
            try:
                e_last.connect('activate', lambda e_last, e: e.grab_focus(), e)
            except NameError:
                pass
            col2.pack_start(e)
            self.fields.append(e)
            e.set_text('' if data[index] is None else data[index])
            e_last = e
        # select forum field
        self.fields[0].grab_focus()
        # obscure password field
        self.fields[2].set_visibility(False)
        # actions
        col = gtk.VBox(False, 6)
        login.pack_start(col, False)
        indices = (2, 3)
        fields = (_('Sa_ve to file:'), _('O_pen with:'))
        for i, (index, label) in enumerate(zip(indices, fields)):
            hbox = gtk.HBox(False, 6)
            col.pack_start(hbox, False)
            c = gtk.CheckButton(label)
            hbox.pack_start(c, False)
            # activating last entry above should focus first checkbox
            if i == 0:
                e_last.connect('activate', lambda e_last, c: c.grab_focus(), c)
            b = gtk.Button(_('_Browse'), None, True)
            hbox.pack_end(b, False)
            e = gtk.Entry()
            hbox.pack_end(e, False)
            val = data[index]
            if val is not None:
                c.set_active(True)
                e.set_text(val)
            c.connect('toggled', self.set_sensitive)
            e.connect('changed', self.set_sensitive)
            defaultise(b, e)
            self.fields.append((c, e, b))
            b.connect('clicked', self.get_file, index - 2)

        top.pack_start(gtk.VSeparator(), False)

        # ignored
        ignored = gtk.VBox(False, 6)
        top.pack_start(ignored)
        # labels
        ignored.pack_start(gtk.Label(_('Add IDs of topics or subforums to ignore, as seen in the URL.')), False)
        err_add = gtk.Label(_('ID must be an integer'))
        ignored.pack_start(err_add, False)
        err_add.set_property('attributes', italic)
        err_rm = gtk.Label(_('No row selected'))
        ignored.pack_start(err_rm, False)
        err_rm.set_property('attributes', italic)
        hbox = gtk.HBox(True, 6)
        ignored.pack_start(hbox, False)
        tree_labels = []
        for label in (_('_Subforums'), _('_Topics')):
            l = gtk.Label(label + ':')
            hbox.pack_start(l, False)
            tree_labels.append(l)
            l.set_use_underline(True)
        # trees
        hbox = gtk.HBox(True, 6)
        ignored.pack_start(hbox)
        self.trees = []
        self.ls = []
        for i, label in enumerate(tree_labels):
            ls = gtk.ListStore(gobject.TYPE_STRING)
            self.ls.append(ls)
            scroll = gtk.ScrolledWindow()
            hbox.pack_start(scroll)
            scroll.set_policy(gtk.POLICY_NEVER, gtk.POLICY_AUTOMATIC)
            tree = gtk.TreeView(ls)
            scroll.add(tree)
            self.trees.append(tree)
            label.set_mnemonic_widget(tree)
            tree.set_headers_visible(False)
            col = gtk.TreeViewColumn()
            tree.append_column(col)
            renderer = gtk.CellRendererText()
            col.pack_start(renderer, True)
            col.add_attribute(renderer, 'text', 0)
            tree.get_selection().select_path(0)
            tree.connect('button_press_event', self.tree_clicked, err_add, err_rm)
            self.update_tree(i)
        # controls
        hbox = gtk.HBox(True, 6)
        ignored.pack_start(hbox, False)
        for i in (0, 1):
            vbox = gtk.VBox(False, 6)
            hbox.pack_start(vbox)
            rm = gtk.HBox(False, 6)
            vbox.pack_start(rm)
            b = gtk.Button(stock = gtk.STOCK_REMOVE)
            rm.pack_start(b)
            b.connect('clicked', self.rm_ignored, i, err_add, err_rm)
            b = gtk.Button(_('Re_move All'), None, True)
            rm.pack_start(b)
            b.connect('clicked', self.rm_all_ignored, i)
            add = gtk.HBox(False, 6)
            vbox.pack_start(add)
            e = gtk.Entry()
            add.pack_start(e)
            e.set_width_chars(12)
            b = gtk.Button(stock = gtk.STOCK_ADD)
            add.pack_start(b)
            defaultise(b, e)
            b.connect('clicked', self.add_ignored, i, e, err_add, err_rm)

        # alias entry
        outer.pack_start(gtk.HSeparator(), False)
        hbox = gtk.HBox(False, 6)
        outer.pack_start(hbox, False)
        hbox.pack_start(gtk.Label(_('Configuration name:')), False)
        e = gtk.Entry()
        hbox.pack_start(e, False, padding = 6)
        self.fields.append(e)
        e.set_text(alias)
        e.connect('changed', self.set_sensitive)
        # buttons
        self.ok_button = gtk.Button(stock = gtk.STOCK_OK)
        hbox.pack_end(self.ok_button, False)
        defaultise(self.ok_button, e)
        self.ok_button.connect('clicked', self.finish)
        b = gtk.Button(stock = gtk.STOCK_CANCEL)
        hbox.pack_end(b, False)
        b.connect('clicked', self.end)
        self.apply_button = gtk.Button(stock = gtk.STOCK_APPLY)
        hbox.pack_end(self.apply_button, False)
        self.apply_button.connect('clicked', self.apply_input)

        self.set_sensitive()
        self.window.show_all()
        err_add.hide()
        err_rm.hide()

    def end (self, *args):
        self.window.destroy()
        update_gui()
        self.finish_cb(self)
        return False

    def esc (self, *args):
        self.end()
        return True

    def get_file (self, widget, save):
        # 'Browse' action
        f = gtk.FileChooserDialog([_('Save to file'), _('Select file')][save], action = [gtk.FILE_CHOOSER_ACTION_SAVE, gtk.FILE_CHOOSER_ACTION_OPEN][save], buttons = (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK))
        current = self.fields[save + 3][1].get_text()
        if current:
            f.set_filename(current)
        else:
            f.set_current_folder(os.path.expanduser('~'))
        if f.run() == gtk.RESPONSE_OK:
            self.fields[save + 3][1].set_text(f.get_filename())
        f.destroy()

    def set_sensitive (self, widget = None):
        # set sensitivity of some widgets
        for x in (3, 4):
            fields = self.fields[x]
            sensitive = fields[0].get_active()
            fields[1].set_sensitive(sensitive)
            fields[2].set_sensitive(sensitive)
        sensitive = True
        for x in (0, 1, 5):
            sensitive &= bool(self.fields[x].get_text())
        self.apply_button.set_sensitive(sensitive)
        self.ok_button.set_sensitive(sensitive)

    def add_ignored (self, widget, is_topic, entry, e_add, e_rm):
        # add to ignored list
        e_rm.hide()
        try:
            val = int(entry.get_text())
        except ValueError:
            e_add.show()
        else:
            e_add.hide()
            if val not in self.ignored[is_topic]:
                self.ignored[is_topic].append(val)
                self.update_tree(is_topic)
                # select new entry
                i = self.ignored[is_topic].index(val)
                self.trees[is_topic].get_selection().select_path(i)
                entry.set_text('')
        # focus entry
        entry.grab_focus()

    def rm_ignored (self, widget, is_topic, e_add, e_rm):
        # remove from ignored list
        e_add.hide()
        sel = self.trees[is_topic].get_selection().get_selected_rows()[1]
        if sel:
            e_rm.hide()
            index = sel[0][0]
            sel = max(index - 1, 0)
            del self.ignored[is_topic][index]
            self.update_tree(is_topic)
            # select ID above deleted one
            self.trees[is_topic].get_selection().select_path(sel)
        else:
            e_rm.show()

    def rm_all_ignored (self, widget, is_topic):
        if not self.ignored[is_topic]:
            return
        q = _('Remove all {0} from ignore list?').format(_('topics') if is_topic else _('subforums'))
        if not self.editor.confirm(_('Confirm remove'), q, 5):
            return
        # clear ignore list
        self.ignored[is_topic] = []
        self.update_tree(is_topic)

    def update_tree (self, is_topic):
        # fill specified tree from self.ignored
        self.ls[is_topic].clear()
        self.ignored[is_topic].sort()
        for x in self.ignored[is_topic]:
            self.ls[is_topic].append([x])

    def tree_clicked (self, tree, event, e_add, e_rm):
        # right-click menu
        if event.button != 3:
            return
        sel = tree.get_path_at_pos(int(event.x), int(event.y))
        if sel is None:
            return
        sel = sel[0][0]
        tree.get_selection().select_path(sel)
        is_topic = self.trees.index(tree)
        # create menu
        menu = gtk.Menu()
        item = gtk.ImageMenuItem(gtk.STOCK_REMOVE)
        menu.append(item)
        item.connect('activate', self.rm_ignored, is_topic, e_add, e_rm)
        menu.show_all()
        menu.popup(None, None, None, event.button, event.time)

    def apply_input (self, widget = None):
        # compile data and return via given callback
        # returns whether necessary changes were made
        data = []
        for x in (0, 1, 3, 4, 2):
            field = self.fields[x]
            try:
                text = field.get_text()
            except AttributeError:
                data.append(field[1].get_text() if field[0].get_active() else None)
            else:
                if x == 2 and text == '':
                    # blank password
                    text = None
                data.append(text)
        alias = self.fields[5].get_text()
        if data[0] == self.data[0]:
            # same forum: retain calibration data
            data.append(self.cal)
        else:
            data.append([[], []])
        data.append(self.ignored)
        if alias == self.alias and alias in self.editor.configs and data == self.editor.configs[alias]:
            # no change
            return True
        else:
            result = self.edit_cb(self.alias, alias, data)
            if result:
                # so that change detection is correct next time this is called
                self.alias = alias
                self.data = data
            return result

    def finish (self, widget):
        # apply changes and close this editor
        if self.apply_input():
            self.end()


class Editor:
    def __init__ (self, icon):
        self.icon = icon
        self.configs = icon.configs
        self.load_config()
        self.children = []

        self.window = gtk.Window()
        self.window.connect('delete_event', self.end)
        self.window.set_title(_('Configuration Editor') + ' - ' + _('ZetaBoards topic fetcher'))
        self.window.set_resizable(False)
        try:
            self.window.set_icon_from_file(ICON)
        except GError:
            pass
        self.window.set_border_width(12)
        # close on escape key
        accel = gtk.AccelGroup()
        accel.connect_group(65307, 0, 0, self.esc)
        self.window.add_accel_group(accel)
        vbox = gtk.VBox()
        self.window.add(vbox)
        self.outer = gtk.VBox(False, 12)
        vbox.pack_start(self.outer)

        # tree
        s = gobject.TYPE_STRING
        self.ls = gtk.ListStore(s, s, s, s, s, s, s)
        # for when rows are manually reordered
        self.ls_id = self.ls.connect('row-deleted', self.order_from_tree)
        self.tree = gtk.TreeView(self.ls)
        self.outer.pack_start(self.tree)
        self.tree.set_reorderable(True)
        self.tree.connect('row_activated', self.edit_single)
        self.tree.connect('button_press_event', self.tree_clicked)
        cols = (_('Alias'), _('Forum'), _('Username'), _('Password'), _('Password'), _('Save'), _('Open'))
        for i in xrange(len(cols)):
            col = gtk.TreeViewColumn(cols[i])
            self.tree.append_column(col)
            col.set_resizable(True)
            renderer = gtk.CellRendererText()
            # bold config name
            if i == 0:
                renderer.set_property('weight', 700)
            col.pack_start(renderer, True)
            col.add_attribute(renderer, 'text', i)
        # select first row
        self.tree.get_selection().select_path(0)

        # buttons
        self.err_msg = gtk.Label('No row selected')
        self.outer.pack_start(self.err_msg, False)
        self.err_msg.set_property('attributes', italic)
        hbox = gtk.HBox(False, 6)
        self.outer.pack_start(hbox)
        b = gtk.Button(stock = gtk.STOCK_NEW)
        hbox.pack_start(b)
        b.connect('clicked', self.edit_single)
        b = gtk.Button(stock = gtk.STOCK_EDIT)
        hbox.pack_start(b)
        b.connect('clicked', self.edit_selected)
        b = gtk.Button(stock = 'duplicate')
        hbox.pack_start(b)
        b.connect('clicked', self.dup_selected)
        b = gtk.Button(stock = gtk.STOCK_DELETE)
        hbox.pack_start(b)
        b.connect('clicked', self.del_selected)
        b = gtk.Button(stock = 'forgetpwd')
        hbox.pack_start(b)
        b.connect('clicked', self.forget_selected)
        self.pw_b = gtk.Button(_('_Show Passwords'), None, True)
        hbox.pack_start(self.pw_b)
        self.pw_b.connect('clicked', self.show_hide_pw)

        self.none = gtk.Button(_('_Create Configuration'), None, True)
        vbox.pack_start(self.none)
        self.none.connect('clicked', self.edit_single)
        self.update_tree()
        # need to show window to make tree columns calculate their widths
        self.window.show_all()
        self.window.hide()
        # make wide cols narrow
        for i in xrange(len(cols)):
            col = self.tree.get_column(i)
            w = col.get_width()
            col.set_sizing(gtk.TREE_VIEW_COLUMN_FIXED)
            if w > 150:
                col.set_fixed_width(150)
            else:
                col.set_fixed_width(w)
        # hide password column by default
        self.tree.get_column(4).set_visible(False)
        self.update_tree()
        self.set_selected(0)
        self.err_msg.hide()
        self.window.show()

    def end (self, *args):
        if self.children:
            q = _('If this window is closed, all open editor windows will close without saving; close anyway?')
            if not self.confirm(_('Confirm close'), q, 3):
                return True
        self.window.destroy()
        update_gui()
        self.icon.editor_open = False
        while self.children:
            self.children[0].end()
        return False

    def esc (self, *args):
        self.end()
        return True

    def load_config (self):
        # load prefs from disk
        self.icon.cannot_quit = True
        try:
            with open(CONF + 'editorconfig') as f:
                order, self.show_dialogues = load(f)
        except (IOError, UnpicklingError, EOFError):
            order = sorted(self.configs.keys())
            self.show_dialogues = [True, True, True, True, True]
        self.icon.cannot_quit = False
        # maintain compatibility with previous versions
        while len(self.show_dialogues) < 6:
            self.show_dialogues.append(True)
        # known existing configs followed by alphabetised unknown configs
        self.tree_order = [x for x in order if x in self.configs] + sorted(x for x in self.configs if x not in order)

    def save_config (self):
        # save some stuff to disk
        self.icon.cannot_quit = True
        try:
            with open(CONF + 'editorconfig', 'w') as f:
                dump((self.tree_order, self.show_dialogues), f)
        except IOError:
            pass
        self.icon.cannot_quit = False

    def save_icon_config (self):
        # save configs to disk
        self.icon.configs = self.configs
        if not save_config(self.icon):
            msg = _('Couldn\'t save configurations to \'{0}\'; make sure you have sufficient permissions.').format(CONF + 'config')
            d = gtk.MessageDialog(None, 0, gtk.MESSAGE_ERROR, gtk.BUTTONS_OK, msg)
            d.run()
            d.destroy()

    def get_selected (self):
        # return selected config name, or None
        sel = self.tree.get_selection().get_selected_rows()[1]
        if not sel:
            self.err_msg.show()
            return None
        else:
            self.err_msg.hide()
            return self.tree_order[sel[0][0]]

    def set_selected (self, sel):
        # set selected tree row to given config name or index
        if isinstance(sel, str):
            # get index
            sel = self.tree_order.index(sel)
        if len(self.tree_order):
            sel %= len(self.tree_order)
        self.tree.get_selection().select_path(sel)

    def confirm (self, title, text, ID, save_now = True):
        # ask a question with 'don't ask again' checkbox
        if self.show_dialogues[ID]:
            # display dialogue
            response, again = confirm(title, text, self.window, _('don\'t ask again'))
            if response and again:
                    self.show_dialogues[ID] = False
                    if save_now:
                        self.save_config()
            return response
        else:
            return True

    def edit (self, old_alias, alias, data):
        # callback for single-config editors; returns whether changes were made
        if old_alias != alias:
            if alias in self.configs:
                # already exists: confirm overwrite
                q = _('Configuration \'{0}\' exists; overwrite it?'.format(alias))
                if not self.confirm(_('Confirm overwrite'), q, 2, False):
                    return False
            if old_alias:
                # renamed: delete original
                del self.configs[old_alias]
        self.configs[alias] = data
        self.save_icon_config()
        self.update_tree()
        self.set_selected(alias)
        self.save_config()
        return True

    def finish (self, instance):
        # callback for single-config editors
        self.children.remove(instance)
        self.err_msg.hide()

    def show_hide_pw (self, widget):
        obscured = self.tree.get_column(3)
        visible = self.tree.get_column(4)
        if visible.get_visible():
            visible.set_visible(False)
            obscured.set_visible(True)
            self.pw_b.set_label(_('_Show passwords'))
        else:
            q = _('Display all saved passwords?')
            if not self.confirm(_('Confirm action'), q, 1):
                return
            obscured.set_visible(False)
            visible.set_visible(True)
            self.pw_b.set_label(_('_Hide passwords'))
        self.err_msg.hide()

    def order_from_tree (self, widget, path):
        # save order to disk - called when rows manually reordered
        self.tree_order = [self.ls.get(self.ls.get_iter(x), 0)[0] for x in xrange(len(self.tree_order))]
        self.save_config()
        self.err_msg.hide()

    def update_tree (self):
        # update self.tree_order
        for conf in self.configs:
            if conf not in self.tree_order:
                self.tree_order.append(conf)
        rm = []
        for conf in self.tree_order:
            if conf not in self.configs:
                rm.append(conf)
        for conf in rm:
            self.tree_order.remove(conf)
        # change what's visible based on existence of any configs
        if len(self.tree_order):
            self.none.hide()
            self.outer.show()
        else:
            self.outer.hide()
            self.none.show()
        # update self.tree's ListStore
        self.ls.disconnect(self.ls_id)
        self.ls.clear()
        self.ls_id = self.ls.connect('row-deleted', self.order_from_tree)
        for conf in self.tree_order:
            data = self.configs[conf]
            obscured_pw = _('[not stored]') if data[4] is None else _('[stored]')
            self.ls.append([conf, data[0], data[1], obscured_pw, data[4], data[2], data[3]])

    def edit_single (self, widget, conf = None, col = None):
        # open single-config editor
        if conf is not None and isinstance(conf[0], int):
            conf = self.tree_order[conf[0]]
        if conf is None:
            self.children.append(SingleEditor(self, self.window, self.edit, self.finish))
        else:
            self.children.append(SingleEditor(self, self.window, self.edit, self.finish, conf, self.configs[conf]))
        self.err_msg.hide()

    def edit_selected (self, widget):
        # open single-config editor for selected config, if any
        sel = self.get_selected()
        if sel is None:
            return
        self.edit_single(None, sel)

    def dup_selected (self, widget):
        sel = self.get_selected()
        if sel is None:
            return
        # compute new config name
        alias = sel + ' (copy)'
        n = 2
        while alias in self.tree_order:
            alias = sel + ' (copy {0})'.format(n)
            n += 1
        # copy data properly
        data = self.configs[sel]
        self.configs[alias] = data[:5] + [[i[:] for i in data[j]] for j in (5, 6)]
        self.save_icon_config()
        # select new config
        index = self.tree_order.index(sel) + 1
        self.tree_order.insert(index, alias)
        self.update_tree()
        self.set_selected(index)
        self.save_config()

    def del_selected (self, widget):
        sel = self.get_selected()
        if sel is None:
            return
        q = _('Delete configuration \'{0}\'?').format(sel)
        if not self.confirm(_('Confirm delete'), q, 0, False):
            return
        # delete
        del self.configs[sel]
        self.save_icon_config()
        sel = max(self.tree_order.index(sel) - 1, 0)
        self.update_tree()
        # select config above deleted one
        self.set_selected(sel)
        self.save_config()

    def forget_selected (self, widget):
        # forget password for selected config
        sel = self.get_selected()
        if sel is None:
            return
        if self.configs[sel][4]:
            q = _('Forget configuration password \'{0}\'?').format(sel)
            if not self.confirm(_('Confirm forget'), q, 4):
                return
        # forget
        self.configs[sel][4] = None
        self.save_icon_config()
        self.update_tree()
        self.set_selected(sel)

    def tree_clicked (self, tree, event):
        # right-click menu
        if event.button != 3:
            return
        sel = tree.get_path_at_pos(int(event.x), int(event.y))
        if sel is None:
            return
        sel = sel[0][0]
        self.set_selected(sel)
        # create menu
        menu = gtk.Menu()
        item = gtk.ImageMenuItem(gtk.STOCK_EDIT)
        menu.append(item)
        item.connect('activate', self.dup_selected)
        item = gtk.ImageMenuItem('duplicate')
        menu.append(item)
        item.connect('activate', self.edit_selected)
        item = gtk.ImageMenuItem(gtk.STOCK_DELETE)
        menu.append(item)
        item.connect('activate', self.del_selected)
        item = gtk.ImageMenuItem('forgetpwd')
        menu.append(item)
        item.connect('activate', self.forget_selected)
        menu.show_all()
        menu.popup(None, None, None, event.button, event.time)