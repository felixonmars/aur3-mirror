"""ZetaBoards topic fetcher GUI package by J.

Licensed under the GNU General Public License, version 3; if this was not
included, you can find it here:
    http://www.gnu.org/licenses/gpl-3.0.txt

"""

# TODO:
# 1.9.0: new icons: notification and logo
# 'view topics' menu entry: open window with topic URLs laid out by forum (links? python-sexy if can't otherwise) (in ScrolledWindow)

import sys
import os
from os.path import abspath, dirname, pardir, isdir, isfile
from time import sleep, localtime, strftime, mktime
from cPickle import load, dump
from webbrowser import open as open_url
from multiprocessing import freeze_support

import gtk
import gobject
try:
    from gobject import GError
except ImportError:
    from glib import GError

from .. import __version__
from ..backend import CONF, CONFIGS, fetch, util
from ..gtkutil import get_login

# paths
for path in (dirname(__file__) + os.sep + pardir + os.sep + pardir, '/usr/share/zb-fetcher/', 'lib'):
    ICON_PATH = abspath(path) + os.sep
    if isdir(ICON_PATH) and isfile(ICON_PATH + 'new.png'):
        break
for path in (ICON_PATH + pardir, '/usr/share/pixmaps', 'lib'):
    ICON = abspath(path) + os.sep + 'zb-fetcher.png'
    if isfile(ICON):
        break
ICON_NAMES = ('new.png', 'old.png', 'work.png', 'disabled.png', 'error.png')
DEFAULT_ICONS = [ICON_PATH + name for name in ICON_NAMES]
if not all((isfile(fn) for fn in DEFAULT_ICONS)):
    raise IOError(_('couldn\'t find default icons; ensure installation was performed correctly'))
DEFAULT_SET = _('default')
CUSTOM_ICON_PATH = CONF + 'icons' + os.sep
DUMP = CONF + 'dump'
ICON_CONF = CONF + 'iconconfig'

def load_config (icon, of_zbi = False):
    icon.cannot_quit = True
    if of_zbi:
        result = util.load_dict(ICON_CONF)
    else:
        result = util.load_configs()
    icon.cannot_quit = False
    return result

def save_config (icon):
    icon.cannot_quit = True
    success = util.save_configs(icon.configs)
    icon.cannot_quit = False
    if icon.prefs_open:
        icon.prefs_open.reload_configs()
    return success

def open_editor (widget, icon):
    if icon.editor_open:
        icon.editor_open.window.present()
    else:
        icon.editor_open = Editor(icon)

def open_prefs (widget, icon):
    if icon.prefs_open:
        icon.prefs_open.window.present()
    else:
        icon.prefs_open = Preferences(icon)

def apply_prefs (icon):
    icon.cannot_quit = True
    icon.cannot_quit = False
    t = int(icon.prefs['time']) * 60
    if icon.time != t:
        # start new timer to match setting
        icon.time = t
        last = icon.last_checked if icon.last_checked else icon.startup
        icon.timer_id += 1
        time_left = max(int(icon.time - (mktime(localtime()) - mktime(last))), 1)
        gobject.timeout_add_seconds(time_left, new, None, icon, icon.timer_id, False)
    set_icon(icon)
    show_homepages(icon)
    show_overrides(icon)
    try:
        with open(CONF + 'iconconfig', 'w') as f:
            dump(icon.prefs, f)
    except IOError:
        pass

def wait (processing, icon):
    """Keep GTK main loop going while a process is running."""
    while processing():
        if icon.quitting:
            # backend process has .daemon = True, so will die on exit
            # it does nothing that would be dangerous to quit, so just cancel it
            if icon.finished:
                sys.exit()
            else:
                break
        # might be nothing to do, so don't block
        gtk.main_iteration(False)
        sleep(.001)

def validate_pw (pwd, remember, icon, data, config, every, offline, cal, ignore, reuse_cookie):
    temp = fetch.run_root(True, wait, (icon,), data[0], data[1], pwd, every, [x[:] for x in cal], ignore, offline, reuse_cookie)
    if isinstance(temp, int):
        return False
    else:
        return temp

def new_single (icon, config, every, offline, ignore, recal):
    if icon.quitting:
        return
    data = icon.configs[config][:]
    cal = [[], [], []] if recal else data[5]
    ignore = [[], []] if ignore else data[6]
    save_pw = False
    if not data[4]:
        # no password stored in config; ask for one
        # don't reuse cookie, since if it was created using the correct password
        # and this is incorrect, we might end up saving the incorrect password
        root_args = (icon, data, config, every, offline, cal, ignore, False)
        title = _('ZetaBoards topic fetcher - password entry')
        text = _('Enter password for {0} at {1}.').format(data[1], data[0].split('/')[-1])
        error = _('Password incorrect; try again.')
        temp = get_login(title, None, text, True, _('remember password'), validate_pw, root_args, True, error, _('Username'), _('Password'))
        if temp is None:
            print _('password entry canceled; skipping to next forum (if any)')
            return
        data[4], save_pw, temp = temp
    # fetch topics
    try:
        temp
    except NameError:
        temp = fetch.run_root(True, wait, (icon,), data[0], data[1], data[4], every, [x[:] for x in cal], ignore, offline)
    if temp is None:
        return
    if isinstance(temp, int):
        icon.error = True
        msg = _('Couldn\'t log in ({0} at {1}); check your internet connection and login details.').format(data[1], util.full_forum(data[0]))
        icon.error_data = gtk.MessageDialog(None, 0, gtk.MESSAGE_ERROR, gtk.BUTTONS_OK, msg)
        return
    # save some stuff back to disk
    save_cal = temp[0] != cal and temp[0] is not False
    if save_cal:
        icon.configs[config][5] = temp[0]
    if save_pw:
        icon.configs[config][4] = data[4]
    if save_cal or save_pw:
        save_config(icon)
    # do stuff with topics
    topics = temp[1]
    total = sum(len(x) for x in icon.topics.values())
    if len(topics) > 0:
        n = sum(len(x[1]) for x in topics)
        for x in topics:
            if config in icon.topics:
                icon.topics[config] += [i for i in x[1] if i not in icon.topics[config]]
            else:
                icon.topics[config] = [i for i in x[1]]
        total = sum(len(x) for x in icon.topics.values())
        print ngettext('{0} topic with new posts found;', '{0} topics with new posts found;', n).format(n), ngettext('now have {0} topic queued up', 'now have {0} topics queued up', total).format(total)
        # dump to file
        icon.cannot_quit = True
        try:
            with open(DUMP, 'w') as f:
                dump(icon.topics, f)
        except IOError:
            # non-essential, not worth bothering anyone about
            pass
        icon.cannot_quit = False
    else:
        print _('no topics with new posts found;'), ngettext('now have {0} topic queued up', 'now have {0} topics queued up', total).format(total)

def new (widget = None, icon = None, t = None, rtn = True, every = False, ignore = False, recal = False):
    if not icon.is_embedded():
        print _('error: icon not embedded on a panel; aborting')
        quit(None, icon)
    if icon.disabled:
        icon.queued = True
    if icon.disabled or icon.working or icon.error:
        return rtn
    if t is None or (icon.timer_id == t and not rtn):
        # start new timer
        icon.timer_id += 1
        gobject.timeout_add_seconds(icon.time, new, None, icon, icon.timer_id)
    elif icon.timer_id != t:
        # ignore and end old timer
        return False
    # parse icon prefs
    icon.working = True
    icon.menu.do.hide()
    icon.menu.restore.hide()
    icon.menu.discard.hide()
    icon.menu.line.hide()
    icon.menu.disable.hide()
    set_icon(icon)
    # check necessary forums
    if icon.prefs['using_n'] == 0:
        # make sure one or more configs are selected
        if icon.prefs['using0'] is not None:
            new_single(icon, icon.prefs['using0'], icon.prefs['using0_all'] or every, icon.prefs['using0_off'], ignore, recal)
    elif icon.prefs['using_n'] == 1:
        for x in icon.prefs['using1_list']:
            new_single(icon, x[0], x[1] or every, x[2], ignore, recal)
    elif icon.prefs['using_n'] == 2:
        for x in icon.configs:
            new_single(icon, x, icon.prefs['using2_all'] or every, icon.prefs['using2_off'], ignore, recal)
    # set icon stuff
    total = sum(len(x) for x in icon.topics.values())
    icon.new = total > 0
    if icon.new and not icon.disabled:
        icon.menu.line.show()
        icon.menu.do.show()
        icon.menu.discard.show()
    if icon.new:
        icon.menu.do.set_submenu(submenu(icon))
    if icon.last:
        icon.menu.restore.show()
        icon.menu.line.show()
    icon.menu.disable.show()
    icon.working = False
    icon.last_checked = localtime()
    set_icon(icon)
    return rtn

def action (widget, icon, data):
    if icon.disabled or icon.working or not icon.new:
        return
    if data == True:
        # do for all
        topics = dict((x, icon.topics[x][:]) for x in icon.topics)
    elif data == False:
        if icon.prefs['click_new'] == 0:
            # prefs: do for all
            topics = dict((x, icon.topics[x][:]) for x in icon.topics)
        elif icon.prefs['click_new'] == 1:
            # prefs: do for forum with most topics
            temp = [(len(icon.topics[x]), x, icon.topics[x]) for x in icon.topics]
            temp.sort()
            topics = {temp[-1][1]: temp[-1][2][:]}
        else:
            # prefs: do for set number of topics
            n = 0
            lim = int(icon.prefs['next_x_topics'])
            topics = {}
            for conf in icon.topics:
                temp = icon.topics[conf][:lim - n]
                if icon.topics[conf] and not temp:
                    break
                n += len(temp)
                topics[conf] = temp
    else:
        # do for given forum
        topics = dict([(data, icon.topics[data][:])])
    to_save = {}
    to_run = {}
    # compile list of actions to do
    if icon.prefs['actions']:
        # use override rules
        if icon.prefs['actions_do'][0][0]:
            fn = icon.prefs['actions_do'][0][1]
            for x in topics:
                to_save[x] = fn
        if icon.prefs['actions_do'][1][0]:
            cmd = icon.prefs['actions_do'][1][1]
            for x in topics:
                to_run[x] = cmd
    else:
        # use rules from config
        for x in topics:
            if icon.configs[x][2] is not None:
                to_save[x] = icon.configs[x][2]
            if icon.configs[x][3] is not None:
                to_run[x] = icon.configs[x][3]
    # do actions
    success = {}
    if to_save:
        icon.cannot_quit = True
        done = util.action_save(((x, topics[x], to_save[x]) for x in to_save))
        icon.cannot_quit = False
        for x in done:
            success[x] = (done[x], None)
    if to_run:
        done = util.action_run(((x, topics[x], to_run[x]) for x in to_run))
        for x in done:
            if x in success:
                success[x] = (success[x][0], done[x])
            else:
                success[x] = (None, done[x])
    last = {}
    error_data = []
    for x in success:
        r = s = True
        if success[x][0] is False:
            # save failed
            s = False
            icon.error = True
            error_data.append(_('Configuration \'{0}\': couldn\'t save to \'{1}\'; make sure the parent directory exists and you have sufficient permissions.').format(x, to_save[x]))
        if success[x][1] is False:
            # run failed
            r = False
            icon.error = True
            error_data.append(_('Configuration \'{0}\': couldn\'t run \'{1}\'; make sure it exists and is executable.').format(x, to_run[x]))
        if s and r:
            # success
            last[x] = []
            for topic in topics[x]:
                last[x].append(topic)
                icon.topics[x].remove(topic)
            if not icon.topics[x]:
                del icon.topics[x]
        else:
            if len(error_data) > 1:
                error_data.insert(0, _('Some errors occurred:'))
            error_data.append(_('Would you like to retain the topic list?'))
            icon.error_data = gtk.MessageDialog(None, 0, gtk.MESSAGE_ERROR, gtk.BUTTONS_YES_NO, '\n\n'.join(error_data))
    if last:
        # something didn't fail
        icon.last = last
        icon.menu.restore.show()
    icon.new = bool(icon.topics)
    if icon.new:
        icon.menu.do.set_submenu(submenu(icon))
    else:
        icon.menu.do.hide()
        icon.menu.discard.hide()
    set_icon(icon)
    if icon.error:
        if icon.prefs['show_error']:
            handle_error(icon)
    elif not icon.new:
        # remove topic list dump
        try:
            os.remove(DUMP)
        except OSError:
            pass

def handle_error (icon):
    # don't want lots of these going on at once
    if icon.running_error:
        return
    icon.running_error = True
    response = icon.error_data.run()
    if response == gtk.RESPONSE_NO:
        discard(None, icon)
    if response in (gtk.RESPONSE_YES, gtk.RESPONSE_NO, gtk.RESPONSE_OK):
        icon.error_data.destroy()
        icon.error = False
        set_icon(icon)
    else:
        # if yes or no not clicked, want to keep the error around
        icon.error_data.hide()
    icon.running_error = False

def open_about (widget, icon):
    if not icon.about_open:
        about = gtk.AboutDialog()
        about.set_name(_('ZetaBoards topic fetcher'))
        about.set_version(__version__)
        about.set_comments(_('A status icon to check periodically for new posts.'))
        about.set_copyright(_('Copyright 2009-2011 J'))
        icon.cannot_quit = True
        for license in ('LICENSE', 'LICENSE.txt', '/usr/share/common-licenses/GPL-3'):
            try:
                with open(license) as f:
                    about.set_license(f.read())
                break
            except IOError:
                pass
        icon.cannot_quit = False
        about.set_website('http://i-know-nothing.co.cc/ZetaBoards_topic_fetcher')
        try:
            about.set_logo(gtk.gdk.pixbuf_new_from_file(ICON))
        except GError:
            pass
        icon.about_open = about
    icon.about_open.run()
    icon.about_open.hide()

def activated (widget, icon):
    if icon.error:
        # show error dialogue
        handle_error(icon)
    elif icon.new:
        action(None, icon, False)
    elif icon.prefs['click_old'] == 0:
        open_prefs(None, icon)
    elif icon.prefs['click_old'] == 1:
        new(None, icon)
    elif icon.prefs['click_old'] == 2:
        if icon.disabled:
            enable(None, icon)
        else:
            disable(None, icon)

def show_overrides (icon):
    # check if check all/ignored ignored options should be displayed
    if icon.prefs['using_n'] == 0:
        check_all = not icon.prefs['using0_all']
        ignore_ignored = False if icon.prefs['using0'] is None else icon.configs[icon.prefs['using0']][-1] != [[], []]
    elif icon.prefs['using_n'] == 1:
        check_all = not all(x[1] for x in icon.prefs['using1_list'])
        ignore_ignored = not all(icon.configs[x[0]][6] == [[], []] for x in icon.prefs['using1_list'])
    else:
        check_all = not icon.prefs['using2_all']
        ignore_ignored = False in (x[6] == [[], []] for x in icon.configs.itervalues())
    check_all &= not icon.disabled
    ignore_ignored &= not icon.disabled
    # set menu item visibility
    if check_all:
        icon.menu.check_all.show()
    else:
        icon.menu.check_all.hide()
    if ignore_ignored:
        icon.menu.ignore.show()
        icon.menu.recal_ignore.show()
    else:
        icon.menu.ignore.hide()
        icon.menu.recal_ignore.hide()
    if check_all and ignore_ignored:
        icon.menu.all_ignore.show()
    else:
        icon.menu.all_ignore.hide()

def restore (widget, icon):
    for x in icon.last:
        if x in icon.topics:
            icon.topics[x] += [i for i in icon.last[x] if i not in icon.topics[x]]
        else:
            icon.topics[x] = icon.last[x]
    icon.last = {}
    icon.new = True
    set_icon(icon)
    icon.menu.restore.hide()
    icon.menu.do.set_submenu(submenu(icon))
    icon.menu.do.show()
    icon.menu.discard.show()
    # dump to file
    icon.cannot_quit = True
    try:
        with open(DUMP, 'w') as f:
            dump(icon.topics, f)
    except IOError:
        # non-essential, not worth bothering anyone about
        pass
    icon.cannot_quit = False

def discard (widget, icon):
    icon.last = icon.topics
    icon.topics = {}
    icon.new = False
    set_icon(icon)
    icon.menu.restore.show()
    icon.menu.do.hide()
    icon.menu.discard.hide()
    # remove dump
    try:
        os.remove(DUMP)
    except OSError:
        pass

def disable (widget, icon):
    if icon.working:
        return
    icon.disabled = True
    set_icon(icon)
    icon.menu.check.hide()
    icon.menu.do.hide()
    icon.menu.discard.hide()
    icon.menu.line.hide()
    icon.menu.restore.hide()
    show_overrides(icon)
    icon.menu.disable.hide()
    icon.menu.enable.show()

def enable (widget, icon):
    icon.disabled = False
    set_icon(icon)
    icon.menu.enable.hide()
    icon.menu.disable.show()
    icon.menu.check.show()
    if icon.new:
        icon.menu.do.show()
        icon.menu.discard.show()
    if icon.last:
        icon.menu.restore.show()
    if icon.last or icon.new:
        icon.menu.line.show()
    show_overrides(icon)
    if icon.queued:
        icon.queued = False
        new(None, icon)

def popup (icon, button, time):
    if icon.error:
        # show error dialogue
        handle_error(icon)
    elif button == 3:
        # show right click menu
        icon.menu.popup(None, None, None, button, time)

def submenu (icon):
    submenu = gtk.Menu()
    if len(icon.topics) > 1:
        item = gtk.MenuItem(_('_All ({0})').format(sum(len(x) for x in icon.topics.values())))
        submenu.append(item)
        item.connect('activate', action, icon, True)
        item = gtk.MenuItem()
        submenu.append(item)
    temp = [(len(icon.topics[x]), x) for x in icon.topics]
    temp.sort(reverse = True)
    for x in temp:
        item = gtk.MenuItem('_{0} ({1})'.format(x[1], x[0]))
        item.connect('activate', action, icon, x[1])
        submenu.append(item)
    submenu.show_all()
    return submenu

def open_homepage (widget, url):
    open_url(url)

def show_homepages (icon):
    # get forum list
    if icon.prefs['using_n'] == 0:
        forum = icon.prefs['using0']
        forums = [] if forum is None else [forum]
    elif icon.prefs['using_n'] == 1:
        forums = [forum[0] for forum in icon.prefs['using1_list']]
    else:
        forums = [forum for forum in icon.configs.keys()]
    # create menu items
    try:
        icon.menu.home.disconnect(icon.menu.home_cb_id)
        del icon.menu.home_cb_id
    except AttributeError:
        pass
    if len(forums) == 0:
        # no forums set
        icon.menu.home.hide()
    elif len(forums) == 1:
        # one forum: create single item
        icon.menu.home.set_submenu(None)
        icon.menu.home.set_label(_('_Open index: {0}').format(forums[0]))
        url = icon.configs[forums[0]][0]
        icon.menu.home_cb_id = icon.menu.home.connect('activate', open_homepage, 'http://{0}/index'.format(util.full_forum(url)))
        icon.menu.home.show()
    else:
        # multiple forums: create submenu
        submenu = gtk.Menu()
        for forum in sorted(forums):
            item = gtk.MenuItem('_' + forum)
            url = icon.configs[forum][0]
            item.connect('activate', open_homepage, 'http://{0}/index'.format(util.full_forum(url)))
            submenu.append(item)
        icon.menu.home.set_submenu(submenu)
        icon.menu.home.set_label(_('_Open index pages'))
        icon.menu.home.show_all()

def ask_configs_yes (button, icon, d):
    d.destroy()
    open_editor(None, icon)

def ask_configs_cancel (widget, d, event = None):
    if type(widget) is gtk.MessageDialog:
        widget.destroy()
    else:
        d.destroy()

def ask_configs (icon):
    d = gtk.MessageDialog(None, 0, gtk.MESSAGE_QUESTION, gtk.BUTTONS_YES_NO, _('No configurations exist; open the editor?'))
    children = d.action_area.get_children()
    yes = not 'yes' in children[0].get_label()
    children[yes].connect('clicked', ask_configs_yes, icon, d)
    children[not yes].connect('clicked', ask_configs_cancel, d)
    d.connect('delete_event', ask_configs_cancel)
    d.show()

def set_icon (icon):
    total = sum(len(x) for x in icon.topics.values())
    if icon.last_checked:
        t = strftime('%I:%M%p', icon.last_checked).lower()
        if t.find(':') == 2 and t[0] == '0' and t[1] != '0':
            t = t[1:]
    append = _(' (last checked {0})').format(t) if icon.last_checked else ''
    if icon.error:
        n = 4
        t = _('Error: click for details')
    elif icon.disabled:
        n = 3
        t = _('Disabled{0}').format(append)
    elif icon.working:
        n = 2
        t = _('Working...')
    elif icon.new:
        n = 0
        t = ngettext('{0} topic with new posts{1}', '{0} topics with new posts{1}', total).format(total, append)
    else:
        n = 1
        t = _('No new topics{0}').format(append)
    if icon.prefs['icons'] == DEFAULT_SET:
        fn = DEFAULT_ICONS[n]
    else:
        fn = ICON_PATH + icon.prefs['icons'] + os.sep + ICON_NAMES[n]
        # if doesn't exist, fall back on default set (which we knew to exist at time of startup)
        if not os.path.isfile(fn):
            fn = DEFAULT_ICONS[n]
    icon.set_from_file(fn)
    icon.set_tooltip(t)

def quit (widget, icon):
    icon.quitting = True
    n = 0
    while icon.cannot_quit:
        # doing something it might be destructive to terminate
        if n == 600:
            # something's obviously gone wrong: quit anyway
            break
        print _('waiting 0.1s...')
        sleep(.1)
        n += 1
    # destroy about dialogue
    if icon.about_open:
        icon.about_open.destroy()
    # explicitly hide icon (otherwise it hangs around on Windows sometimes)
    icon.set_visible(False)
    gtk.main_quit()
    icon.finished = True

def image_item (img, label):
    # convenience function to create an ImageMenuItem with custom stock image
    item = gtk.ImageMenuItem(label)
    item.set_image(gtk.image_new_from_stock(img, gtk.ICON_SIZE_MENU))
    return item

try:
    from editor import Editor
    from prefs import Preferences
except ImportError:
    raise ImportError(_('couldn\'t find modules; ensure installation was performed correctly'))

def run ():
    deleted = len(util.cleanup_cookies())
    if deleted:
        print ngettext('cleaned up {0} expired cookie', 'cleaned up {0} expired cookies', deleted).format(deleted)
    freeze_support()
    icon = gtk.StatusIcon()

    menu = gtk.Menu()
    menu.do = gtk.MenuItem(_('Per_form action(s)'))
    menu.append(menu.do)
    menu.restore = image_item(gtk.STOCK_UNDO, _('_Restore previous topics'))
    menu.restore.connect('activate', restore, icon)
    menu.append(menu.restore)
    menu.discard = image_item(gtk.STOCK_CLEAR, _('D_iscard topics'))
    menu.discard.connect('activate', discard, icon)
    menu.append(menu.discard)
    menu.line = gtk.SeparatorMenuItem()
    menu.append(menu.line)
    overrides = image_item(gtk.STOCK_EXECUTE, _('Check now: o_verrides'))
    menu.append(overrides)
    sub = gtk.Menu()
    menu.check_all = gtk.MenuItem(_('_All subforums'))
    menu.check_all.connect('activate', new, icon, None, True, True)
    sub.append(menu.check_all)
    menu.ignore = gtk.MenuItem(_('_Ignore ignored'))
    menu.ignore.connect('activate', new, icon, None, True, False, True)
    sub.append(menu.ignore)
    menu.all_ignore = gtk.MenuItem(_('All subforums an_d ignore ignored'))
    menu.all_ignore.connect('activate', new, icon, None, True, True, True)
    sub.append(menu.all_ignore)
    item = gtk.MenuItem(_('_Recalibrate'))
    item.connect('activate', new, icon, None, True, False, False, True)
    sub.append(item)
    menu.recal_ignore = gtk.MenuItem(_('Recalibrate a_nd ignore ignored'))
    menu.recal_ignore.connect('activate', new, icon, None, True, False, True, True)
    sub.append(menu.recal_ignore)
    sub.show_all()
    overrides.set_submenu(sub)
    overrides.show()
    menu.check = image_item(gtk.STOCK_EXECUTE, _('_Check now'))
    menu.check.connect('activate', new, icon)
    menu.append(menu.check)
    menu.check.show()
    menu.home = gtk.ImageMenuItem(gtk.STOCK_HOME)
    menu.append(menu.home)
    item = gtk.ImageMenuItem(gtk.STOCK_PREFERENCES)
    item.connect('activate', open_prefs, icon)
    menu.append(item)
    item.show()
    item = gtk.SeparatorMenuItem()
    menu.append(item)
    item.show()
    menu.disable = image_item(gtk.STOCK_NO, _('_Disable'))
    menu.disable.connect('activate', disable, icon)
    menu.append(menu.disable)
    menu.disable.show()
    menu.enable = image_item(gtk.STOCK_YES, _('_Enable'))
    menu.enable.connect('activate', enable, icon)
    menu.append(menu.enable)
    item = gtk.ImageMenuItem(gtk.STOCK_ABOUT)
    item.connect('activate', open_about, icon)
    menu.append(item)
    item.show()
    item = gtk.ImageMenuItem(gtk.STOCK_QUIT)
    item.connect('activate', quit, icon)
    menu.append(item)
    item.show()
    menu.show()

    icon.connect('activate', activated, icon)
    icon.connect('popup-menu', popup)
    icon.set_visible(True)
    icon.error = False
    icon.running_error = False
    icon.disabled = False
    icon.working = False
    icon.new = False
    icon.queued = False
    icon.prefs_open = False
    icon.editor_open = False
    icon.about_open = False
    icon.cannot_quit = False
    icon.quitting = False
    icon.finished = False
    icon.last_checked = False
    icon.startup = localtime()
    icon.topics = {}
    icon.last = {}
    icon.menu = menu
    icon.configs = load_config(icon)
    icon.timer_id = 1

    # get preferences
    icon.prefs = load_config(icon, True)
    defaults = {
        'time': 15,
        'on_start': True,
        'using_n': 0,
        'using0': None,
        'using0_all': False,
        'using0_off': False,
        'using1_list': [],
        'using2_all': False,
        'using2_off': False,
        'click_new': 0,
        'next_x_topics': 10,
        'click_old': 0,
        'show_error': False,
        'actions': False,
        'actions_do': [[False, ''], [False, '']],
        'icons': DEFAULT_SET
    }
    if icon.prefs:
        # make sure configs chosen in prefs exist
        if icon.prefs['using_n'] == 0 and icon.prefs['using0'] not in icon.configs:
            icon.prefs['using0'] = None
            open_prefs(None, icon)
        elif icon.prefs['using_n'] == 1 and not all(x[0] in icon.configs for x in icon.prefs['using1_list']):
            icon.prefs['using1_list'] = [x for x in icon.prefs['using1_list'] if x[0] in icon.configs]
            if not icon.prefs['using1_list']:
                open_prefs(None, icon)
        # maintain compatibility with older versions
        if not isinstance(icon.prefs['icons'], basestring):
            icon.prefs['icons'] = defaults['icons']
        for key in defaults:
            if key not in icon.prefs:
                icon.prefs[key] = defaults[key]
    else:
        # else initialise defaults and open preferences dialogue
        icon.prefs = defaults
        open_prefs(None, icon)
    if os.path.exists(DUMP):
        print _('found topic dump; restoring...')
        with open(DUMP) as f:
            icon.topics = load(f)
        icon.new = True
        icon.menu.line.show()
        icon.menu.do.show()
        icon.menu.discard.show()
        icon.menu.do.set_submenu(submenu(icon))
    set_icon(icon)
    show_homepages(icon)
    show_overrides(icon)
    icon.time = int(icon.prefs['time']) * 60

    if icon.prefs['on_start']:
        # if exist already and want to, fetch straight away
        # wait a second to make sure icon's initialised
        gobject.timeout_add_seconds(1, new, None, icon, icon.timer_id, False)
    else:
        # just start the normal timer
        gobject.timeout_add_seconds(icon.time, new, None, icon, icon.timer_id)
    if not icon.configs:
        ask_configs(icon)
    gtk.main()