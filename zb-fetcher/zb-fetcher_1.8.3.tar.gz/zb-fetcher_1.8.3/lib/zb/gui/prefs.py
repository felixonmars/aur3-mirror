"""ZetaBoards topic fetcher preferences module by J.

Licensed under the GNU General Public License, version 3; if this was not
included, you can find it here:
    http://www.gnu.org/licenses/gpl-3.0.txt

"""

import os
from shutil import rmtree
from tarfile import open as open_ar, ReadError

import gtk
import gobject
try:
    from gobject import GError
except ImportError:
    from glib import GError

from ..backend import HOME, CONF
from ..gui import ICON, ICON_PATH, ICON_NAMES, DEFAULT_SET, CUSTOM_ICON_PATH, load_config, open_editor, apply_prefs, set_icon
from ..gtkutil import italic, defaultise, tabify, confirm

TEMP = CUSTOM_ICON_PATH + 'temp' + os.sep
SETS = CUSTOM_ICON_PATH + 'sets'

class IconManager (gtk.VBox):
    def __init__ (self, selected, icon, *args, **kw):
        gtk.VBox.__init__(self, *args, **kw)
        self.selected = selected
        self.icon = icon
        self.confirm_del = not os.path.isfile(CONF + 'deliconsetconfirm')
        self.disp = gtk.HBox(False, 6)
        self.pack_start(self.disp, False)

        # tree
        self.ls = gtk.ListStore(gtk.gdk.Pixbuf, gobject.TYPE_STRING)
        self.ls.set_sort_column_id(1, gtk.SORT_ASCENDING)
        self.ls.set_sort_func(1, self.sort_tree)
        self.tree = gtk.TreeView(self.ls)
        self.pack_start(self.tree)
        self.tree.set_headers_visible(False)
        col = gtk.TreeViewColumn()
        self.tree.append_column(col)
        renderers = (gtk.CellRendererPixbuf, gtk.CellRendererText)
        attrs = ('pixbuf', 'text')
        for i in xrange(2):
            renderer = renderers[i]()
            col.pack_start(renderer, i)
            col.add_attribute(renderer, attrs[i], i)
        self.tree_sel = self.tree.get_selection()
        self.tree_sel.connect('changed', self.select)
        self.update()

        # buttons
        buttons = gtk.HBox(False, 6)
        self.pack_start(buttons, False)
        add = gtk.Button(stock = gtk.STOCK_ADD)
        buttons.pack_end(add, False)
        add.connect('clicked', self.load)
        self.rm = gtk.Button(stock = gtk.STOCK_DELETE)
        buttons.pack_end(self.rm, False)
        self.rm.connect('clicked', self.delete)

        i = self.get_row(self.selected)
        self.tree_sel.select_path(0 if i is None else i)

    def get_sets (self):
        # get listed sets in sets file
        self.icon.cannot_quit = True
        try:
            with open(SETS) as f:
                sets = [line.strip() for line in f.readlines()]
        except IOError:
            sets = []
        self.icon.cannot_quit = False
        return sets

    def load (self, widget):
        # load new icon set from file and install
        d = gtk.FileChooserDialog(_('Load icon set'), action = gtk.FILE_CHOOSER_ACTION_OPEN, buttons = (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK))
        d.set_current_folder(HOME)
        if d.run() == gtk.RESPONSE_OK:
            fn = d.get_filename()
        else:
            fn = None
        d.destroy()
        if fn is None:
            return

        self.icon.cannot_quit = True
        error = False
        try:
            f = open_ar(fn)
        except ReadError:
            error = True
        else:
            files = [mem for mem in f if mem.name in ICON_NAMES + ('data',)]
            if len(set(files)) == 6:
                if os.path.exists(TEMP):
                    rmtree(TEMP)
                os.makedirs(TEMP)
                f.extractall(TEMP, files)
            else:
                error = True
            f.close()
        self.icon.cannot_quit = False
        if error:
            msg = _('The selected file is not a valid icon set.')
            d = gtk.MessageDialog(self.icon.prefs_open.window, 0, gtk.MESSAGE_ERROR, gtk.BUTTONS_OK, msg)
            d.run()
            d.destroy()
        else:
            with open(TEMP + 'data') as f:
                name = f.read().strip()
            do = True
            existing = self.get_sets()
            if name == DEFAULT_SET:
                msg = _('This icon set uses a reserved name and cannot be installed.')
                d = gtk.MessageDialog(self.icon.prefs_open.window, 0, gtk.MESSAGE_ERROR, gtk.BUTTONS_OK, msg)
                d.run()
                d.destroy()
            elif name in existing:
                d = gtk.Dialog(None, self.icon.prefs_open.window, 0, (gtk.STOCK_CANCEL, 0, '_Rename', 1))
                v = gtk.VBox()
                v.set_border_width(10)
                l = gtk.Label(_('This icon set has already been installed,\nor its name conflicts with another set.'))
                v.pack_start(l)
                l.show()
                d.vbox.pack_start(v)
                v.show()
                response = d.run()
                d.destroy()
                if response == 1:
                    # show rename dialogue
                    d = gtk.Dialog(None, self.icon.prefs_open.window, 0, (gtk.STOCK_CANCEL, 0, gtk.STOCK_OK, 1))
                    d.action_area.get_children()[0].grab_default()
                    v = gtk.VBox(False, 5)
                    v.set_border_width(10)
                    err = gtk.Label(_('Invalid name.'))
                    v.pack_start(err, False)
                    err.set_property('attributes', italic)
                    l = gtk.Label(_('Enter a new name for the icon set.'))
                    l.show()
                    v.pack_start(l, False)
                    l.set_alignment(0, .5)
                    e = gtk.Entry()
                    v.pack_start(e, False)
                    e.set_activates_default(True)
                    e.show()
                    d.vbox.pack_start(v)
                    v.show()
                    response = d.run()
                    text = e.get_text()
                    while response == 1 and ('/' in text or not text or text in existing or text == DEFAULT_SET):
                        err.show()
                        e.grab_focus()
                        response = d.run()
                        text = e.get_text()
                    if response > 0:
                        # got through error checking: change name to given one
                        name = text
                    else:
                        do = False
                    d.destroy()
                else:
                    do = False

            self.icon.cannot_quit = True
            if do:
                os.remove(TEMP + 'data')
                if os.path.exists(CUSTOM_ICON_PATH + name):
                    rmtree(CUSTOM_ICON_PATH + name)
                os.rename(TEMP, CUSTOM_ICON_PATH + name)
                existing += (name,)
                with open(SETS, 'w') as f:
                    f.write('\n'.join(existing))
                self.update()
            else:
                rmtree(TEMP)
            self.icon.cannot_quit = False

    def delete (self, widget = None):
        name = self.selected
        if self.confirm_del:
            # display dialogue
            q = _('Delete icon set \'{0}\'?').format(name)
            response, again = confirm(_('Confirm delete'), q, self.icon.prefs_open.window, _('don\'t ask again'))
            if response:
                if again:
                    self.confirm_del = False
                    self.icon.cannot_quit = True
                    try:
                        with open(CONF + 'deliconsetconfirm', 'w') as f:
                            f.write('')
                    except IOError:
                        pass
                    self.icon.cannot_quit = False
            else:
                return
        # remove from sets file
        sets = self.get_sets()
        self.icon.cannot_quit = True
        try:
            sets.remove(name)
        except KeyError:
            pass
        else:
            with open(SETS, 'w') as f:
                f.write('\n'.join(sets))
        # remove dir
        try:
            rmtree(CUSTOM_ICON_PATH + name)
        except OSError:
            pass
        self.icon.cannot_quit = True
        # remove from tree
        path = self.get_row(name)
        if path != 0:
            path -= 1
        self.tree_sel.select_path(path)
        self.update()

    def select (self, widget = None):
        # selection changed callback
        i = self.tree_sel.get_selected()[1]
        self.selected = self.ls.get_value(i, 1)
        self.rm.set_sensitive(self.selected != DEFAULT_SET)
        self.display()
        # update status icon
        self.icon.prefs['icons'] = self.selected
        set_icon(self.icon)

    def get_row (self, name, i = False):
        # get icon sets tree iter from set name
        for row in iter(self.ls):
            if row[1] == name:
                return row.iter if i else row.path[0]
        return None

    def pixbuf (self, fn):
        # load an icon from file and return 30*30 pixbuf
        pixbuf = gtk.gdk.pixbuf_new_from_file(fn)
        return pixbuf.scale_simple(30, 30, gtk.gdk.INTERP_BILINEAR)

    def display (self, name = None):
        # render and display icons for the given set
        if name is None:
            name = self.selected
        try:
            self.rendered
        except AttributeError:
            self.rendered = {}
        if name in self.rendered:
            icons = self.rendered[name]
        else:
            # render icons
            if name == DEFAULT_SET:
                path = ICON_PATH
            else:
                path = CUSTOM_ICON_PATH + name + os.sep
            icons = []
            for icon in ICON_NAMES:
                img = gtk.Image()
                icons.append(img)
                try:
                    img.set_from_pixbuf(self.pixbuf(path + icon))
                except GError:
                    img.set_from_file('')
                img.show()
            self.rendered[name] = icons
        for child in self.disp.get_children():
            self.disp.remove(child)
        for icon in icons:
            self.disp.pack_start(icon)

    def update (self):
        # update tree from sets file
        sets = set(self.get_sets())
        try:
            new = sets.difference(self.sets)
            old = self.sets.difference(sets)
            self.sets = sets
        except AttributeError:
            self.sets = sets
            new = list(sets)
            old = set()
            std_icon = self.pixbuf(ICON_PATH + 'old.png')
            self.ls.append((std_icon, DEFAULT_SET))
        for name in new:
            try:
                std_icon = self.pixbuf(CUSTOM_ICON_PATH + name + os.sep + 'old.png')
            except GError:
                self.sets.remove(name)
                continue
            self.ls.append((std_icon, name))
        for name in old:
            self.ls.remove(self.get_row(name, True))

    def sort_tree (self, model, iter1, iter2):
        text1 = model.get_value(iter1, 1)
        text2 = model.get_value(iter2, 1)
        if text1 == DEFAULT_SET:
            return -1
        if text2 == DEFAULT_SET:
            return 1
        if text1 < text2:
            return -1
        else:
            return 1


class Preferences:
    def __init__ (self, icon):
        self.icon = icon
        self.configs = self.icon.configs.keys()
        self.configs.sort()
        self.window = gtk.Window()
        self.window.connect('delete_event', self.end)
        self.window.set_title(_('ZetaBoards topic fetcher') + ' ' + _('Preferences'))
        self.window.set_resizable(False)
        try:
            self.window.set_icon_from_file(ICON)
        except GError:
            pass
        self.window.set_border_width(12)
        # close on escape key
        accel = gtk.AccelGroup()
        accel.connect_group(65307, 0, 0, self.esc)
        self.window.add_accel_group(accel)
        outer = gtk.VBox(False, 12)
        self.window.add(outer)
        book = gtk.Notebook()
        outer.pack_start(book, False)

        # tab: Main
        # when to check
        tab_list = [_('Fetching Topics')]

        h = gtk.HBox(False, 6)
        section = [h]
        tab_list.append(section)
        h.pack_start(gtk.Label(_('Check every')), False)
        self.time = gtk.SpinButton(gtk.Adjustment(self.icon.prefs['time'], 1, 1440, 1, 5))
        h.pack_start(self.time, False)
        h.pack_start(gtk.Label(_('minutes')), False)
        self.on_start = gtk.CheckButton(_('Check on s_tartup'))
        section.append(self.on_start)
        self.on_start.set_active(icon.prefs['on_start'])

        # configs to use
        tab_list.append(_('Configurations'))

        h = gtk.HBox(False, 6)
        section = [h]
        tab_list.append(section)
        h.pack_start(gtk.Label(_('Use configurations:')), False)
        b = gtk.Button(_('Open _Editor'), None, True)
        h.pack_end(b, False)
        b.connect('clicked', open_editor, self.icon)

        self.using_n = []
        for i, option in enumerate((_('O_ne'), _('Cu_stom'), _('A_ll'))):
            h = gtk.HBox(False)
            section.append(h)
            h.pack_start(gtk.HBox(), False, padding = 6)
            r = gtk.RadioButton(None if i == 0 else r, option)
            h.pack_start(r, False)
            self.using_n.append(r)
            if i == self.icon.prefs['using_n']:
                r.set_active(True)
            r.connect('toggled', self.visible)

        # configs: 'one' block
        self.using0 = gtk.VBox(False, 6)
        section.append(self.using0)
        h = gtk.HBox()
        self.using0.pack_start(h, False)
        self.using0_c = gtk.combo_box_new_text()
        h.pack_start(self.using0_c, False)
        for name in self.configs:
            self.using0_c.append_text(name)
        if self.icon.prefs['using0'] is None:
            self.using0_c.set_active(0)
        else:
            self.using0_c.set_active(self.configs.index(self.icon.prefs['using0']))

        self.using0_all = gtk.CheckButton(_('Chec_k all subforums'))
        self.using0.pack_start(self.using0_all, False)
        self.using0_all.set_active(self.icon.prefs['using0_all'])
        self.using0_off = gtk.CheckButton(_('Appear o_ffline'))
        self.using0.pack_start(self.using0_off, False)
        self.using0_off.set_active(self.icon.prefs['using0_off'])

        # configs: 'custom' block
        self.using1 = gtk.VBox(False, 6)
        section.append(self.using1)
        h = gtk.HBox(False, 6)
        self.using1.pack_start(h, False)
        self.using1_c = gtk.combo_box_new_text()
        h.pack_start(self.using1_c, False)
        for name in (i for i in self.configs if i not in (j[0] for j in self.icon.prefs['using1_list'])):
            self.using1_c.append_text(name)
        self.using1_c.set_active(0)
        b = gtk.Button(stock = gtk.STOCK_ADD)
        h.pack_start(b, False)
        b.connect('clicked', self.add_using, self.using1_c)

        self.using1_data = []
        self.using1_list = gtk.VBox(False, 6)
        self.using1.pack_start(self.using1_list, False)
        self.using1_none = gtk.Label(_('No configurations selected'))
        self.using1_list.pack_start(self.using1_none, False)
        self.using1_none.set_property('attributes', italic)
        for x in self.icon.prefs['using1_list']:
            self.add_using(config = x)

        # configs: 'all' block
        self.using2 = gtk.VBox(False, 6)
        section.append(self.using2)
        self.using2_all = gtk.CheckButton(_('Chec_k all subforums'))
        self.using2.pack_start(self.using2_all, False)
        self.using2_all.set_active(self.icon.prefs['using2_all'])
        self.using2_off = gtk.CheckButton(_('Appear o_ffline'))
        self.using2.pack_start(self.using2_off, False)
        self.using2_off.set_active(self.icon.prefs['using2_off'])

        self.append_page(book, tab_list, _('Main'))

        # tab: Action
        # icon click action
        tab_list = [_('Clicking the Icon')]

        data = ((
            _('If there are new posts, perform actions for:'),
            (_('All _forums'), _('The forum with the most _queued topics'), _('The _next')),
            self.icon.prefs['click_new']
        ), (
            _('If there are no new posts:'),
            (_('Open _preferences'), _('Check for ne_w posts'), _('_Disable/enable'), _('Do no_thing')),
            self.icon.prefs['click_old']
        ))
        groups = []
        section = []
        tab_list.append(section)
        for heading, labels, current in data:
            l = gtk.Label(heading)
            section.append(l)
            l.set_alignment(0, .5)
            group = []
            groups.append(group)
            for i, label in enumerate(labels):
                h = gtk.HBox(False, 6)
                section.append(h)
                # 3px padding either side plus 6px spacing makes 12px indent
                h.pack_start(gtk.HBox(), False, padding = 3)
                r = gtk.RadioButton(None if i == 0 else r, label)
                group.append(r)
                h.pack_start(r, False)
                if i == current:
                    r.set_active(True)
        # next x topics spin/rest of label
        self.next_x_topics = gtk.SpinButton(gtk.Adjustment(self.icon.prefs['next_x_topics'], 1, 1000, 1, 10))
        section[3].pack_start(self.next_x_topics, False)
        section[3].pack_start(gtk.Label(_('topic(s)')), False)
        self.click_new, self.click_old = groups

        self.append_page(book, tab_list, _('Action'))

        # tab: Customisation
        # errors
        tab_list = ['Errors']

        self.error = gtk.CheckButton(_('Show _errors without clicking the icon'))
        tab_list.append((self.error,))
        try:
            self.error.set_active(self.icon.prefs['show_error'])
        except KeyError:
            self.error.set_active(False)

        # override actions
        tab_list.append(_('Override Actions'))

        self.actions_on = gtk.CheckButton(_('O_verride configuration actions'))
        section = [self.actions_on]
        tab_list.append(section)
        self.actions_on.set_active(self.icon.prefs['actions'])
        self.actions_on.connect('toggled', self.visible)

        # override actions: config block
        self.actions = gtk.VBox(False, 6)
        section.append(self.actions)
        self.actions_data = []
        for label, active, path in (
            [_('Save to _file:')] + self.icon.prefs['actions_do'][0],
            [_('O_pen with:')] + self.icon.prefs['actions_do'][1]
        ):
            h = gtk.HBox(False, 6)
            self.actions.pack_start(h, False)
                # 3px padding either side plus 6px spacing makes 12px indent
            h.pack_start(gtk.HBox(), False, padding = 3)
            c = gtk.CheckButton(label)
            h.pack_start(c, False)
            self.actions_data.append(c)
            c.set_active(active)
            c.connect('toggled', self.sensitive)
            b = gtk.Button(_('_Browse'), None, True)
            h.pack_end(b, False)
            self.actions_data.append(b)
            f = gtk.Entry()
            defaultise(b, f)
            h.pack_end(f, False)
            self.actions_data.append(f)
            f.set_text(path)
            b.connect('clicked', self.get_file, f, label == _('Save to _file:'))

        # custom icons
        tab_list.append(_('Icon Sets'))
        self.icons = IconManager(self.icon.prefs['icons'], self.icon, False, 6)
        tab_list.append((self.icons,))
        vbox = self.append_page(book, tab_list, _('Customisation'))

        # buttons
        h = gtk.HBox(False, 6)
        outer.pack_start(h, False)
        b = gtk.Button(stock = gtk.STOCK_OK)
        h.pack_end(b, False)
        b.connect('clicked', self.finish)
        b = gtk.Button(stock = gtk.STOCK_CANCEL)
        h.pack_end(b, False)
        b.connect('clicked', self.end)
        b = gtk.Button(stock = gtk.STOCK_APPLY)
        h.pack_end(b, False)
        b.connect('clicked', self.apply_input)

        # initialise
        outer.show_all()
        self.visible()
        self.window.show()
        self.sensitive()

    def end (self, *args):
        self.icon.prefs_open = False
        self.window.destroy()
        return False

    def esc (self, *args):
        self.end()
        return True

    def append_page (self, book, tab_list, label):
        vbox = tabify(tab_list)
        vbox.set_border_width(12)
        book.append_page(vbox, gtk.Label(label))
        return vbox

    def visible (self, widget = None):
        if isinstance(widget, gtk.RadioButton) and not widget.get_active():
            return
        widgets = ([], [])
        u = [x.get_active() for x in self.using_n].index(True)
        widgets[u == 0].append(self.using0)
        widgets[u == 1].append(self.using1)
        widgets[u == 2].append(self.using2)
        widgets[self.actions_on.get_active()].append(self.actions)
        for widget in widgets[0]:
            widget.hide()
        for widget in widgets[1]:
            widget.show()
        self.window.resize(1, 1)

    def sensitive (self, widget = None):
        s = self.actions_data[0].get_active()
        for x in (1, 2):
            self.actions_data[x].set_sensitive(s)
        s = self.actions_data[3].get_active()
        for x in (4, 5):
            self.actions_data[x].set_sensitive(s)

    def display_icon (self, widget, icon):
        try:
            icon.set_from_pixbuf(gtk.gdk.pixbuf_new_from_file(widget.get_text()).scale_simple(30, 30, gtk.gdk.INTERP_BILINEAR))
        except GError:
            icon.set_from_file('')

    def reload_configs (self, widget = None):
        # load from disk
        self.icon.configs = load_config(self.icon)
        self.configs = self.icon.configs.keys()
        self.configs.sort()
        # make changes to combo boxes
        for skip_some, combo in enumerate((self.using0_c, self.using1_c)):
            prev = combo.get_active_text()
            combo.set_active(0)
            while combo.get_active() == 0:
                combo.remove_text(0)
                combo.set_active(0)
            #print skip_some, combo
            if skip_some:
                less = [x[0] for x in self.using1_data]
            else:
                less = ()
            for label in self.configs:
                if label not in less:
                    combo.append_text(label)
            try:
                prev = [x for x in self.configs if x not in less].index(prev)
            except ValueError:
                prev = 0
            combo.set_active(prev)

    def add_using (self, widget = None, combo = None, config = None):
        if config is None:
            config = [combo.get_active_text(), False, False]
            if config[0] is None:
                return
        data = [config[0]]
        self.using1_data.append(data)
        h = gtk.HBox(False, 6)
        self.using1_list.pack_start(h, False)
        data.append(h)
        l = gtk.Label(config[0])
        h.pack_start(l)
        l.set_alignment(0, .5)
        b = gtk.Button(stock = gtk.STOCK_REMOVE)
        h.pack_start(b, False)
        b.connect('clicked', self.rm_using, config[0])
        c = gtk.CheckButton(_('Chec_k all subforums'))
        h.pack_start(c, False)
        data.append(c)
        c.set_active(config[1])
        c = gtk.CheckButton(_('Appear o_ffline'))
        h.pack_start(c, False)
        data.append(c)
        c.set_active(config[2])
        h.show_all()
        self.reload_configs()
        self.using_label()

    def rm_using (self, widget, config):
        for x in xrange(len(self.using1_data)):
            if self.using1_data[x][0] == config:
                self.using1_data[x][1].destroy()
                self.using1_data.pop(x)
                break
        self.reload_configs()
        self.using_label()
        self.window.resize(1, 1)

    def using_label (self):
        if len(self.using1_data):
            self.using1_none.hide()
        else:
            self.using1_none.show()

    def get_file (self, widget, entry, save = False):
        f = gtk.FileChooserDialog([_('Select file'), _('Save to file')][save], action = [gtk.FILE_CHOOSER_ACTION_OPEN, gtk.FILE_CHOOSER_ACTION_SAVE][save], buttons = (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, gtk.STOCK_OPEN, gtk.RESPONSE_OK))
        current = entry.get_text()
        if current:
            f.set_filename(current)
        else:
            f.set_current_folder(os.path.expanduser('~'))
        if f.run() == gtk.RESPONSE_OK:
            entry.set_text(f.get_filename())
        f.destroy()

    def apply_input (self, widget = None):
        # tab: Main
        using_n = [x.get_active() for x in self.using_n].index(True)
        if using_n == 0:
            if self.using0_c.get_active() == -1:
                # no configs exist
                using0 = None
            else:
                using0 = self.configs[self.using0_c.get_active()]
            using0_all = self.using0_all.get_active()
            using0_off = self.using0_off.get_active()
            using1_list, using2_all, using2_off = [], False, False
        elif using_n == 1:
            using0, using0_all, using0_off = None, False, False
            using1_list = [(x[0], x[2].get_active(), x[3].get_active()) for x in self.using1_data]
            using2_all, using2_off = False, False
            if using1_list == []:
                d = gtk.MessageDialog(self.window, 0, gtk.MESSAGE_WARNING, gtk.BUTTONS_OK, _('You must select at least one configuration.'))
                d.run()
                d.destroy()
                return False
        elif using_n == 2:
            using0, using0_all, using0_off, using1_list = None, False, False, []
            using2_all = self.using2_all.get_active()
            using2_off = self.using2_off.get_active()

        # tab: Customisation
        actions = self.actions_on.get_active()
        if actions:
            actions_do = [[self.actions_data[x].get_active()] for x in (0, 3)]
            for x in (0, 1):
                if actions_do[x][0]:
                    actions_do[x].append(self.actions_data[3 * x + 2].get_text())
                    if actions_do[x][-1] == '':
                        msg = _('Can\'t {0} without a filename; ignore the setting?').format((_('save'), _('open'))[x])
                        d = gtk.MessageDialog(self.window, 0, gtk.MESSAGE_QUESTION, gtk.BUTTONS_YES_NO, msg)
                        response = d.run()
                        d.destroy()
                        if response == gtk.RESPONSE_YES:
                            actions_do[x][0] = False
                        else:
                            return False
                else:
                    actions_do[x].append('')
            if not any(x[0] for x in actions_do):
                msg = _('No override action specified; cancel the override?')
                d = gtk.MessageDialog(self.window, 0, gtk.MESSAGE_QUESTION, gtk.BUTTONS_YES_NO, msg)
                response = d.run()
                d.destroy()
                if response == gtk.RESPONSE_YES:
                    actions = False
                    actions_do = [[False, ''], [False, '']]
                else:
                    return False
        else:
            actions_do = [[False, ''], [False, '']]

        self.icon.prefs = {
            'time': self.time.get_value(),
            'on_start': self.on_start.get_active(),
            'using_n': using_n,
            'using0': using0,
            'using0_off': using0_off,
            'using0_all': using0_all,
            'using1_list': using1_list,
            'using2_all': using2_all,
            'using2_off': using2_off,
            'show_error': self.error.get_active(),
            'click_new': [x.get_active() for x in self.click_new].index(True),
            'next_x_topics': self.next_x_topics.get_value(),
            'click_old': [x.get_active() for x in self.click_old].index(True),
            'actions': actions,
            'actions_do': actions_do,
            'icons': self.icons.selected
        }
        apply_prefs(self.icon)
        return True

    def finish (self, widget):
        if self.apply_input():
            self.end()