"""ZetaBoards topic fetcher backend package by J.

Licensed under the GNU General Public License, version 3; if this was not
included, you can find it here:
    http://www.gnu.org/licenses/gpl-3.0.txt

"""

# TODO:
# 1.8.4: improved allow/ignore
# 1.9.0: change prefs system when support multiple forums:
    # use JSON for most prefs - icon.prefs, configs (should be dict) (not calibration), confirm dialogues
    # calibration data is per-forum (not per-config) and is stored in a sqlite database
    # have migration system - if .zb-fetcher exists but not new conf dir, ask if want to migrate, then if want to delete old settings
# 1.9.0: multiple forum support (have forum/base.py for common stuff might use, e.g. login(url, GET, POST, uname, pw, look_for_in_page))
# optionally check for new PMs; then include in CLI, GUI

import os

HOME = os.path.expanduser('~')
CONF = HOME + os.sep + '.zb-fetcher' + os.sep
CONFIGS = CONF + 'config'
if not os.path.exists(CONF):
    os.mkdir(CONF)
COOKIES = CONF + 'cookies' + os.sep
if not os.path.exists(COOKIES):
    os.mkdir(COOKIES)