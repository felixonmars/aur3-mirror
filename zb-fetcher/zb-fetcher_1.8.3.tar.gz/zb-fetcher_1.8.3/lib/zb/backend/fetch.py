"""ZetaBoards topic fetcher fetching module by J.

Licensed under the GNU General Public License, version 3; if this was not
included, you can find it here:
    http://www.gnu.org/licenses/gpl-3.0.txt

"""

import sys
from re import sub
from urllib import urlencode
from htmlentitydefs import name2codepoint
from multiprocessing import Process, Queue

from ..backend import COOKIES
from util import full_forum, cookie_expired, action_save, action_run
from ..fetch import get, fetch_pages
from ..htmlparse import HTMLTree
from ..miscutil import greedy

INDEX = 'index/'

def unescape (text):
    """Unescape HTML entities in a string.

source: http://effbot.org/zone/re-sub.htm#unescape-html

"""
    def fixup (m):
        text = m.group(0)
        if text[:2] == '&#':
            # character reference
            try:
                if text[:3] == '&#x':
                    return unichr(int(text[3:-1], 16))
                else:
                    return unichr(int(text[2:-1]))
            except ValueError:
                pass
        else:
            # named entity
            try:
                text = unichr(name2codepoint[text[1:-1]])
            except KeyError:
                pass
        return text # leave as is
    return sub('&#?\w+;', fixup, text)

def logged_in (page, forum, user):
    """Determine if a user is logged in on the given page."""
    welcome_string = 'Welcome <strong><a href=\'http://{0}/profile/'.format(forum)
    welcome = page.find(welcome_string)
    if welcome == -1:
        return False
    page = page[welcome + len(welcome_string):]
    page = page[page.find('>'):]
    if not page.startswith('>{0}</a></strong>'.format(user)):
        return False
    return True

def login (forum, user, pwd, cookie, appear_offline = False):
    """login(user, pwd, cookie, appear_offline = False) -> page or False"""
    POST = {'uname': user, 'pw': pwd, 'cookie_on': '0', 'anon_on': '1' if appear_offline else '0'}
    page = get('http://{0}/login/log_in/'.format(forum), urlencode(POST), save = cookie)
    if logged_in(page, forum, user):
        return page
    else:
        return False

def new (forum, user, pwd, every = False, save = None, run = None, cal = [[], [], []], ignore = [[], []], appear_offline = False, reuse_cookie = True, sep_ps = False):
    """new(forum, user, pwd, every = False[, save][, run][, cal][, ignore],
           appear_offline = False, reuse_cookie = True, sep_ps = False)
            -> new_cal or error"""
    # fetch topics
    temp = [x[:] for x in cal]
    args = (forum, user, pwd, every, temp, ignore, appear_offline, reuse_cookie)
    if sep_ps:
        temp = run_root(None, None, None, *args)
        if isinstance(temp, int):
            return temp
        else:
            cal, topics = temp
    else:
        temp = Root(*args)
        temp.run()
        if temp.failed:
            return temp.failed
        topics = temp.new_topics()
        cal = temp.cal
    if len(topics) > 0:
        n = sum(len(x[1]) for x in topics)
        print ngettext('\t{0} topic with new posts found', '\t{0} topics with new posts found', n).format(n)
        # do stuff with topics
        if save is not None:
            # save to file
            action_save([(_('{0} at {1}').format(user, full_forum(forum)), topics, save)])
        if run is not None:
            # open with program
            action_run([(_('{0} at {1}').format(user, full_forum(forum)), [topic.url for topic in reduce(list.__add__, (x[1] for x in topics))], run)])
        if save is None and run is None:
            # print to stdout
            sys.__stdout__.write(_('URLs:\n'))
            sys.__stdout__.write('\t' + '\n\t'.join(['\n\t'.join([i.url for i in x[1]]) for x in topics]) + '\n')
    else:
        print _('\tno topics with new posts found')
    return cal

def root_wrapper (queue, new_topics_arg, *args, **kwargs):
    # runs in spawned process to return new topics properly
    temp = Root(*args, **kwargs)
    temp.run()
    if temp.failed:
        queue.put(temp.failed)
    else:
        queue.put((temp.cal, temp.new_topics(new_topics_arg)))

def run_root (new_topics_arg, wait = None, wait_args = (), *args, **kwargs):
    """Run backend in a separate process.

run_root(new_topics_arg[, wait[, wait_args]], root_args...)

Returns error code if failed, else (Root.cal, Root.new_topics(new_topics_arg)).

Call wait(processing, *wait_args) once the process has started, where
processing() returns whether the process is still running.

This avoids memory fragmentation that increases overall usage, and so is useful
when Root needs to be run multiple times over the running time of a program.

"""
    queue = Queue(1)
    process = Process(target = root_wrapper, args = (queue, new_topics_arg) + args, kwargs = kwargs)
    process.daemon = True
    process.start()
    if wait is not None:
        wait(queue.empty, *wait_args)
    process.join()
    return queue.get()


class Root:
    """Forum root.

Root(url, user, pwd, every = False[, cal][, ignore], appear_offline = False,
     reuse_cookie = True)

url: forum URL root, up to the 'index.php'; if only identifier given, assumed
     to be at s1.zetaboards.com
user: username
pwd: password
every: check all subforums
cal: calibration data
ignore: topics and subforums to ignore
appear_offline: whether not to be visible on the online list, if allowed
reuse_cookie: whether to reuse a cookie if one exists and hasn't expired

    METHODS

fetch: return the page at a URL
fetch_tree: return HTMLTree for the given URL
load: load subforums to find topics with new posts
all_forums: return list of all subforums
all_topics: return list of all topics
needs_cal: return list of forum and topic instances that need calibration
calibrate: calibrate everything
new_topics: get list of topics with new posts
run: load stuff and populate forums list

    ATTRIBUTES

failed: False (did not fail), 1 (couldn't log in) or 2 (lost access to forum
        partway through)
forums: forum instance list

"""

    def __init__ (self, url, user, pwd, every = False, cal = [[], [], []], ignore = [[], []], appear_offline = False, reuse_cookie = True):
        self.failed = False
        self.url = full_forum(url)
        self.user = user
        self.pwd = pwd
        self.cookie = COOKIES + str(hash(self.url + self.user))
        self.every = every
        if len(cal) == 2:
            print _('\tdeleting some calibration data (one-time only)...')
            cal[1] = []
            cal.append([])
        self.cal = cal
        self.ignore = ignore
        self.offline = appear_offline
        self.reuse_cookie = reuse_cookie
        self.name = _('main board')
        self.forums = []

    def fetch (self, url, x = None):
        """Fetch the page at the given URL.  Return False if failed."""
        s = '?x={0}'.format(x) if x is not None else ''
        page = get(url + s, use = self.cookie)
        if not logged_in(page, self.url, self.user):
            success = self.login()
            if success:
                page = get(url, use = self.cookie)
            if not success or not logged_in(page, self.url, self.user):
                return False
        return page

    def fetch_tree (self, url, x = None):
        """Short wrapper around fetch to parse with HTMLTree."""
        page = self.fetch(url, x)
        if page:
            return HTMLTree(page)
        else:
            return False

    def fetch_multi (self, urls, names = None, x = None, err_names = None, tree = False):
        """Fetch multiple pages.  Return False if failed."""
        if len(urls) == 1:
            page = self.fetch(urls[0], x)
            if page is False:
                return False
            else:
                print names[0]
                return [HTMLTree(page) if tree else page]
        elif len(urls) == 0:
            return []
        if x is not None:
            urls = [url + '?x={0}'.format(x) for url in urls]
        failed, succeeded = fetch_pages(urls, func = self._parse_tree if tree else self._parse, names = names, err_names = err_names, failed_msg = _('not logged in'), cookie = self.cookie)
        return False if failed else succeeded

    def fetch_multi_tree (self, urls, names = None, x = None, err_names = None):
        """Short wrapper around fetch_multi to parse with HTMLTree."""
        return self.fetch_multi(urls, names, x, err_names, True)

    def _parse (self, s):
        # fetch_pages argument (try to log in if not logged in, else return page)
        if not logged_in(s, self.url, self.user):
            self.login()
            return False
        else:
            return s

    def _parse_tree (self, s):
        # fetch_pages argument (try to log in if not logged in, else return tree)
        if not logged_in(s, self.url, self.user):
            self.login()
            return False
        else:
            return HTMLTree(s)

    def login (self):
        return login(self.url, self.user, self.pwd, self.cookie, self.offline)

    def load (self):
        """Compile topics with new posts."""
        # compile fetch list for wanted forums
        rm = []
        skip = []
        urls = []
        names = []
        forums = self.all_forums() if self.skip_first_page else self.forums
        old = self.cal[1]
        for forum in forums:
            if (forum.html not in old or self.every) and forum.ID != 'trash':
                if not self.skip_first_page and forum.ID in self.ignore[0]:
                    print _('(ignoring {0})').format(x.name)
                    rm.append(forum)
                else:
                    if self.skip_first_page:
                        # only fetch next page if it exists and first had no old topics
                        if forum.multiple_pages and not forum.done:
                            # page 2
                            urls.append('{0}2/'.format(forum.url))
                            names.append(_('{0}: page {1}').format(forum.name, 2))
                        else:
                            skip.append(forum)
                    else:
                        # page 1
                        urls.append(forum.url)
                        names.append(_('{0}: page {1}').format(forum.name, 1))
            else:
                rm.append(forum)
        if not self.skip_first_page:
            # remove unwanted forums
            for forum in rm:
                self.forums.remove(forum)
        # fetch
        trees = self.fetch_multi_tree(urls, names, 20)
        if trees is False:
            return False
        for i in xrange(len(trees)):
            if skip and skip[0] is forums[i]:
                skip.pop(0)
            elif forums[i] in skip:
                print _('FAIL'), forums[i].name, skip.index(forums[i])
            elif not forums[i].load(trees[i]):
                return False
        return True

    def all_forums (self):
        """Compile a list of all subforums."""
        queue = self.forums[:]
        forums = []
        while len(queue) > 0:
            queue += queue[0].forums
            forums.append(queue.pop(0))
        return forums

    def all_topics (self):
        """Compile a list of all topics in all subforums."""
        forums = self.all_forums()
        topics = []
        for forum in forums:
            topics += forum.topics
        return topics

    def needs_cal (self):
        """Check whether calibrate needs to be called."""
        known = self.cal[0] + self.cal[1] + self.cal[2]
        forums = self.all_forums()
        # check if need calibrating
        for forum in forums:
            if forum.html not in known:
                return True
            for topic in forum.topics:
                if topic.html not in known:
                    return True
        return False

    def calibrate (self):
        print _('\tone or more forums or topics with unknown status found;')
        print _('\tcalibrating (this may take a while)...')
        new, old, locked = self.cal
        every = new + old + locked

        # compile dicts:
        # {page: [htmls we can check by loading this]}
        pages = {}
        # {html: [pages we can load to change this]}
        htmls = {}
        for x in self.all_forums() + self.all_topics():
            if x.html in every:
                continue
            if x.parent_url in pages:
                pages[x.parent_url].append(x.html)
            else:
                pages[x.parent_url] = [x.html]
            if x.html in htmls:
                htmls[x.html].append(x)
            else:
                htmls[x.html] = [x]
        # switch key, value; remove duplicate htmls
        pages = dict(((tuple(set(v)), k) for k, v in pages.iteritems()))

        # minimise parent pages to load
        universe = htmls.keys()
        html_lists = greedy(pages.keys(), universe)
        fetch_list = {}
        for html_list in html_lists:
            parent = pages[html_list]
            for html in html_list:
                if html not in universe:
                    # already done this one
                    continue
                for page in htmls[html]:
                    if page.parent_url == parent:
                        break
                if parent in fetch_list:
                    fetch_list[parent].append((html, page))
                else:
                    fetch_list[parent] = [(html, page)]
                universe.remove(html)

        # load forums/topics with unknown htmls:
        # compile lists
        urls, names, err_names = [], [], []
        parents = fetch_list.keys()
        for parent in parents:
            for html, page in fetch_list[parent]:
                urls.append(page.url)
                if isinstance(page, Topic):
                    names.append(_('loading topic: \'{0}\'').format(page.name))
                else:
                    names.append(_('loading forum: \'{0}\'').format(page.name))
                err_names.append('\'{0}\''.format(page.name))
        # fetch
        pages = self.fetch_multi(urls, names, 5, err_names)
        if pages is False:
            return False
        # check if changed:
        # compile lists
        urls, names, err_names = [], [], []
        for parent in parents:
            urls.append(parent)
            s = '\', \''.join((page.name for html, page in fetch_list[parent]))
            names.append(ngettext('checking if icon changed: \'{0}\'', 'checking if icons changed: \'{0}\'', len(fetch_list[parent])).format(s))
            err_names.append('\'{0}\''.format(fetch_list[parent][0][1].parent.name))
        # fetch
        trees = self.fetch_multi_tree(urls, names, 20, err_names)
        if trees is False:
            return False
        # check
        n = 0
        for i in xrange(len(trees)):
            for html, page in fetch_list[parents[i]]:
                if html == page.new_html(trees[i]):
                    # unchanged: old or locked
                    if isinstance(page, Forum):
                        old.append(html)
                    elif HTMLTree(pages[n]).selection('#fast-reply').selection:
                        # not locked if quick reply is available
                        old.append(html)
                    else:
                        locked.append(html)
                else:
                    # changed: new
                    new.append(html)
                n += 1

        self.cal = [new, old, locked]
        return True

    def new_topics (self, f = None):
        """Return list of (forum, topics_with_new_posts) tuples."""
        forums = self.all_forums()
        result = []
        for forum in forums:
            topics = []
            for topic in forum.topics:
                if topic.html in self.cal[0]:
                    if f is None:
                        topics.append(topic)
                    elif f is True:
                        topics.append(topic.url)
                    else:
                        topics.append(f(topic))
            if len(topics) > 0:
                result.append((forum.name, topics))
        return result

    def run (self):
        """Fetch everything necessary."""
        # try to reuse existing cookie
        reuse = self.reuse_cookie and not cookie_expired(self.cookie)
        # log in
        if reuse:
            print _('\treusing existing cookie')
        else:
            print _('\tlogging in...')
            page = self.login()
            if page:
                print _('\tsuccess!')
            else:
                print _('\tlogin details incorrect or forum doesn\'t exist')
                self.failed = 1
                return
        if self.every:
            print _('\tfetching all forums and subforums...')
        else:
            print _('\tfetching forums with new posts...')
        # fetch index page if not given by login
        if reuse or page is True:
            page = self.fetch('http://{0}/{1}'.format(self.url, INDEX))
            if not page:
                print _('\tnot logged in any more; can\'t log back in; aborting...')
                self.failed = 2
                return
        # create forum list
        page = HTMLTree(page)
        for tr in page.selection('.forum').selection:
            self.forums.append(Forum(self, self, tr))

        def do ():
            # load everything
            if not self.load():
                print _('\tnot logged in any more; can\'t log back in; aborting...')
                self.failed = 2
                return False
            # calibrate
            if self.needs_cal():
                if not self.calibrate():
                    print _('\tnot logged in any more; can\'t log back in; aborting...')
                    self.failed = 2
                    return False
            return True

        # fetch page 1 of each subforum
        self.skip_first_page = False
        self.page_limit = 1
        # then calibrate
        if not do():
            return
        # then fetch subsequent pages and calibrate again
        self.skip_first_page = True
        self.page_limit = 5
        do()


class Forum:
    """Forum.

Forum(root, parent, tr)

root: root instance for this forum
parent: parent subforum or root
tr: HTMLTree for this subforum's table row

    METHODS

new_html: fetch parent and return new value for self.html
load: load and compile topic and subforum lists

    ATTRIBUTES

root: root instance for this forum
parent: parent subforum or root
html: first table cell HTML source; used for calibration
url: full URL
ID: forum identifier as found in its URL, int if possible
parent_url: full parent URL
forums: Forum instance list
topics: Topic instance list

"""

    def __init__ (self, root, parent, tr):
        self.root = root
        self.parent = parent
        html = tr.tds[0].source.strip()
        # remove 'mark as read' link around content
        open_tag_end = html.find('>')
        if html.startswith('<a') and 'task=3' in html[:open_tag_end]:
            html = html[open_tag_end + 1:html.find('</a')]
        self.html = html
        link = tr.tds[1].strong._a
        self.url = link.attrs['href']
        self.ID = self.url.split('/')[-2]
        try:
            self.ID = int(self.ID)
        except ValueError:
            pass
        self.name = unescape(link.source)
        self.parent_url = self.parent.url if self.parent is self.root else '{0}1/'.format(self.parent.url)
        self.forums = []
        self.topics = []
        self.multiple_pages = False

    def new_html (self, tree = None):
        """Fetch and return new value for self.html."""
        for tr in tree.selection('.forum').selection:
            if self.url == tr.tds[1].strong._a.attrs['href']:
                return tr.tds[0].source

    def load (self, tree = None):
        """Compile topics with new posts."""
        if not self.root.skip_first_page:
            self.done = False
            # create subforum list
            urls = []
            names = []
            old = self.root.cal[1]
            for tr in tree.selection('#subforum_set .forum').selection:
                forum = Forum(self.root, self, tr)
                if forum.html not in old or self.root.every:
                    if forum.ID in self.root.ignore[0]:
                        print _('(ignoring {0})').format(forum.name)
                    else:
                        self.forums.append(forum)
                        urls.append(forum.url)
                        names.append(_('{0}: page {1}').format(forum.name, 1))
            # fetch
            trees = self.root.fetch_multi_tree(urls, names, 20)
            if trees is None:
                return False
            for i in xrange(len(trees)):
                if not self.forums[i].load(trees[i]):
                    return False

        # create topics list
        def parse_tr (tr, pinned, page):
            done = False
            if not tr.selection('.pin').selection:
                # no more pinned topics
                pinned = False
            topic = Topic(self.root, self, tr, page)
            if topic.html in self.root.cal[1] and not pinned:
                # no new posts; stop looking
                done = True
            elif topic.ID in self.root.ignore[1]:
                print _('(ignoring topic \'{0}\')').format(topic.name)
            else:
                self.topics.append(topic)
            return pinned, done

        pinned = True
        if self.root.skip_first_page:
            n = 2
            done = not self.multiple_pages
        else:
            n = 1
            done = False
        while not done:
            table = tree.selection('.posts').selection
            if table:
                for tr in table[0].trs:
                    if not tr.selection('.row1').selection + tr.selection('.row2').selection:
                        # header or footer row
                        continue
                    pinned, done = parse_tr(tr, pinned, n)
                    if done:
                        self.done = True
                        self.multiple_pages = False
                        break
            else:
                self.done = True
                self.multiple_pages = False
                break
            # look for further pages if allowed
            pages = tree.selection('.cat-pages').selection
            if pages:
                next = pages[0].selection('a[rel="next"]').selection
                if next:
                    self.multiple_pages = True
                    if n < self.root.page_limit:
                        n += 1
                        print _('{0}: page {1}').format(self.name, n)
                        tree = self.root.fetch_tree(next[0].attrs['href'], 20)
                    else:
                        break
                else:
                    break
            else:
                break
        return True


class Topic:
    """Topic(root, parent, tr)

root: root instance for this forum
parent: parent subforum or root
tr: HTMLTree for this subforum's table row

    METHODS

new_html: fetch parent and return new value for self.html

    ATTRIBUTES

root: root instance for this forum
parent: parent subforum or root
url: full URL
ID: forum identifier as found in its URL (int)
name: topic name
parent_url: full parent URL

"""

    def __init__ (self, root, parent, tr, page):
        self.root = root
        self.parent = parent
        self.page = page
        self.html = tr.tds[0]
        try:
            self.html.input
        except AttributeError:
            self.html = self.html.source
        else:
            self.html = tr.tds[1].source
        link = tr.selection('.c_cat-title > a').selection[0]
        self.url = link.attrs['href']
        self.ID = int(self.url.split('/')[-2])
        self.name = unescape(link.source)
        self.parent_url = '{0}{1}/'.format(self.parent.url, self.page)
        self.pinned = 'pin' in tr.attrs['class']

    def new_html (self, tree = None):
        """Fetch and return new value for self.html."""
        for tr in tree.selection('.posts .row1').selection + tree.selection('.posts .row2').selection:
            try:
                if self.url == tr.selection('.c_cat-title > a').selection[0].attrs['href']:
                    result = tr.tds[0]
                    try:
                        result.input
                    except AttributeError:
                        result = result.source
                    else:
                        # checkbox (mod): use other td
                        result = tr.tds[1].source
                    return result
            except IndexError:
                continue