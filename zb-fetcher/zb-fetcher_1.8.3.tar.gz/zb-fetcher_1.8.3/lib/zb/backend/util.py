"""ZetaBoards topic fetcher utilities module by J.

Licensed under the GNU General Public License, version 3; if this was not
included, you can find it here:
    http://www.gnu.org/licenses/gpl-3.0.txt

"""

from os import remove
from time import time
from glob import glob
from subprocess import Popen
from cPickle import load, dump, UnpicklingError

from ..backend import CONFIGS, COOKIES

def full_forum (url):
    """Default to s1.zetaboards.com and clean up some stuff in a forum URL."""
    dot = url.find('.')
    if dot == -1:
        url = 's1.zetaboards.com/{0}'.format(url)
    else:
        # remove protocol prefixes
        while '/' in url[:dot]:
            url = url[url.find('/') + 1:]
            dot = url.find('.')
    # remove trailing slash
    while url[-1] == '/':
        url = url[:-1]
    return url

def cookie_expired (fn):
    """Check whether the cookie in the given file has expired."""
    try:
        with open(fn) as f:
            for line in f.readlines():
                if '\t' in line:
                    data = line.split('\t')
                    try:
                        expires = int(data[4])
                    except (IndexError, ValueError):
                        continue
                    # play it safe: fetching should never take 10 minutes
                    if expires == 0 or expires - time() > 600:
                        return False
    except IOError:
        pass
    return True

def cleanup_cookies (*args):
    """Delete cookies that have expired."""
    deleted = []
    for fn in glob(COOKIES + '*'):
        if cookie_expired(fn):
            remove(fn)
            deleted.append(fn)
    return deleted

def load_dict (fn, default = {}):
    """cPickle.load a dict from a file."""
    try:
        with open(fn) as f:
            return load(f)
    except (IOError, UnpicklingError, EOFError):
        return {}

def dump_dict (fn, data):
    """cPickle.dump a dict to a file.

Returns whether dumping was successful.

"""
    try:
        with open(fn, 'w') as f:
            dump(data, f)
    except IOError:
        return False
    else:
        return True

def load_configs ():
    """Load configurations."""
    configs = load_dict(CONFIGS)
    for conf, data in configs.iteritems():
        if len(data) != 7:
            if data[4]:
                data[4] = data[4].decode('base64')
            configs[conf] = data[:7]
        # else passwords not obfuscated yet
    return configs

def save_configs (configs):
    """Save configurations.

Returns whether saving was successful.

"""
    # make copy
    configs = dict((k, v[:]) for k, v in configs.iteritems())
    # obfuscate passwords
    for data in configs.itervalues():
        if data[4]:
            data[4] = data[4].encode('base64')
        else:
            data[4] = None
        data.append(True)
    return dump_dict(CONFIGS, configs)

def action_save (data):
    """Save topics to file.

Takes a list of (config_name, topic_list, file) tuples.

topic_list can be a list of topics or a list of (subforum_name, topic_list)
tuples.  In either case, each topic can be either a URL or a Topic instance.

Returns a {config_name: success} dict, where success is a bool indicating
whether the action succeeded.

"""
    def topic_item (topic):
        if isinstance(topic, basestring):
            url, name = topic, topic.split('/')[-2]
        else:
            url, name = topic.url, topic.name
        return '\n            <li><a href="{0}">{1}</a></li>'.format(url, name)

    save_list = {}
    for config, topics, fn in data:
        if fn in save_list:
            save_list[fn].append((config, topics))
        else:
            save_list[fn] = [(config, topics)]
    data = {}
    for fn in save_list:
        n = 0
        try:
            with open(fn, 'w') as f:
                f.write('''<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
    <head>
        <title>{0}</title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8">
    </head>
    <body>'''.format(_('Topics with new posts')))
                for config, topics in save_list[fn]:
                    if len(topics) == 0:
                        continue
                    f.write('\n        <h2>{0}</h2>'.format(config))
                    got_forums = not isinstance(topics[0], (basestring, Topic))
                    if not got_forums:
                        f.write('\n        <ul>')
                    for topic in topics:
                        if got_forums:
                            forum, topics = topic
                            f.write('\n        <h3>{0}</h3>\n        <ul>'.format(forum))
                            for topic in topics:
                                f.write(topic_item(topic))
                                n += 1
                            f.write('\n        </ul>')
                        else:
                            f.write(topic_item(topic))
                            n += 1
                    if not got_forums:
                        f.write('\n        </ul>')
                f.write('\n    </body>\n</html>')
        except IOError:
            print _('\tcouldn\'t save to \'{0}\'; make sure the parent directory exists and you have sufficient permissions').format(x.split('/')[-1])
            for config, topics in save_list[fn]:
                data[config] = False
        else:
            f.close()
            print ngettext('saved {0} topic to \'{1}\'...', 'saved {0} topics to \'{1}\'', n).format(n, fn)
            for config, topics in save_list[fn]:
                data[config] = True
    return data

def action_run (data):
    """Open topics in programs.

Takes a list of (config_name, topic_url_list, program) tuples.

Returns a {config_name: success} dict, where success is a bool indicating
whether the action succeeded.

"""
    run_list = {}
    for x in data:
        if x[2] in run_list:
            run_list[x[2]].append((x[0], x[1]))
        else:
            run_list[x[2]] = [(x[0], x[1])]
    data = {}
    for x in run_list:
        n = sum(len(i[1]) for i in run_list[x])
        print ngettext('opening {0} topic with \'{1}\'...', 'opening {0} topics with \'{1}\'...', n).format(n, x)
        try:
            Popen([x] + reduce(list.__add__, [i[1] for i in run_list[x]]))
        except OSError, e:
            print _('\tcouldn\'t run \'{0}\'; the error returned was \'{1}\'').format(x.split('/')[-1], str(e))
            for i in run_list[x]:
                data[i[0]] = False
        else:
            for i in run_list[x]:
                data[i[0]] = True
    return data