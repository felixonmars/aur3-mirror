"""ZetaBoards topic fetcher CLI module by J.

Licensed under the GNU General Public License, version 3; if this was not
included, you can find it here:
    http://www.gnu.org/licenses/gpl-3.0.txt

"""

# TODO:
# 1.8.4: bash completion
# 1.8.4: man page

import os
from math import ceil
from optparse import OptionParser, Option
from getpass import getpass

from . import __version__
from backend import fetch, util
from backend.util import load_configs, save_configs
from cmdparse import CommandParser
from miscutil import startwith

def get_config (op, args, cmd):
    # function to reduce code duplication in callbacks
    configs = load_configs()
    try:
        config = configs[args[0]]
    except IndexError:
        op.error(_('expected CONFIG argument'), cmd)
    except KeyError:
        op.error(_('no such config \'{0}\'').format(args[0]), cmd)
    else:
        return args[0], config, configs

def multi_config_args (op, args, cmd):
    # parse a list of arguments meant to be at least one config name
    configs = load_configs()
    if len(args) == 0:
        op.error(_('expected CONFIG argument'), cmd)
    todo = []
    # remove duplicates
    args = set(args)
    # expand *
    if '*' in args:
        args |= set(configs.iterkeys())
        args.remove('*')
    # check configs exist
    for arg in args:
        if arg in configs:
            todo.append(arg)
        else:
            print _('error: no such config \'{0}\'; skipping').format(arg)
    return todo, configs

def format_fields (fields, data):
    width = max(len(f) for f in fields) + 1
    for i in xrange(len(fields)):
        print '{0}:{1}{2}'.format(fields[i], ' ' * (width - len(fields[i])), data[i])

def printable (val, index, display_pwd = False):
    if index in (2, 3) and val is None:
        val = _('[not set]')
    elif index == 4 and val is None:
        val = _('[not stored]')
    elif index == 4 and not display_pwd:
        val = _('[stored]')
    else:
        val = '\'{0}\''.format(val)
    return val

# callbacks

def allow (op, args):
    args = args[1]
    k, config, configs = get_config(op, args, _('allow'))
    try:
        pool = (_('forum'), _('topic'))
        ign = config[6][pool.index(startwith(pool, args[1], False, True))]
    except IndexError:
        op.error(_('expected forum|topic argument'), _('allow'))
    except ValueError:
        op.error(_('second argument must be \'forum\' or \'topic\''), _('allow'))
    for arg in args[2:]:
        try:
            arg = int(arg)
        except ValueError:
            print _('\'{0}\': invalid ID').format(arg)
        else:
            try:
                ign.remove(arg)
            except ValueError:
                print _('{0}: not in ignore list').format(arg)
            else:
                print _('{0}: removed').format(arg)
    save_configs(configs)

def ignore (op, args):
    args = args[1]
    k, config, configs = get_config(op, args, _('ignore'))
    try:
        pool = (_('forum'), _('topic'))
        ign = config[6][pool.index(startwith(pool, args[1], False, True))]
    except IndexError:
        op.error(_('expected forum|topic argument'), _('ignore'))
    except ValueError:
        op.error(_('second argument must be \'forum\' or \'topic\''), _('ignore'))
    for arg in args[2:]:
        try:
            arg = int(arg)
        except ValueError:
            print _('\'{0}\': invalid ID').format(arg)
        else:
            if arg in ign:
                print _('{0}: already in ignore list').format(arg)
            else:
                ign.append(arg)
                print _('{0}: added').format(arg)
    save_configs(configs)

def list_ignored (op, args):
    k, config, configs = get_config(op, args[1], _('list_ignored'))
    ign = config[6]
    if ign[0]:
        print _('Ignored forums:\n')
        for i in ign[0]:
            print i
    else:
        print _('No ignored forums')
    if ign[1]:
        print _('\nIgnored topics:\n')
        for i in ign[1]:
            print i
    else:
        print _('\nNo ignored topics')

def detail (op, args):
    show_pw = args[0].show_pw
    configs = load_configs()
    try:
        config = args[1][0]
    except IndexError:
        fields = sorted(configs.keys())
        data = ['{0} at {1}'.format(configs[name][1], util.full_forum(configs[name][0])) for name in fields]
    else:
        if config not in configs:
            op.error(_('no such config \'{0}\'').format(config), _('detail'))
        data = configs[config]
        fields = (_('Name'), _('Forum'), _('Username'), _('Password'), _('Save to'), _('Open with'))
        # make entire dataset printable
        data = (config, util.full_forum(data[0]), data[1], data[4], data[2], data[3])
        data = [printable(v, i, show_pw) for v, i in zip(data, (None, 0, 1, 4, 2, 3))]
    if data:
        format_fields(fields, data)

def delete (op, args):
    todo, configs = multi_config_args(op, args[1], _('delete'))
    if todo:
        for config in todo:
            del configs[config]
        save_configs(configs)

def delete_all (op, args):
    save_configs({})

def duplicate (op, args):
    config, data, configs = get_config(op, args[1], _('duplicate'))
    if len(args[1]) > 1:
        target = args[1][1]
    else:
        copy = _('copy')
        end = ' ({0})'.format(copy)
        if config.endswith(end):
            base_name = config[:config.find(end)]
        else:
            base_name = config
        n = 1
        fmt = '{0} ({1})'
        if fmt.format(base_name, copy) in configs:
            n += 1
            fmt = '{0} ({1} {2})'
            while fmt.format(base_name, copy, n) in configs:
                n += 1
        # now fmt is the right one
        target = fmt.format(base_name, copy, n)
        print _('using \'{0}\' as target name').format(target)
    configs[target] = data
    save_configs(configs)

def forgetpwd (op, args):
    args = args[1]
    todo, configs = multi_config_args(op, args, _('forgetpwd'))
    if todo:
        for config in todo:
            configs[config][4] = None
        save_configs(configs)

def edit (op, args):
    options, args = args
    config, data, configs = get_config(op, args, _('edit'))
    old_config = config
    fields = []
    changed = []
    optional = (2, 3)
    for title, attr, i in (
        (_('Name'), 'name', None),
        (_('Forum'), 'forum', 0),
        (_('Username'), 'uname', 1),
        (_('Save to'), 'save', 2),
        (_('Open with'), 'prog', 3)
    ):
        new = getattr(options, attr)
        if i is None:
            old = config
        else:
            old = data[i]
        if new is not None and new != old:
            if new.strip() == '':
                if i in optional:
                    new = None
                else:
                    op.error(_('got invalid value for {0}').format(title.lower()), _('edit'))
            if i is None:
                # change config name
                if new in configs:
                    op.error(('config with name \'{0}\' already exists').format(new), _('edit'))
                else:
                    del configs[config]
                    config = new
            else:
                # replace old with new value
                data[i] = new
            fields.append(title)
            old = printable(old, i)
            new = printable(new, i)
            changed.append(_('{0} (used to be {1})').format(new, old))
    if changed:
        configs[config] = data
        save_configs(configs)
        print _('Changes for {0}:\n').format(old_config)
        format_fields(fields, changed)
    else:
        print _('No changes made')

def rename (op, args):
    args = args[1]
    config, data, configs = get_config(op, args, _('rename'))
    try:
        name = args[1]
    except IndexError:
        op.error(_('expected {0} argument').format(_('NAME')), _('rename'))
    else:
        if name.strip() == '':
            op.error(_('invalid {0} argument').format(_('NAME')), _('rename'))
    # if different and not already taken,
    if name != config:
        if name in configs:
            op.error(('config with name \'{0}\' already exists').format(name), _('rename'))
        # make the change
        del configs[config]
        configs[name] = data
        save_configs(configs)

def save (op, args):
    options, args = args
    for i, arg in enumerate((_('CONFIG'), _('FORUM'), _('USERNAME'))):
        if len(args) <= i:
            op.error(_('expected {0} argument').format(arg), _('save'))
        elif args[i].strip() == '':
            op.error(_('invalid {0} argument').format(arg), _('save'))
    configs = load_configs()
    conf, forum, uname = args
    if conf in configs:
        op.error(_('config with name \'{0}\' already exists').format(conf), _('save'))
    configs[conf] = [forum, uname, options.save, options.prog, None, [[], [], []], [[], [], []]]
    save_configs(configs)

def run_config (op, args):
    options, args = args
    todo, configs = multi_config_args(op, args, _('run'))
    for config in todo:
        print _('\tusing configuration \'{0}\'').format(config)
        data = configs[config]
        reuse_cookie = True
        changed = False
        # get password if not stored
        if data[4] is None:
            # don't reuse cookie, since if it was created using the correct password
            # and this is incorrect, we might end up saving the incorrect password
            reuse_cookie = False
            pwd = getpass(_('Password for {0} at {1}: ').format(data[1], util.full_forum(data[0])))
            if options.pwd:
                print _('\tstoring password')
                data[4] = pwd
                changed = True
        else:
            pwd = data[4]
        # handle options
        if options.recal:
            print _('\tdeleting calibration data')
            data[5] = [[], [], []]
        if options.override_ignore:
            print _('\tignoring ignore lists')
            ignore = [[], []]
        else:
            ignore = data[6]
        if options.every:
            print _('\tchecking every subforum')
        if options.offline:
            print _('\ttrying to appear offline')
        save = data[2] if options.save is None else os.path.abspath(options.save)
        prog = data[3] if options.prog is None else options.prog
        # do the fetching
        cal = fetch.new(data[0], data[1], pwd, options.every, save, prog, data[5], ignore, options.offline)
        if not isinstance(cal, int):
            if cal != data[5]:
                data[5] = cal
                changed = True
            # save config if changed
            if changed:
                configs[config] = data
                save_configs(configs)

def cleanup_cookies (op, args):
    deleted = len(util.cleanup_cookies())
    print _('Deleted {0} cookies').format(deleted)

def gui (op, args):
    try:
        import gui
    except Exception, e:
        msg = _('couldn\'t run the GUI; check all dependencies are satisfied')
        op.error(msg + _('\nerror message: {0}').format(str(e)), _('gui'))
    gui.run()

def run ():
    # set up argument parsing
    text = _('''Finds topics with new posts at any ZetaBoards forum and prints the URLs, writes them to an HTML file as links, and/or opens them with any program (intended to be used with a browser).  Commands are case-insensitive, and can be abbreviated as far as you like without introducing ambiguity.\n\nStart by creating configurations using the 'save' command, then fetch with the 'run' command.''')
    cp = CommandParser(full_prog = _('ZetaBoards topic fetcher') + ' ' + __version__, desc = text, case_sensitive = False)
    opt_pwd = Option(_('-p'), _('--pwd'), action = 'store_true', dest = 'pwd', default = False,
                     help = _('store the password and remember it when running the configuration'))
    opt_open = Option(_('-o'), _('--open'), dest = 'prog', default = None, metavar = _('PROGRAM'),
                      help = _('open all URLs with this program - this should work with most tabbed browsers'))
    opt_save = Option(_('-s'), _('--save'), dest = 'save', default = None, metavar = _('FILE'),
                      help = _('save results to this file as HTML; path can be relative or absolute'))

    op = OptionParser(add_help_option = False)
    cp.add_cmd(_('allow'), _('remove forums or topics from the ignore list'), None, _('CONFIG forum|topic ID [IDs...]'), allow, op)

    op = OptionParser(add_help_option = False)
    cp.add_cmd(_('cleanup_cookies'), _('delete expired cookies'), None, None, cleanup_cookies, op)

    op = OptionParser(add_help_option = False)
    op.add_option(_('-p'), _('--show-passwords'), action = 'store_true', dest = 'show_pw', default = False,
                  help = _('display stored passwords'))
    cp.add_cmd(_('detail'), _('print details for a configuration'),
               _('Without an argument, a list of existing configurations is printed.'),
               _('[OPTIONS] [CONFIG]'), detail, op)

    op = OptionParser(add_help_option = False)
    cp.add_cmd(_('delete'), _('delete one or more configurations'),
               _('No confirmation is given, so be careful.  Use * to delete all configurations (your shell might replace this automatically; try \\* or "*").'),
               _('CONFIG [CONFIGS...]'), delete, op)

    op = OptionParser(add_help_option = False)
    cp.add_cmd(_('duplicate'), _('make a copy of a configuration'),
               _('TARGET is the name of the created configuration; if not given, a name based on CONFIG is used.'),
               _('CONFIG [TARGET]'), duplicate, op)

    op = OptionParser(add_help_option = False)
    op.add_option(_('-n'), _('--name'), dest = 'name', default = None, metavar = _('CONFIG'),
                  help = _('the name of the configuration'))
    op.add_option(_('-f'), _('--forum'), dest = 'forum', default = None, metavar = _('URL'),
                  help = _('the forum to fetch topics from'))
    op.add_option(_('-u'), _('--username'), dest = 'uname', default = None, metavar = _('NAME'),
                  help = _('the username to log in with'))
    op.add_option(opt_open)
    op.add_option(opt_save)
    cp.add_cmd(_('edit'), _('edit a configuration\'s settings'),
               _('Override each setting by giving a new value using its corresponding option.  For optional fields, pass an empty string to delete the current stored value.'),
               _('[OPTIONS] CONFIG'), edit, op)

    op = OptionParser(add_help_option = False)
    cp.add_cmd(_('forgetpwd'), _('forget one or more configurations\' saved passwords'),
               _('Use * to forget passwords for all configurations (your shell might replace this automatically; try \\* or "*").'),
               _('CONFIG [CONFIGS...]'), forgetpwd, op)

    op = OptionParser(add_help_option = False)
    cp.add_cmd(_('gui'), _('run the GUI'), None, None, gui, op)

    op = OptionParser(add_help_option = False)
    cp.add_cmd(_('ignore'), _('add forums or topics to the ignore list'), None, _('CONFIG forum|topic ID [IDs...]'), ignore, op)

    op = OptionParser(add_help_option = False)
    cp.add_cmd(_('list_ignored'), _('list ignored forums and topics'), None, _('CONFIG'), list_ignored, op)

    op = OptionParser(add_help_option = False)
    cp.add_cmd(_('rename'), _('rename a configuration'),
               _('This does the same as \'edit CONFIG -n NAME\'.'),
               _('CONFIG NAME'), rename, op)

    op = OptionParser(add_help_option = False)
    op.add_option(_('-a'), _('--all'), action = 'store_true', dest = 'every', default = False,
                  help = _('force checking of every (sub)forum, even those that appear to have no new topics'))
    op.add_option(_('-f'), _('--offline'), action = 'store_true', dest = 'offline', default = False,
                  help = _('appear offline if the forum allows it'))
    op.add_option(opt_pwd)
    op.add_option(_('-r'), _('--recal'), action = 'store_true', dest = 'recal', default = False,
                  help = _('purge and recalculate data stored on forum and topic states'))
    op.add_option(_('-v'), _('--override-ignore'), action = 'store_true', dest = 'override_ignore', default = False,
                  help = _('ignore the configuration\'s ignore lists'))
    op.add_option(opt_open)
    op.add_option(opt_save)
    cp.add_cmd(_('run'), _('run with one or more saved configurations'),
               _('-o --open and -s --save override the configuration\'s saved values.  Use * to run all configurations (your shell might replace this automatically; try \\* or "*").  Options are applied to every configuration.'),
               _('[OPTIONS] CONFIG [CONFIGS...]'), run_config, op)

    op = OptionParser(add_help_option = False)
    op.add_option(opt_open)
    op.add_option(opt_save)
    cp.add_cmd(_('save'), _('create a configuration'),
               _('CONFIG can be any non-empty string, as long as you quote it if it contains spaces; note that configuration names are case-sensitive everywhere they\'re used.\n\nFORUM is the whole of the URL without the protocol prefix (http://), up to and not including the \'/index/\' when viewing the forum index, without a trailing slash.  If this is s1.zetaboards.com/IDENTIFIER, you can just use IDENTIFIER.'),
               _('[OPTIONS] CONFIG FORUM USERNAME'), save, op)

    cp.parse()