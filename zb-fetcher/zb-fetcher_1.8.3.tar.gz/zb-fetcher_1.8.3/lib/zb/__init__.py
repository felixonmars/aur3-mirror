from os import name as os_name
from gettext import install

__version__ = '1.8.3'
localedir = 'locale' if os_name == 'nt' else '/usr/share/locale'
install('zb-fetcher', localedir, names = ('ngettext',))