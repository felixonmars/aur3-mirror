
 Original download links:

    "http://upload.wikimedia.org/wikipedia/commons/1/1e/Archlinux-icon-128.svg"
    "http://upload.wikimedia.org/wikipedia/commons/2/21/Archlinux_logo.svg"
    "http://upload.wikimedia.org/wikipedia/en/a/ac/Archlinux-official-fullcolour.svg"
    "http://upload.wikimedia.org/wikipedia/commons/5/53/GNU_and_Tux.svg"
    "http://upload.wikimedia.org/wikipedia/commons/c/c9/Gnulinux.svg"
    "http://upload.wikimedia.org/wikipedia/commons/b/b0/NewTux.svg"
    "http://wiki.piratenpartei.de/images/f/f9/Pirate.svg"
    "http://wiki.secondlife.com/w/images/e/e5/Snowglobe_with_snow_dropshadow.svg"
    "http://upload.wikimedia.org/wikipedia/commons/3/3b/Tuxcrystal.svg"
    "http://upload.wikimedia.org/wikipedia/commons/8/86/TUX-G2-SVG.svg"
    "http://linwiki.64byte.com/upload/3/35/Tux.svg"

