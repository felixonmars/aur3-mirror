// Copyright Chris Johnson 2012. All rights reserved.

// This is my first program, so please be kind.
// Based on HRdioProvider by Joshua Netterfield

#ifndef HVKPROVIDER_H
#define HVKPROVIDER_H

#include "hbrowser.h"
#include "hvkinit.h"
#include "habstractmusicinterface.h"
#include "hplugin.h"
#include <phonon/MediaObject>

struct HVkTriplet {
    HTrack* t;
    QObject* o;
    QString m;
    HVkTriplet(HTrack* ct,QObject* co,QString cm) : t(ct), o(co), m(cm) {}
};

class HVkProvider : public QObject, public HAbstractTrackProvider
{
    Q_OBJECT
    Q_INTERFACES(HAbstractTrackProvider)
    friend void vk_md5(QMap<QString, QString>& params);
    static HVkProvider* s_singleton;
    QString s_token;
    QString s_user;
    HBrowser s_browser;
    bool s_ready;
    bool s_calmDown;
    HVkInit* s_init;
public:
    HVkProvider();
    QString name() { return "Vk"; }
    QWidget* initWidget() { return s_init; }

    QList<HVkTriplet> s_sendScoreQueue;


public: //HAbstractTrackProvider
    int globalScore() { return 60; }
    void sendScore(HTrack& track,QObject* o,QString m) {
        if(!s_ready) {
            QMetaObject::invokeMethod(o,m.toUtf8().data(),Qt::QueuedConnection,Q_ARG(int,0),Q_ARG(HAbstractTrackProvider*,this));
            return;
        }
        s_sendScoreQueue.push_back(HVkTriplet(&track,o,m));
        QMetaObject::invokeMethod(this,"processScoreRequests",Qt::QueuedConnection);
    }
    void sendTrack(HTrack& track,QObject* o,QString m) {
        HAbstractTrackInterface* ti=new HPhononTrackInterface(track,getKey(track));
        QMetaObject::invokeMethod(o,m.toUtf8().data(),Qt::QueuedConnection,Q_ARG(HAbstractTrackInterface*,ti),Q_ARG(HAbstractTrackProvider*,this));
    }

    HAbstractTrackInterface* queue(HTrack& track) { return new HPhononTrackInterface(track,getKey(track)); }

private:
    struct Key {
        HTrack& track;
        QString s_vkKey;
        HRunOnceNotifier* s_vkKey_getting;
        QString getKey();
        Key(HTrack& ctrack) : track(ctrack), s_vkKey_getting(0) {}
    };

    QList< Key* > s_keys;
    QString getKey(HTrack& track);
public:
    static HVkProvider* singleton() { Q_ASSERT(s_singleton); return s_singleton; }
    QString search(QString query, QString artistF, QString trackF);
public slots:
    void checkBrowser();
    void processScoreRequests() {
        if(s_calmDown) return;
        s_calmDown=1;
        if(s_sendScoreQueue.size()) {
            HTrack& track=*s_sendScoreQueue.first().t;
            QObject* o=s_sendScoreQueue.first().o;
            QString m=s_sendScoreQueue.first().m;
            s_sendScoreQueue.pop_front();
            bool ok=getKey(track)!="_NO_RESULT_";
            if(ok) QMetaObject::invokeMethod(o,m.toUtf8().data(),Qt::QueuedConnection,Q_ARG(int,60),Q_ARG(HAbstractTrackProvider*,this));
            else QMetaObject::invokeMethod(o,m.toUtf8().data(),Qt::QueuedConnection,Q_ARG(int,0),Q_ARG(HAbstractTrackProvider*,this));
        }
        if(s_sendScoreQueue.size()) {
            QMetaObject::invokeMethod(this,"processScoreRequests",Qt::QueuedConnection);
        }
        s_calmDown=0;
    }
    void clearInit() {
        s_init=0;
    }
};

class HVkPlugin : public QObject, public HPlugin
{
    Q_OBJECT
    Q_INTERFACES(HPlugin)
    friend class HLocalIntro;
    friend class HLocalProvider;
    HVkProvider* s_provider;
public:
    HVkPlugin() : s_provider(new HVkProvider) {}
    virtual HAbstractTrackProvider* trackProvider() { return s_provider; }
    virtual QWidget* initWidget() {
        return s_provider->initWidget();
    }
    virtual QString name() { return s_provider->name(); }
    virtual QSet<QString> abilities() { return QSet<QString>(); }
    virtual int** send(const QString &, HObject *, QObject *, QString , QObject *) { Q_ASSERT(0); return 0; }
    virtual int getScore(const QString &, HObject *, QObject *, QString, QObject *) { return -1; }
    bool isLocal(const QString &, HObject *, QObject *, QString , QObject *) { return 0; }

    virtual QWidget* configurationWidget() { return 0; }
};

#endif // HVKINTERFACE_H
