// Copyright Chris Johnson 2012. All rights reserved.

// This is my first program (/plugin), so please be kind.
// Based on HRdioProvider by Joshua Netterfield

#include "hvkprovider.h"
#include <QDebug>
#include <QMessageBox>
#include <QEventLoop>
#include <QTimer>
#include <QSettings>
#include <phonon/MediaObject>
#include <QtPlugin>
#include <lastfm.h>

#define VK_API_ID "2763039"
#define VK_API_SECRET "l2gYoKqA2abe3lCUJZyE"

void vk_md5(QMap<QString, QString>& params) {
    QString s;
    QMapIterator<QString, QString> i( params );
    s+=HVkProvider::singleton()->s_user;
    while (i.hasNext()) {
        i.next();
//        if(i.key()=="v") continue;
//        if(i.key()=="format") continue;
//        if(i.key()=="callback") continue;
        s += i.key() + '=' + i.value();
    }
    s += VK_API_SECRET;

    params["sig"] = lastfm::md5( s.toUtf8() );
}

QNetworkReply* vk_post( QMap<QString, QString> params )
{
    vk_md5(params);
    QByteArray query;
    QMapIterator<QString, QString> i( params );
    while (i.hasNext()) {
        i.next();
        query += QUrl::toPercentEncoding( i.key() )
               + '='
               + QUrl::toPercentEncoding( i.value() )
               + '&';
    }
    if(query.endsWith('&')) query.chop(1);

    QNetworkRequest nr(QUrl("https://api.vkontakte.ru/method/audio.search.xml"));
    nr.setHeader(QNetworkRequest::ContentTypeHeader,"application/x-www-form-urlencoded");

    return lastfm::nam()->post( nr, query );
}

QString vk_standardized(QString r) {
    r=r.toLower();
    r.replace("&amp;","&");
    r.replace("#39;","\'");
    r.replace(224,'a');
    r.replace(225,'a');
    r.replace(226,'a');
    r.replace(227,'a');
    r.replace(228,'a');
    r.replace(232,'e');
    r.replace(233,'e');
    r.replace(234,'e');
    r.replace(235,'e');
    r.replace(236,'i');
    r.replace(237,'i');
    r.replace(238,'i');
    r.replace(241,'i');
    r.replace(239,'i');
    r.replace(244,'o');
    r.replace(219,'u');
    r.replace(249,'u');
    r.replace(251,'u');
    r.replace(252,'u');
    r.replace(221,'y');
    r.replace(255,'y');
    r.replace("’","\'");
    r.replace("\' ","\'");
    while(r.endsWith(' ')) {
        r.chop(1);
    }
    return r;
}



HVkProvider* HVkProvider::s_singleton=0;

HVkProvider::HVkProvider() : s_browser(0,true) {
    qDebug()<<"VKP";
    s_ready=0;
    s_singleton=this;
    s_calmDown=0;
    QSettings settings("Chris Johnson","VKPlugin for Hathor");
    if(settings.value("token","NONE")!="NONE") {
        s_token=settings.value("token").toString();
        s_user=settings.value("user").toString();
        qDebug()<<"Vk is ready to roll.";
        s_ready=1;
        s_init=0;
    } else {
        qDebug()<<"INITI";
        s_browser.loadPage(QString("http://oauth.vkontakte.ru/oauth/authorize?client_id=")+QString(VK_API_ID)+QString("&scope=audio,offline&redirect_uri=http://api.vkontakte.ru/blank.html&response_type=token"));
        s_init=new HVkInit(s_browser);
    }
    connect(&s_browser,SIGNAL(ready()),this,SLOT(checkBrowser()));
    if(s_init) connect(s_init,SIGNAL(destroyed()),this,SLOT(clearInit()));
}

void HVkProvider::checkBrowser() {
    if(s_browser.url().contains("&scope=audio,offline")||s_browser.url().contains("state=&display=page&m=4")) {
        //TRANSLATE
        s_browser.doJS("document.getElementsByClassName(\"label\")[0].innerHTML=\"Telephone or e-mail:\"");
        s_browser.doJS("document.getElementsByClassName(\"label\")[1].innerHTML=\"Password:\"");
        s_browser.doJS("document.getElementById(\"expire_checkbox\").innerHTML=\"<div></div><font><font class>Don't remember me</font></font>\"");
        s_browser.doJS("document.getElementsByClassName(\"oauth_header\")[0].innerHTML=\"<font><font class>Log in</font></font>\"");
        s_browser.doJS("document.getElementById(\"install_allow\").innerHTML=\"<font><font class>Log in</font></font>\"");
        s_browser.doJS("document.getElementById(\"install_cancel\").innerHTML=\"<font><font class>Cancel</font></font>\"");
    }
    if(s_browser.url().contains("error")) {
        if(QMessageBox::critical(0,"Error getting access","Could not get access to Vk. Try again?",QMessageBox::Yes,QMessageBox::No)==QMessageBox::Yes) {
            s_browser.loadPage("http://oauth.vkontakte.ru/oauth/authorize?client_id=2757104&scope=audio,offline&redirect_uri=http://api.vkontakte.ru/blank.html&response_type=token");
        }
    } else if(s_browser.url().contains("access_token")) {
        s_browser.hide();
        s_token=s_browser.url();
        s_user=s_browser.url();
        s_token.remove(0,s_token.indexOf("access_token=")+13);
        s_user.remove(0,s_user.indexOf("user_id=")+8);
        s_token.truncate(s_token.indexOf('&'));
        QSettings settings("Chris Johnson","VKPlugin for Hathor");
        settings.setValue("token",s_token);
        settings.setValue("user",s_user);
//        s_user.truncate(s_token.indexOf('&'));
        qDebug()<<"Rdio is ready to roll...";
        s_ready=1;
        if(s_init) disconnect(s_init,SIGNAL(destroyed()),this,SLOT(clearInit()));
        if(s_init) s_init->deleteLater();
    }
}

QString HVkProvider::search(QString query, QString artistF, QString trackF) {
    artistF=vk_standardized(artistF);
    trackF=vk_standardized(trackF);
    QMap<QString,QString> map1;
    map1.insert("v", "2.0");
    map1.insert("access_token", s_token);
    map1.insert("count", "30");
    map1.insert("q", query);
    QNetworkReply* r=vk_post(map1);

    QEventLoop loop;
    QTimer::singleShot(2850,&loop,SLOT(quit()));
    loop.connect( r, SIGNAL(finished()), SLOT(quit()) );
    loop.exec();

    QString d=QString::fromUtf8(r->readAll().data());
    QString url;
    try {
        QDomDocument doc;
        doc.setContent( d );

        QDomElement element = doc.documentElement();

        for(QDomNode n = element.firstChild(); !n.isNull(); n = n.nextSibling()) {
            for (QDomNode m = n.firstChild(); !m.isNull(); m = m.nextSibling()) {
                for (QDomNode l = m.firstChild(); !l.isNull(); l = l.nextSibling()) {
                    if ( m.nodeName() == "artist" && !artistF.isNull() &&artistF!=vk_standardized(l.toText().data())) break;
                    if ( m.nodeName() == "track" && !trackF.isNull() &&trackF!=vk_standardized(l.toText().data())) break;
                    if ( m.nodeName() == "url" ) {
                        qDebug()<<"VK got url"<<l.toText().data();
                        return l.toText().data();
                    }
                }
            }
        }

    } catch (std::runtime_error& e) {
        qWarning() << e.what();
    }
    return "";
}

QString HVkProvider::getKey(HTrack& track) {

    for(int i=0;i<s_keys.size();i++) {
        if(&s_keys[i]->track==&track) {
            return s_keys[i]->getKey();
        }
    }
    s_keys.push_back(new Key(track));
    return s_keys.back()->getKey();
}

QString HVkProvider::Key::getKey() {
    if(s_vkKey.size()) return s_vkKey;
    if(s_vkKey_getting) {
        QEventLoop loop; connect(s_vkKey_getting,SIGNAL(notify()),&loop,SLOT(quit())); loop.exec();
        return s_vkKey;
    }
//    QSettings sett("Chris Johnson","VKPlugin for Hathor");

//    if(sett.value("key for "+track.getArtistName()+"__"+track.getTrackName()).isValid()) {
//        return s_vkKey=sett.value("key for "+track.getArtistName()+"__"+track.getTrackName()).toString();
//    }
    s_vkKey_getting=new HRunOnceNotifier;
    s_vkKey=HVkProvider::singleton()->search(track.getArtistName()+" "+track.getTrackName(),track.getArtistName(),track.getTrackName());
    if(!s_vkKey.size()) s_vkKey="_NO_RESULT_";
    s_vkKey_getting->emitNotify();
    s_vkKey_getting=0;
//    sett.setValue("key for "+track.getArtistName()+"__"+track.getTrackName(),s_vkKey);
    return s_vkKey;
}

Q_EXPORT_PLUGIN2(hvk_plugin, HVkPlugin)
