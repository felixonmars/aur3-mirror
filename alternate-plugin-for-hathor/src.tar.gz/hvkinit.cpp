#include "hvkinit.h"
#include "ui_hvkinit.h"
#include <QDebug>

HVkInit::HVkInit(HBrowser &browser, QWidget *parent) :
    QWidget(parent),
    s_browser(browser),
    ui(new Ui::HVkInit)
{
    ui->setupUi(this);
    connect(ui->pushButton,SIGNAL(pressed()),this,SLOT(next()));
}

void HVkInit::next() {
    if(ui->checkBox->isChecked()) {
        ui->label_warning->hide();
        ui->frame->layout()->addWidget(&s_browser);
        ui->pushButton->hide();
        ui->checkBox->hide();
        ui->frame_2->hide();
        s_browser.show();
    } else {
        deleteLater();
    }
}

void HVkInit::relax() {
    ui->frame->layout()->removeWidget(&s_browser);
    s_browser.setParent(0);
}

HVkInit::~HVkInit()
{
    relax();
    delete ui;
}
