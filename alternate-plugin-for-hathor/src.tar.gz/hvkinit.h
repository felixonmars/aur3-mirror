#ifndef HVKINIT_H
#define HVKINIT_H

#include <QWidget>
#include "hbrowser.h"

namespace Ui {
class HVkInit;
}

class HVkInit : public QWidget
{
    Q_OBJECT
    HBrowser& s_browser;

public:
    explicit HVkInit(HBrowser& browser, QWidget *parent = 0);
    ~HVkInit();

public slots:
    void next();
    void relax();
    
private:
    Ui::HVkInit *ui;
};

#endif // HVKINIT_H
