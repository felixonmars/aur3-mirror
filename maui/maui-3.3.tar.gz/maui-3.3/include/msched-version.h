#define MSCHED_VERSION "3.3"
#define MSCHED_SVERSION "maui-3.3"
