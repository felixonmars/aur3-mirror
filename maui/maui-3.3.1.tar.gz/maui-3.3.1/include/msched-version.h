#define MSCHED_VERSION "3.3.1"
#define MSCHED_SVERSION "maui-3.3.1"
