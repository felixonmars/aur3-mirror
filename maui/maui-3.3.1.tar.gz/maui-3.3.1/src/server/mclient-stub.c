/*
Package:  maui
Module:   mclient-stub.c
Version:  3.3.1

Copyright:

  Copyright (C) 1999-2010 Cluster Resources, Inc

  All Rights Reserved

Disclaimer:

  

*/

#if defined(__MLL) || defined(__MLL2) || defined(__MLL31)

int MLLLoadModule(mrmfunc_t *F) { return(SUCCESS); }

#endif /* __MLL || __MLL2 || __MLL31 */

/* END mclient-stub.c */

