#ifndef  _CRC16_H
#define  _CRC16_H
unsigned short crc16(unsigned char *data, unsigned short len); 
#endif
