/* Header file for asus_eee.c */

struct eeefv
{
    int mul;
    int div;
    int voltage;
};


static bool eee_pll_init(void);
static bool eee_pll_read(void);
static bool eee_pll_write(void);
static void eee_pll_cleanup(void);
static void eee_set_state(int n, int m, int voltage);
static void eee_work_fn(struct work_struct *work);
			   