/* Compilation options */

#define EEE_FSBSTEPUP1 	10	// Maximum FSB step up per tick,%
#define EEE_FSBRANGE1	60
#define EEE_FSBSTEPUP2 	25	// Maximum FSB step up per tick,%
#define EEE_FSBSTEPDN 	25	// Maximum FSB step down per tick,%
#define EEE_MINFSB 	50	// Minimum FSB allowed
#define EEE_MAXFSB	105	// Maximum FSB allowed
#define EEE_HIVOLTFSB	85	// FSB value when needed high voltage
#define EEE_STEPDELAY	200	// Delay between steps
#define EEE_DEBUG	1	// Enable debug printk