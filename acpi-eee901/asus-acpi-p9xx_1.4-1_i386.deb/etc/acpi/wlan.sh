#! /bin/sh

PWR=`cat /proc/acpi/asus/wlan`
SERVICE=""

unload_modules() {
	# remove wlan modules
	rmmod wlan_scan_sta
	rmmod wlan_tkip 2>/dev/null
	rmmod wlan_wep 2>/dev/null
	rmmod wlan_ccmp 2>/dev/null
	rmmod wlan_acl 2>/dev/null
	rmmod ath_pci
	sleep 1
	rmmod ath_rate_atheros
	rmmod wlan
	rmmod ath_dfs
	rmmod ath_hal
	rmmod fakephp
}


case $1 in
	poweron)
		if [ "$PWR" = "0" ]; then
			echo 1 > /proc/acpi/asus/wlan
			modprobe -r -q fakephp
			unload_modules
			modprobe fakephp
			sleep 2
			/sbin/ifconfig ath0 up
		fi
		;;

	restore)
		if [ "$PWR" = "1" ]; then
			if [ -f /tmp/wlan_suspend.dat ]; then
				SERVICE=`cat /tmp/wlan_suspend.dat`
				rm -f /tmp/wlan_suspend.dat
			fi
			if [ -n "$SERVICE" ] ; then
				#restore wlan connection only if present!
				WLAN_ESSID=`/opt/xandros/bin/xandrosncs-servicedb -i $SERVICE -g WIRELESS_ESSID | cut -f 2 -d '='`
				if [ -n "$WLAN_ESSID" ]; then
					/sbin/ifconfig ath0 down
					WLAN_CHANNEL=`/opt/xandros/bin/xandrosncs-servicedb -i $SERVICE -g WIRELESS_CHANNEL | cut -f 2 -d '='`
					if [ -n "$WLAN_CHANNEL" ]; then
						iwconfig ath0 channel $WLAN_CHANNEL
						DELAY=15
					else
						iwconfig ath0 channel 0
						DELAY=30
					fi
					iwconfig ath0 essid "$WLAN_ESSID"
					/sbin/ifconfig ath0 up

					while [ $DELAY -gt 0 ]; do
						sleep 1
						WLAN_FOUND=`iwlist ath0 scan 2>/dev/null | grep ESSID | cut -d '"' -f 2`
						ESSID_FOUND=`echo $WLAN_FOUND | grep "\b${WLAN_ESSID}\b"`
						echo "$DELAY. Looking for: $WLAN_ESSID, found $WLAN_FOUND. match $ESSID_FOUND.">>/tmp/wlan_wakeup.log
						if [ -n "$ESSID_FOUND" ]; then
							break;
						fi
						DELAY=$((DELAY - 1))
					done

					if [ -n "$ESSID_FOUND" ]; then
						touch /tmp/xandrosncs_no_status_dialog
						/opt/xandros/bin/xandrosncs-control -i $SERVICE start
						rm /tmp/xandrosncs_no_status_dialog
					fi
				fi
			fi
		fi
		;;

	poweroff)
		if [ "$PWR" = "1" ]; then
			for i in `/opt/xandros/bin/xandrosncs-servicedb --list | grep "[[:space:]]wlan[[:space:]]" | cut -f 1 -d ' '` ; do
				WLAN_STATUS=`/opt/xandros/bin/xandrosncs-control -i $i status | cut -f 2 -d ' '`
				if [ "up" = $WLAN_STATUS ]; then
					SERVICE=$i
					echo $SERVICE > /tmp/wlan_suspend.dat
					break;
				fi
			done

			if [ -n "$SERVICE" ] ; then 
				touch /tmp/xandrosncs_no_status_dialog
				/opt/xandros/bin/xandrosncs-control -i $SERVICE stop
				rm -f /etc/resolvconf/run/interface/ath0.$SERVICE
				rm /tmp/xandrosncs_no_status_dialog
			fi

			# remove wlan interface
			ifconfig ath0 down
			sleep 1
			wlanconfig ath0 destroy

			unload_modules

			echo 0 > /proc/acpi/asus/wlan
		fi
		;;

	suspend)
		if [ "$PWR" = "1" ]; then
			echo 0 > /proc/acpi/asus/wlan
		fi
		;;

	cleanup)
		if [ "$PWR" = "0" ]; then
			for i in `/opt/xandros/bin/xandrosncs-servicedb --list | grep "[[:space:]]wlan[[:space:]]" | cut -f 1 -d ' '` ; do
				WLAN_STATUS=`/opt/xandros/bin/xandrosncs-control -i $i status | cut -f 2 -d ' '`
				if [ "up" = $WLAN_STATUS ]; then
					SERVICE=$i
					echo $SERVICE > /tmp/wlan_suspend.dat
					break;
				fi
			done
			if [ -n "$SERVICE" ] ; then 
				touch /tmp/xandrosncs_no_status_dialog
				/opt/xandros/bin/xandrosncs-control -i $SERVICE stop
				rm -f /etc/resolvconf/run/interface/ath0.$SERVICE
				rm /tmp/xandrosncs_no_status_dialog
			fi

			# remove wlan interface
			ifconfig ath0 down
			sleep 1
			wlanconfig ath0 destroy
			unload_modules
		fi
		;;

	status)
		if [ "$PWR" = "1" ]; then
			echo "ON"
		else
			echo "OFF"
		fi
		;;

esac
