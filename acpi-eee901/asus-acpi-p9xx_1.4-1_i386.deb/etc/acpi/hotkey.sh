#!/bin/sh


export DISPLAY=:0

case $3 in
	#Fn+F1
	00000080)
		# echo "Suspend2RAM" > /dev/console
		;;
	#Fn+F2
	00000010)
		# echo "Wlan On" > /dev/console &
		/etc/acpi/wlan.sh poweron
		/etc/acpi/wlan.sh restore
		;;
	00000011)
		# echo "Wlan Off" > /dev/console &
		/etc/acpi/wlan.sh poweroff
		;;
	#Fn+F3
	00000030)
		# echo "LCD" > /dev/console &
		/etc/acpi/esc2impress.sh
		# /bin/su user -c "/usr/bin/xrandr --output LVDS --preferred --output VGA --off"
		;;
	00000031)
		# echo "CRT" > /dev/console &
		/etc/acpi/esc2impress.sh
		# /bin/su user -c "/usr/bin/xrandr --output VGA --mode 800x600 --output LVDS --off"
		;;
	00000032)
		# echo "LCD-CRT" > /dev/console &
		/etc/acpi/esc2impress.sh
		# /bin/su user -c "/usr/bin/xrandr --output VGA --mode 800x480 --output LVDS --mode 800x480"
		;;
	#Fn+F6
	00000012)
		# echo "Task Manage On" > /dev/console
		DISPLAY=:0 /bin/su -c "/usr/bin/ksysguard --showprocesses" user &
		;;
	#Fn+F7
	00000013)
		# echo "Volume Mute" > /dev/pts/0 &
		;;
	#Fn+F8
	00000014)
		# echo "Volume Down" > /dev/console &
		/usr/local/bin/volume_control.sh on
		amixer set LineOut 3.20dB-
		;;
	#Fn+F9
	00000015)
		# echo "Volume Up" > /dev/console &
		/usr/local/bin/volume_control.sh on
		amixer set LineOut 3.20dB+
		;;
	#Fn+F3
	0000002x)
		#echo "Brightness Down" > /dev/pts/0
		;;
	#Fn+F4
	0000002x)
		#echo "Brightness Up" > /dev/pts/0
		;;
	#AC Mode
	00000050)
		echo 0 > /proc/acpi/asus/cpufv
		;;
	#Battery Mode
	00000051)
		echo 1 > /proc/acpi/asus/cpufv
		;;
esac

