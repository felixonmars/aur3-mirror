#!/bin/sh

# This script sends an escape key press and release event to OpenOffice
# Impress, which is not RandR aware. This forces the user to re-enter
# full-screen mode.

[ -z `pidof soffice.bin` ] && exit 0

for i in `xwininfo -root -tree | grep Impress | awk '{print $1}'`; do
	/usr/bin/send-escape-event $i
done
