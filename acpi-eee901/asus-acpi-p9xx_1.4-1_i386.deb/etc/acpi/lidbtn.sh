#!/bin/sh
LID_STATE=`cat /proc/acpi/button/lid/LID/state | awk '{print $2 }'`

if [ $LID_STATE = "closed" ] ; then
	/etc/acpi/suspend2ram.sh
fi
exit 0
