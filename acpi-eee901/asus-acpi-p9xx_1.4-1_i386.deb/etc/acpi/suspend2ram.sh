#!/bin/sh

if grep -q mem /sys/power/state ; then

	# Switch on external video port. Prevents hangs.
	#su user -c "DISPLAY=:0.0 /usr/bin/xrandr --output VGA --mode 1024x768"

	echo "0 0 0 0">/proc/sys/kernel/printk

	# save the wireless power state, if ON - prepare for suspend
	WLANP=`cat /proc/acpi/asus/wlan`
	if [ $WLANP == "1" ]; then
		/etc/acpi/wlan.sh suspend
	fi

	# Bring down all dialup connections, including 3G
	DIALUP=0
	for i in "`/opt/xandros/bin/xandrosncs-servicedb --list | /bin/grep -v SUBTYPE`" ; do
	    NAME=`echo $i | /usr/bin/awk '{print $1}'`
	    TYPE=`echo $i | /usr/bin/awk '{print $2}'`
	    if [ "${TYPE#dialup}" != "$TYPE" ] ; then
	    	/opt/xandros/bin/xandrosncs-control -i $NAME stop
		DIALUP=1
	    fi
	done

	# turn off webcam
	CAMP=`cat /proc/acpi/asus/camera`
	if [ $CAMP == "1" ] ; then
		killall -9 ucview.real
	fi
	echo 0 > /proc/acpi/asus/camera

	# kill ASUS 3G tool related process
	/opt/3gmpt/delui.sh
	/opt/3gmpt/delpppd.sh

	# unload some usb modules (3G)
	if [ $DIALUP == "1" ]; then 
		/sbin/rmmod option usbserial 2>/dev/null
	fi

	# save the brightness value
	BRN=`cat /proc/acpi/asus/brn`

	/usr/bin/killall krecord

	# reset numlock - system wakes with numlock off
	su user -c "DISPLAY=:0.0 /usr/local/bin/numlockx off"

	# flush the buffers to disk
	sync

	echo -n "mem" > /sys/power/state

	# enable webcam if Skype is running before standby
	if [ "$(/bin/pidof skype)" != "" ]; then
	 echo 1 >/proc/acpi/asus/camera
	fi


	# get ready to re-init the wireless
	rmmod fakephp

	# wait for X display to come up
	sleep 4

	# restore screen brightness
	echo $BRN > /proc/acpi/asus/brn

	if [ $WLANP == "1" ]; then
		sleep 1
		/etc/acpi/wlan.sh cleanup
	fi

	# turn wireless down so it can be cleanly loaded by PCIe hotplug
	echo 0 > /proc/acpi/asus/wlan
	sleep 1
	modprobe fakephp

	# if wireless was ON before sleep - power it up
	if [ $WLANP == "1" ]; then
		sleep 1
		/etc/acpi/wlan.sh poweron
		/etc/acpi/wlan.sh restore
	fi

	# unload some usb modules (3G)
	if [ $DIALUP == "1" ]; then 
		/sbin/modprobe option 2>/dev/null
	fi

	# signal the acpid to unlock a flag from suspend.
	(sleep 2 ; killall -SIGALRM acpid )&
fi

exit 0
