/*
-----------------------------------------------------------------------------
 $Id: pal_version.h,v 1.2 2007/10/17 15:36:34 cnepveu Exp $
-----------------------------------------------------------------------------
Copyright (c) 2007 Hexago Inc. All rights reserved.

  LICENSE NOTICE: You may use and modify this source code only if you
  have executed a valid license agreement with Hexago Inc. granting
  you the right to do so, the said license agreement governing such
  use and modifications.   Copyright or other intellectual property
  notices are not to be removed from the source code.
-----------------------------------------------------------------------------

  Platform abstraction layer version.

-----------------------------------------------------------------------------
*/
#ifndef __PAL_VERSION_H__
#define __PAL_VERSION_H__


#ifndef PLATFORM
#define PLATFORM "Unknown platform"
#endif

const char* get_pal_version( void );

#endif
