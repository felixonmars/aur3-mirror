/*
-----------------------------------------------------------------------------
 $Id: pal_stdarg.h,v 1.2 2008/02/22 23:48:17 krause Exp $
-----------------------------------------------------------------------------
Copyright (c) 2007 Hexago Inc. All rights reserved.

  LICENSE NOTICE: You may use and modify this source code only if you
  have executed a valid license agreement with Hexago Inc. granting
  you the right to do so, the said license agreement governing such
  use and modifications.   Copyright or other intellectual property
  notices are not to be removed from the source code.
-----------------------------------------------------------------------------

  Platform abstraction layer for stdarg.

-----------------------------------------------------------------------------
*/
#ifndef __PAL_STDARG_H__
#define __PAL_STDARG_H__

#include <stdarg.h>

#endif
