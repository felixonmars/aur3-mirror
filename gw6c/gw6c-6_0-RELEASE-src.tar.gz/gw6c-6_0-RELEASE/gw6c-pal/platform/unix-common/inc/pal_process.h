/*
-----------------------------------------------------------------------------
 $Id: pal_process.h,v 1.3 2008/02/27 14:55:30 cnepveu Exp $
-----------------------------------------------------------------------------
Copyright (c) 2007 Hexago Inc. All rights reserved.

  LICENSE NOTICE: You may use and modify this source code only if you
  have executed a valid license agreement with Hexago Inc. granting
  you the right to do so, the said license agreement governing such
  use and modifications.   Copyright or other intellectual property
  notices are not to be removed from the source code.
-----------------------------------------------------------------------------

  Platform abstraction layer process definitions.

-----------------------------------------------------------------------------
*/
#ifndef __PAL_PROCESS_H__
#define __PAL_PROCESS_H__


// process API definitions.
#include "pal_process.def"
#include <unistd.h>


// process functions already available in this platform.
#undef pal_getpid
#define pal_getpid getpid

#undef pal_getppid
#define pal_getppid getppid

#endif
