/*
-----------------------------------------------------------------------------
 $Id: net_cksm.h,v 1.7 2008/01/09 15:08:46 cnepveu Exp $
-----------------------------------------------------------------------------
  Copyright (c) 2007 Hexago Inc. All rights reserved.

  LICENSE NOTICE: You may use and modify this source code only if you
  have executed a valid license agreement with Hexago Inc. granting
  you the right to do so, the said license agreement governing such
  use and modifications.   Copyright or other intellectual property
  notices are not to be removed from the source code.
-----------------------------------------------------------------------------
*/

uint16_t            in_cksum              (uint16_t *addr, sint32_t len);
