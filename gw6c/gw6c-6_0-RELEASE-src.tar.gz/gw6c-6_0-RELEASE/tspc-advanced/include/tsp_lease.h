/*
-----------------------------------------------------------------------------
 $Id: tsp_lease.h,v 1.8 2008/03/13 19:52:11 cnepveu Exp $
-----------------------------------------------------------------------------
  Copyright (c) 2007 Hexago Inc. All rights reserved.

  LICENSE NOTICE: You may use and modify this source code only if you
  have executed a valid license agreement with Hexago Inc. granting
  you the right to do so, the said license agreement governing such
  use and modifications.   Copyright or other intellectual property
  notices are not to be removed from the source code.
-----------------------------------------------------------------------------
*/

#ifndef _TSP_LEASE_H_
#define _TSP_LEASE_H_

long                tspLeaseGetExpTime    ( const long tun_lifetime );

sint32_t            tspLeaseCheckExp      ( const long tun_expiration );

#endif
