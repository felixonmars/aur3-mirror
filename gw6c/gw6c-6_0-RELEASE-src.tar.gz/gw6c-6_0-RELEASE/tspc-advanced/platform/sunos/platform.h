/*
---------------------------------------------------------------------------
 $Id: platform.h,v 1.3 2008/02/22 14:38:04 cnepveu Exp $
---------------------------------------------------------------------------
Copyright (c) 2001-2007 Hexago Inc. All rights reserved.

  LICENSE NOTICE: You may use and modify this source code only if you
  have executed a valid license agreement with Hexago Inc. granting
  you the right to do so, the said license agreement governing such
  use and modifications.   Copyright or other intellectual property
  notices are not to be removed from the source code.
---------------------------------------------------------------------------
*/
#ifndef _PLATFORM_H_
#define _PLATFORM_H_

/* Solaris */

#include "pal.h"

#define SCRIPT_TMP_FILE                   "/tmp/gw6c-tmp.log"

#endif
