/*
---------------------------------------------------------------------------
 $Id: platform.h,v 1.22 2008/02/22 14:37:59 cnepveu Exp $
---------------------------------------------------------------------------
This source code copyright (c) Hexago Inc. 2002-2007.

  LICENSE NOTICE: You may use and modify this source code only if you
  have executed a valid license agreement with Hexago Inc. granting
  you the right to do so, the said license agreement governing such
  use and modifications.   Copyright or other intellectual property
  notices are not to be removed from the source code.
---------------------------------------------------------------------------
*/
#ifndef _PLATFORM_H_
#define _PLATFORM_H_

/* Linux */

#include "pal.h"

#define SCRIPT_TMP_FILE                   "/tmp/gw6c-tmp.log"

#endif
