/*
-----------------------------------------------------------------------------
 $Id: net_cksm.c,v 1.8 2008/01/09 15:09:09 cnepveu Exp $
-----------------------------------------------------------------------------
Copyright (c) 2001-2005 Hexago Inc. All rights reserved.

  LICENSE NOTICE: You may use and modify this source code only if you
  have executed a valid license agreement with Hexago Inc. granting
  you the right to do so, the said license agreement governing such
  use and modifications.   Copyright or other intellectual property
  notices are not to be removed from the source code.
-----------------------------------------------------------------------------
*/

#include "platform.h"
#include "net_cksm.h"

/* checksum calculation */
uint16_t in_cksum( uint16_t *addr, sint32_t len )
{
	sint32_t nleft = len;
	sint32_t sum = 0;
	uint16_t *w = addr;
	uint16_t answer = 0;

	while (nleft > 1) {
		sum += *w++;
		nleft -= 2;
	}
	if (nleft == 1) {
		*(uint8_t *) (&answer) = *(uint8_t *) w;
		sum += answer;
	}
	sum = (sum >> 16) + (sum & 0xffff);
	sum += (sum >> 16);
	answer = (uint16_t)(~sum);
	return (answer);
}
