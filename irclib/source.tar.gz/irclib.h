#ifndef IRCLIB_H
#define IRCLIB_H

#define IRC_CHANMSG 1
#define IRC_PRIVMSG 2
#define IRC_PING 3
#define IRC_INVALID -1

#include <string.h>
#include <stdlib.h>

#ifdef Win32
#include <winsock2.h>
#include <windows.h>

typedef SOCKET socket_type;

#else
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>

typedef int socket_type;
#endif //Win32

typedef struct {
	socket_type sockfd;
	char *channel, *nick, *real, *pass;
} Irc;

socket_type getSockfd(Irc* irc) {
	return irc->sockfd;
}

char* getChannel(Irc* irc) {
	return irc->channel;
}

char* getNick(Irc* irc) {
	return irc->nick;
} 

char* getReal(Irc* irc) {
	return irc->real;
}

char* getPass(Irc* irc) {
	return irc->pass;
}

void initIrc(Irc* irc, char* chan,
	     char* nick, char *real, char* pass) {
	irc->sockfd = (socket_type)0;
	irc->channel = chan;
	irc->nick = nick;
	irc->real = real;
	irc->pass = pass;
}

void setChannel(Irc* irc, char* chan) {
	irc->channel = chan;
}

void setNick(Irc* irc, char* nick) {
	irc->nick = nick;
}

void setReal(Irc* irc, char* real) {
	irc->real = real;
}

void setPass(Irc* irc, char* pass) {
	irc->pass = pass;
}

void setSockfd(Irc* irc, socket_type sock) {
	irc->sockfd = sock;
}

void connectIrc(Irc* irc, char* host, int port);
void joinChan(Irc* irc, char* passwrd);
void readBuffer(Irc* irc, char* buffer);
void sendChanMsg(Irc* irc, char* msg);
void sendPrivMsg(Irc* irc, char* rec, char* msg);
void pong(Irc* irc, char* msg);
int getMsgType(char* msg);
void leaveChan(Irc* irc);
void disconnect(Irc* irc);
void getSender(char* msg, char* sender);
#endif //IRCLIB_H
