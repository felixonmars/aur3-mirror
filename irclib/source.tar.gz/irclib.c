#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "irclib.h"

#ifdef Win32
#define CLOSEME(x) closesocket(x)
#else
#define CLOSEME(x) close(x)
#endif //Win32

int split(char *str, char c, char ***arr) {
	int count = 1;
	int token_len = 1;
	int i = 0;
	char *p = "";
	char *t = "";

	p = str;
	while (*p != '\0') {
		if (*p == c)
			count++;
        	p++;
    	}

 	*arr = (char**) malloc(sizeof(char*) * count);
	if (*arr == NULL)
        	exit(1);

	p = str;
	while (*p != '\0') {
		if (*p == c) {
            		(*arr)[i] = (char*) malloc( sizeof(char) * token_len );
            		if ((*arr)[i] == NULL)
                		exit(1);

            		token_len = 0;
            		i++;
        	}
       		p++;
        	token_len++;
    	}
	(*arr)[i] = (char*) malloc( sizeof(char) * token_len );
	if ((*arr)[i] == NULL)
		exit(1);

	i = 0;
	p = str;
	t = ((*arr)[i]);
    	while (*p != '\0') {
        	if (*p != c && *p != '\0') {
            		*t = *p;
            		t++;
        	} else {
            		*t = '\0';
            		i++;
            		t = ((*arr)[i]);
        	}
       		p++;
    	}

	return count;
}

char* hostname_to_ip(char* hostname) {
    	struct hostent *he;
    	struct in_addr **addr_list;
    	int i;
         
	if ((he = gethostbyname(hostname)) == NULL)
        	return "";
 
    	addr_list = (struct in_addr **)he->h_addr_list;
     
    	for(i = 0; addr_list[i] != NULL; i++) {
		char* ch = inet_ntoa(*addr_list[i]);
		return ch;
	}
     
	return "";
}

void connectIrc(Irc* irc, char* host, int port) {
	if (getSockfd(irc) != (socket_type)0) {
		CLOSEME(getSockfd(irc));
		#ifdef Win32
		WSACleanup();
		#endif //Win32
	}
	
	struct sockaddr_in server;
	memset(&server, 0, sizeof(server));

	socket_type sockl;

	#ifdef Win32
	WSADATA wsa;

	if (WSAStartup(MAKEWORD(2, 0), &wsa) < 0) {
		printf("IrcLib: Error at WSAStartup: %d\n", WSAGetLastError());
		exit(1);
	}

	if ((sockl = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
		printf("IrcLib: Error at socket creation:  %d\n", WSAGetLastError());
		WSACleanup();
		exit(1);
	}
	#else
	if ((sockl = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		printf("IrcLib: Error at socket creation.\n");
		exit(1);
	}
	#endif //Win32

	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	
	char *ip = hostname_to_ip(host);
	server.sin_addr.s_addr = inet_addr(ip);

	if (connect(sockl, (struct sockaddr *)&server, sizeof(server)) < 0) {
		CLOSEME(sockl);

		#ifdef Win32
		printf("IrcLib: Error at connection: %d\n", WSAGetLastError());
		WSACleanup();
		#else
		printf("IrcLib: Error at connection.\n");
		#endif //Win32

		exit(1);
	}

	char *tmp = malloc(sizeof(char)*256);
	sprintf(tmp, "PASS %s\r\n", getPass(irc));
	send(sockl, tmp, strlen(tmp), 0);
	
	sprintf(tmp, "NICK %s\r\n", getNick(irc));
	send(sockl, tmp, strlen(tmp), 0);
	
	sprintf(tmp, "USER %s 0 * : %s\r\n", getNick(irc), getReal(irc));
	
	send(sockl, tmp, strlen(tmp), 0);
	free(tmp);

	setSockfd(irc, sockl);
}

void joinChan(Irc* irc, char* passwrd) {
	char *join = malloc(sizeof(char)*256);
	sprintf(join, "JOIN %s %s\r\n", getChannel(irc), passwrd);

	printf("%s", join);
	send(getSockfd(irc), join, strlen(join), 0);
	free(join);
}

void readBuffer(Irc* irc, char* buffer) {
	int n = recv(getSockfd(irc), buffer, 255, 0);
	if (n < 0) {
		char *tmp = "ERROR";
		memcpy(buffer, tmp, 6);
		return;
	}

	buffer[n] = '\0';
}

void sendChanMsg(Irc* irc, char* msg) {
	char *m = malloc(sizeof(char)*256);
	sprintf(m, "PRIVMSG %s : %s\r\n", getChannel(irc), msg);
	
	send(getSockfd(irc), m, strlen(m), 0);
	free(m);
}

void sendPrivMsg(Irc* irc, char* rec, char* msg) {
	char *m = malloc(sizeof(char)*256);
	sprintf(m, "PRIVMSG %s : %s\r\n", rec, msg);

	send(getSockfd(irc), m, strlen(m), 0);
	free(m);
}

void pong(Irc* irc, char* msg) {
	char **words = NULL;
	if (split(msg, ' ', &words) < 1) {
		free(words);
		return;
	}

	char *host = (char *)words[0];
	char *out = malloc(sizeof(char)*256);
	sprintf(out, "PONG %s\r\n", host);

	send(getSockfd(irc), out, strlen(out), 0);
	free(words);
	free(out);
}

int getMsgType(char* msg) {
	char *ms = msg;
	char *intr = malloc(sizeof(char)*1024);
	memcpy(intr, ms, 4);
	
	intr[5] = '\0';
	if (strcmp(intr, "PING") == 0) {
		free(intr);
		return IRC_PING;
	}
	free(intr);

	char **m = NULL;
	int c = 0;
	if ((c = split(ms, ' ', &m)) < 2) {
		free(m);
		return IRC_INVALID;
	}

	if (m[2][0] == '#') {
		free(m);
		return IRC_CHANMSG;
	}

	free(m);
	return IRC_PRIVMSG;
}

void leaveChan(Irc* irc) {
	setChannel(irc, "");
	send(getSockfd(irc), "QUIT :\r\n", 9, 0);
}

void disconnect(Irc* irc) {
	CLOSEME(getSockfd(irc));

	#ifdef Win32
	WSACleanup();
	#endif //Win32
}

void getSender(char* msg, char* sender) {
	char **words = NULL;
	
	split(msg, ' ', &words);
	
	char **user = NULL;
	split(words[0], '!', &user);

	char *trueU = (char *)user[0];
	memset(sender, 0, sizeof(sender));
	memcpy(sender, trueU+1, strlen(trueU+1));

	free(words);
	free(user);
}
