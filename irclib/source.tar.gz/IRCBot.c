#include "irclib.h"
#include <stdio.h>

int main(int argc, char **argv) {
	Irc *ORE = malloc(sizeof(Irc));
	initIrc(ORE, "#OREServerChat", "IrcLib", "AftBot", "");
	connectIrc(ORE, "irc.freenode.net", 6667);
	joinChan(ORE, "");
	sendChanMsg(ORE, "Hi :D");

	char *msg = malloc(sizeof(char)*1024);
	char *sender = malloc(sizeof(char)*256);
	while(1) {
		readBuffer(ORE, msg);
		if (strcmp(msg, "ERROR\n") != 0)
			printf(msg);

		if (getMsgType(msg) == IRC_PING)
			pong(ORE, msg);

		getSender(msg, sender);
		if (strcmp(sender, "Aftix") == 0)
			break;
	}

	leaveChan(ORE);
	disconnect(ORE);
	free(ORE);
	free(msg);
	free(sender);
	return 0;
}
