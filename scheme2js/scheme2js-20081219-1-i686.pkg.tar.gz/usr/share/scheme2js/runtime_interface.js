/*** META ((export *js*))
 */
var sci_JS_GLOBALS = sc_JS_GLOBALS;

/*** META ((export #t))
 */
var sci_alert = sc_alert;

/*** META ((export #t))
 */
var sci_typeof = sc_typeof;

/*** META ((export #t))
 */
var sci_error = sc_error;

/*** META ((export #t) (peephole (prefix "throw ")))
 */
var sci_raise = sc_raise;

/*** META ((export with-handler-lambda))
 */
var sci_withHandlerLambda = sc_withHandlerLambda;

/*** META ((export #t))
 */
var sci_putpropBang = sc_putpropBang;

/*** META ((export #t))
 */
var sci_getprop = sc_getprop;

/*** META ((export #t))
 */
var sci_rempropBang = sc_rempropBang;

/*** META ((export #t))
 */
var sci_any2String = sc_any2String;

/*** META ((export #t)
 (peephole (infix 2 2 "==="))
 (type bool))
 */
var sci_isEqv = sc_isEqv;

/*** META ((export #t)
 (peephole (infix 2 2 "==="))
 (type bool))
 */
var sci_isEq = sc_isEq;

/*** META ((export #t) (type bool))
 */
var sci_isNumber = sc_isNumber;

/*** META ((export #t) (type bool))
 */
var sci_isComplex = sc_isComplex;

/*** META ((export #t) (type bool))
 */
var sci_isReal = sc_isReal;

/*** META ((export #t) (type bool))
 */
var sci_isRational = sc_isRational;

/*** META ((export #t) (type bool))
 */
var sci_isInteger = sc_isInteger;

/*** META ((export #t)
 (type bool)
 (peephole (postfix ", false")))
 */
var sci_isExact = sc_isExact;

/*** META ((export #t)
 (peephole (postfix ", true"))
 (type bool))
 */
var sci_isInexact = sc_isInexact;

/*** META ((export = =fx =fl)
 (type bool)
 (peephole (infix 2 2 "===")))
 */
var sci_equal = sc_equal;

/*** META ((export < <fx <fl)
 (type bool)
 (peephole (infix 2 2 "<")))
 */
var sci_less = sc_less;

/*** META ((export > >fx >fl)
 (type bool)
 (peephole (infix 2 2 ">")))
 */
var sci_greater = sc_greater;

/*** META ((export <= <=fx <=fl)
 (type bool)
 (peephole (infix 2 2 "<=")))
 */
var sci_lessEqual = sc_lessEqual;

/*** META ((export >= >=fl >=fx)
 (type bool)
 (peephole (infix 2 2 ">=")))
 */
var sci_greaterEqual = sc_greaterEqual;

/*** META ((export #t)
 (type bool)
 (peephole (postfix "=== 0")))
 */
var sci_isZero = sc_isZero;

/*** META ((export #t)
 (type bool)
 (peephole (postfix "> 0")))
 */
var sci_isPositive = sc_isPositive;

/*** META ((export #t)
 (type bool)
 (peephole (postfix "< 0")))
 */
var sci_isNegative = sc_isNegative;

/*** META ((export #t)
 (type bool)
 (peephole (postfix "%2===1")))
 */
var sci_isOdd = sc_isOdd;

/*** META ((export #t)
 (type bool)
 (peephole (postfix "%2===0")))
 */
var sci_isEven = sc_isEven;

/*** META ((export #t))
 */
var sci_max = sc_max;

/*** META ((export #t))
 */
var sci_min = sc_min;

/*** META ((export + +fx +fl)
 (peephole (infix 0 #f "+" "0")))
 */
var sci_plus = sc_plus;

/*** META ((export * *fx *fl)
 (peephole (infix 0 #f "*" "1")))
 */
var sci_multi = sc_multi;

/*** META ((export - -fx -fl) (peephole (minus)))
 */
var sci_minus = sc_minus;

/*** META ((export / /fl) (peephole (div)))
 */
var sci_div = sc_div;

/*** META ((export #t))
 */
var sci_abs = sc_abs;

/*** META ((export quotient /fx)
 (peephole (hole 2 "parseInt(" x "/" y ")")))
 */
var sci_quotient = sc_quotient;

/*** META ((export #t) (peephole (infix 2 2 "%")))
 */
var sci_remainder = sc_remainder;

/*** META ((export #t) (peephole (modulo)))
 */
var sci_modulo = sc_modulo;

/*** META ((export #t))
 */
var sci_gcd = sc_gcd;

/*** META ((export #t))
 */
var sci_lcm = sc_lcm;

/*** META ((export #t))
 */
var sci_floor = sc_floor;

/*** META ((export #t))
 */
var sci_ceiling = sc_ceiling;

/*** META ((export #t))
 */
var sci_truncate = sc_truncate;

/*** META ((export #t))
 */
var sci_round = sc_round;

/*** META ((export #t))
 */
var sci_exp = sc_exp;

/*** META ((export #t))
 */
var sci_log = sc_log;

/*** META ((export #t))
 */
var sci_sin = sc_sin;

/*** META ((export #t))
 */
var sci_cos = sc_cos;

/*** META ((export #t))
 */
var sci_tan = sc_tan;

/*** META ((export #t))
 */
var sci_asin = sc_asin;

/*** META ((export #t))
 */
var sci_acos = sc_acos;

/*** META ((export #t))
 */
var sci_atan = sc_atan;

/*** META ((export #t))
 */
var sci_sqrt = sc_sqrt;

/*** META ((export #t))
 */
var sci_expt = sc_expt;

/*** META ((export #t) (peephole (id)))
 */
var sci_exact2inexact = sc_exact2inexact;

/*** META ((export #t) (peephole (postfix "<< 0")))
 */
var sci_inexact2exact = sc_inexact2exact;

/*** META ((export #t) (type bool) (peephole (not)))
 */
var sci_not = sc_not;

/*** META ((export #t) (type bool))
 */
var sci_isBoolean = sc_isBoolean;

/*** META ((export #t)
 (type bool)
 (peephole (postfix " instanceof sc_Pair")))
 */
var sci_isPair = sc_isPair;

/*** META ((export #t)
 (peephole
   (hole 2 "new sc_Pair(" car ", " cdr ")")))
 */
var sci_cons = sc_cons;

/*** META ((export cons*))
 */
var sci_consStar = sc_consStar;

/*** META ((export #t) (peephole (postfix ".car")))
 */
var sci_car = sc_car;

/*** META ((export #t) (peephole (postfix ".cdr")))
 */
var sci_cdr = sc_cdr;

/*** META ((export #t) (peephole (hole 2 p ".car = " val)))
 */
var sci_setCarBang = sc_setCarBang;

/*** META ((export #t) (peephole (hole 2 p ".cdr = " val)))
 */
var sci_setCdrBang = sc_setCdrBang;

/*** META ((export #t) (peephole (postfix ".car.car")))
 */
var sci_caar = sc_caar;

/*** META ((export #t) (peephole (postfix ".cdr.car")))
 */
var sci_cadr = sc_cadr;

/*** META ((export #t) (peephole (postfix ".car.cdr")))
 */
var sci_cdar = sc_cdar;

/*** META ((export #t) (peephole (postfix ".cdr.cdr")))
 */
var sci_cddr = sc_cddr;

/*** META ((export #t) (peephole (postfix ".car.car.car")))
 */
var sci_caaar = sc_caaar;

/*** META ((export #t) (peephole (postfix ".car.cdr.car")))
 */
var sci_cadar = sc_cadar;

/*** META ((export #t) (peephole (postfix ".cdr.car.car")))
 */
var sci_caadr = sc_caadr;

/*** META ((export #t) (peephole (postfix ".cdr.cdr.car")))
 */
var sci_caddr = sc_caddr;

/*** META ((export #t) (peephole (postfix ".car.car.cdr")))
 */
var sci_cdaar = sc_cdaar;

/*** META ((export #t) (peephole (postfix ".cdr.car.cdr")))
 */
var sci_cdadr = sc_cdadr;

/*** META ((export #t) (peephole (postfix ".car.cdr.cdr")))
 */
var sci_cddar = sc_cddar;

/*** META ((export #t) (peephole (postfix ".cdr.cdr.cdr")))
 */
var sci_cdddr = sc_cdddr;

/*** META ((export #t)
 (peephole (postfix ".car.car.car.car")))
 */
var sci_caaaar = sc_caaaar;

/*** META ((export #t)
 (peephole (postfix ".car.cdr.car.car")))
 */
var sci_caadar = sc_caadar;

/*** META ((export #t)
 (peephole (postfix ".cdr.car.car.car")))
 */
var sci_caaadr = sc_caaadr;

/*** META ((export #t)
 (peephole (postfix ".cdr.cdr.car.car")))
 */
var sci_caaddr = sc_caaddr;

/*** META ((export #t)
 (peephole (postfix ".car.car.car.cdr")))
 */
var sci_cdaaar = sc_cdaaar;

/*** META ((export #t)
 (peephole (postfix ".car.cdr.car.cdr")))
 */
var sci_cdadar = sc_cdadar;

/*** META ((export #t)
 (peephole (postfix ".cdr.car.car.cdr")))
 */
var sci_cdaadr = sc_cdaadr;

/*** META ((export #t)
 (peephole (postfix ".cdr.cdr.car.cdr")))
 */
var sci_cdaddr = sc_cdaddr;

/*** META ((export #t)
 (peephole (postfix ".car.car.cdr.car")))
 */
var sci_cadaar = sc_cadaar;

/*** META ((export #t)
 (peephole (postfix ".car.cdr.cdr.car")))
 */
var sci_caddar = sc_caddar;

/*** META ((export #t)
 (peephole (postfix ".cdr.car.cdr.car")))
 */
var sci_cadadr = sc_cadadr;

/*** META ((export #t)
 (peephole (postfix ".cdr.cdr.cdr.car")))
 */
var sci_cadddr = sc_cadddr;

/*** META ((export #t)
 (peephole (postfix ".car.car.cdr.cdr")))
 */
var sci_cddaar = sc_cddaar;

/*** META ((export #t)
 (peephole (postfix ".car.cdr.cdr.cdr")))
 */
var sci_cdddar = sc_cdddar;

/*** META ((export #t)
 (peephole (postfix ".cdr.car.cdr.cdr")))
 */
var sci_cddadr = sc_cddadr;

/*** META ((export #t)
 (peephole (postfix ".cdr.cdr.cdr.cdr")))
 */
var sci_cddddr = sc_cddddr;

/*** META ((export #t))
 */
var sci_lastPair = sc_lastPair;

/*** META ((export #t)
 (type bool)
 (peephole (postfix " === null")))
 */
var sci_isNull = sc_isNull;

/*** META ((export #t) (type bool))
 */
var sci_isList = sc_isList;

/*** META ((export #t))
 */
var sci_list = sc_list;

/*** META ((export #t))
 */
var sci_iota = sc_iota;

/*** META ((export #t))
 */
var sci_makeList = sc_makeList;

/*** META ((export #t))
 */
var sci_length = sc_length;

/*** META ((export #t))
 */
var sci_remq = sc_remq;

/*** META ((export #t))
 */
var sci_remqBang = sc_remqBang;

/*** META ((export #t))
 */
var sci_delete = sc_delete;

/*** META ((export #t))
 */
var sci_deleteBang = sc_deleteBang;

/*** META ((export #t))
 */
var sci_append = sc_append;

/*** META ((export #t))
 */
var sci_appendBang = sc_appendBang;

/*** META ((export #t))
 */
var sci_reverse = sc_reverse;

/*** META ((export #t))
 */
var sci_reverseBang = sc_reverseBang;

/*** META ((export #t))
 */
var sci_listTail = sc_listTail;

/*** META ((export #t))
 */
var sci_listRef = sc_listRef;

/*** META ((export #t))
 */
var sci_memq = sc_memq;

/*** META ((export #t))
 */
var sci_memv = sc_memv;

/*** META ((export #t))
 */
var sci_member = sc_member;

/*** META ((export #t))
 */
var sci_assq = sc_assq;

/*** META ((export #t))
 */
var sci_assv = sc_assv;

/*** META ((export #t))
 */
var sci_assoc = sc_assoc;

/*** META ((export #t)
 (type bool)
 (peephole (postfix "instanceof sc_Char")))
 */
var sci_isChar = sc_isChar;

/*** META ((export char=?)
 (type bool)
 (peephole (hole 2 c1 ".val === " c2 ".val")))
 */
var sci_isCharEqual = sc_isCharEqual;

/*** META ((export char<?)
 (type bool)
 (peephole (hole 2 c1 ".val < " c2 ".val")))
 */
var sci_isCharLess = sc_isCharLess;

/*** META ((export char>?)
 (type bool)
 (peephole (hole 2 c1 ".val > " c2 ".val")))
 */
var sci_isCharGreater = sc_isCharGreater;

/*** META ((export char<=?)
 (type bool)
 (peephole (hole 2 c1 ".val <= " c2 ".val")))
 */
var sci_isCharLessEqual = sc_isCharLessEqual;

/*** META ((export char>=?)
 (type bool)
 (peephole (hole 2 c1 ".val >= " c2 ".val")))
 */
var sci_isCharGreaterEqual = sc_isCharGreaterEqual;

/*** META ((export char-ci=?)
 (type bool)
 (peephole
   (hole 2
         c1
         ".val.toLowerCase() === "
         c2
         ".val.toLowerCase()")))
 */
var sci_isCharCIEqual = sc_isCharCIEqual;

/*** META ((export char-ci<?)
 (type bool)
 (peephole
   (hole 2
         c1
         ".val.toLowerCase() < "
         c2
         ".val.toLowerCase()")))
 */
var sci_isCharCILess = sc_isCharCILess;

/*** META ((export char-ci>?)
 (type bool)
 (peephole
   (hole 2
         c1
         ".val.toLowerCase() > "
         c2
         ".val.toLowerCase()")))
 */
var sci_isCharCIGreater = sc_isCharCIGreater;

/*** META ((export char-ci<=?)
 (type bool)
 (peephole
   (hole 2
         c1
         ".val.toLowerCase() <= "
         c2
         ".val.toLowerCase()")))
 */
var sci_isCharCILessEqual = sc_isCharCILessEqual;

/*** META ((export char-ci>=?)
 (type bool)
 (peephole
   (hole 2
         c1
         ".val.toLowerCase() >= "
         c2
         ".val.toLowerCase()")))
 */
var sci_isCharCIGreaterEqual = sc_isCharCIGreaterEqual;

/*** META ((export #t) (type bool))
 */
var sci_isCharAlphabetic = sc_isCharAlphabetic;

/*** META ((export #t)
 (type bool)
 (peephole
   (hole 1
         "SC_NUMBER_CLASS.indexOf("
         c
         ".val) != -1")))
 */
var sci_isCharNumeric = sc_isCharNumeric;

/*** META ((export #t) (type bool))
 */
var sci_isCharWhitespace = sc_isCharWhitespace;

/*** META ((export #t)
 (type bool)
 (peephole
   (hole 1
         "SC_UPPER_CLASS.indexOf("
         c
         ".val) != -1")))
 */
var sci_isCharUpperCase = sc_isCharUpperCase;

/*** META ((export #t)
 (type bool)
 (peephole
   (hole 1
         "SC_LOWER_CLASS.indexOf("
         c
         ".val) != -1")))
 */
var sci_isCharLowerCase = sc_isCharLowerCase;

/*** META ((export #t)
 (peephole (postfix ".val.charCodeAt(0)")))
 */
var sci_char2integer = sc_char2integer;

/*** META ((export #t)
 (peephole
   (hole 1
         "new sc_Char(String.fromCharCode("
         n
         "))")))
 */
var sci_integer2char = sc_integer2char;

/*** META ((export #t)
 (peephole
   (hole 1 "new sc_Char(" c ".val.toUpperCase())")))
 */
var sci_charUpcase = sc_charUpcase;

/*** META ((export #t)
 (peephole
   (hole 1 "new sc_Char(" c ".val.toLowerCase())")))
 */
var sci_charDowncase = sc_charDowncase;

/*** META ((export vector? array?)
 (type bool)
 (peephole (postfix " instanceof sc_Vector")))
 */
var sci_isVector = sc_isVector;

/*** META ((export make-vector make-array))
 */
var sci_makeVector = sc_makeVector;

/*** META ((export vector array) (peephole (vector)))
 */
var sci_vector = sc_vector;

/*** META ((export vector-length array-length)
 (peephole (postfix ".length")))
 */
var sci_vectorLength = sc_vectorLength;

/*** META ((export vector-ref array-ref)
 (peephole (hole 2 v "[" pos "]")))
 */
var sci_vectorRef = sc_vectorRef;

/*** META ((export vector-set! array-set!)
 (peephole (hole 3 v "[" pos "] = " val)))
 */
var sci_vectorSetBang = sc_vectorSetBang;

/*** META ((export vector->list array->list))
 */
var sci_vector2list = sc_vector2list;

/*** META ((export list->vector list->array))
 */
var sci_list2vector = sc_list2vector;

/*** META ((export vector-fill! array-fill!))
 */
var sci_vectorFillBang = sc_vectorFillBang;

/*** META ((export #t))
 */
var sci_copyVector = sc_copyVector;

/*** META ((export #t)
 (peephole (hole 3 a ".slice(" start "," end ")")))
 */
var sci_vectorCopy = sc_vectorCopy;

/*** META ((export #t))
 */
var sci_vectorCopyBang = sc_vectorCopyBang;

/*** META ((export #t)
 (type bool)
 (peephole (hole 1 "typeof " o " === 'function'")))
 */
var sci_isProcedure = sc_isProcedure;

/*** META ((export #t))
 */
var sci_apply = sc_apply;

/*** META ((export #t))
 */
var sci_map = sc_map;

/*** META ((export #t))
 */
var sci_mapBang = sc_mapBang;

/*** META ((export #t))
 */
var sci_forEach = sc_forEach;

/*** META ((export #t))
 */
var sci_filter = sc_filter;

/*** META ((export #t))
 */
var sci_filterBang = sc_filterBang;

/*** META ((export #t))
 */
var sci_filterMap = sc_filterMap;

/*** META ((export #t))
 */
var sci_any = sc_any;

/*** META ((export any?)
 (peephole
   (hole 2 "sc_any(" proc "," l ") !== false")))
 */
var sci_anyPred = sc_anyPred;

/*** META ((export #t))
 */
var sci_every = sc_every;

/*** META ((export every?)
 (peephole
   (hole 2 "sc_every(" proc "," l ") !== false")))
 */
var sci_everyPred = sc_everyPred;

/*** META ((export #t) (peephole (postfix "()")))
 */
var sci_force = sc_force;

/*** META ((export #t))
 */
var sci_makePromise = sc_makePromise;

/*** META ((export #t) (peephole (values)))
 */
var sci_values = sc_values;

/*** META ((export #t))
 */
var sci_callWithValues = sc_callWithValues;

/*** META ((export #t))
 */
var sci_dynamicWind = sc_dynamicWind;

/*** META ((export #t)
 (peephole (hole 1 "new sc_Struct(" name ")")))
 */
var sci_makeStruct = sc_makeStruct;

/*** META ((export #t)
 (type bool)
 (peephole (postfix " instanceof sc_Struct")))
 */
var sci_isStruct = sc_isStruct;

/*** META ((export #t)
 (type bool)
 (peephole
   (hole 2
         "("
         1
         " instanceof sc_Struct) && ( "
         1
         ".name === "
         0
         ")")))
 */
var sci_isStructNamed = sc_isStructNamed;

/*** META ((export struct-field)
 (peephole (hole 3 0 "[" 2 "]")))
 */
var sci_getStructField = sc_getStructField;

/*** META ((export struct-field-set!)
 (peephole (hole 4 0 "[" 2 "] = " 3)))
 */
var sci_setStructFieldBang = sc_setStructFieldBang;

/*** META ((export #t) (peephole (prefix "~")))
 */
var sci_bitNot = sc_bitNot;

/*** META ((export #t) (peephole (infix 2 2 "&")))
 */
var sci_bitAnd = sc_bitAnd;

/*** META ((export #t) (peephole (infix 2 2 "|")))
 */
var sci_bitOr = sc_bitOr;

/*** META ((export #t) (peephole (infix 2 2 "^")))
 */
var sci_bitXor = sc_bitXor;

/*** META ((export #t) (peephole (infix 2 2 "<<")))
 */
var sci_bitLsh = sc_bitLsh;

/*** META ((export #t) (peephole (infix 2 2 ">>")))
 */
var sci_bitRsh = sc_bitRsh;

/*** META ((export #t) (peephole (infix 2 2 ">>>")))
 */
var sci_bitUrsh = sc_bitUrsh;

/*** META ((export js-field js-property)
 (peephole (hole 2 o "[" field "]")))
 */
var sci_jsField = sc_jsField;

/*** META ((export js-field-set! js-property-set!)
 (peephole (hole 3 o "[" field "] = " val)))
 */
var sci_setJsFieldBang = sc_setJsFieldBang;

/*** META ((export js-field-delete! js-property-delete!)
 (peephole (hole 2 "delete" o "[" field "]")))
 */
var sci_deleteJsFieldBang = sc_deleteJsFieldBang;

/*** META ((export #t) (peephole (jsCall)))
 */
var sci_jsCall = sc_jsCall;

/*** META ((export #t) (peephole (jsMethodCall)))
 */
var sci_jsMethodCall = sc_jsMethodCall;

/*** META ((export new js-new) (peephole (jsNew)))
 */
var sci_jsNew = sc_jsNew;

/*** META ((export #t))
 */
var sci_pregexp = sc_pregexp;

/*** META ((export #t))
 */
var sci_pregexpMatch = sc_pregexpMatch;

/*** META ((export #t))
 */
var sci_pregexpReplace = sc_pregexpReplace;

/*** META ((export pregexp-replace*))
 */
var sci_pregexpReplaceAll = sc_pregexpReplaceAll;

/*** META ((export #t))
 */
var sci_pregexpSplit = sc_pregexpSplit;

/*** META ((export #t)
 (peephole
   (hole 1 "Math.floor(Math.random()*" 'n ")")))
 */
var sci_random = sc_random;

/*** META ((export current-date)
 (peephole (hole 0 "new Date()")))
 */
var sci_currentDate = sc_currentDate;

/*** META ((export #t)
 (peephole (hole 0 "new sc_Hashtable()")))
 */
var sci_makeHashtable = sc_makeHashtable;

/*** META ((export #t))
 */
var sci_hashtablePutBang = sc_hashtablePutBang;

/*** META ((export #t))
 */
var sci_hashtableGet = sc_hashtableGet;

/*** META ((export #t))
 */
var sci_hashtableForEach = sc_hashtableForEach;

/*** META ((export hashtable-contains?)
 (peephole (hole 2 "sc_hash(" 1 ") in " 0)))
 */
var sci_hashtableContains = sc_hashtableContains;

/*** META ((export bind-exit-lambda))
 */
var sci_bindExitLambda = sc_bindExitLambda;

/*** META ((export #t))
 */
var sci_read = sc_read;

/*** META ((export #t))
 */
var sci_readChar = sc_readChar;

/*** META ((export #t))
 */
var sci_peekChar = sc_peekChar;

/*** META ((export #t) (type bool))
 */
var sci_isCharReady = sc_isCharReady;

/*** META ((export #t) (peephole (postfix ".close()")))
 */
var sci_closeInputPort = sc_closeInputPort;

/*** META ((export #t)
 (type bool)
 (peephole (postfix " instanceof sc_InputPort")))
 */
var sci_isInputPort = sc_isInputPort;

/*** META ((export eof-object?)
 (type bool)
 (peephole (postfix " === SC_EOF_OBJECT")))
 */
var sci_isEOFObject = sc_isEOFObject;

/*** META ((export #t) (peephole (hole 0 "SC_DEFAULT_IN")))
 */
var sci_currentInputPort = sc_currentInputPort;

/*** META ((export #t))
 */
var sci_callWithInputFile = sc_callWithInputFile;

/*** META ((export #t))
 */
var sci_callWithOutputFile = sc_callWithOutputFile;

/*** META ((export #t))
 */
var sci_withInputFromFile = sc_withInputFromFile;

/*** META ((export #t))
 */
var sci_withOutputToFile = sc_withOutputToFile;

/*** META ((export #t))
 */
var sci_openInputFile = sc_openInputFile;

/*** META ((export #t))
 */
var sci_openOutputFile = sc_openOutputFile;

/*** META ((export #t))
 */
var sci_basename = sc_basename;

/*** META ((export #t))
 */
var sci_dirname = sc_dirname;

/*** META ((export #t))
 */
var sci_withInputFromPort = sc_withInputFromPort;

/*** META ((export #t))
 */
var sci_withInputFromString = sc_withInputFromString;

/*** META ((export #t))
 */
var sci_withOutputToPort = sc_withOutputToPort;

/*** META ((export #t))
 */
var sci_withOutputToString = sc_withOutputToString;

/*** META ((export #t))
 */
var sci_withOutputToProcedure = sc_withOutputToProcedure;

/*** META ((export #t)
 (peephole (hole 0 "new sc_StringOutputPort()")))
 */
var sci_openOutputString = sc_openOutputString;

/*** META ((export #t))
 */
var sci_openInputString = sc_openInputString;

/*** META ((export #t))
 */
var sci_getOutputString = sc_getOutputString;

/*** META ((export #t)
 (type bool)
 (peephole (postfix " instanceof sc_OutputPort")))
 */
var sci_isOutputPort = sc_isOutputPort;

/*** META ((export #t) (peephole (postfix ".close()")))
 */
var sci_closeOutputPort = sc_closeOutputPort;

/*** META ((export #t))
 */
var sci_write = sc_write;

/*** META ((export #t))
 */
var sci_display = sc_display;

/*** META ((export #t))
 */
var sci_newline = sc_newline;

/*** META ((export #t))
 */
var sci_writeChar = sc_writeChar;

/*** META ((export #t))
 */
var sci_writeCircle = sc_writeCircle;

/*** META ((export #t))
 */
var sci_displayCircle = sc_displayCircle;

/*** META ((export #t))
 */
var sci_print = sc_print;

/*** META ((export #t))
 */
var sci_format = sc_format;

/*** META ((export #t) (peephole (id)))
 */
var sci_jsstring2string = sc_jsstring2string;

/*** META ((export #t) (peephole (prefix "'\\uEBAC' +")))
 */
var sci_jsstring2symbol = sc_jsstring2symbol;

/*** META ((export #t) (peephole (id)))
 */
var sci_string2jsstring = sc_string2jsstring;

/*** META ((export #t)
 (peephole (symbol2jsstring_immutable)))
 */
var sci_symbol2jsstring = sc_symbol2jsstring;

/*** META ((export #t) (peephole (postfix ".slice(1)")))
 */
var sci_keyword2jsstring = sc_keyword2jsstring;

/*** META ((export #t) (peephole (prefix "'\\uEBAD' +")))
 */
var sci_jsstring2keyword = sc_jsstring2keyword;

/*** META ((export #t) (type bool))
 */
var sci_isKeyword = sc_isKeyword;

/*** META ((export #t))
 */
var sci_gensym = sc_gensym;

/*** META ((export #t) (type bool))
 */
var sci_isEqual = sc_isEqual;

/*** META ((export number->symbol integer->symbol))
 */
var sci_number2symbol = sc_number2symbol;

/*** META ((export number->string integer->string))
 */
var sci_number2string = sc_number2string;

/*** META ((export #t))
 */
var sci_symbol2number = sc_symbol2number;

/*** META ((export #t))
 */
var sci_string2number = sc_string2number;

/*** META ((export #t) (peephole (prefix "+" s)))
 */
var sci_string2integer = sc_string2integer;

/*** META ((export #t) (peephole (prefix "+")))
 */
var sci_string2real = sc_string2real;

/*** META ((export #t) (type bool))
 */
var sci_isSymbol = sc_isSymbol;

/*** META ((export #t)
 (peephole (symbol2string_immutable)))
 */
var sci_symbol2string = sc_symbol2string;

/*** META ((export #t) (peephole (prefix "'\\uEBAC' +")))
 */
var sci_string2symbol = sc_string2symbol;

/*** META ((export symbol-append)
 (peephole (symbolAppend_immutable)))
 */
var sci_symbolAppend = sc_symbolAppend;

/*** META ((export #t) (peephole (postfix ".val")))
 */
var sci_char2string = sc_char2string;

/*** META ((export #t)
 (peephole (hole 1 "'\\uEBAC' + " c ".val")))
 */
var sci_char2symbol = sc_char2symbol;

/*** META ((export #t) (type bool))
 */
var sci_isString = sc_isString;

/*** META ((export #t))
 */
var sci_makeString = sc_makeString;

/*** META ((export #t))
 */
var sci_string = sc_string;

/*** META ((export #t) (peephole (postfix ".length")))
 */
var sci_stringLength = sc_stringLength;

/*** META ((export #t))
 */
var sci_stringRef = sc_stringRef;

/*** META ((export string=?)
 (type bool)
 (peephole (hole 2 str1 " === " str2)))
 */
var sci_isStringEqual = sc_isStringEqual;

/*** META ((export string<?)
 (type bool)
 (peephole (hole 2 str1 " < " str2)))
 */
var sci_isStringLess = sc_isStringLess;

/*** META ((export string>?)
 (type bool)
 (peephole (hole 2 str1 " > " str2)))
 */
var sci_isStringGreater = sc_isStringGreater;

/*** META ((export string<=?)
 (type bool)
 (peephole (hole 2 str1 " <= " str2)))
 */
var sci_isStringLessEqual = sc_isStringLessEqual;

/*** META ((export string>=?)
 (type bool)
 (peephole (hole 2 str1 " >= " str2)))
 */
var sci_isStringGreaterEqual = sc_isStringGreaterEqual;

/*** META ((export string-ci=?)
 (type bool)
 (peephole
   (hole 2
         str1
         ".toLowerCase() === "
         str2
         ".toLowerCase()")))
 */
var sci_isStringCIEqual = sc_isStringCIEqual;

/*** META ((export string-ci<?)
 (type bool)
 (peephole
   (hole 2
         str1
         ".toLowerCase() < "
         str2
         ".toLowerCase()")))
 */
var sci_isStringCILess = sc_isStringCILess;

/*** META ((export string-ci>?)
 (type bool)
 (peephole
   (hole 2
         str1
         ".toLowerCase() > "
         str2
         ".toLowerCase()")))
 */
var sci_isStringCIGreater = sc_isStringCIGreater;

/*** META ((export string-ci<=?)
 (type bool)
 (peephole
   (hole 2
         str1
         ".toLowerCase() <= "
         str2
         ".toLowerCase()")))
 */
var sci_isStringCILessEqual = sc_isStringCILessEqual;

/*** META ((export string-ci>=?)
 (type bool)
 (peephole
   (hole 2
         str1
         ".toLowerCase() >= "
         str2
         ".toLowerCase()")))
 */
var sci_isStringCIGreaterEqual = sc_isStringCIGreaterEqual;

/*** META ((export #t)
 (peephole
   (hole 3 s ".substring(" start ", " end ")")))
 */
var sci_substring = sc_substring;

/*** META ((export #t))
 */
var sci_isSubstring_at = sc_isSubstring_at;

/*** META ((export #t) (peephole (infix 0 #f "+" "''")))
 */
var sci_stringAppend = sc_stringAppend;

/*** META ((export #t))
 */
var sci_string2list = sc_string2list;

/*** META ((export #t))
 */
var sci_list2string = sc_list2string;

/*** META ((export #t) (peephole (id)))
 */
var sci_stringCopy = sc_stringCopy;

/*** META ((export #t) (peephole (postfix ".slice(1)")))
 */
var sci_keyword2string = sc_keyword2string;

/*** META ((export #t) (peephole (prefix "'\\uEBAD' +")))
 */
var sci_string2keyword = sc_string2keyword;

/*** META ((export #t)
 (peephole (hole 2 1 ".indexOf(" 0 ") === 0")))
 */
var sci_isStringPrefix = sc_isStringPrefix;

/*** META ((export #t))
 */
var sci_isStringSuffix = sc_isStringSuffix;

/*** META ((export #t))
 */
var sci_stringSplit = sc_stringSplit;

