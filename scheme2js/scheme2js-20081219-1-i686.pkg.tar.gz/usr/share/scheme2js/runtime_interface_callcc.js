/*** META ((export with-handler-lambda)
 (call/cc? #t)
 (call/cc-params (0 1)))
 */
var sci_withHandlerLambda_callcc = sc_withHandlerLambda_callcc;

/*** META ((export apply)
 (call/cc? #t)
 (call/cc-params (0)))
 */
var sci_apply_callcc = sc_apply_callcc;

/*** META ((export map) (call/cc? #t) (call/cc-params (0)))
 */
var sci_map_callcc = sc_map_callcc;

/*** META ((export map!)
 (call/cc? #t)
 (call/cc-params (0)))
 */
var sci_mapBang_callcc = sc_mapBang_callcc;

/*** META ((export for-each)
 (call/cc? #t)
 (call/cc-params (0)))
 */
var sci_forEach_callcc = sc_forEach_callcc;

/*** META ((export filter!)
 (call/cc? #t)
 (call/cc-params (0)))
 */
var sci_filterBang_callcc = sc_filterBang_callcc;

/*** META ((export filter)
 (call/cc? #t)
 (call/cc-params (0)))
 */
var sci_filter_callcc = sc_filter_callcc;

/*** META ((export filter-map)
 (call/cc? #t)
 (call/cc-params (0)))
 */
var sci_filterMap_callcc = sc_filterMap_callcc;

/*** META ((export any) (call/cc? #t) (call/cc-params (0)))
 */
var sci_any_callcc = sc_any_callcc;

/*** META ((export any?)
 (call/cc? #t)
 (call/cc-params (1)))
 */
var sci_anyPred_callcc = sc_anyPred_callcc;

/*** META ((export every)
 (call/cc? #t)
 (call/cc-params (0)))
 */
var sci_every_callcc = sc_every_callcc;

/*** META ((export every?)
 (call/cc? #t)
 (call/cc-params (1)))
 */
var sci_everyPred_callcc = sc_everyPred_callcc;

/*** META ((export force)
 (call/cc? #t)
 (peephole (postfix "()")))
 */
var sci_force_callcc = sc_force_callcc;

/*** META ((export call-with-values)
 (call/cc? #t)
 (call/cc-params (0 1)))
 */
var sci_callWithValues_callcc = sc_callWithValues_callcc;

/*** META ((export dynamic-wind)
 (call/cc? #t)
 (call/cc-params (0 1 2)))
 */
var sci_dynamicWind_callcc = sc_dynamicWind_callcc;

/*** META ((export #t)
 (call/cc? #t)
 (call/cc-params (1))
 (peephole (jsCall)))
 */
var sci_jsCall_callcc = sc_jsCall_callcc;

/*** META ((export js-method-call)
 (call/cc? #t)
 (peephole (jsMethodCall)))
 */
var sci_jsMethodCall_callcc = sc_jsMethodCall_callcc;

/*** META ((export with-input-from-port)
 (call/cc? #t)
 (call/cc-params (1)))
 */
var sci_withInputFromPort_callcc = sc_withInputFromPort_callcc;

/*** META ((export with-input-from-string)
 (call/cc? #t)
 (call/cc-params (1)))
 */
var sci_withInputFromString_callcc = sc_withInputFromString_callcc;

/*** META ((export with-output-to-port)
 (call/cc? #t)
 (call/cc-params (1)))
 */
var sci_withOutputToPort_callcc = sc_withOutputToPort_callcc;

/*** META ((export with-output-to-string)
 (call/cc? #t)
 (call/cc-params (0)))
 */
var sci_withOutputToString_callcc = sc_withOutputToString_callcc;

/*** META ((export with-output-to-procedure)
 (call/cc? #t)
 (call/cc-params (1)))
 */
var sci_withOutputToProcedure_callcc = sc_withOutputToProcedure_callcc;

/*** META ((export hashtable-for-each)
 (call/cc? #t)
 (call/cc-params (1)))
 */
var sci_hashtableForEach_callcc = sc_hashtableForEach_callcc;

/*** META ((export bind-exit-lambda)
 (call/cc? #t)
 (call/cc-params (0)))
 */
var sci_bindExitLambda_callcc = sc_bindExitLambda_callcc;

/*** META ((export suspend) (call/cc? #t))
 */
var sci_suspend = sc_suspend;

/*** META ((export call/cc call-with-current-continuation)
 (call/cc? #t))
 */
var sci_callcc = sc_callcc;

