#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <X11/extensions/XTest.h>
#include <string>

using namespace std;

void XIMovePointer(int xpos, int ypos, bool relative);
void XIClickMouse(int button, bool release);
// Possible mouse buttons:
//    Button1 : Left
//    Button2 : Middle
//    Button3 : Right
//    Button4 : scroll wheel up
//    Button5 : scroll wheel down

void XIUseKeyboard(int keycode, bool release);
// see /usr/include/X11/keysymdef.h for a full list of possible keycodes

KeyCode get_x_keycode_from_string(string keystr);


/*************************************************************************
Must do the following to obtain a display object for passing to functions.  
Put it in your main()
**************************************************************************

Display *display = XOpenDisplay(0);
	if(display == NULL)
		return;
*/
