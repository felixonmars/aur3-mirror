#include "xinterpret.h"
#include <iostream>
#include <vector>

using namespace std;

extern Display *display;

void XIMovePointer(int xpos, int ypos, bool relative)
{
Display *display = XOpenDisplay(0);

if (relative)
    XTestFakeRelativeMotionEvent(display, xpos, ypos, 0);
else
    XTestFakeMotionEvent(display, -1, xpos, ypos, 0);
    
XCloseDisplay(display);
return;
}

void XIUseKeyboard(int keycode, bool release)
{
Display *display = XOpenDisplay(0);
XTestFakeKeyEvent(display, keycode, !release, 0);
XCloseDisplay(display);
return;
}

void XIClickMouse(int button, bool release)
{
Display *display = XOpenDisplay(0);
XTestFakeButtonEvent(display, button, !release, 0);
XCloseDisplay(display);
return;
}


KeyCode get_x_keycode_from_string(string keystr)
{
KeySym sym = XStringToKeysym(keystr.c_str());
KeyCode code = XKeysymToKeycode(display, sym);
return code;
} 

