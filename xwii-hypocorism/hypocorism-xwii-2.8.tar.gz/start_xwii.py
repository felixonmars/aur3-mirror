#!/usr/bin/python

import os
import sys

os.chdir(sys.path[0])
configs = os.listdir("./profiles")

# remove hidden files from list
for item in configs:
    if item[len(item)-1] == "~":
        configs.remove(item)

# display list of config files in "profiles" subdir
index_num = 1
for item in configs:
   print "[" + str(index_num) + "] " + item
   index_num = index_num + 1
profile_index = raw_input("Which profile would you like to use (pick a number)? ")
profile_path = "\"profiles/" + configs[int(profile_index)-1] + "\""
print "./xwii " + profile_path
print "Press 1 + 2 to put the Wiimote in discoverable mode."
x = os.popen("./xwii " + profile_path)
print x.read()

