#!/bin/bash

#-----------------------------------------------------------------------
# INSTALL SCRIPT FOR DIVERGENCE IV - A NEW HOPE 
#-----------------------------------------------------------------------

ROOT_UID=0
if [ "$UID" -ne "$ROOT_UID" ]
then
zenity --info --text "The installation script requires root privledges."
gksudo "./copy.sh"
exit 0
fi

zenity --info --text "This will install Divergence IV - A New Hope for All Users"
tar -xvf A-New-Hope.tar.gz
chmod 777 -R -f A-New-Hope

zenity --question --text "Remove Old Themes? (Recommended)"

if [ "$?" -eq "0" ]
then
rm -R -f /usr/share/themes/A-New-Hope
rm -R -f /usr/share/themes/A-New-Hope-ROTJ
rm -R -f /usr/share/themes/A-New-Hope-TESB
rm -R -f ~/.themes/A-New-Hope
rm -R -f ~/.themes/A-New-Hope-ROTJ
rm -R -f ~/.themes/A-New-Hope-TESB
fi

mv -f A-New-Hope /usr/share/themes/
exit
