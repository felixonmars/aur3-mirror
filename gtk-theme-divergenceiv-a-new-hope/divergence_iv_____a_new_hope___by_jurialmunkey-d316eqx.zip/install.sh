#!/bin/bash

#-----------------------------------------------------------------------
# INSTALL SCRIPT FOR DIVERGENCE IV - A NEW HOPE 
#-----------------------------------------------------------------------

./copy.sh
cd /usr/share/themes/A-New-Hope/
./customise.py
