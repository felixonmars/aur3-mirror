/*
rfidtool - rfid command line tool and library.
Copyright (C) 2005  Wade Alcorn
wade@bindshell.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/


#include <stdio.h>

#include "rfid.h"

int main (int argc, char *argv[]) {

  if ( !((argc == 3) || (argc == 4)) )  {
    // display the usage
    usage(argv[0]);
  }

  rfid_setdevice(argv[1]);

  // print the tag contents
  if ((!strcmp(argv[2], "print")) && (argc == 3)) {
    rfid_print();

  // wipe the tag
  } else if ((!strcmp(argv[2], "wipe")) && (argc == 3)) {
    rfid_wipe();

  // save the tag contents to a file
  } else if ((!strcmp(argv[2], "save")) && (argc == 4)) {
    rfid_save(argv[3]);

  // load the contents of a file to the tag
  } else if ((!strcmp(argv[2], "load")) && (argc == 4)) {
    rfid_load(argv[3]);

  // print the rfid size
  } else if ((!strcmp(argv[2], "size")) && (argc == 3)) {
    printf("%d\n", rfid_size());

  // print the rfid id
  } else if ((!strcmp(argv[2], "id")) && (argc == 3)) {
    char id[RFID_ID_LEN];

    rfid_id(id, RFID_ID_LEN);

    printf("%s\n", id);

  // display the usage
  } else {
    usage(argv[0]);
  }

  return 0;
}

int usage (char * arg0) {
  printf("rfidtool version 0.1\n");
  printf("\n");
  printf("usage:   %s <tty> command [filename]\n", arg0);
  printf("example: %s /dev/tts/0 print\n");
  printf("commands:\n");
  printf("\tprint\n");
  printf("\twipe\n");
  printf("\tsave <filename>\n");
  printf("\tload <filename>\n");
  printf("\tsize\n");
  printf("\tid\n");
  printf("\n");

  exit(0);
}
