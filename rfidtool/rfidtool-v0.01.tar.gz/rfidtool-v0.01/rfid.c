/*
rfidtool - rfid command line tool and library.
Copyright (C) 2005  Wade Alcorn
wade@bindshell.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/


#include "rfid.h"

int rfid_raw_error(char *pStr) {
  // print error and exit

  assert(pStr);
  assert(*pStr);

  fprintf(stderr, "Error: %s\n", pStr);
  exit(-1);
}

int rfid_raw_init() {
  // init the rfid reader

  char buff[RFID_BUFF_LEN];

  if(rfid_raw_connect()) rfid_raw_error("Coundn't connect to Reader");
  rfid_raw_reset();

  memset(buff, 0x0, RFID_BUFF_LEN);
  rfid_raw_writecmd(RFID_CMD_SELECT, buff, RFID_BUFF_LEN);
  rfid_raw_readline(buff, RFID_BUFF_LEN);

  return 0;
}

int rfid_raw_int2hex(unsigned value, char *pStr) {
  // convert the int to a hex string

  assert(pStr);

  memset(pStr, 0x0, RFID_HEX_LEN);
  if( value<16 ) snprintf(pStr, RFID_HEX_LEN, "0%x", value);
  else snprintf(pStr, RFID_HEX_LEN, "%x", value);

  return 0;
}

int rfid_raw_char2int(char c) {
  // convert a hex char to int

  if( (c >= '0') && (c <= '9') ) return (c - '0');
  if( (c >= 'A') && (c <= 'F') ) return (c - 'A' + 10);

  return -1;
}

char rfid_raw_str2int(char *pStr, unsigned pos) {
  // convert the 2 chars at pos & pos+1 to an int

  assert(pStr);
  assert(*pStr);

  return rfid_raw_char2int(pStr[pos])*16 + \
           rfid_raw_char2int(pStr[pos+1]);
}

int rfid_raw_setport() {
  // set reader port

  rfidio.c_cflag     = BAUDRATE | CRTSCTS | DATABITS | STOPBITS | \
                         PARITYON | PARITY | CLOCAL | CREAD;
  rfidio.c_iflag     = IGNPAR;
  rfidio.c_oflag     = 0;
  rfidio.c_lflag     = 0;
  rfidio.c_cc[VMIN]  = 1;
  rfidio.c_cc[VTIME] = 0;

  return 0;
}

int rfid_raw_connect() {
  // connect to reader

  // open the device
  fd = open(devicename, O_RDWR | O_NOCTTY | O_NONBLOCK);
  if( fd<0 ) return -1;

  // set reader port
  rfid_raw_setport();

  // set rfid reader attributes
  tcflush(fd, TCIFLUSH);
  tcsetattr(fd, TCSANOW, &rfidio);

  return 0;
}

int rfid_raw_isterminated(char *pStr, unsigned pos) {
  // check if terminator exists

  assert(pStr);
  assert(*pStr);

  return ((pos > 1) && \
           ((int)pStr[pos-1] == RFID_TERMINATOR_CHAR_1) && \
           ((int)pStr[pos-2] == RFID_TERMINATOR_CHAR_2));
}

int rfid_raw_readline(char *pStr, unsigned len) {
  // read from rfid reader

  unsigned pos     = 0;
  unsigned attempt = 0;
  char byte        = 0x0;
  char buff[RFID_BUFF_LEN];

  assert(pStr);
  assert(len);

  memset(buff, 0x0, RFID_BUFF_LEN);

  // do the work
  for(attempt=0; attempt<RFID_RAWREAD_MAX; attempt++) {

    if( read(fd, &byte, 1) == 1 ) {
      buff[pos++] = byte;

      // check termination
      if( rfid_raw_isterminated(buff, pos) ) {
        // terminate string and crop terminator chars
        buff[pos-2] = '\0';
        break;
      }
    }
  }

  // check if read failed
  if( attempt>=RFID_RAWREAD_MAX ) rfid_raw_error("No rfid tag");

  // return result
  strncpy(pStr, buff, MIN(RFID_BUFF_LEN, len)-1);

  return 0;
}

int rfid_raw_pageread(unsigned pageNum, char *pPage, unsigned len) {
  // read page from rfid

  char rfidCmd[RFID_CMD_LEN];
  char pageNumStr[RFID_HEX_LEN];

  assert(pPage);
  assert(len);

  // convert page number to a string
  rfid_raw_int2hex(pageNum, pageNumStr);

  // build read command
  memset(rfidCmd, 0x0, RFID_CMD_LEN);
  strncat(rfidCmd, RFID_CMD_READ_PAGE, RFID_CMD_LEN-1);
  strncat(rfidCmd, pageNumStr, (RFID_CMD_LEN-strlen(rfidCmd))-1);

  // execute command
  memset(pPage, 0x0, len);
  rfid_raw_writecmd(rfidCmd, pPage, len);

  return 0;
}

int rfid_raw_pagewrite(unsigned pageNum, char *pPage) {
  // write page to rfid tag

  char rfidCmd[RFID_CMD_LEN];
  char buff[RFID_BUFF_LEN];
  char pageNumStr[RFID_HEX_LEN];

  assert(pPage);

  // convert page number to a string
  rfid_raw_int2hex(pageNum, pageNumStr);

  // build write command
  memset(rfidCmd, 0x0, RFID_CMD_LEN);
  strncat(rfidCmd, RFID_CMD_WRITE_PAGE, RFID_CMD_LEN-1);
  strncat(rfidCmd, pageNumStr, (RFID_CMD_LEN-strlen(rfidCmd))-1);
  strncat(rfidCmd, pPage, (RFID_CMD_LEN-strlen(rfidCmd))-1);

  // execute command
  memset(buff, 0x0, RFID_BUFF_LEN);
  rfid_raw_writecmd(rfidCmd, buff, RFID_BUFF_LEN);

  return 0;
}

int rfid_raw_reset() {
  // reset rfid

  char rfidCmd[RFID_CMD_LEN];
  char buff[RFID_BUFF_LEN];

  // build command
  memset(rfidCmd, 0x0, RFID_CMD_LEN);
  strncat(rfidCmd, RFID_CMD_RESET, RFID_CMD_LEN-1);

  // execute command
  memset(buff, 0x0, RFID_BUFF_LEN);
  rfid_raw_writecmd(rfidCmd, buff, RFID_BUFF_LEN);

  return 0;
}

int rfid_raw_writecmd(char *pCmd, char *pResp, unsigned respLen) {
  // write cmd to card reader

  char buff[RFID_BUFF_LEN];

  assert(pCmd);
  assert(*pCmd);
  assert(pResp);

  // write command and read response
  write(fd, pCmd, strlen(pCmd));
  memset(buff, 0x0, RFID_BUFF_LEN);
  rfid_raw_readline(buff, RFID_BUFF_LEN);

  // return result
  strncpy(pResp, buff, MIN(RFID_BUFF_LEN, respLen)-1);

  return 0;
}


int rfid_pageread(unsigned pageNum, char *pPage, unsigned len) {
  // read page from rfid tag

  unsigned attempt = 0;
  char readPage[RFID_PAGE_LEN];

  assert(pPage);
  assert(len);

  // read the page
  memset(readPage, 0x0, RFID_PAGE_LEN);
  rfid_raw_pageread(pageNum, readPage, RFID_PAGE_LEN);

  // if the read failed try again RFID_READ_RETRY times max
  while( !(strcmp(RFID_CMD_FAILED, readPage)) ) {
    memset(readPage, 0x0, RFID_PAGE_LEN);
    rfid_raw_pageread(pageNum, readPage, RFID_PAGE_LEN);
    if( attempt > RFID_READ_RETRY ) return -1;
    attempt++;
  }

  // return result
  strncpy(pPage, readPage, MIN(RFID_PAGE_LEN, len)-1);

  return 0;
}

int rfid_pagewrite(unsigned pageNum, char *pPage) {
  // write page to rfid tag

  unsigned pos = 0;
  char readPage[RFID_PAGE_LEN];
  char newPage[RFID_PAGE_LEN];

  assert(pPage);

  // pad newPage
  memset(newPage, 0x0, RFID_PAGE_LEN);
  strncpy(newPage, pPage, (RFID_PAGE_LEN-1));

  for(pos = strlen(newPage); pos < (RFID_PAGE_LEN-1); pos++) {
    newPage[pos] = '0';
  }

  // check if the page can be read
  memset(readPage, 0x0, RFID_PAGE_LEN);
  if( rfid_pageread(pageNum, readPage, RFID_PAGE_LEN) ) return -1;

  // write the page
  rfid_raw_pagewrite(pageNum, newPage);

  return 0;
}

int rfid_setdevice(char *pDev) {
  // set the rfid device

  assert(pDev);

  strncpy(devicename, pDev, (RFID_DEV_LEN-1));
}

int rfid_print() {
  // print the rfid tag

  unsigned byteNum = 0;
  unsigned pageNum = 0;
  char page[RFID_PAGE_LEN];

  rfid_raw_init();

  for(pageNum = 0; ; pageNum++) {
    // read the page
    memset(page, 0x0, RFID_PAGE_LEN);
    if( rfid_pageread(pageNum, page, RFID_PAGE_LEN) ) break;

    // print the result
    printf("%d -\t", pageNum);
    for(byteNum = 0; byteNum < RFID_PAGE_LEN; byteNum++) {
      printf("%c", page[byteNum]);
    }
    printf("\n");
  }

  return 0;
}

int rfid_wipe() {
  // wipe the rfid tag

  unsigned pageNum = 0;

  rfid_raw_init();

  // write RFID_WIPE_STR to every page
  for(pageNum=0; pageNum<RFID_PAGE_MAX; pageNum++) {
    if( rfid_pagewrite(pageNum, RFID_WIPE_STR) ) break;
  }

  return 0;
}

int rfid_save(char *pFilename) {
  // save the contents of the tag to a file

  char byte        = 0;
  unsigned byteNum = 0;
  unsigned pageNum = 0;
  char page[RFID_PAGE_LEN];
  FILE *hFile = NULL;

  assert(pFilename);
  assert(*pFilename);

  rfid_raw_init();

  hFile = fopen (pFilename, "wb");
  if (!hFile) {
    printf("Couldn't open file for writing\n");
    return -1;
  }

  // do the work
  for(pageNum = 0;; pageNum++) {
    // read the page
    memset(page, 0x0, RFID_PAGE_LEN);
    if( rfid_pageread(pageNum, page, RFID_PAGE_LEN) ) break;

    for (byteNum=0; byteNum<strlen(page)/2; byteNum++) {
      // convert to int
      byte = rfid_raw_str2int(page, byteNum*2);
      // write to file
      fputc(byte, hFile);
    }
  }

  fclose(hFile);

  return 0;
}

int rfid_load(char *pFilename) {
  // load file to rfid tag

  char byte        = 0;
  unsigned byteNum = 0;
  unsigned pageNum = 0;
  char page[RFID_PAGE_LEN];
  FILE *hFile = NULL;

  assert(pFilename);
  assert(*pFilename);

  memset(page, 0x0, RFID_PAGE_LEN);

  rfid_raw_init();

  hFile = fopen(pFilename, "rb");
  if(!hFile) {
    printf("Couldn't open file for reading\n");
    return -1;
  }

  // do the work
  while(EOF != (byte = fgetc(hFile))) {

    // build a string of hex ascii representations 
    sprintf(page+(2*byteNum), "%x", byte);
    byteNum++;

    // if we have 4 bytes then write them
    if( byteNum>=4 ) {
      if( rfid_pagewrite(pageNum, page) ) return 0;
      byteNum = 0;
      pageNum++;
    }
  }

  fclose(hFile);
}

int rfid_size() {
  // determine tag size in bytes

  unsigned pageCount = 0;
  char page[RFID_PAGE_LEN];

  rfid_raw_init();

  memset(page, 0x0, RFID_PAGE_LEN);
  // read and count every page 
  for( pageCount=0; pageCount<RFID_PAGE_MAX; pageCount++) {
    if( rfid_pageread(pageCount, page, RFID_PAGE_LEN) ) return (pageCount*4);
  }
}

int rfid_id(char *pId, unsigned len) {
  // get the tag id

  char tmpId[RFID_ID_LEN];

  assert(pId);

  if(rfid_raw_connect()) rfid_raw_error("Coundn't connect to Reader");
  rfid_raw_reset();

  // get the id
  memset(tmpId, 0x0, RFID_ID_LEN);
  rfid_raw_writecmd(RFID_CMD_SELECT, tmpId, RFID_ID_LEN);

  if( !(strcmp(RFID_CMD_NO_TAG, tmpId)) ) rfid_raw_error("No rfid tag");

  // return result
  strncpy(pId, tmpId, MIN(RFID_ID_LEN, len)-1);

  return 0;
}

