/*
rfidtool - rfid command line tool and library.
Copyright (C) 2005  Wade Alcorn
wade@bindshell.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/


#ifndef __RFID_H__
#define __RFID_H__

#include <assert.h>
#include <termios.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/signal.h>

#define FALSE 0
#define TRUE 1

#define MIN(a,b) (((a)<(b))?(a):(b))

// RFID Definitions
#define RFID_CMD_RESET      "x"
#define RFID_CMD_SELECT     "s"
#define RFID_CMD_READ_PAGE  "r"
#define RFID_CMD_WRITE_PAGE "w"
#define RFID_CMD_FAILED     "F"
#define RFID_CMD_NO_TAG     "S"

// RFID constants
#define RFID_READ_RETRY  32
#define RFID_ID_LEN      255
#define RFID_CMD_LEN     255
#define RFID_BUFF_LEN    255
#define RFID_PAGE_LEN    9
#define RFID_PAGE_MAX    100
#define RFID_HEX_LEN     3
#define RFID_WIPE_STR    "00000000"
#define RFID_DEV_LEN     30
#define RFID_RAWREAD_MAX 500000

// RFID terminators
#define RFID_TERMINATOR_CHAR_1 0x0A 
#define RFID_TERMINATOR_CHAR_2 0x0D 

// configuration information for ACG reader
#define BAUDRATE B9600
#define DATABITS CS8
#define STOPBITS 0
#define PARITYON 0
#define PARITY   0

int fd;
struct termios rfidio;
static char devicename[RFID_DEV_LEN];

int rfid_setdevice(char*);
int rfid_print();
int rfid_wipe(); 
int rfid_save(char*);
int rfid_load(char*);
int rfid_size();
int rfid_id(char*, unsigned);

#endif
