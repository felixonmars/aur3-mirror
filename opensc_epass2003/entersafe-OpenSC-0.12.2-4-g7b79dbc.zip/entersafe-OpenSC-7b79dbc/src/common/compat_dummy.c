/* Required so ld will not complain regarding empty lib */
void compat_dummy (void);
void compat_dummy (void) {
}
