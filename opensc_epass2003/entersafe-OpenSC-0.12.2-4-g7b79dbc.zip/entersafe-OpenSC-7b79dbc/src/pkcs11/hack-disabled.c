extern int hack_enabled;
int hack_enabled = 0;
