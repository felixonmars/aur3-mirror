// create pseudo measured data (2 Breit-Wigner distributions)
// ----------------------------------------------------------
// run with:
// root -l makeData.C+
//
// or if parameter modification is wanted:
// root -l
// .L makeData.C+
// makeData("<fileNameData.root>", resolution, nr events)
// ----------------------------------------------------------

#include <iostream>
#include "TRandom.h"
#include "TFile.h"
#include "TTree.h"
#include "TBranch.h"
#include "TH1.h"
using std::cout;
using std::endl;

void makeData(const char *fileName = "data.root", Double_t resolution = 0.5, UInt_t nEvents = 10000)
{
	gRandom->SetSeed(2236540);
	const Double_t minXt = 2., maxXt = 18.;
	const Int_t nBinT = 30;
	Double_t x_true = 0;
	Double_t x_m = 0;

	TFile *rootfile = new TFile(fileName, "recreate");
	TTree *tree = new TTree("tree","");
	TH1D *hTrue = new TH1D("hTrue", "with full acceptance", nBinT, minXt, maxXt);
	tree->Branch("x_true", &x_true, "x_true/D");
	tree->Branch("x_m", &x_m, "x_m/D");
	UInt_t peak = 0;
	// ========= left breit-wigner peak ============
	do {
		const Double_t xTrue = gRandom->BreitWigner(7.0, 2.0);
		const Double_t acceptance = 1. - (xTrue - 10.) * (xTrue - 10.) / 64.;
		hTrue->Fill(xTrue);
		if (gRandom->Rndm() > acceptance) {
			continue;
		} else {
			// simulate a measurement
			const Double_t xMeas = gRandom->Gaus(xTrue, resolution);
			x_m = xMeas;
			x_true = xTrue;
			tree->Fill();
		}
		// fill histogram of true distribution
		if(xTrue >= minXt && xTrue <= maxXt) {
			peak++;
		}
	} while(peak < nEvents/2);
	// ========= right breit-wigner peak ============
	do {
		const Double_t xTrue = gRandom->BreitWigner(13.0, 3.0);
		const Double_t acceptance = 1. - (xTrue - 10.) * (xTrue - 10.) / 64.;
		hTrue->Fill(xTrue);
		if (gRandom->Rndm() > acceptance) {
			continue;
		} else {
			// simulate a measurement
			const Double_t xMeas = gRandom->Gaus(xTrue, resolution);
			x_m = xMeas;
			x_true = xTrue;
			tree->Fill();
		}
		// fill histogram of true distribution
		if(xTrue >= minXt && xTrue <= maxXt) {
			peak++;
		}
	} while(peak < nEvents);
	hTrue->Write();
	tree->Write();
	rootfile->Close();
}
