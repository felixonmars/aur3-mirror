// create your training MC with a uniform distribution
// ----------------------------------------------------------
// run with:
// root -l makeResponse.C+
//
// or if parameter modification is wanted:
// root -l
// .L makeResponse.C+
// makeResponse("<fileNameResponse.root>", resolution, nr events)
// ----------------------------------------------------------

#include <iostream>
#include "TRandom.h"
#include "TFile.h"
#include "TTree.h"
#include "TBranch.h"
#include "TH1.h"
using std::cout;
using std::endl;

void makeResponse(const char *fileName = "response.root", Double_t resolution = 0.5, UInt_t nEvents = 1000000)
{
	gRandom->SetSeed(123654);
	const Double_t minXt = 2., maxXt = 18.; // minimum and maximum of the true distribution = sought-after variable
	Double_t x_true = 0;
	Double_t x_m = 0;


	TFile *rootfile = new TFile(fileName, "recreate"); // your output file
	TTree *tree = new TTree("tree","");
	TH1D *hTrue = new TH1D("hTrue", "with full acceptance", 100, 0, 0);
	tree->Branch("x_true", &x_true, "x_true/D"); // sought variable
	tree->Branch("x_m", &x_m, "x_m/D"); // measured observable

	for (UInt_t i = 0; i < nEvents; ++i) {
		const Double_t xTrue = gRandom->Uniform(minXt, maxXt);
		const Double_t acceptance = 1. - (xTrue - 10.) * (xTrue - 10.) / 64.;
		hTrue->Fill(xTrue);
		if (gRandom->Rndm() > acceptance) {
			continue;
		} else {
			// simulate a measurement
			const Double_t xMeas = gRandom->Gaus(xTrue, resolution);
			x_m = xMeas;
			x_true = xTrue;
			tree->Fill();
		}

	}
	hTrue->Write();
	tree->Write();
	rootfile->Close();
}
