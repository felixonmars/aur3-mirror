//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

#include<Frontend.h>
#include<trueeresult.h>
#include<trueecsvreader.h>



using namespace std;


int main(int argc, char* argv[]) {

    gROOT->SetStyle("Plain");
    gStyle->SetPalette(1);
    string parameterconfigpath;

    if(argc ==2){
        if((string) argv[1] == "--version"){
            cout <<"TRUEE version 3.0.4"<<endl;
            return 0;
        }
        parameterconfigpath = argv[1];

    }
    else
        parameterconfigpath = "./parameter.config";

    Frontend *real = new Frontend(parameterconfigpath);

    if(real->GetPathCheck() == 0)
        return 0;

    vector<TrueeResult* > Resultvector;

    vector<vector<TrueeResult *> > Pullmode_Resultvector;

    bool datamode =  (real->get_Input()->getTestmode() == false) && (real->get_Input()->GetPullmode()==false);

    if(real->get_Input()->getTestmode() == true || datamode == true)
        Resultvector = real->testmode();



    if(real->get_Input()->getTestmode() == true){
        Resultvector = real->result_suppression(Resultvector);
        real->plot_testmode(Resultvector);
    }

    if(real->get_Input()->GetPullmode() == true){
        cout << " ************* Pullmode is starting ************* "<<endl;
        Pullmode_Resultvector = real->pullmode();
        real->plot_pullmode(Pullmode_Resultvector);
    }

    if(!real->get_Input()->GetPullmode())
        real->plot_datamode(Resultvector);

    return 0;
}

