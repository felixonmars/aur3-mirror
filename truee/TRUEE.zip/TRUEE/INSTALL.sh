#/bin/bash
echo "Your root version is"
$ROOTSYS/bin/root-config --version
echo "recommended is 5.26"

echo "Your cmake version is"
cmake --version
echo "recommended is 2.8.6"

export TRUEE_BUILD=$PWD/build

echo "#### Going to build TrueeCore ####"
cd $TRUEE_BUILD
cmake ../
make
echo "#### Going to build truee.cxx"
cd $TRUEE_BUILD/../example/build/
make clean
cmake ../
make
cp bin/truee $TRUEE_BUILD/../bin/
