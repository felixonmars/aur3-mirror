//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

// BMDEQU (original)
// Solution of band matrix equation
// bandMatrix[nr_of_band][nr_of_row] = symmetric band matrix in "band matrix storage mode"
// Delta = function change in fit

#include "BandMatrix.h"
#include <iostream>
#include "TMath.h"
#include "math.h"

using namespace std;

BandMatrix::BandMatrix(){};
BandMatrix::~BandMatrix(){};

void BandMatrix::GetSolution(Double_t bandMatrix[][63], Int_t nrBand, Int_t nrRow, Double_t *solution, Double_t &Delta) {
// bandMatrix[][] is a symmetric nrRow x nrRow-Matrix (max. 63x63) with 2*nrBand-1 diagonal bands (which contain elements !=0)
	Double_t diagonalElement[257];
	Double_t ratio;
	Double_t sum;
	Int_t imax = 0;
	Int_t jmax = 0;
	Int_t N = 0;

	// copy diagonal elements
	for(Int_t n = 0; n < nrRow; ++n) {
		diagonalElement[n] = bandMatrix[0][n];
	}

	// factorization
	for(Int_t m = 0; m < nrRow; ++m) {
		if((bandMatrix[0][m]+diagonalElement[m]) <= diagonalElement[m]) {
			// singular case
			for(Int_t j = 0; j<nrBand; ++j) {
				bandMatrix[j][m] = 0.0;// every element in line m =0
			}
		}
		else {
			bandMatrix[0][m] = 1.0/bandMatrix[0][m];
			imax = TMath::Min(nrBand-1,nrRow-m-1);
			jmax = imax;
			for(Int_t i = 0; i < imax; ++i) {
                                if(fabs(bandMatrix[i+1][m]) < pow(10.,-18.)) bandMatrix[i+1][m] = 0.0;
				ratio = bandMatrix[i+1][m]*bandMatrix[0][m];
				for(Int_t j = 0; j < jmax; ++j) {
					bandMatrix[j][m+i+1] = bandMatrix[j][m+i+1]-bandMatrix[j+i+1][m]*ratio;
				}
				jmax = jmax-1;
				bandMatrix[i+1][m] = ratio;
			}
		}
	}

	// copy vector solution to auxiliary array
	for(Int_t p = 0; p < nrRow; ++p) {
		diagonalElement[p] = solution[p];
	}

	// solution by forward ...
	for(Int_t q = 0; q < nrRow; ++q) {
		for(Int_t r = 0; r < min(nrBand-1, nrRow-q-1); ++r) {
                        if(fabs(bandMatrix[r+1][q]) < pow(10.,-18.)) {
				bandMatrix[r+1][q] = 0.0;
			}
			solution[r+q+1] = solution[r+q+1]-bandMatrix[r+1][q]*solution[q];
		}
	}

	// ... and backward substitution
	for(Int_t nn = 0; nn < nrRow; ++nn) {
		N = nrRow-nn;
		solution[N-1] = solution[N-1]*bandMatrix[0][N-1];
		for(Int_t jj = 0; jj < min(nrBand-1, nrRow-N); ++jj) {
                        if(fabs(bandMatrix[jj+1][N-1]) < pow(10.,-18.)) bandMatrix[jj+1][N-1] = 0.0;
			solution[N-1] = solution[N-1]-bandMatrix[jj+1][N-1]*solution[jj+N];
		}
	}

	// expected change in chi square
	sum = 0.0;
	for(Int_t k = 0; k < nrRow; ++k) {
		sum = sum+diagonalElement[k]*solution[k];
	}
	Delta = sum;
}
