//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

#ifndef SearchFitPeaks_h
#define SearchFitPeaks_h

#include "Rtypes.h"

class SearchFitPeaks {

public:
	SearchFitPeaks();
	virtual ~SearchFitPeaks();

	void SearchPeaks(Double_t *Y, Int_t NrBins, Int_t &NrPeaks);
	void fitGauss(Double_t *hsit ,Int_t NrBins, Int_t PeakIndex);

	//--------------------- get peak parameters ---------------------
	Double_t GetPeakAbscissa(Int_t PeakIndex) { return PeakAbscissa[PeakIndex]; }//TODO delete some Gets and Sets
	Double_t GetPeakOrdinate(Int_t PeakIndex) { return PeakOrdinate[PeakIndex]; }
	Double_t GetPeakBackgr(Int_t PeakIndex) { return PeakBackgr[PeakIndex]; };
	Double_t GetPeakIntegral(Int_t PeakIndex) { return PeakIntegral[PeakIndex]; }
	Double_t GetPeakSigma(Int_t PeakIndex) { return PeakSigma[PeakIndex]; }
	Double_t GetPeakFWHM(Int_t PeakIndex) { return PeakFWHM[PeakIndex]; }
	Double_t GetLeftFWHMAbscissa(Int_t PeakIndex) { return LeftFWHMAbscissa[PeakIndex]; }
	Double_t GetLeftFWHMOrdinate(Int_t PeakIndex) { return LeftFWHMOrdinate[PeakIndex]; }
	Double_t GetRightFWHMAbscissa(Int_t PeakIndex) { return RightFWHMAbscissa[PeakIndex]; }
	Double_t GetRightFWHMOrdinate(Int_t PeakIndex) { return RightFWHMOrdinate[PeakIndex]; }
	Double_t GetLeftBackgrAbscissa(Int_t PeakIndex) { return LeftBackgrAbscissa[PeakIndex]; }
	Double_t GetLeftBackgrOrdinate(Int_t PeakIndex) { return LeftBackgrOrdinate[PeakIndex]; }
	Double_t GetRightBackgrAbscissa(Int_t PeakIndex) { return RightBackgrAbscissa[PeakIndex]; }
	Double_t GetRightBackgrOrdinate(Int_t PeakIndex) { return RightBackgrOrdinate[PeakIndex]; }
	Double_t GetLeftBackgrBin(Int_t PeakIndex) { return LeftBackgrBin[PeakIndex]; }
	Double_t GetRightBackgrBin(Int_t PeakIndex) { return RightBackgrBin[PeakIndex]; }

	//--------------------- set peak parameters ---------------------
	Double_t SetPeakAbscissa(Double_t PeakParameter, Int_t PeakIndex) {
		return PeakAbscissa[PeakIndex] = PeakParameter;
	}
	Double_t SetPeakOrdinate(Double_t PeakParameter, Int_t PeakIndex) {
		return PeakOrdinate[PeakIndex] = PeakParameter;
	}
	Double_t SetPeakBackgr(Double_t PeakParameter, Int_t PeakIndex) {
		return PeakBackgr[PeakIndex] = PeakParameter;
	};
	Double_t SetPeakIntegral(Double_t PeakParameter, Int_t PeakIndex) {
		return PeakIntegral[PeakIndex] = PeakParameter;
	}
	Double_t SetPeakSigma(Double_t PeakParameter, Int_t PeakIndex) {
		return PeakSigma[PeakIndex] = PeakParameter;
	}
	Double_t SetPeakFWHM(Double_t PeakParameter, Int_t PeakIndex) {
		return PeakFWHM[PeakIndex] = PeakParameter;
	}
	Double_t SetLeftFWHMAbscissa(Double_t PeakParameter, Int_t PeakIndex) {
		return LeftFWHMAbscissa[PeakIndex] = PeakParameter;
	}
	Double_t SetLeftFWHMOrdinate(Double_t PeakParameter, Int_t PeakIndex) {
		return LeftFWHMOrdinate[PeakIndex] = PeakParameter;
	}
	Double_t SetRightFWHMAbscissa(Double_t PeakParameter, Int_t PeakIndex) {
		return RightFWHMAbscissa[PeakIndex] = PeakParameter;
	}
	Double_t SetRightFWHMOrdinate(Double_t PeakParameter, Int_t PeakIndex) {
		return RightFWHMOrdinate[PeakIndex] = PeakParameter;
	}
	Double_t SetLeftBackgrAbscissa(Double_t PeakParameter, Int_t PeakIndex) {
		return LeftBackgrAbscissa[PeakIndex] = PeakParameter;
	}
	Double_t SetLeftBackgrOrdinate(Double_t PeakParameter, Int_t PeakIndex) {
		return LeftBackgrOrdinate[PeakIndex] = PeakParameter;
	}
	Double_t SetRightBackgrAbscissa(Double_t PeakParameter, Int_t PeakIndex) {
		return RightBackgrAbscissa[PeakIndex] = PeakParameter;
	}
	Double_t SetRightBackgrOrdinate(Double_t PeakParameter, Int_t PeakIndex) {
		return RightBackgrOrdinate[PeakIndex] = PeakParameter;
	}
	Double_t SetLeftBackgrBin(Double_t PeakParameter, Int_t PeakIndex) {
		return LeftBackgrBin[PeakIndex] = PeakParameter;
	}
	Double_t SetRightBackgrBin(Double_t PeakParameter, Int_t PeakIndex) {
		return RightBackgrBin[PeakIndex] = PeakParameter;
	}


private:

	//--------------------- peak parameters ---------------------
	Double_t PeakAbscissa[5];
	Double_t PeakOrdinate[5];
	Double_t PeakBackgr[5];
	Double_t PeakIntegral[5];
	Double_t PeakSigma[5];
	Double_t PeakFWHM[5];// full width at half maximum
	Double_t LeftFWHMAbscissa[5];
	Double_t LeftFWHMOrdinate[5];
	Double_t RightFWHMAbscissa[5];
	Double_t RightFWHMOrdinate[5];
	Double_t LeftBackgrAbscissa[5];
	Double_t LeftBackgrOrdinate[5];
	Double_t RightBackgrAbscissa[5];
	Double_t RightBackgrOrdinate[5];
	Double_t LeftBackgrBin[5];
	Double_t RightBackgrBin[5];


};


#endif //SearchFitPeaks_h
