//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

// here the data, MC and background is read from source files
// the event weight can be modified in the TreeA filling loops

#include "ReadIn.h"
#include "math.h"
#include "TH1.h"
#include "TLeaf.h"
#include "TLegend.h"
#include "TCanvas.h"
#include "Input.h"

using namespace std;

// ClassImp(ReadIn)

TRandom3 *RANDOM = new TRandom3(0);

ReadIn::ReadIn(){}

ReadIn::ReadIn(Double_t wantedXLowLimit, Double_t wantedXHighLimit, TString NameWantedX, TString *NameObsY, Int_t nrAllMeasuredVariables, Int_t nrMocaTypes, Input* In) {

    BackEventNr = 0;
    DataEventNr = 0;
    MocaEventNr = 0;
    nameWantedX = NameWantedX;
    NrAllMeasuredVariables = nrAllMeasuredVariables;
    for(Int_t i = 0; i < NrAllMeasuredVariables; ++i) {
        nameObsY[i] = NameObsY[i];
    }
    NrMocaTypes = nrMocaTypes;
    WantedXHighLimit = wantedXHighLimit;
    WantedXLowLimit = wantedXLowLimit;
    InputObject = In;
    printflag = In->getPrintflag();

    SplittedEvents = false;
}

ReadIn::~ReadIn(){
};
/*
void ReadIn::ReadInAscii(const std::string &asciiSourceFile, const std::string &label, Int_t ColumnWantedVariable, Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex, std::string outpath) {
    // read in the ASCII files with data, MC or background
    // Write events (n-tuples) to file A (TreeA)
    Double_t weight = 1.0;// can be modified for data, MC or background
    Double_t countw = 0.0;
    Double_t x = 0.0;
    Double_t y[NrAllMeasuredVariables];
    Double_t VariableAscii[NrAllMeasuredVariables+1];
    Int_t index=0;
    Int_t eventIndex=0;
    for(Int_t i=0; i<NrAllMeasuredVariables; ++i) {
        y[i]=0.0;
    }
       if(printflag > 0){
    cout<<"\nread in events from ASCII file"<<endl;
    cout<<"=============================="<<endl;
    cout<<label<<"\n-----"<<endl;
       }
    // create RootTree file and set branches
    TFile *fileA = 0;
    TTree *TreeA = 0;
    TH1D *hWeightedMC = 0;// weighted MC x distribution to check the distribution form
    if(label=="DATA") {
        if(NTupleIndex == 0) {
                    fileA = new TFile((outpath+"RDfileA.root").c_str(),"RECREATE");
            TreeA = new TTree("TreeA", "Data from ASCII file");
        }
        else {
                    fileA = new TFile((outpath+"RDfileA.root").c_str(),"UPDATE");
            TreeA = (TTree*)fileA->Get("TreeA");
        }
    }
    else if(label=="MOCA") {
        if(NTupleIndex == 0) {
                        fileA = new TFile((outpath+"MCfileA.root").c_str(),"RECREATE");
            TreeA = new TTree("TreeA", "MC data from ASCII file");
            TreeA->Branch(nameWantedX, &x, "WantedX/D");
            hWeightedMC = new TH1D("WeightedWantedXMC","MC wanted x distribution weighted", 100, WantedXLowLimit, WantedXHighLimit);
        }
        else {
                        fileA = new TFile((outpath+"MCfileA.root").c_str(),"UPDATE");
            TreeA = (TTree*)fileA->Get("TreeA");
            TreeA->SetBranchAddress(nameWantedX, &x);
            hWeightedMC = (TH1D*)fileA->Get("WeightedWantedXMC");
        }
    }
    else if(label=="BKGD") {
            fileA = new TFile((outpath+"BGfileA.root").c_str(),"RECREATE");
        TreeA = new TTree("TreeA", "Background data from ASCII file");
    }
    char Variable[NrAllMeasuredVariables];
    if(NTupleIndex == 0) {
        TreeA->Branch("weight", &weight, "weight/D");
        TreeA->Branch("NTupleIndex", &NTupleIndex, "NTupleIndex/I");
        for(Int_t I=0; I<NrAllMeasuredVariables; ++I) {
            sprintf(Variable, "Variable%d/D", I);
            TreeA->Branch(nameObsY[I], &y[I], Variable);
        }
    }
    else {
        TreeA->SetBranchAddress("weight", &weight);
        TreeA->SetBranchAddress("NTupleIndex", &NTupleIndex);
        for(Int_t I=0; I<NrAllMeasuredVariables; ++I) {
            TreeA->SetBranchAddress(nameObsY[I], &y[I]);
        }
    }

    // ---------- fill TreeA with data from ASCII file ----------------
    ifstream infile;
    infile.open(asciiSourceFile.c_str());

    Bool_t go = 0;// boolian to reject events with log10(0)
    while (infile.good()) {
        weight = 1.0;
        for(Int_t i=0; i<=NrAllMeasuredVariables; ++i) infile>>VariableAscii[i];
        if(!infile.good()) break;
        index=0;
        go = 0;
        for(Int_t i=0; i<=NrAllMeasuredVariables; ++i) {
            if(i!=ColumnWantedVariable) {
                y[index]=VariableAscii[i];
                if(logOption[index] == 1) {
                    // logarithmic input
                    if(y[index] > 0) {
                        y[index]=log10(y[index]);
                    }
                    else {
                        go = 1;
                        break;
                    }
                }
                index++;
            }
        }
        if(go == 1) continue;
        if(label == "DATA") {
            //weight = 1.0;// can be modified
            eventIndex++;
        }
        else if(label == "MOCA") {
            x = VariableAscii[ColumnWantedVariable];
            if(logOptionX == 1) {
                if(x > 0) x = log10(x);
                else continue;
            }
            //weight = 1.0;// can be modified
            hWeightedMC->Fill(x, weight);
            eventIndex++;
        }
        else if (label == "BKGD") {
            //weight=1.0;// can be modified
            eventIndex++;
        }
               // if(x >= InputObject->GetCutMin() && x<= InputObject->GetCutMax()){
                    TreeA->Fill();
                    countw=countw+weight;
           //     }
    }
    infile.close();
    if(label == "BKGD") BackEventNr = countw;
    TreeA->Write("", TObject::kOverwrite);// restock the existing tree for several (MC) data types
    if(label == "MOCA") hWeightedMC->Write("", TObject::kOverwrite);
    fileA->Close();
    cout<<"number of events: "<<eventIndex<<endl;
    cout<<"total sum of weights: "<<countw<<endl;
}

*/
void ReadIn::Read(const std::string &rootTreeSourceFile, const std::string &SourceTreeName, const std::string &label, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex) {
    // read in the root files with data, MC or background
    // Write n-tuples to file A (TreeA)
    Double_t weight = 1.0;// can be modified for data, MC or background
    Double_t countw=0.0;
    Int_t eventNonZero=0;
    Double_t x=0.0;
    Double_t y[NrAllMeasuredVariables];
    Int_t eventIndex=0;
    for(Int_t i=0; i<NrAllMeasuredVariables; ++i) {
        y[i]=0.0;
    }
    if(printflag > 1){
        cout<<"\nread in events from the RootTree"<<endl;
        cout<<"================================"<<endl;
        cout<<label<<"\n-----"<<endl;
    }

    // ---------- fill vectors with data from RootTree source file ----------------
    // open RootTree file and set BranchAddress for all user defined variables
    TChain *fileSource = new TChain(SourceTreeName.c_str());
    fileSource->Add(rootTreeSourceFile.c_str());
    fileSource->SetBranchStatus("*",0); // deactivate all branches
    // make possible to read different variable types and cast to Double_t (there must be a better way!)
    Int_t xTypeIdent = 0; // type identifier: 1 = int, 2 = float, 3 = double
    Int_t wTypeIdent = 0; // type identifier weight: 1 = int, 2 = float, 3 = double
    Int_t yTypeIdent[NrAllMeasuredVariables]; // type identifier: 1 = int, 2 = float, 3 = double
    Int_t x_int = 0;
    Int_t w_int = 0;
    Int_t y_int[NrAllMeasuredVariables];
    Float_t x_float = 0.0;
    Float_t w_float = 0.0;
    Float_t y_float[NrAllMeasuredVariables];
    Double_t x_double = 0.0;
    Double_t w_double = 0.0;
    Double_t y_double[NrAllMeasuredVariables];
    if(label=="MOCA") {
        // check the leaf type for the sought-after x variable
        CheckLeafType(fileSource, BranchWantedX, xTypeIdent, x_int, x_float, x_double);
        // check the leaf type for the individual event weight
    }
    if(BranchEventWeight != "no_weight") {
        CheckLeafType(fileSource, BranchEventWeight, wTypeIdent, w_int, w_float, w_double);
    }
    for(Int_t j=0; j<NrAllMeasuredVariables; ++j) {
        // check the leaf type for the measured observables
        CheckLeafType(fileSource, BranchMeasurVariable[j].c_str(), yTypeIdent[j], y_int[j], y_float[j], y_double[j]);
    }
    //fileA->cd();
    Int_t NrEntries = static_cast<Int_t>(fileSource->GetEntries());
    Bool_t go = 0; // boolian to reject events with log10(0)
    for(Int_t AB=0; AB<NrEntries; AB++) {
        //cout  << AB <<endl;
        weight = 1.0;
        fileSource->GetEntry(AB);
        go = 0;
        for(Int_t ij=0; ij<NrAllMeasuredVariables; ++ij) {
            if(yTypeIdent[ij] == 1) y[ij] = static_cast<Double_t>(y_int[ij]);
            else if(yTypeIdent[ij] == 2) y[ij] = static_cast<Double_t>(y_float[ij]);
            else if(yTypeIdent[ij] == 3) y[ij] = static_cast<Double_t>(y_double[ij]);
            else {
                y[ij] = -10000000; // no type determined?
                cerr<<"no type determined for observable: "<<y[ij]<<endl;
            }
            if(logOption[ij] == 1) {
                if(y[ij] > 0) {
                    y[ij]=log10(y[ij]);
                }
                else {
                    go = 1;
                    break;
                }
            }
            // read event weights from root tree
            if(BranchEventWeight != "no_weight") {
                if(wTypeIdent == 1) weight = static_cast<Double_t>(w_int);
                else if(wTypeIdent == 2) weight = static_cast<Double_t>(w_float);
                else if(wTypeIdent == 3) weight = static_cast<Double_t>(w_double);
                else {
                    weight = -10000000; // no type determined
                    cerr<<"no type determined for weight"<<endl;
                }
            }
        }
        if(go == 1) continue;
        TrueeEvent* temp_event = new TrueeEvent();
        temp_event->SetWeight(weight);



        for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {

            temp_event->add_y(y[ij]);

        }

        temp_event->set_NTupleIndex(NTupleIndex);
        if(label=="DATA") {
            InputObject->GetData()->Real_Data.push_back(temp_event);
        }
        else if(label=="MOCA") {
            if(xTypeIdent == 1) x = static_cast<Double_t>(x_int);
            else if(xTypeIdent == 2) x = static_cast<Double_t>(x_float);
            else if(xTypeIdent == 3) x = static_cast<Double_t>(x_double);
            else {
                x = -10000000;// no type determined?
                cerr<<"no type determined for sought-after variable"<<endl;
            }
            if(logOptionX == 1) {
                if(x > 0) {
                    x=log10(x); //TODO events < 0 => ?
                }
                else continue;
            }
            //hWeightedMC->Fill(x, weight);
            temp_event->set_x(x);
            InputObject->GetData()->MonteCarlo_Data.push_back(temp_event);
        }
        else if (label=="BKGD") {
            InputObject->GetData()->BG_Data.push_back(temp_event);
        }
        eventIndex++;
        if(weight != 0) eventNonZero++;
        countw=countw+weight;
    }
    //	TreeA->Write("", TObject::kOverwrite); // restock the existing tree for several (MC) data types
    //	if(label == "MOCA") hWeightedMC->Write("", TObject::kOverwrite);
    //	fileA->Close();
    if(label == "BKGD") BackEventNr = countw;
    if(label =="MOCA")  MocaEventNr = countw;
    if(label == "DATA") DataEventNr = countw;
    if(printflag > 0){
        cout << "Eventnumbers for unfolding: \n==============================\n"<<endl;
        cout<<"number of events: "<<eventIndex<<endl;
        cout<<"number of events (weight != 0): "<<eventNonZero<<endl;
        cout<<"total sum of weights: "<<countw<<endl;
        cout<<"weight factor (nr of events / sum of weights) = "<<eventIndex/countw<<endl;
        cout<<"weight factor non zero (nr of events (weight != 0) / sum of weights) = "<<eventNonZero/countw<<endl;
    }
    fileSource->Delete();
}
/*
void ReadIn::ReadInAsciiTest(const std::string &asciiSourceFile, const std::string &asciiSourceFileBG, Int_t ColumnWantedVariable, Bool_t *logOption, Bool_t logOptionX, Double_t fraction, TRandom3 *searchEventFraction, Int_t NTupleIndex, string outpath) {
    // read in the ASCII files with data, MC or background
    // Write n-tuples to file A (TreeA)
    Double_t weight = 1;// can be modified for data, MC or background (here bg weight = fraction*weight)
    Double_t x=0.0;
    Double_t y[NrAllMeasuredVariables];
    Double_t VariableAscii[NrAllMeasuredVariables+1];
    Int_t index=0;
    Int_t eventIndexMC=0;
    Int_t eventIndexRD=0;
    Int_t eventIndexBG=0;
    for(Int_t i=0; i<NrAllMeasuredVariables; ++i) {
        y[i]=0.0;
    }
        if(printflag > 0){
    cout<<"\nread in MC test events from ASCII file"<<endl;
    cout<<"======================================"<<endl;
        }
    TFile *Testfile;
    TTree *TestTree;
    // create a transient RootTree file (Testfile) and set branches
    // after Testfile is filled with all events, it will be divided in 2 parts
    if(NTupleIndex == 0) {
            Testfile = new TFile((outpath+"Testfile.root").c_str(), "RECREATE");
        TestTree = new TTree("TestTree", "TestMC from ASCII file");
    }
    else {
            Testfile = new TFile((outpath+"Testfile.root").c_str(), "UPDATE");
        TestTree = (TTree*) Testfile->Get("TestTree");
    }
    char Variable[NrAllMeasuredVariables];
    if(NTupleIndex == 0) {
        TestTree->Branch("weight", &weight, "weight/D");
        TestTree->Branch("NTupleIndex", &NTupleIndex, "NTupleIndex/I");
        TestTree->Branch(nameWantedX, &x, "WantedX/D");
        for(Int_t I=0; I<NrAllMeasuredVariables; ++I) {
            sprintf(Variable, "Variable%d/D", I);
            TestTree->Branch(nameObsY[I], &y[I], Variable);
        }
    }
    else {
        TestTree->SetBranchAddress("weight", &weight);
        TestTree->SetBranchAddress("NTupleIndex", &NTupleIndex);
        TestTree->SetBranchAddress(nameWantedX, &x);
        for(Int_t I=0; I<NrAllMeasuredVariables; ++I) {
            TestTree->SetBranchAddress(nameObsY[I], &y[I]);
        }
    }

    // ---------- fill events from ASCII file ----------------
    ifstream infile;
    infile.open(asciiSourceFile.c_str());
    Bool_t go = 0; // boolian to reject events with log10(0)
    while (infile.good()) {
        weight = 1.0;
        for(Int_t i=0; i<=NrAllMeasuredVariables; ++i) infile>>VariableAscii[i];
        if(!infile.good()) break;
        index=0;
        go = 0;
        for(Int_t i=0; i<=NrAllMeasuredVariables; ++i) {
            if(i!=ColumnWantedVariable) {
                y[index]=VariableAscii[i];
                if(logOption[index] == 1) {
                    if(y[index] > 0) {
                        y[index]=log10(y[index]);
                    }
                    else {
                        go = 1;
                        break;
                    }
                }
                index++;
            }
        }
        if(go == 1) continue;
        x=VariableAscii[ColumnWantedVariable];
        if(logOptionX == 1) {
            if(x > 0) x = log10(x);
            else continue;
        }
        //weight=1.0;
        TestTree->Fill();
    }
    infile.close();
    TestTree->Write("", TObject::kOverwrite); // restock the existing tree for several MC types
    go = 0;
    // now divide Testfile into quasi real data and MC
    // if existent, all background events are filled in the data and in the background file
    // and weighted by 2 to scale down background
    if(NTupleIndex == NrMocaTypes-1) {
        //--------- fill background events into a background file --------------
        TFile *BGfileA;
        ifstream infileBG;
        if(asciiSourceFileBG != "no_BG") {
            //---------------- create BG RootTree file and set branches ------------------
                    BGfileA = new TFile((outpath+"BGfileA.root").c_str(),"RECREATE");
            TTree *BGTreeA = new TTree("TreeA", "background events");
            BGTreeA->Branch("weight", &weight, "weight/D");
            BGTreeA->Branch("NTupleIndex", &NTupleIndex, "NTupleIndex/I");
            for(Int_t I=0; I<NrAllMeasuredVariables; ++I) {
                sprintf(Variable, "Variable%d/D", I);
                BGTreeA->Branch(nameObsY[I], &y[I], Variable);
            }
            infileBG.open(asciiSourceFileBG.c_str());
            go = 0;
            while (infileBG.good()) {
                weight = 1.0;
                for(Int_t i=0; i<=NrAllMeasuredVariables; ++i) infileBG>>VariableAscii[i];
                if(!infileBG.good()) break;
                index=0;
                go = 0;
                for(Int_t i=0; i<=NrAllMeasuredVariables; ++i) {
                    if(i!=ColumnWantedVariable) {
                        y[index]=VariableAscii[i];
                        if(logOption[index] == 1) {
                            if(y[index] > 0) {
                                y[index]=log10(y[index]);
                            }
                            else {
                                go = 1;
                                break;
                            }
                        }
                        index++;
                    }
                }
                if(go == 1) continue;
                //weight = weight*fraction;// scale background to the selected data fraction
                BackEventNr = BackEventNr + weight;
                eventIndexBG++;
                BGTreeA->Fill();
            }
            infileBG.close();
            BGfileA->Write();
            BGfileA->Close();
        }

        TestTree->SetBranchAddress("weight", &weight);
        TestTree->SetBranchAddress("NTupleIndex", &NTupleIndex);
        TestTree->SetBranchAddress(nameWantedX, &x);
        for(Int_t I=0; I<NrAllMeasuredVariables; ++I) {
            sprintf(Variable, "Variable%d/D", I);
            TestTree->SetBranchAddress(nameObsY[I], &y[I]);
        }
        Int_t testentries = TestTree->GetEntries();
        //-------- fill test mode MC file with the fraction of MC events ------
        // every first event is accepted, start counting at 0
                TFile *MCfileA = new TFile((outpath+"MCfileA.root").c_str(),"RECREATE");
        TTree *MCTreeA = new TTree("TreeA", "MC from ASCII file");
        TH1D *hWeightedMC = new TH1D("WeightedWantedXMC","MC x histo weighted", 100, WantedXLowLimit, WantedXHighLimit);
        MCTreeA->Branch("weight", &weight, "weight/D");
        MCTreeA->Branch("NTupleIndex", &NTupleIndex, "NTupleIndex/I");
        MCTreeA->Branch(nameWantedX, &x, "WantedX/D");
        //--------- fill test mode quasi real data file with the fraction of MC events ---------
                TFile *RDfileA = new TFile((outpath+"RDfileA.root").c_str(), "RECREATE");
        TTree *RDTreeA = new TTree("TreeA", "MC as RD from ASCII file");
        TH1D *hWeightedRD = new TH1D("WeightedWantedXRD","quasi rd x distribution weighted", 100, WantedXLowLimit, WantedXHighLimit);
        RDTreeA->Branch("weight", &weight, "weight/D");
        RDTreeA->Branch("NTupleIndex", &NTupleIndex, "NTupleIndex/I");
        RDTreeA->Branch(nameWantedX, &x, "WantedX/D");
        for(Int_t I=0; I<NrAllMeasuredVariables; ++I) {
            sprintf(Variable, "Variable%d/D", I);
            RDTreeA->Branch(nameObsY[I], &y[I], Variable);
            MCTreeA->Branch(nameObsY[I], &y[I], Variable);
        }
        for(Int_t ij = 0; ij < testentries; ++ij) {
            weight = 1.0;
            TestTree->GetEntry(ij);
            const Double_t randomNumber = searchEventFraction->Uniform(0, 1);
            if(randomNumber >= fraction) {
                //cout<<" MC random nr ="<<randomNumber<<" fraction = "<<fraction<<endl;
                //weight=1.0; // can be modified
                eventIndexMC++;
                hWeightedMC->Fill(x, weight);
                MCTreeA->Fill();
            }
            else {
                eventIndexRD++;
                hWeightedRD->Fill(x, weight);
                RDTreeA->Fill();
            }
        }
        MCfileA->Write();
        MCfileA->Close();
        //----------- fill background events into quasi real data file -------------
        if(asciiSourceFileBG != "no_BG") {
            infileBG.open(asciiSourceFileBG.c_str());
            go = 0;
            while (infileBG.good()) {
                weight = 1.0;
                for(Int_t i=0; i<=NrAllMeasuredVariables; ++i) infileBG>>VariableAscii[i];
                if(!infileBG.good()) break;
                index=0;
                go = 0;
                for(Int_t i=0; i<=NrAllMeasuredVariables; ++i) {
                    if(i!=ColumnWantedVariable) {
                        y[index]=VariableAscii[i];
                        if(logOption[index] == 1) {
                            if(y[index] > 0) {
                                y[index]=log10(y[index]);
                            }
                            else {
                                go = 1;
                                break;
                            }
                        }
                        index++;
                    }
                }
                if(go == 1) continue;
                x = 0.000001;
                //weight = weight*fraction;// scale background to the selected data fraction
                RDTreeA->Fill();
            }
            infileBG.close();
        }
        RDfileA->Write();
        RDfileA->Close();
                    if(printflag > 0){
        cout<<"number of events MC: "<<eventIndexMC<<endl;
        cout<<"number of events rd: "<<eventIndexRD<<endl;
        cout<<"number of events bg: "<<eventIndexBG<<endl;
                    }
        //pullSigma = sqrt(eventIndexRD);
    }
    Testfile->Close();
}
*/

void ReadIn::ReadTest(const std::string &rootTreeSourceFile, const std::string &rootSourceFileBG, const std::string &SourceTreeName, const std::string &SourceTreeNameBG, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Double_t fraction, TRandom3 *searchEventFraction, Int_t NTupleIndex, string outpath,string type) {
    // read in the root files with data, MC or background
    // Write n-tuples to file A (TreeA)


    weight = 1;// can be modified for data, MC or background (here bg weight = fraction*weight)
    x=0.0;
    double y[NrAllMeasuredVariables];
    eventIndexMC=0;
    eventIndexRD=0;
    eventIndexBG=0;
    for(int i=0; i<NrAllMeasuredVariables; ++i) {
        y[i]=0.0;
    }
    if(printflag > 1){
        cout<<"\nread in MC test events from the RootTree"<<endl;
        cout<<"========================================"<<endl;
    }


    // make possible to read different variable types and cast to double (there must be a better way!)
    int xTypeIdent = 0; // type identifier: 1 = int, 2 = float, 3 = double
    int wTypeIdent = 0; // weight type identifier: 1 = int, 2 = float, 3 = double
    int yTypeIdent[NrAllMeasuredVariables]; // type identifier: 1 = int, 2 = float, 3 = double


    // if x,w or y are integers, those variables are used.
    int x_int = 0;
    int w_int = 0;
    int y_int[NrAllMeasuredVariables];

    // if x,w or y are floats, those variables are used.
    Float_t x_float = 0;
    Float_t w_float = 0;
    Float_t y_float[NrAllMeasuredVariables];

    // if x,w or y are doubles, those variables are used.
    double x_double = 0;
    double w_double = 0;
    double y_double[NrAllMeasuredVariables];

    // this is a hack i will do it nicely sometime later. So we can read "full events" if they are splitted into some events with sumofweights 1;

    int eventid = 0;


    // ---------- fill events from RootTree source file ----------------
    // if existent, all background events are filled in the data and in the background file
    // and weighted by 2 to scale down background
    // open RootTree file and set BranchAddress for all variables (observables)
    TChain *MCfileSource = new TChain(SourceTreeName.c_str());
    MCfileSource->Add(rootTreeSourceFile.c_str());
    MCfileSource->SetBranchStatus("*",0); // deactivate all branches
    // check the leaf type for the sought-after x variable
    CheckLeafType(MCfileSource, BranchWantedX.c_str(), xTypeIdent, x_int, x_float, x_double);
    // check the leaf type for the individual event weight
    if(BranchEventWeight != "no_weight") {
        CheckLeafType(MCfileSource, BranchEventWeight, wTypeIdent, w_int, w_float, w_double);
    }
    if(SplittedEvents)
    {
        MCfileSource->SetBranchStatus("EventID",1);
        MCfileSource->SetBranchAddress("EventID",&eventid);
    }
    for(int j=0; j<NrAllMeasuredVariables; ++j) {
        // check the leaf type for the measured observables
        CheckLeafType(MCfileSource, BranchMeasurVariable[j].c_str(), yTypeIdent[j], y_int[j], y_float[j], y_double[j]);
    }

    //-------- fill MC and pseudo RD files with fractions of MC events ------
    // every first event is accepted, start counting at 0
    int NrEntries = static_cast<int>(MCfileSource->GetEntries());
    //Full_data.resize(NrEntries);
    Bool_t go = 0; // boolian to reject events with log10(0)

    for(int AB=0; AB<(NrEntries); AB++) {
        weight = 1.0;
        MCfileSource->GetEntry(AB);
        if(xTypeIdent == 1) x = static_cast<double>(x_int);
        else if(xTypeIdent == 2) x = static_cast<double>(x_float);
        else if(xTypeIdent == 3) x = static_cast<double>(x_double);
        else {
            x = -10000000;// no type determined?
            cerr<<"no type determined for sought-after variable"<<endl;
        }
        if(BranchEventWeight != "no_weight") {
            if(wTypeIdent == 1) weight = static_cast<double>(w_int);
            else if(wTypeIdent == 2) weight = static_cast<double>(w_float);
            else if(wTypeIdent == 3) weight = static_cast<double>(w_double);
            else {
                weight = -10000000; // no type determined
                cerr<<"no type determined for weight"<<endl;
            }
        }
        go = 0;
        for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {
            if(yTypeIdent[ij] == 1) y[ij] = static_cast<double>(y_int[ij]);
            else if(yTypeIdent[ij] == 2) y[ij] = static_cast<double>(y_float[ij]);
            else if(yTypeIdent[ij] == 3) y[ij] = static_cast<double>(y_double[ij]);
            else {
                y[ij] = -10000000; // no type determined?
                cerr<<"no type determined for observable: "<<y[ij]<<endl;
            }
            if(logOption[ij] == 1) {
                if(y[ij] > 0) {
                    y[ij]=log10(y[ij]);
                }
                else {
                    go = 1;
                    break;
                }
            }
        }
        if(logOptionX == 1) {
            if(x > 0) {
                x=log10(x);
            }
            else go = 1;
        }
        if(go == 1) continue;
        TrueeEvent* temp_event = new TrueeEvent();
        //cout << weight <<endl;
        temp_event->SetWeight(weight);
        temp_event->set_x(x);
        // cout << x<<endl;
        for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {

            temp_event->add_y(y[ij]);

        }

        temp_event->set_NTupleIndex(NTupleIndex);
        temp_event->SetEventID(eventid);
        if(type == "USUAL")
            InputObject->Full_data.push_back(temp_event);
        if(type == "DIFFMC")
            InputObject->Full_MC.push_back(temp_event);

        if(type=="USUAL")
            DataEventNr+=weight;
        if(type == "DIFFMC")
            MocaEventNr+=weight;
    }


    // ---------- fill tree with background data from RootTree source file ----------------
    // open RootTree file and set BranchAddress for all variables
    int yTypeIdentBG[NrAllMeasuredVariables]; // type identifier for background: 1 = int, 2 = float, 3 = double
    int wTypeIdentBG; // type identifier of weight for background: 1 = int, 2 = float, 3 = double
    int y_intBG[NrAllMeasuredVariables];
    int w_intBG;
    Float_t y_floatBG[NrAllMeasuredVariables];
    Float_t w_floatBG;
    double y_doubleBG[NrAllMeasuredVariables];
    double w_doubleBG;
    TChain *BGfileSource = 0;
    TFile *BGfileA;
    int NrEntriesBG=0;
    if(NTupleIndex == (NrMocaTypes-1) && rootSourceFileBG != "no_BG") {
        BGfileSource = new TChain(SourceTreeNameBG.c_str());
        BGfileSource->Add(rootSourceFileBG.c_str());
        BGfileSource->SetBranchStatus("*",0); // deactivate all branches
        // check the leaf type for the individual event weight
        if(BranchEventWeight != "no_weight") {
            CheckLeafType(BGfileSource, BranchEventWeight, wTypeIdentBG, w_intBG, w_floatBG, w_doubleBG);
        }

        for(int j=0; j<NrAllMeasuredVariables; ++j) {
            // check the leaf type for the measured observables
            CheckLeafType(BGfileSource, BranchMeasurVariable[j].c_str(), yTypeIdentBG[j], y_intBG[j], y_floatBG[j], y_doubleBG[j]);
        }


        NrEntriesBG = static_cast<int>(BGfileSource->GetEntries());
        for(int AB=0; AB<NrEntriesBG; AB++) {
            weight = 1.0;
            BGfileSource->GetEntry(AB);
            go = 0;
            for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {
                if(BranchEventWeight != "no_weight") {
                    if(wTypeIdentBG == 1) weight = static_cast<double>(w_intBG);
                    else if(wTypeIdentBG == 2) weight = static_cast<double>(w_floatBG);
                    else if(wTypeIdentBG == 3) weight = static_cast<double>(w_doubleBG);
                    else {
                        weight = -10000000; // no type determined
                        cerr<<"no type determined for weight"<<endl;
                    }
                }
                if(yTypeIdentBG[ij] == 1) y[ij] = static_cast<double>(y_intBG[ij]);
                else if(yTypeIdentBG[ij] == 2) y[ij] = static_cast<double>(y_floatBG[ij]);
                else if(yTypeIdentBG[ij] == 3) y[ij] = static_cast<double>(y_doubleBG[ij]);
                else {
                    y[ij] = -10000000; // no type determined?
                    cerr<<"no type determined for observable: "<<y[ij]<<endl;
                }
                if(logOption[ij] == 1) {
                    if(y[ij] > 0) {
                        y[ij]=log10(y[ij]);// can be modified
                    }
                    else {
                        go = 1;
                        break;
                    }
                }
            }
            if(go == 1) continue;
            BackEventNr = BackEventNr + weight;
            eventIndexBG++;
            TrueeEvent* temp_event = new TrueeEvent();
            temp_event->SetWeight(weight);
            temp_event->set_x(x);

            for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {
                temp_event->add_y(y[ij]);

            }
            InputObject->GetData()->BG_Data.push_back(temp_event);

        }
    }




    //Pull(fraction, searchEventFraction);

    MCfileSource->Delete();
    if(rootSourceFileBG != "no_BG") BGfileSource->Delete();
}
/*
void ReadIn::MakeObsHistogram(const std::string &label, Int_t fraction, const std::string &rootTreeSourceFile, const std::string &SourceTreeName, const std::string &BranchMeasurVariable, const std::string &branchEventWeight, Bool_t logOption, Int_t NTupleIndex) {
    // create a histogram of a fit variable from real data (without background!!)
    // to re-weight the pseudo real data in test mode
    Double_t weight = 1;
    Double_t y = 0.0;
    TFile *fileA;
    TH1D *hObs;
    Int_t nrBins = 200;
    Double_t yMin = 0.0;
    Double_t yMax = 0.0;
    TString obsHistoName = "bla";
    if(label == "DATA") obsHistoName = "ReweightingObservableRD";
    else if(label == "MOCA") obsHistoName = "ReweightingObservableMC";
    else if(label == "BKGD") obsHistoName = "ReweightingObservableBG";
    if(NTupleIndex == 0) {
        if(label == "DATA") {
            fileA = new TFile("RDfileA.root","RECREATE");
            hObs = new TH1D(obsHistoName,"rescale observable in test mode", nrBins, yMin, yMax);
        }
        else {
            fileA = new TFile("RDfileA.root","UPDATE");
            TH1D *hObsRD = (TH1D*) fileA->Get("ReweightingObservableRD");
            yMin = hObsRD->GetBinLowEdge(1);
            yMax = yMin + hObsRD->GetBinWidth(1) * nrBins;
            hObs = new TH1D(obsHistoName,"rescale observable in test mode", nrBins, yMin, yMax);
        }
    }
    else {
        fileA = new TFile("RDfileA.root","UPDATE");
        hObs = (TH1D*) fileA->Get(obsHistoName);
    }
    // ---------- fill events from RootTree source file ----------------
    TChain *fileSource = new TChain(SourceTreeName.c_str());
    fileSource->Add(rootTreeSourceFile.c_str());
    fileSource->SetBranchStatus("*",0); // deactivate all branches
    Int_t wTypeIdent = 0;
    Int_t yTypeIdent = 0;
    Int_t w_int = 0;
    Int_t y_int = 0;
    Float_t w_float = 0.0;
    Float_t y_float = 0.0;
    Double_t w_double = 0.0;
    Double_t y_double = 0.0;
    // check the leaf type for the measured observables
    CheckLeafType(fileSource, BranchMeasurVariable.c_str(), yTypeIdent, y_int, y_float, y_double);
    if(branchEventWeight != "no_weight") {
        CheckLeafType(fileSource, branchEventWeight, wTypeIdent, w_int, w_float, w_double);
    }
    Int_t NrEntries  = static_cast<Int_t>(fileSource->GetEntries());
        Bool_t go = 0; // boolian to reject events with log10(0)
    for(Int_t AB=0; AB<NrEntries; ++AB) {
        if(AB%fraction == 0) {
            fileSource->GetEntry(AB);
            if(branchEventWeight != "no_weight") {
                if(wTypeIdent == 1) weight = static_cast<Double_t>(w_int);
                else if(wTypeIdent == 2) weight = static_cast<Double_t>(w_float);
                else if(wTypeIdent == 3) weight = static_cast<Double_t>(w_double);
                else {
                    weight = -10000000; // no type determined
                    cerr<<"no type determined for weight"<<endl;
                }
            }
            go = 0;
            if(yTypeIdent == 1) y = static_cast<Double_t>(y_int);
            else if(yTypeIdent == 2) y = static_cast<Double_t>(y_float);
            else if(yTypeIdent == 3) y = static_cast<Double_t>(y_double);
            else {
                y = -10000000; // no type determined?
                cerr<<"no type determined for observable: "<<y<<endl;
            }
            if(logOption == 1) {
                if(y > 0) {
                    y = log10(y);// can be modified
                }
                else {
                    go = 1;
                    break;
                }
            }
            if(go == 1) continue;
            hObs->Fill(y, weight);
        }
    }
    hObs->Write("", TObject::kOverwrite);
    fileA->Close();
}
 */


void ReadIn::CheckLeafType(TChain *fileName, const std::string &branchName, Int_t &typeIdent, Int_t &type_int, Float_t &type_float, Double_t &type_double) {
    // check the type of the leaf to read the right type and set the branch address
    string integer_t = "Int_t";
    string integer = "int";
    string floating_t = "Float_t";
    string floating = "float";
    string doubles_t = "Double_t";
    string doubles = "double";
    fileName->SetBranchStatus(branchName.c_str(), 1);
    if(fileName->GetLeaf(branchName.c_str())->GetTypeName() == integer || fileName->GetLeaf(branchName.c_str())->GetTypeName() == integer_t) {
        fileName->SetBranchAddress(branchName.c_str(), &type_int);
        typeIdent = 1;
    }
    else if(fileName->GetLeaf(branchName.c_str())->GetTypeName() == floating || fileName->GetLeaf(branchName.c_str())->GetTypeName() == floating_t) {
        fileName->SetBranchAddress(branchName.c_str(), &type_float);
        typeIdent = 2;
    }
    else if(fileName->GetLeaf(branchName.c_str())->GetTypeName() == doubles || fileName->GetLeaf(branchName.c_str())->GetTypeName() == doubles_t) {
        fileName->SetBranchAddress(branchName.c_str(), &type_double);
        typeIdent = 3;
    }
}


void ReadIn::Pull(double fraction, TRandom3* searchEventFraction, bool use_different_mc){

    //cout << "##### Pull is running"<<endl;


    double randomNumber, currenteventid;
    InputObject->GetData()->MonteCarlo_Data.reserve(InputObject->Full_data.size());
    InputObject->GetData()->Real_Data.reserve(InputObject->Full_data.size());

    if(use_different_mc){
        for(int j = 0; j <  InputObject->Full_data.size(); ++j){
            randomNumber                = searchEventFraction->Uniform(0, 1);
            currenteventid              = InputObject->Full_data.at(j)->GetEventID();

            while(currenteventid == InputObject->Full_data.at(j)->GetEventID() && j < InputObject->Full_data.size()-1){
               //cout << currenteventid<<"\t"<<j<< "\t"<<InputObject->Full_data.size()<<endl;
                if(randomNumber < fraction)
                {
                    InputObject->GetData()->Real_Data.push_back( InputObject->Full_data.at(j));
                }
                if(SplittedEvents)
                    j++;
                else
                    break;
            }
        }
        InputObject->GetData()->MonteCarlo_Data = InputObject->Full_MC;

        //        for(int j = 0; j <  InputObject->Full_MC.size(); ++j){
        //                              InputObject->GetData()->MonteCarlo_Data.push_back( InputObject->Full_MC.at(j));
        //        }

    }
    else{
        for(int j = 0; j <  InputObject->Full_data.size(); ++j){

            randomNumber = searchEventFraction->Uniform(0, 1);
            if(randomNumber >= fraction) {
                InputObject->GetData()->MonteCarlo_Data.push_back( InputObject->Full_data.at(j));
            }
            else {
                InputObject->GetData()->Real_Data.push_back( InputObject->Full_data.at(j));
            }
        }

    }
    for(int j = 0; j <  InputObject->GetData()->BG_Data.size(); j++)
        InputObject->GetData()->Real_Data.push_back( InputObject->GetData()->BG_Data.at(j));


    if(printflag > 0){

        cout << "Eventnumbers for unfolding: \n==============================\n"<<endl;
        cout<<"number of events MC: "<< InputObject->GetData()->MonteCarlo_Data.size()<<endl;
        cout<<"number of events rd: "<< InputObject->GetData()->Real_Data.size()<<endl;
        cout<<"number of events bg: "<< InputObject->GetData()->BG_Data.size()<<endl;
    }

    InputObject->GetData()->MonteCarlo_Data_after_pp.reserve( InputObject->GetData()->MonteCarlo_Data.size());
    InputObject->GetData()->Real_Data_after_pp.reserve( InputObject->GetData()->Real_Data.size());
}


