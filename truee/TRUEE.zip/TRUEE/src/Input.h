//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef Input_H_
#define Input_H_

#include "trueedata.h"
#include <TString.h>
#include <TF1.h>
#include <string>

class ReadIn;


class Input {

public:
    Input();
    virtual ~Input();
    Int_t ParameterInput(TString steerFilePath);
    void SourceFilesInput(Int_t pullIndex);
    /*	void setNrBinsNext(Int_t nrBinsNext) {
        this->nrBinsNext = nrBinsNext;
    }*/
    void setNrBinsResult(Int_t NrBinsResult) {
        this->NrBinsResult = NrBinsResult;
    }
    void setNrDegreeOfFreedom(Int_t NrDegreeOfFreedom) {
        this->NrDegreeOfFreedom = NrDegreeOfFreedom;
    }
    void setNrOfFitVariables(Int_t NrOfFitVariables) {
        this->NrOfFitVariables = NrOfFitVariables;
    }
    void setNrKnots(Int_t NrKnots) {
        this->NrKnots = NrKnots;
    }
    void setWantedXLowLimit(Double_t WantedXLowLimit) {
        this->WantedXLowLimit = WantedXLowLimit;
    }
    void setWantedXHighLimit(Double_t WantedXHighLimit) {
        this->WantedXHighLimit = WantedXHighLimit;
    }

    Bool_t GetFXpositive() {return FXpositive;}
    Bool_t getLogOptionX() {return logOptionX;}
    Bool_t GetMCFuncFlag() {return mcFuncFlag;}
    int getPrintflag() { return print;}
    Bool_t GetPullmode() { return pullmode;}
    Bool_t GetSmoothX() {return SmoothX;}
    Bool_t getTestmode() {return testmode;}
    Bool_t getTreeBG() { return TreeBG;}
    Bool_t getTreeMC() { return TreeMC;}
    Bool_t getTreeRD() { return TreeRD;}
    Bool_t GetZeroLeft() {return zeroLeft;}
    Bool_t GetZeroRight() {return zeroRight;}
    bool GetIgnoreLastBin() { return ignore_last_bin;}

    Double_t GetBackEventNr(){return BackEventNr;}
    Double_t GetMocaEventNr(){return MocaEventNr;}
    Double_t GetDataEventNr(){return DataEventNr;}
    Double_t GetDataFraction() {return fraction;} // fraction of pseudo data in test/pull mode
    Double_t getDataLumi(Int_t DataTypeIndex) { return DataLumi[DataTypeIndex];}
    Double_t GetDataWeight(Int_t DataTypeIndex) {return DataWeight[DataTypeIndex];}
    Double_t GetFitVarHighLimit(Int_t FitVarIndex) {return FitVarHighLimit[FitVarIndex];}
    Double_t GetFitVarLowLimit(Int_t FitVarIndex) {return FitVarLowLimit[FitVarIndex];}
    Double_t GetFXconstraint(Int_t FxIndex) {return FXconstraint[FxIndex];}
    Double_t GetLimitsOfBinsResult(Int_t NrLimit) {return LimitsOfBinsResult[NrLimit];}
    Double_t GetLinWeight() {return LinWeight;}
    Double_t GetMocaLumi(Int_t MCTypeIndex) {return MocaLumi[MCTypeIndex];}
    Double_t GetMocaWeight(Int_t MCTypeIndex) {return MocaWeight[MCTypeIndex];}
    Double_t GetPullSigma() { return pullSigma;}
    Double_t GetSumLumiData() {return SumLumiData;}
    Double_t GetWantedXHighLimit() {return WantedXHighLimit;}
    Double_t GetWantedXLowLimit() {return WantedXLowLimit;}
    Double_t GetXconstraint(Int_t xIndex) {return Xconstraint[xIndex];}
    Double_t GetXMCLumi() {return XMCLumi;}
    Double_t GetCutMax(){return CutMax;}
    Double_t GetCutMin(){return CutMin;}
    Double_t GetResultSuppression_DPC() { return ResultSuppression_DPC; }
    Double_t GetResultSuppression_ChiSquare() { return ResultSuppression_ChiSquare; }
    Double_t GetResultSuppression_Kolmogorov() { return ResultSuppression_Kolmogorov; }


    Int_t GetIndexFitVariable(Int_t FitVarIndex) {return IndexFitVariable[FitVarIndex];}// IndexFitVariable=0...31; FitVarIndex=0...4;
    Int_t GetNrAllMeasuredVariables() {return NrAllMeasuredVariables;}
    Int_t GetNrBinsMCMax() {return NrBinsMCMax;}
    //	Int_t GetNrBinsNext() {return nrBinsNext;}
    Int_t GetNrBinsResult() {return NrBinsResult;}
    Int_t GetMinNrBinsResult(){return  MinNrBinsResult;}
    Int_t getNrBinsResultMax() { return NrBinsResultMax;}
    Int_t getNrBinsResultMaxUser() { return NrBinsResultMaxUser;}
    Int_t GetNrBinsFitVar(Int_t FitVarIndex) {return NrBinsFitVar[FitVarIndex];}
    Int_t GetNrConstraints() {return NrConstraints;}
    Int_t GetNrDataTypes() {return NrDataTypes;}
    Int_t GetNrDegreeOfFreedom() {return NrDegreeOfFreedom;}
    Int_t GetMinNrDegreeOfFreedom(){return MinNrDegreeOfFreedom;}
    //Int_t GetNrDegreeOfFreedomMax() {return NrDegreeOfFreedomMax;}
    Int_t getNrDegreeOfFreedomMaxUser() {return NrDegreeOfFreedomMaxUser;}
    Int_t GetNrOfFitVariables() {return NrOfFitVariables;}
    Int_t GetNrKnots() {return NrKnots;}
    Int_t GetMinNrKnots(){return MinNrKnots;}
    Int_t GetNrKnotsMax() {return NrKnotsMax;}
    Int_t getNrKnotsMaxUser() { return NrKnotsMaxUser;}
    Int_t GetNrMocaTypes() {return NrMocaTypes;}
    Int_t GetNrPulls() { return nrPulls;}

    std::string getProjectTitle() {return projectTitle;}
    TString getoutputpath() {return outputpath;}
    std::string get_csvseperator(){return csvseperator;}
    std::string GetSourceTreeMC(int i ){return SourceTreeMC[i];}
    //	TString GetBranchEventWeight() { return branchEventWeight; }
    TString GetMCFormula() {return mcFormula;}
    TString getNameObsY(Int_t index) {return nameObsY[index];}
    TString getNameWantedX() {return nameWantedX;}
    TString get_Cutvariable() {return Cutvariable;}

    TString GetSourceFileMC(int i){return SourceFileMC[i];}
    //TString GetSourceTreeMC(int i){return SourceTreeMC[i];}


    ReadIn* getReadIn(){return ReadInFiles;}
    TrueeData* GetData(){return Rawdata;}
    std::vector<TrueeEvent* > Full_data;
    std::vector<TrueeEvent* > Full_MC;

    void setTestmode(bool newTestmode){ testmode = newTestmode;}
    void setPullmode(bool newPullmode){ pullmode = newPullmode;}


private:



    Bool_t FXpositive;
    Bool_t mcFuncFlag;// is the mc f(x) generated function defined?
    Bool_t logOption[32];
    Bool_t logOptionX;
    int print;
    Bool_t pullmode;
    Bool_t randomseed;
    Bool_t SmoothX;
    Bool_t testmode;
    Bool_t TreeBG;
    Bool_t TreeRD;
    Bool_t TreeMC;
    Bool_t zeroLeft;
    Bool_t zeroRight;
    Bool_t read_files;
    bool ignore_last_bin;
    bool Use_different_MC;

    Double_t DataLumi[32];
    Double_t DataWeight[32];
    Double_t FitVarHighLimit[5];
    Double_t FitVarLowLimit[5];
    Double_t fraction;
    Double_t FXconstraint[10];
    Double_t LimitsOfBinsResult[32];
    Double_t LinWeight;
    Double_t MocaLumi[32];
    Double_t MocaWeight[32];
    Double_t SumLumiData;
    Double_t MeasuredVarHighLimit[32];
    Double_t MeasuredVarLowLimit[32];
    Double_t pullSigma;
    Double_t WantedXLowLimit;
    Double_t WantedXHighLimit;
    Double_t Xconstraint[10];
    Double_t XMCLumi;
    Double_t CutMax;
    Double_t CutMin;
    Double_t ResultSuppression_DPC;
    Double_t ResultSuppression_ChiSquare;
    Double_t ResultSuppression_Kolmogorov;


    Double_t BackEventNr;
    Double_t DataEventNr;
    Double_t MocaEventNr;
    Int_t ColumnMeasuredVariable[32];// column index of measured variables in ascii file
    Int_t ColumnWantedVariable;
    Int_t IndexFitVariable[5];// index of fit variable
    //	Int_t indexFinestFitVar; // index of fit variable with the finest binning
    Int_t MaxNrVariables;//TODO change variable number 32
    Int_t NrAllMeasuredVariables;
    Int_t NrConstraints;
    Int_t NrBinsFitVar[5];
    //Int_t nrBinsNext;
    Int_t NrBinsResultMax;
    Int_t NrBinsResultMaxUser;
    Int_t MinNrBinsResult;
    Int_t NrBinsMCMax;// NHU = NrBinsMCMax
    Int_t NrBinsMeasuredVar[32];
    Int_t NrBinsResult;

    Int_t NrDataTypes;	//NTAB=Nr...Types
    Int_t NrDegreeOfFreedom;
    Int_t MinNrDegreeOfFreedom;
    //	Int_t NrDegreeOfFreedomMax;
    Int_t NrDegreeOfFreedomMaxUser;
    Int_t NrKnots;
    Int_t MinNrKnots;
    Int_t NrKnotsMax;
    Int_t NrKnotsMaxUser;
    Int_t NrMocaTypes;
    Int_t NrOfFitVariables;
    Int_t nrPulls;

    //	TF1 *mcFunc;

    std::string BranchBG;
    std::string BranchFitVariable[5];
    std::string BranchMeasurVariable[32];// first index: tree index, second index: index of measured variable
    std::string BranchWantedX;
    std::string branchEventWeight;
    TString mcFormula;
    TString nameObsY[32];
    TString nameWantedX;
    TString Cutvariable;
    std::string SourceFileBG;
    std::string SourceFileMC[32];
    std::string SourceFileRD[32];
    std::string SourceTreeBG;
    std::string SourceTreeMC[32];
    std::string SourceTreeRD[32];
    std::string projectTitle;
    std::string outputpath;
    std::string csvseperator;

    TrueeData* Rawdata;

    ReadIn *ReadInFiles;
};

#endif /* Input_H_ */
