//	author: Martin Schmitz <martin.schmitz@uni-dortmund.de>
//	Dortmund, 2012
//	==========

#include "trueeresult.h"

using namespace std;



TrueeResult::TrueeResult()
{
}

void TrueeResult::add(std::vector<double> Result, std::vector<double>  Result_error, std::vector<double> MC_truth, double dpc, double kolmo, double chi, int Bins, int Knots, int Ndf, double fitmin, double regterm){


    result = Result;
    error_of_result = Result_error;
    mc_truth = MC_truth;

    DPC = dpc;
    kolmogorov = kolmo;
    chisquare = chi;

    bins = Bins;
    knots = Knots;
    ndf = Ndf;
    this->RegTerm = regterm;
    this->fitmin = fitmin;



}

void TrueeResult::print(){

    cout << "/n##### Unfolding result  #####"<<endl;
    for(int i = 0; i < result.size(); ++i){
        cout <<"bin content["<<i<<"] = "<< result.at(i) << " +/- "<<error_of_result.at(i)<<endl;
    }
    cout << "/n##### Real distribution #####"<<endl;
    for(int i = 0; i < mc_truth.size(); ++i){
        cout<< "real bin content["<<i<<"] = "<< mc_truth.at(i) <<endl;
    }


}
