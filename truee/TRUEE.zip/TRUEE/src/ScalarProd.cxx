//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

// scalar product of two ndimensional vectors
#include "ScalarProd.h"
#include <iostream>
using namespace std;
Double_t ScalarProd(Double_t *VectorX, Double_t *VectorY, Int_t N){
	Double_t sum=0.0;
	//Int_t M=N/4;
	//Int_t i=0;
	//// loop for N>=4
	//for(Int_t j=0; j<M; j++)
	//{
	//	sum=sum+VectorX[i]*VectorY[i]+VectorX[i+1]*VectorY[i+1]+VectorX[i+2]*VectorY[i+2]+VectorX[i+3]*VectorY[i+3];
	//i=i+4;
	//}

	for(Int_t k=0; k<N; k++)
	{
		sum=sum+VectorX[k]*VectorY[k];
	}

	return sum;
}
