

#include "trueedata.h"
using namespace std;


TrueeData::TrueeData(){


}

void TrueeData::erase(){
//    cout << "going to destroy"<<endl;
//    while(!MonteCarlo_Data.empty()){
//        delete MonteCarlo_Data.back();
//        MonteCarlo_Data.pop_back();
 //   }

    MonteCarlo_Data.clear();
   // while(!MonteCarlo_Data_after_pp.empty()){
     //   delete MonteCarlo_Data_after_pp.back();
       // MonteCarlo_Data_after_pp.pop_back();
   // }
    MonteCarlo_Data_after_pp.clear();

   // while(!Real_Data.empty()){
     //   delete Real_Data.back();
    //    Real_Data.pop_back();
    //}

    Real_Data.clear();

    //while(!Real_Data_after_pp.empty()){
      //  delete Real_Data_after_pp.back();
      //  Real_Data_after_pp.pop_back();
   // }

    Real_Data_after_pp.clear();
//    cout << "done"<<endl;


}


//std::vector<TrueeEvent* > TrueeData::MonteCarlo_Data;
//std::vector<TrueeEvent* > TrueeData::BG_Data;
//std::vector<TrueeEvent* > TrueeData::Real_Data;
//std::vector<TrueeEvent* > TrueeData::Full_data;

//std::vector<TrueeEvent* > TrueeData::MonteCarlo_Data_after_pp;
//std::vector<TrueeEvent* > TrueeData::BG_Data_after_pp;
//std::vector<TrueeEvent* > TrueeData::Real_Data_after_pp;
