#ifndef TRUEECSVREADER_H
#define TRUEECSVREADER_H

#include "trueereader.h"
#include <sstream>
#include <fstream>

class TrueeCSVReader : public TrueeReader
{
public:
    TrueeCSVReader(int nrAllMeasuredVariables, Input* in);
    void Read(const std::string &Sourcefile, const std::string &SourceTreeName, const std::string &label, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex);
    void ReadTest(const std::string &Sourcefile, const std::string &SourceTreeName, const std::string &label, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex, std::string type);

    void setSeperator(std::string S){ seperator = S;}

    std::string getSeperator(){ return seperator;}

private:
    std::vector<std::string> getline(std::istream& str); //!< turns back one raw of the given csv file

    int getcoloumn (std::string name, std::vector<std::string> title ); //!< turns back the position (coulomn wise) in your file for a given attribute

    double convert(std::string S);

    // Positions in your file

    int         Pos_WantedX;
    int         Pos_Weight;
    vector<int> Pos_Obs;

    int         NrAllMeasuredVariables;

    ifstream    in;
    std::string seperator;


};

#endif // TRUEECSVREADER_H
