#include "TrueeCovariance.h"
#include "TGraph.h"
#include <iostream> 
#include "TMath.h"
#include <cmath>
using namespace std;



void TrueeCovariance::SetPath(string P,string treename){
    // add endswith stuff!

    Path = P;
    this->treename = treename;
}


void TrueeCovariance::load(){
    inChain = new TChain(treename.c_str());
    inChain->Add(Path.c_str());
}


TCanvas* TrueeCovariance::GetCorrelationPlot() {
    load();

    Observables.erase(Observables.begin(),Observables.end());   // reset...

    TObjArray* BranchList = inChain->GetListOfBranches();
    for(int j = 0; j < BranchList->GetSize(); ++j){
        if(BranchList->At(j)->GetName() != WantedX){
            Observables.push_back(BranchList->At(j)->GetName());

        }
    }
    //Observables.resize(1);

    Correlations.resize(0);

    Correlations = GetCorrelation(Observables);

    CorrelationPlots.push_back(GetFullCorrPlot());
    CorrelationPlots.push_back(GetNonZeroCorrPlot());
    CorrelationPlots.push_back(GetHigherLimitCorrPlot());
    CorrelationPlots.push_back(GetHighlyCorrPlot());
    TCanvas *C = new TCanvas("Correlation overview", "Correlation overview", 1024, 768);
    C->Divide(2,2);
    for(int i = 1; i <5; ++i){
        C->cd(i);
        CorrelationPlots.at(i-1)->GetYaxis()->SetTitle("Correlation");
        CorrelationPlots.at(i-1)->Draw();
    }

    return C;

}

vector<double> TrueeCovariance::GetCorrelation(vector<TString> Obs){
    vector<TGraph*> CorrGraphs;
    vector<double> o;
    o.resize(Obs.size());
    double x;

    for(unsigned int j = 0; j < Obs.size(); ++j){
        CorrGraphs.push_back(new TGraph());
    }

    inChain->SetBranchStatus("*",0);
    inChain->SetBranchStatus(WantedX.c_str(),1);
    for(unsigned int j = 0; j < Obs.size(); ++j){
        inChain->SetBranchStatus(Obs.at(j),1);
    }

    inChain->SetBranchAddress(WantedX.c_str(),&x);
    for(unsigned int j = 0; j < Obs.size(); ++j){
        inChain->SetBranchAddress(Obs.at(j),&o.at(j));
    }

    vector<int> counter;
    counter.resize(Obs.size());
    for(unsigned int i = 0; i < Obs.size(); ++i){
        counter.at(i)= 0;
    }
    for(unsigned int i = 0; i < inChain->GetEntries(); ++i){
        inChain->GetEntry(i);
        bool xbreak = false;
        if(logX){
            if(x > 0)
                x = TMath::Log10(x);
            else
                xbreak = true;
        }
        for(unsigned int j =0; j < Obs.size();++j){
            bool ybreak = false;
            if(logY){
                if(o.at(j) > 0){
                    o.at(j) = TMath::Log10(o.at(j));
                }
                else{
                    ybreak = true;
                }
            }

            if(!ybreak && !xbreak){
                CorrGraphs.at(j)->SetPoint(counter.at(j),o.at(j),x);
                counter.at(j)++;
            }
        }
    }
    vector<double> Correlations;
    for(unsigned int j = 0; j < Obs.size();++j){
        Correlations.push_back(CorrGraphs.at(j)->GetCorrelationFactor());
    }
    return	Correlations;
}


TH1F* TrueeCovariance::GetFullCorrPlot(){
    TH1F* CorrelationOverview = new TH1F("Correlation overview", "Correlation to your WantedX",Observables.size(),0.5,Observables.size()+0.5);
    for(unsigned int j = 0; j < Correlations.size(); ++j){
        CorrelationOverview->GetXaxis()->SetBinLabel(j+1,Observables.at(j));
        if(Correlations.at(j) == Correlations.at(j)){
            CorrelationOverview->Fill(j+1,Correlations.at(j));
        }
    }
    return CorrelationOverview;
}

TH1F* TrueeCovariance::GetNonZeroCorrPlot(){
    int bins=0;
    for(unsigned int i = 0; i < Correlations.size(); ++i){
        if(Correlations.at(i) == Correlations.at(i) && fabs(Correlations.at(i)) > 0 )
            bins++;

    }
    TH1F* CorrelationOverview = new TH1F("Non zero correlation overview", "Non zero correlation to your WantedX",bins,0.5,bins+0.5);
    bins = 1;
    for(unsigned int j = 0; j < Correlations.size(); ++j){
        CorrelationOverview->GetXaxis()->SetBinLabel(j+1,Observables.at(j));
        if(Correlations.at(j) == Correlations.at(j) && fabs(Correlations.at(j)) > 0){
            CorrelationOverview->GetXaxis()->SetBinLabel(bins,Observables.at(j));
            CorrelationOverview->Fill(bins,Correlations.at(j));
            bins++;
        }
    }
    return CorrelationOverview;
}
TH1F* TrueeCovariance::GetHigherLimitCorrPlot(){
    int bins=0;
    for(unsigned int i = 0; i < Correlations.size(); ++i){
        if(Correlations.at(i) == Correlations.at(i) && fabs(Correlations.at(i)) > CorrLimit)
            bins++;

    }

    TH1F* CorrelationOverview = new TH1F("User filtered correlation overview", "User filtered correlation to your WantedX",bins,0.5,bins+0.5);
    bins = 1;
    for(unsigned int j = 0; j < Correlations.size(); ++j){
        if(Correlations.at(j) == Correlations.at(j) && fabs(Correlations.at(j)) > CorrLimit)
        {
            CorrelationOverview->GetXaxis()->SetBinLabel(bins,Observables.at(j));

            cout << Correlations.at(j) <<endl;
            CorrelationOverview->Fill(bins,Correlations.at(j));
            bins++;
        }
    }
    return CorrelationOverview;

}

TH1F* TrueeCovariance::GetHighlyCorrPlot(){
    double maxcorr = 0;
    for(unsigned int i = 0; i < Correlations.size(); ++i){
        maxcorr = TMath::Max(maxcorr,fabs(Correlations.at(i)));
    }
    int bins=0;
    for(unsigned int i = 0; i < Correlations.size(); ++i){
        if(Correlations.at(i) == Correlations.at(i) && fabs(Correlations.at(i)) > 0.5*maxcorr)
            bins++;

    }

    TH1F* CorrelationOverview = new TH1F("Filtered correlation overview", "Correlation to your WantedX (only high correlations are shown) ",bins,0.5,bins+0.5);
    bins = 1;
    for(unsigned int j = 0; j < Correlations.size(); ++j){
        if(Correlations.at(j) == Correlations.at(j) && fabs(Correlations.at(j)) > 0.5*maxcorr)
        {
            CorrelationOverview->GetXaxis()->SetBinLabel(bins,Observables.at(j));

            cout << Correlations.at(j) <<endl;
            CorrelationOverview->Fill(bins,Correlations.at(j));
            bins++;
        }
    }
    return CorrelationOverview;




}
