//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef LINEARALGEBRA_H_
#define LINEARALGEBRA_H_
#include "Rtypes.h"
#include <iostream>

class LinearAlgebra {
public:
	LinearAlgebra();
	virtual ~LinearAlgebra();

	void General2MatrixMult(Double_t *A, Double_t *B, Double_t *C, Int_t N, Int_t M, Int_t L);
	void GeneralSymGeneralTMatrixMult(Double_t *V, Double_t *A, Double_t *W, Int_t N, Int_t M);
	void SquareSymMatrix(Double_t *V, Double_t *VQ, Int_t N);
	void SymGeneralMult(Double_t *V, Double_t *A, Double_t *B, Int_t N, Int_t M);
	void EigenHouseholder(Double_t *V, Int_t N, Double_t *D, Double_t *UU, Int_t Direction);
	void OrderEigenvalues(Int_t N, Double_t *D, Double_t *E, Double_t *UU, Int_t Direction);
	void TransposeMatrix(Double_t *A, Double_t *B, Int_t N, Int_t M);

};

#endif /* LINEARALGEBRA_H_ */
