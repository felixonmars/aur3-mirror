#include "trueereader.h"

TrueeReader::TrueeReader()
{
}

void TrueeReader::Pull(double fraction,TRandom3* searchEventFraction, bool use_different_mc){

    //cout << "##### Pull is running"<<endl;

        double randomNumber;

        if(use_different_mc){
            for(int j = 0; j <  InputObject->Full_data.size(); ++j){
                            randomNumber = searchEventFraction->Uniform(0, 1);
                            if(randomNumber < fraction) {

                                 InputObject->GetData()->Real_Data.push_back( InputObject->Full_data.at(j));
                            }
            }
            for(int j = 0; j <  InputObject->Full_MC.size(); ++j){
                                  InputObject->GetData()->MonteCarlo_Data.push_back( InputObject->Full_MC.at(j));
            }

        }
        else{
            for(int j = 0; j <  InputObject->Full_data.size(); ++j){

                            randomNumber = searchEventFraction->Uniform(0, 1);
                            if(randomNumber >= fraction) {
                                 InputObject->GetData()->MonteCarlo_Data.push_back( InputObject->Full_data.at(j));
                            }
                            else {
                                 InputObject->GetData()->Real_Data.push_back( InputObject->Full_data.at(j));
                            }
            }

        }
        for(int j = 0; j <  InputObject->GetData()->BG_Data.size(); j++)
             InputObject->GetData()->Real_Data.push_back( InputObject->GetData()->BG_Data.at(j));


            if(printflag > 0){

                cout << "Eventnumbers for unfolding: \n==============================\n"<<endl;
                cout<<"number of events MC: "<< InputObject->GetData()->MonteCarlo_Data.size()<<endl;
                cout<<"number of events rd: "<< InputObject->GetData()->Real_Data.size()<<endl;
                cout<<"number of events bg: "<< InputObject->GetData()->BG_Data.size()<<endl;
            }
    }


