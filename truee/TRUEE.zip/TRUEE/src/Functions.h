//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef FUNCTIONS_H_
#define FUNCTIONS_H_
#include "Rtypes.h"
#include "BandMatrix.h"

class Functions {
public:
	Functions();
	virtual ~Functions();
	Double_t FValueOfDerivatives(Double_t X, Double_t *A, Int_t N, Double_t XlowLimit, Double_t XhighLimit, Int_t nrDerivative);
	Double_t SplineFuncIntegral(Double_t X1, Double_t X2, Double_t *A, Int_t N, Double_t XlowLimit, Double_t XhighLimit);
	void LeastSquareFit(Double_t *Y, Double_t *Y2, Int_t NH, Double_t XlowLimit, Double_t XhighLimit, Int_t NKN, Double_t *FIntegral, Double_t *A);
	void SplineFuncValue(Double_t X, Int_t N, Double_t XlowLimit, Double_t XhighLimit, Int_t &I, Double_t *Spline);
	Double_t FunctionValueFx(Double_t X, Double_t *A, Int_t N, Double_t XlowLimit, Double_t XhighLimit);
	Double_t NextXValue(Double_t XL, Double_t *A, Int_t N, Double_t XlowLimit, Double_t XhighLimit);
	Double_t getS(Int_t SIndex) {return S[SIndex];}
private:
	Double_t delta;
	Double_t S[2000];
	Int_t I0;
	Int_t N0;
	BandMatrix *BMatrix;
};

#endif /* FUNCTIONS_H_ */
