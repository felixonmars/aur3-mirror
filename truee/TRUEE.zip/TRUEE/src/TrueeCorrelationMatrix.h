#include<string>
#include<vector>
#include<TGraph.h>
#include<TH2F.h>

class TrueeCorrelationMatrix{
	public:

		TrueeCorrelationMatrix();

		TH2F* GetCorrelationMatrix();	
	
		void SetPath(std::string p){ Path = p;}

        void SetTreename(std::string t){Treename = t;}

        void SetLimit(double l){Limit = l;}

        void SetLog(bool l){ Log = l;}
	private:
		void read_data();

        double Limit;
        bool Log;
        std::string Path;
        std::string Treename;

        std::vector< double > data;

        std::vector<TString> Observables;
        std::vector< std::vector<TGraph*> > Graphs;
        std::vector< std::vector<double> > Correlation;
};
