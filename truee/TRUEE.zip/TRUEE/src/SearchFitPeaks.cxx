//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

// search for peaks in smoothed histogram
#include "SearchFitPeaks.h"
#include "math.h"
#include <iostream>
#include "TMath.h"
#include "BandMatrix.h"

using namespace std;

SearchFitPeaks::SearchFitPeaks(){
	for(Int_t i = 0; i < 5; ++i) {
		PeakAbscissa[i] = 0;
		PeakOrdinate[i] = 0;
		PeakBackgr[i] = 0;
		PeakIntegral[i] = 0;
		PeakSigma[i] = 0;
		PeakFWHM[i] = 0;
		LeftFWHMAbscissa[i] = 0;
		LeftFWHMOrdinate[i] = 0;
		RightFWHMAbscissa[i] = 0;
		RightFWHMOrdinate[i] = 0;
		LeftBackgrAbscissa[i] = 0;
		LeftBackgrOrdinate[i] = 0;
		RightBackgrAbscissa[i] = 0;
		RightBackgrOrdinate[i] = 0;
		LeftBackgrBin[i] = 0;
		RightBackgrBin[i] = 0;
	}
};
SearchFitPeaks::~SearchFitPeaks(){
};

void SearchFitPeaks::SearchPeaks(Double_t *Y, Int_t NrBins, Int_t &NrPeaks) {
	// SPEAKS
	Int_t istatus=0, k=0, KR=0, KL=0, LP=0, L=0, iBreak=0, jBreak=0, lBreak=0;
	Double_t sum=0, Ymax=0, derivative1=0, derivative2=0, derivative1max=0, derivative1min=0, XX=0, asymmetry=0;// original derivative1min=derivative1max=DER1M
	Float_t FM=0, XM=0, SND=0, rndmin=0, RN=0, RD=0, FL=0, RND=0, XR=0, XRD=0, XRN=0, XL=0, XLD=0, XLN=0, sigma=0, weight=0, back=0, FWHM=0, FR=0, FC=0, FD=0, FB=0, FS=0;
	Double_t PeakParameter[5][16];
	for(Int_t i = 0; i < 5; ++i) {
		for(Int_t j = 0; j < 16; ++j) {
			PeakParameter[i][j] = 0.0;
		}
	}
	for(Int_t i = 0; i < NrBins; i++) {
		sum=sum+Y[i];
		Ymax=max(Ymax, Y[i]);
	}
	// ... and analyse smoothed data
	for(Int_t j = 1; j < (NrBins-1); j++) {
		//cout<<"number of peaks="<<NrPeaks<<endl;
		// do 60. j not first or last bin
		if(Y[j]==0) continue;
		if(Y[j-1]>Y[j]) continue;
		if(Y[j+1]>Y[j]) continue;
		// first and second derivative
		derivative1=0.5*(Y[j+1]-Y[j-1]);
		derivative2=Y[j+1]-2.0*Y[j]+Y[j-1];
		if(derivative2>0) continue; // in mimimum of f between inflection points
		XX=0;
		if(derivative2!=0) XX=-derivative1/derivative2; //null at max (and min, but not here) of f
		if(fabs(XX)>0.5) continue; // gradient of f max or min
		// here a maximum (peak) has been found of FM at XM
		FM=Y[j]+XX*(derivative1+0.5*derivative2*XX);
		XM=static_cast<Double_t>(j)+XX;
		SND=0;
		// analyse region below peak
		rndmin=0;
		derivative1max=0;
		istatus=0;
		XL=1;
		k=j;
		// 20
		while(k!=1) {
			k=k-1;
			derivative2=Y[k+1]-2.0*Y[k]+Y[k-1];
			derivative1=0.5*(Y[k+1]-Y[k-1]);
			if(istatus==0) {
				// find maximum slope
				derivative1max=max(derivative1max,derivative1);
				// switch to status 1 if second derivative positive
				if(derivative2>=0) istatus=1;
			}
			// test slope at 3 sigma
			if(istatus==1) {
				// test slope reduction
				if(k>1 && k<NrBins-2) derivative1=0.25*(Y[k+2]-Y[k-2]);
				if(derivative1>0.2*derivative1max) continue;
				RN=derivative1*(static_cast<Double_t>(j-k)+XX);
				RD=FM-Y[k];
				// constant refers to 3 sigma
				if(RD!=0.0) {
					RND=RN/RD-0.075;
					if(RND<=0.0) {
						// more than 2 sigma reached
						XL=-RND/(SND-RND);
						break;
					}
					else if(rndmin>0.0) {
						// stop if RND is increasing
						if(RND>rndmin) break;
					}
					rndmin=RND;
				}
			}
			// goto 20
		}
		// 29
		FL=(1.0-XL)*Y[k]+XL*Y[k+1];
		KL=k;
		XL=static_cast<Double_t>(k)+XL;
		// analyze region above peak
		rndmin=0;
		derivative1max=0;
		istatus=0;
		XR=1.0;
		k=j;
		// 30
		while (k!=(NrBins-2)) {
			k=k+1;
			derivative2=Y[k+1]-2.0*Y[k]+Y[k-1];
			derivative1=0.5*(Y[k+1]-Y[k-1]);
			if(istatus==0) {
				// find maximum slope
				derivative1min=min(derivative1min, derivative1);
				if(derivative2>=0) istatus=1;
			}
			if(istatus==1) {
				// test slope reduction
				if(k>1 && k<(NrBins-2)) derivative1=0.25*(Y[k+2]-Y[k-2]);
				if(derivative1<0.2*derivative1min) continue;
				RN=-derivative1*(static_cast<Double_t>(k-j)-XX);
				RD=FM-Y[k];
				if(RD!=0.0) {
					RND=RN/RD-0.075;
					if(RND<=0.0) {
						// more than 2 sigma
						XR=-RND/(SND-RND);
						break;
					}
					else if(rndmin>0.0) {
						// stop if RND is increasing
						if(RND>rndmin) break;
					}
					rndmin=RND;
				}
			}
		}
		// 39
		FR=(1.0-XR)*Y[k]+XR*Y[k-1];
		KR=k;
		XR=static_cast<Double_t>(k)-XR;

		// test consistency of both sides
		for(Int_t Loop=0; Loop<3; Loop++) {
			// estimate background level at maximum
			FC=0.5*(FL+FR);
			if((XR-XL)>0.0) FC=(FL*(XR-XM)+FR*(XM-XL))/(XR-XL);
			FB=FC;
			FS=FM-FB;
			iBreak=0;
			if(FS<=0) {
				iBreak=1;
				break;
			}
			if(FB<=0 || FC<=0) {
				FL=0;
				FR=0;
			}
			else {
				FL=FL*FB/FC;
				FR=FR*FB/FC;
			}
			// half maximum
			FD=0.5*(FB+FM);

			// determine full width at half maximum
			for(Int_t l=j; l>=(KL-1); l--) {
				jBreak=0;
				if(Y[l]<=FD) {
					// linear interpolation

					jBreak=1;
					XLD=static_cast<Double_t>(k);
					if(Y[k]!=Y[k+1]) XLD=XLD+(FD-Y[k])/(Y[k+1]-Y[k]);
					//jBreak=0;

					for(Int_t m=j; m<KR; m++) {
						lBreak=0;
						if(Y[m]<=FD) {
							// linear interpolation
							lBreak=1;
							XRD=static_cast<Double_t>(k-1);

							if(Y[k]!=Y[k-1]) XRD=XRD+(Y[k-1]-FD)/(Y[k-1]-Y[k]);

							// correct limits
							XLN=XLD+2.00*(XLD-XM);
							if(XL<XLN) {

								XL=XLN;
								KL=static_cast<Int_t>(XL);
								FL=Y[KL];
							}
							XRN=XRD+2.00*(XRD-XM);
							if(XR>XRN) {
								XR=XRN;
								KR=static_cast<Int_t>(XR);
								FR=Y[KR];
							}
							// jBreak=1;
							break;
						}
					}
				}
				if(jBreak==1) break;
			}
			if(lBreak==1) continue;
			else {
				iBreak = 1;
				break;
			}
		}// 49 continue
		if(iBreak==1) continue;
		//  test symmetry of peak
		asymmetry=min(2.0+XM-XLD,2.0+XRD-XM)/max(2.0+XM-XLD,2.0+XRD-XM);
		if(asymmetry<0.333) continue;
		// ... and full width_at-half_max, sigma and integral
		FWHM=XRD-XLD;
		sigma=FWHM/2.31;
		weight=2.5066*FS*sigma;
		back=(XR-XL)*FB;
		// reject if signal less than 10 % of (signal +background) ...
		if(weight/(weight+back)<0.10) continue;
		//     ... or if signal less than 1 % of total ...
		if(weight<0.01*sum) continue;
		//     ... or if peak less than 2 % of max
		if(FS<0.02*Ymax) continue;
		//     store peak parameters in array
		if(NrPeaks==0) {
			// first peak
			L=1;
			NrPeaks=1;
		}
		else {
			// not first peak - determine position of new peak
			LP=0;
			for(Int_t n=0; n<NrPeaks; ++n) {
				if(PeakParameter[n][4]>weight) LP=LP+1;
			}
			if(LP<NrPeaks) {
				for(Int_t p=min(4, NrPeaks); p>LP; --p) {
					for(Int_t q=0; q<16; q++) {
						PeakParameter[p][q]=PeakParameter[p-1][q];
					}
				}
				L=LP+1;
				NrPeaks=min(NrPeaks+1,5);
			}
			else {
				if(NrPeaks==5) continue;
				NrPeaks=NrPeaks+1;
				L=NrPeaks;
			}
		}
		// store peak parameters under index L
		PeakAbscissa[L]=XM;
		PeakOrdinate[L]=FM;
		PeakBackgr[L]=FB;
		PeakIntegral[L]=weight;
		PeakSigma[L]=sigma;
		PeakFWHM[L]=FWHM;
		LeftFWHMAbscissa[L]=XLD;
		LeftFWHMOrdinate[L]=FD;
		RightFWHMAbscissa[L]=XRD;
		RightFWHMOrdinate[L]=FD;
		LeftBackgrAbscissa[L]=XL;
		LeftBackgrOrdinate[L]=FL;
		RightBackgrAbscissa[L]=XR;
		RightBackgrOrdinate[L]=FR;
		LeftBackgrBin[L]=KL;
		RightBackgrBin[L]=KR;
	}// 60 continue
}//100

void SearchFitPeaks::fitGauss(Double_t *hist, Int_t NrBins, Int_t PeakIndex) {
	// FTPEAK
	Double_t FY[256], PA[9];
	Double_t Chi2PerDegOfFreedom = 0.0, sumu2 = 0.0, sumg2 = 0.0, sumun = 0.0, sumgn = 0.0, rat = 0.0, facg = 0.0, tstg = 0.0, XX = 0.0, WT = 0.0;
	Double_t fmd[256], DE[5], der[5];
	Double_t delf = 0.0, delp = 0.0, fun = 0.0, fgau = 0.0, flin = 0.0, facu = 0.0, tstu = 0.0, II = 0.0, X = 0.0;
	Double_t R[5];
	Double_t res = 0.0;
	Bool_t bgl = 1;
	Bool_t bgr = 1;
	Double_t chsq = 0;
	Double_t Q[5][63];
	Double_t Xmax = RightBackgrBin[PeakIndex]-LeftBackgrBin[PeakIndex]+1;
        Double_t arglim = log(pow(10.,-10.)), arg, addu, addg;
	Int_t L = 0;
	PA[0] = PeakAbscissa[PeakIndex];
	PA[1] = PeakSigma[PeakIndex];
	PA[2] = PeakOrdinate[PeakIndex];
	PA[3] = LeftBackgrOrdinate[PeakIndex];
	PA[4] = RightBackgrOrdinate[PeakIndex];

/*	*     PA(5) =  mean for correction
	*     PA(6) =  sigma for correction
	*     PA(7) =  odd correction
	*     PA(8) =  even correction */

	// start assuming background left and right
	Int_t NPA = 5;// number of peak parameters?

	Double_t chiSum = 0.0, chlSum = 0.0;

	// start with zero modulation
	Int_t mdl = 0;

	// 01
	for(Int_t iter = 0; iter<10; iter++)  {
		// reset normal equations
		for(Int_t j = 0; j<5; j++) {
			R[j] = 0.0;
			for(Int_t i = 0; i<5; i++) {
				Q[i][j] = 0.0;
			}
		}

		chlSum = chiSum;
		chiSum = 0.0;
		delf = 0.0;
		fun = 0.0;
		fgau = 0.0;
		flin = 0.0;
		II = LeftBackgrBin[PeakIndex]-1;
		X = II;
		for(Int_t I = 0; I<=2*(RightBackgrBin[PeakIndex]-LeftBackgrBin[PeakIndex]+1); I++) {
			if((I%2)==1 && I!=0) {
				// lower bin_edge values from previous index ...
				II = II+1;
				fun = fgau+flin;
				for(Int_t J = 0; J<5; J++) {
					der[J] = DE[J];
				}
			}
			// gaussian plus linear
			arg = -0.5*pow((X-PA[0]),2)/pow(PA[1],2);
			if(arg<arglim) arg = arglim;
			fgau = PA[2]*exp(arg);
			XX = 0.5*static_cast<Double_t>(I);
			flin = (PA[3]*(Xmax-XX)+PA[4]*XX)/Xmax;

			// derivatives of gaussian ...
			DE[0] = PA[2]*exp(arg)*(X-PA[0])/pow(PA[1],2);
			DE[1] = PA[2]*exp(arg)*pow((X-PA[0]),2)/pow(PA[1],3);
			DE[2] = exp(arg);

			// ... and of linear background
			DE[3] = (Xmax-XX)/Xmax;
			DE[4] = (XX)/Xmax;

			if(I==0) {
				X = X+0.5;
				continue;
			}
			// add to integrated value
			if((I%2)==1) {
				// bin center
				fun = fun+4.0*(fgau+flin);
				for(Int_t k = 0; k<5; k++) {
					der[k] = der[k]+4.0*DE[k];
				}
				X = X+0.5;
				continue;
			}
			else {
				// upper bin edge
				fun = (fun+fgau+flin)/6.0;
				if(mdl!=0) fun = fmd[static_cast<Int_t>(II-1)]*fun;
				for(Int_t l = 0; l<5; l++) {
					der[l] = (der[l]+DE[l])/6.0;
					if(mdl!=0) der[l] = fmd[static_cast<Int_t>(II-1)]*der[l];
				}
			}

			// residuum
			res = hist[static_cast<Int_t>(II-1)]-fun;
			FY[static_cast<Int_t>(II-1)] = fun;

			// ... and weight for least square
			WT = 1.0;
			if(hist[static_cast<Int_t>(II-1)]!=0.0) WT = 1.0/fabs(hist[static_cast<Int_t>(II-1)]);
			if(!bgl) der[3] = 0.0;
			if(!bgr) der[4] = 0.0;

			// add to vector and matrix
			for(Int_t m = 0; m<5; m++) {
				R[m] = R[m]+WT*res*der[m];
				for(Int_t n = m; n<5; n++) {
					Q[n-m][m] = Q[n-m][m]+WT*der[m]*der[n];
				}
			}
			chiSum = chiSum+WT*res*res;
			// 60
			X = X+0.5;
		}

		// solve system of equations
		BandMatrix *Matrix = new BandMatrix();

		Matrix->GetSolution(Q,5,5,R,chsq);
		delp = delf;

		for(Int_t k = 0; k<5; ++k){
			PA[k] = PA[k]+R[k];
		}

		delf = chsq;
		// tests: peak inside histogram? ...
		if(PA[0]<0.0 || PA[0]>static_cast<Double_t>(NrBins)) {
			break;
		}

		// width and factor positive?
		if(PA[1]<=0.0 || PA[2]<=0.0) {
			break;
		}
		// chisquare per degree of freedom
		Chi2PerDegOfFreedom = 0.0;
		if((RightBackgrBin[PeakIndex]-LeftBackgrBin[PeakIndex]+1-NPA)>0) Chi2PerDegOfFreedom = chiSum/static_cast<Double_t>(RightBackgrBin-LeftBackgrBin+1-NPA);
		// convergence recognition
		if(iter==0) continue;
		if(delf<0.01 && TMath::Max(delp, chlSum-chiSum)<0.1) {

			// analyse background
			// 91
			L = 0;
			if(NPA==5) {
				// background assumed
				L = 4;
				if(PA[4]<PA[3]) L = 5;
			}
			else if(NPA==4) {
				// one-sided background
				L = 4;
				if(bgr) L = 5;
			}
			if(L!=0 && PA[L-1]<=0.0) {
				// assume no background at L-side
				PA[L-1] = 0.0;
				NPA = NPA-1;
				if(L==4) bgl = 0;
				if(L==5) bgr = 0;
				continue;
			}
			// analyse peak shape
			//92
			if(mdl!=0) return;
			sumu2 = 0.0;
			sumg2 = 0.0;
			sumun = 0.0;
			sumgn = 0.0;
			for(Int_t q = static_cast<Int_t>(LeftBackgrBin[PeakIndex]-1); q<static_cast<Int_t>(RightBackgrBin[PeakIndex]); q++) {
				X = static_cast<Double_t>(q)+0.5-PA[0];
				arg = -0.5*pow((X/PA[1]),2);
				if(arg<arglim) arg = arglim;
				WT = 1.0;
				if(hist[q]!=0.0) WT = 1.0/fabs(hist[q]);
				WT = WT*pow(FY[q],2);
				rat = hist[q]/FY[q]-1.0;
				sumu2 = sumu2+WT*rat*exp(arg)*X;
				sumg2 = sumg2+WT*rat*exp(arg)*(X*X-PA[1]*PA[1]);
				// underflows
				sumun = sumun+WT*pow((exp(arg)*X),2);
				sumgn = sumgn+WT*pow((exp(arg)*(X*X-PA[1]*PA[1])),2);
			}
			// test asymmetric modulation
			facu = sumu2/sumun;
			tstu = sumu2/sumgn;
			// test asymmetric modulation
			facg = sumg2/sumgn;
			tstg = sumg2/sqrt(sumgn);

			if(facg==0.0 && facu==0.0) return;
			mdl = 1;
			// calculate correction to gaussian
			PA[5] = PA[0];
			PA[6] = PA[1];
			PA[7] = facu;
			PA[8] = facg;

			for(Int_t r = static_cast<Int_t>(LeftBackgrBin[PeakIndex]); r<=static_cast<Int_t>(RightBackgrBin[PeakIndex]); r++) {
				X = static_cast<Double_t>(r)-0.5-PA[5];
				arg = -0.5*pow((X/PA[6]),2);
				if(arg<arglim) arg = arglim;
				addu = PA[7]*exp(arg)*X;
				addg = PA[8]*exp(arg)*(X*X-PA[6]*PA[6]);
				fmd[r-1] = 1.0+addu+addg;
			}
		}
	}

	// 99
	PA[0] = 0.0;
	PA[1] = 0.0;
	PA[2] = 0.0;
	// 100 return
}
