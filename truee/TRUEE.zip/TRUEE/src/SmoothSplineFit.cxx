//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

// smoothing of poisson distributed data
#include "SmoothSplineFit.h"
#include "TMath.h"
#include "math.h"
#include <iostream>
#include "TH1.h"
#include "TFile.h"

// ClassImp(splft)

using namespace std;

SmoothSplineFit::SmoothSplineFit() {

//	MaxNrOfCoeff=100;// = MBSP
//	MaxNrOfKnots=104;// MKNOT = MBSP+4

	//	KnotPosition[MaxNrOfKnots];// = T(mknot)
	NrNonZeroY=0;// = notz
	SumNonZeroYValues=0;// = sumy
	SumNonZeroZValues=0;// =sumz
	Peak = new SearchFitPeaks();
	SmoothObject = new SmoothingOperation();
	Matrix = new BandMatrix();
	Fit = new FitPolynomial;
}
SmoothSplineFit::~SmoothSplineFit() {
	delete Peak;
	delete SmoothObject;
	delete Matrix;
	delete Fit;
}


void SmoothSplineFit::SmoothAndFit(Double_t *y, Int_t NrYValues) {
	// SPLFT
	Int_t lneg=0, IA=-1, IB=-1, N=0;
	Double_t YS[256];
	Double_t z[256];// smoothed y-values
	Double_t YI=0;
	Double_t  arg=0;
	Double_t ZI=0;
	Double_t FDL=0;
	Double_t FDD=0;
	Double_t FDM=0;
	Int_t X=0;
	Int_t npeaks=0;

	//------check non-zero content of array and form sum-----
	for(Int_t i=0; i<NrYValues; ++i) {
		// NrYValues = number of Y values
		if(y[i] != 0) {
			if(y[i]<0) lneg=1;
			NrNonZeroY=NrNonZeroY+1;// NrNonZeroY = number of Y-values !=0
			if(IA==-1) IA=i;// IA is binnr of the first Y-value != 0
			IB=i;// IB is binnr of the last Y-value != 0
			SumNonZeroYValues=SumNonZeroYValues+fabs(y[i]);// sum of Y-values (!= 0) => SumNonZeroYValues
		}
	}

	N=IB-IA+1;// N = non-zero range of input histogram

	if(IB==-1 || N<5 || NrNonZeroY<5 || N>256) {
		cerr<<"*****!!!!!!!!!!!!! histogram will not be smoothed because of ..."<<endl;
		cerr<<"bin nr of last bin(==-1?)="<<IB<<" non zero bins(<5? or >256?)="<<N<<" NrNonZeroY(<5?)="<<NrNonZeroY<<endl;
		return;
	}

	// ------- transform non-zero part of array -----
	for(Int_t j=IA; j<=IB; ++j) {
		YS[j-IA]=y[j];// YS are values between IA and IB
		if(y[j] != 0.0) {
			YI=fabs(y[j]);
			y[j]=TMath::Sign(sqrt(YI)+sqrt(YI+1.0)-1.0, y[j]);
		}
	}

	//--------- Smoothing by piecewise fits of orthogonal polynomials -----
	// 4th derivative from result and definition of knot density
	Double_t Y[256];
	for(Int_t trafo=0; trafo<N; ++trafo) {
		Y[trafo]=y[trafo+IA];
	}

	Smooth(Y,N,z);

	//------------loops with spline fits--------
	for(Int_t loop=0; loop<2; ++loop) {
	//	cout<<"------------- loop in SmoothSplineFit -------------"<<loop<<endl;
		if(loop==1) {
			for(Int_t trafo=0; trafo<N; ++trafo) {
				// Trafo
				Y[trafo]=y[trafo+IA];
			}
		}
		//--------------- Spline fit using knot positions ----------------------------
		SplineFit(Y, N, z);
		for(Int_t rtrafo=0; rtrafo<N; ++rtrafo) {
			// backtrafo
			y[rtrafo+IA]=Y[rtrafo];
		}

		// inner zero regions of length > 2 are set to zero
		for(Int_t l=IA+1; l<IB; ++l) {
			if(y[l]==0.0) {
				// three zero values
				if(y[l-1]==0.0 && y[l+1]==0.0) z[l-IA]=0.0;
			}
		}

		//-----------  Backtransformation ------------
		// transform result back to z(.)
		SumNonZeroZValues=0.0;

		for(Int_t m=0; m<N; ++m) {
			ZI=fabs(z[m]);
			ZI=TMath::Sign(0.25*pow(((ZI+2.0)*ZI/(ZI+1.0)),2),z[m]);
			//result must be positive for positive input
			if(lneg==0 && ZI<0.0) ZI=0.0;
			z[m]=ZI;
			SumNonZeroZValues=SumNonZeroZValues+fabs(z[m]);
		}
		//--------- Search for peaks in smoothed array z and fit of gaussian to peaks, with improvement of knot density ----------
		if(loop==0) {
			Peak->SearchPeaks(z, N, npeaks);
			//cout<<"number of peaks found: "<<npeaks<<endl;
		}
		if(loop==0 && npeaks>0) {
			// differentiate knot density FD(.)
			FDL=0.0;
			for(Int_t n=0; n<N; ++n) {
				FDD=IntegAbsValue4Deriv[n]-FDL;//FD = integrated abs of fourth derivative
				FDL=IntegAbsValue4Deriv[n];
				IntegAbsValue4Deriv[n]=FDD;
			}
			// loop over peaks
			for(Int_t p=0; p<npeaks; ++p) {
				// define fit region...
				LeftBackgrBin=Peak->GetLeftBackgrBin(p);// left background bin
				RightBackgrBin=Peak->GetRightBackgrBin(p);// right background bin
				PeakSigma=Peak->GetPeakSigma(p);
				// skip if interval too narrow or peak broad
				if((RightBackgrBin-LeftBackgrBin)>=4 && PeakSigma<=10) {
					//...and redefine some start parameters
					Peak->SetPeakAbscissa(Peak->GetPeakAbscissa(p)-0.5, p);
					Peak->SetPeakOrdinate(Peak->GetPeakOrdinate(p)-Peak->GetPeakBackgr(p),p);
					// fit of gaussian peak to original data
					Peak->fitGauss(YS, N, p);
					PeakAbscissa=Peak->GetPeakAbscissa(p);
					PeakOrdinate=Peak->GetPeakOrdinate(p);
					if( PeakOrdinate > 0.0) {
						// increase knot density to FD(.)=1/sigma around peak
						FDM=0.99/TMath::Max(1.00,PeakOrdinate);
						for(Int_t q=0; q<N; ++q) {
							FDL=IntegAbsValue4Deriv[q];
							X=q+1;
							arg=fabs((X-PeakAbscissa)/PeakOrdinate);
							if(arg<3.0 && IntegAbsValue4Deriv[q]<FDM) {
								if(arg<2.0) {
									// inside 2 standard deviations
									IntegAbsValue4Deriv[q]=TMath::Max(IntegAbsValue4Deriv[q],FDM);
								}
								else {
									// 2 to 3 standard deviations
									IntegAbsValue4Deriv[q]=0.5*(IntegAbsValue4Deriv[q]+FDM);
								}
							}
						}
					}
				}
			}
			// sum up knot density
			SmoothObject->SumUp(IntegAbsValue4Deriv, N);
		}
	}

	// final normalization to sum of input distribution
	if(SumNonZeroZValues!=0.0) SumNonZeroZValues=1.0/SumNonZeroZValues;
	for(Int_t r=0; r<N; r++) {
		y[IA+r]=z[r]*SumNonZeroYValues*SumNonZeroZValues;
	}
}

void SmoothSplineFit::Smooth(Double_t *Y, Int_t N, Double_t *Z) {
	// SPOLYN
	// Smooth array Y(.) by fits of orthogonal polynomials. The result is
	// stored in array Z(.).
	// FD(.)      = integrated abs of fourth derivative
	//   R(.)       = r.h.s. for least squares fit
	//  Q(.)       = matrix for least square fit*/

	//cout<<"das ist spolyn"<<endl;
	Double_t  C[5], ZW[13], WW[13], ZW1[13], WW1[13];
	Double_t cut[]={0.0, 4.605, 7.779, 10.645, 13.362};
	Double_t EPS=0.01, EPS2=EPS*EPS, EPS4=EPS2*EPS2, zz[N];

	// copy data to Z and ...
	for(Int_t a=0; a<N; a++) {
		Z[a]=Y[a];
		Q[a]=0.0;
		IntegAbsValue4Deriv[a]=0.0;
	}

//	for(Int_t abc=0; abc<N; abc++) {
//		// cout<< "das ist Z"<<abc<<" vor dem Smoothen \t"<<Z[abc]<<endl;
//	}

	// ...smooth using simple 353QH method
	// call SPSARP(Z,N,-2)
	SmoothObject->smooth(Z,N);
	SmoothObject->SetMedian5(Z,N);
	SmoothObject->SetMedian3C(Z,N);
	SmoothObject->CorrFlatAreas(Z,N);
	SmoothObject->SetAverage3(Z,N);


//	for(Int_t abc=0; abc<N; abc++) {
//		//	cout<< "das ist Z"<<abc<<" nach dem Smoothen \t"<<Z[abc]<<endl;
//	}

	//----smooth using fits of orthogonal polynomial
	Int_t M=1;
	for(Int_t i=3; i<N-1; i++) {
		// maximum value of parameter M
		Int_t maxM=TMath::Min(TMath::Min(5,N-i-1),i-2);
		//			cout<<"MaxM in spolyn: "<<maxM<<"\tund M: "<<M<<endl;
		if(M>maxM) M=maxM;
		// fit and derivative around index i using default M value
		// trafo um von i-M-2 anfangen zu können
		for(Int_t trafo=0; trafo<(3+2*M); ++trafo) {
			zz[trafo]=Z[i-M-2+trafo];
		}
		Fit->FitOfOrthPolyn(zz, ZW, WW, 3+2*M, C);
		// backtrafo
		for(Int_t rtrafo=0; rtrafo<(3+2*M); ++rtrafo) {
			Z[i-M-2+rtrafo]=zz[rtrafo];
		}

		if(C[4]>cut[M-1] && M!=1) {
			// bad chi square - reduce interval
			M=M-1;
			for(Int_t trafo=0; trafo<(3+2*M); trafo++) {
				zz[trafo]=Z[i-M-2+trafo];
			}
			Fit->FitOfOrthPolyn(zz, ZW, WW, 3+2*M, C);
			for(Int_t rtrafo=0; rtrafo<(3+2*M); rtrafo++) {
				zz[rtrafo]=Z[i-M-2+rtrafo];
			}
			//if(C[4]<=cut[M-1]) cout<<"good chi square"<< endl;
			//else cout<<"still bad - use nevertheless"<<endl;
		}
		else if(C[4]<=cut[M-1]) {
			// good chi square - enlarge interval
			if(M<maxM) {
				// save values
				for(Int_t j=0; j<(2*M+1); j++) {
					ZW1[j]=ZW[j];
					WW1[j]=WW[j];
				}
				M=M+1;
				for(Int_t trafo=0; trafo<(3+2*M); trafo++) {
					zz[trafo]=Z[i-M-2+trafo];
				}
				Fit->FitOfOrthPolyn(zz, ZW, WW, 3+2*M, C);
				for(Int_t rtrafo=0; rtrafo<(3+2*M); rtrafo++) {
					Z[i-M-2+rtrafo]=zz[rtrafo];
				}
				//if(C[4]<=cut[M-1])
				if(C[4] > cut[M-1]) {
					//cout<<"good chi square"<<endl;
				//else {
					//cout<<"bad chi square - back to previous M value"<<endl;
					M=M-1;
					// restore previous values
					for(Int_t k=0; k<(2*M+1); k++) {
						ZW[k]=ZW1[k];
						WW[k]=WW1[k];
					}
				}
			}
		}
		// accumulate values and weights from fit
		Int_t K=0;
		for(Int_t l=i-M-1; l<i+M+2; l++) {
			K=K+1;
			Q[l-1]=Q[l-1]+WW[K-1];
			IntegAbsValue4Deriv[l-1]=IntegAbsValue4Deriv[l-1]+WW[K-1]*ZW[K-1];
		}
	}


	// determine result as weighted mean
	for(Int_t m=0; m<N; m++) {
		Z[m]=IntegAbsValue4Deriv[m]/Q[m];

	}
	// ...
	for(Int_t n=0; n<N; n++) {
		IntegAbsValue4Deriv[n]=Z[n];
	}
	// fourth derivative, ...
	// call SmoothingOperation(FD, N, 9)
	SmoothObject->FourthDerivative(IntegAbsValue4Deriv,N);
	// ... abs values ...
	// call SmoothingOperation(FD, N, 8)
	SmoothObject->GetAbs(IntegAbsValue4Deriv,N);
	// .. and hanning (average over three values)
	// call SmoothingOperation(FD, N, 6)
	SmoothObject->SetAverage3(IntegAbsValue4Deriv,N);

	// Transition to knot distances
	Double_t sum=0.0, H, ADD;
	for(Int_t p=0; p<N; p++) {
		// fourth root
		H=sqrt(sqrt(IntegAbsValue4Deriv[p]+EPS4)+3*EPS2)-EPS;
		Q[p]=H;
		// transform linear for small arguments, with maximum of 1-eps
		H=(1.0-exp(-0.5*H))*(1.0-EPS);
		IntegAbsValue4Deriv[p]=H;
		sum=sum+H;
	}
	// correct for a minimum of ... knots
	Double_t FMN=TMath::Max(3.0,static_cast<Double_t>(N)/13.0);
	if(sum<FMN) {
		ADD=(FMN-sum)/static_cast<Double_t>(N);
		for(Int_t q=0; q<N; q++) {
			IntegAbsValue4Deriv[q]=IntegAbsValue4Deriv[q]+ADD;
		}
	}
	// values smoothed by hanning
	SmoothObject->SetAverage3(IntegAbsValue4Deriv,N);

	// sum up
	SmoothObject->SumUp(IntegAbsValue4Deriv,N);
}

void SmoothSplineFit::SplineFit(Double_t *Y, Int_t N, Double_t *Z) {
	// FTSPLN
	// Smooth array Y(.) by spline fits using knot distances, determined from a
	// previous approximation in array Z(.). The result is stored in array Z(.)

	// reset optimal NB value and corresponding chi square sum
	Int_t nbopt=0;
	Int_t NrOfParameter=0;
	Int_t L=0;
	Int_t nsum=0;
	Int_t Inul=0;
	Int_t IJ=0;
	Int_t NB=0;
	Double_t Chi2Sum=0.0;
	Double_t Yfraction=0.0;
	Double_t YL=0.0;
	Double_t qq[5][63];
	Double_t AR=0;
	Double_t Chi2;
	Double_t fun;
	Double_t delta=0;
	Double_t rhsLeastSquares[100];// right hand side of the least square fit

	// determine number of inner knot positions
	Double_t NrInnerKnotPos=TMath::Max(1.0,IntegAbsValue4Deriv[N-1]+0.5);
	// three iterations and fourth one with optimal number
	for(Int_t loop=0; loop<4; ++loop) {
		NB=TMath::Min(TMath::Min(57, static_cast<Int_t>(NrInnerKnotPos+loop)),TMath::Min(N-4,static_cast<Int_t>(NrInnerKnotPos+loop)));
		if(NB<1) NB=1;

		// finally use optimal value of NB
		if(loop==3) NB=nbopt;

		//  definition of NB+1 different knots
		L=0;

		// define NB+1 different knots
		for(Int_t i=0; i<=NB; i++) {
			// fraction of total
			Yfraction=static_cast<Double_t>(i)/static_cast<Double_t>(NB)*IntegAbsValue4Deriv[N-1];
			if(L!=0) {
				if(Yfraction<IntegAbsValue4Deriv[L-1]) L=0;// soll hier L-1 sein, oder doch L?
			}

			// determine index L
			while(Yfraction>=IntegAbsValue4Deriv[L] && L<(N-1)) {
				L=L+1;
			}
			if(L==0) {
				YL=0;
			}
			else {
				YL=IntegAbsValue4Deriv[L-1];
			}
			KnotPosition[i+3]=(static_cast<Double_t>(L)+(Yfraction-YL)/(IntegAbsValue4Deriv[L]-YL))/static_cast<Double_t>(N);
		}

		// ... and repeat initial and final knots
		for(Int_t j=0; j<3; j++)
		{
			KnotPosition[j]=KnotPosition[3];
			KnotPosition[NB+4+j]=KnotPosition[NB+3];
		}
		// number of knots
		NrKnotsSplineFit=NB+7;
		// ... and number of parameters
		NrOfParameter=NrKnotsSplineFit-4;
		if(loop!=3) {
			// fit, using integral over bin, in one iteration
			for(Int_t k=0; k<NrOfParameter; k++) {
				rhsLeastSquares[k]=0.0;
			}
			for(Int_t l=0; l<(5*NrOfParameter); l++) {
				Q[l]=0.0;
			}
			// form normal equations
			Inul=0;
			for(Int_t m=0; m<=(2*N); m++) {
				calculateBSpline4Function(0.5*static_cast<Double_t>(m)/static_cast<Double_t>(N), B);
				AR=rhsLeastSquares[I0]*B[0]+rhsLeastSquares[I0+1]*B[1]+rhsLeastSquares[I0+2]*B[2]+rhsLeastSquares[I0+3]*B[3];
				if(m!=0) {
					nsum=I0-Inul+4;
					if((m%2)==1) {
						//  middle point of bin
						for(Int_t n=0; n<4; n++) {
							der[I0-Inul+n]=der[I0-Inul+n]+4.0*B[n];
						}
						continue;
					}
					else {
						//  left edge of bin
						for(Int_t p=0; p<4; p++) {
							der[I0-Inul+p]=der[I0-Inul+p]+B[p];
						}
					}
					for(Int_t q=0; q<5; q++) {
						der[q]=der[q]/6.0;
					}
					// Add to normal equations
					for(Int_t r=0; r<5; r++) {
						rhsLeastSquares[r+Inul]=rhsLeastSquares[r+Inul]+der[r]*Y[m/2-1];
						IJ=5*(r+Inul);
						for(Int_t s=r; s<5; s++) {
							IJ=IJ+1;
							Q[IJ-1]=Q[IJ-1]+der[r]*der[s];
						}
					}
					// skip at last edge of last interval
					if(m==(2*N)) continue;
				}
				// left edge of bin
				Inul=I0;
				for(Int_t t=0; t<4; t++) {
					der[t]=B[t];
				}
				der[4]=0.0;
			}

			// solve system ...
			// convert Q[index] to qq[band][row]
			//-----------------------------------------------------------------------
			Int_t ijk=0, lmn=5;
			for(Int_t trafo=0; trafo<NrOfParameter; trafo++) {
				qq[0][trafo]=Q[ijk];// diagonal elements
				//	if(trafo>=(NrOfParameter-4)) lmn--;
				ijk=ijk+lmn;
			}
			ijk=1; lmn=5;
			for(Int_t trafo1=0; trafo1<(NrOfParameter); trafo1++) {
				qq[1][trafo1]=Q[ijk];// elements adjacent to diagonal elements (in the same line)
				//	if(trafo1>=(NrOfParameter-4)) lmn--;
				ijk=ijk+lmn;
			}
			ijk=2; lmn=5;
			for(Int_t trafo2=0; trafo2<(NrOfParameter); trafo2++) {
				qq[2][trafo2]=Q[ijk];
				//	if(trafo2>=(NrOfParameter-4)) lmn--;
				ijk=ijk+lmn;
			}
			ijk=3; lmn=5;
			for(Int_t trafo3=0; trafo3<(NrOfParameter); trafo3++) {
				qq[3][trafo3]=Q[ijk];
				ijk=ijk+lmn;
			}
			ijk=4; lmn=5;
			for(Int_t trafo4=0; trafo4<(NrOfParameter); trafo4++) {
				qq[4][trafo4]=Q[ijk];
				ijk=ijk+lmn;
			}
			//-------------------------------------------------------------------------------
			Matrix->GetSolution(qq, 5, NrOfParameter, rhsLeastSquares, delta);
		}
		else {
			// copy best fit
			for(Int_t u=0; u<NrOfParameter; u++) {
				rhsLeastSquares[u]=A[u];
			}
		}
		// reconstruct fitted data with integral over bin
		Chi2=0.0;
		fun=0.0;

		for(Int_t v=0; v<=(2*N); v++) {
			calculateBSpline4Function(0.5*static_cast<Double_t>(v)/static_cast<Double_t>(N),B);
			AR=rhsLeastSquares[I0]*B[0]+rhsLeastSquares[I0+1]*B[1]+rhsLeastSquares[I0+2]*B[2]+rhsLeastSquares[I0+3]*B[3];
			if(v!=0) {
				if((v%2)==1) {
					// middle point of bin
					fun=fun+4.0*AR;
					continue;
				}
				else {
					// left edge of bin
					fun=(fun+AR)/6.0;
				}
				Z[v/2-1]=fun;
				// ... and add to chi square sum
				Chi2=Chi2+pow((Y[v/2-1]-fun),2);
			}
			fun=AR;
		}
		// divide by ndf
		Chi2=Chi2/static_cast<Double_t>(N-NrOfParameter);

		if(loop<3) {
			// compare chi square from fit ...
			if(loop==0 || Chi2<Chi2Sum) {
				// ... and save best fit result
				nbopt=NB;
				Chi2Sum=Chi2;
				for(Int_t w=0; w<NrOfParameter; w++) {
					A[w]=rhsLeastSquares[w];
				}
			}
		}
	}
}

void SmoothSplineFit::calculateBSpline4Function(Double_t X, Double_t *Bspline) {
	// BSPLN4
	// determination of index L for knot interval for x
	Int_t IL=4, IR=NrKnotsSplineFit-3, L=0;
	Double_t XX=TMath::Min(TMath::Max(X,KnotPosition[IL-1]), KnotPosition[IR-1]), DR[4], DL[4], SV=0.0, TR=0.0;

	if(XX<KnotPosition[IR-1]) {
		// binary search
		// 10
		L=(IL+IR)/2;
		while(KnotPosition[L-1]>XX || XX>KnotPosition[L]) {
			if(XX<KnotPosition[L-1]) {
				IR=L;
			}
			else if(XX>KnotPosition[L]) {
				IL=L+1;
			}
			L=(IL+IR)/2;
		}
		// case of multiple knots
		while(XX==KnotPosition[L]) {
			L=L+1;
		}
	}
	else {
		// case of multiple knots right end
		//	XX = right hand side
		L=IR;
		while(XX<=KnotPosition[L-1]) {
			L=L-1;
		}
	}

	I0=L-4;

	// compute B(1) ... B(4) for given x
	Bspline[0]=1.0;

	for(Int_t j=0; j<3; j++) {
		DR[j]=KnotPosition[L+j]-X;
		DL[j]=X-KnotPosition[L-j-1];
		SV=0.0;
		for(Int_t i=0; i<=j; i++) {
			TR=Bspline[i]/(DR[i]+DL[j-i]);
			Bspline[i]=SV+DR[i]*TR;
			SV=DL[j-i]*TR;
		}
		Bspline[j+1]=SV;
	}

	for(Int_t k=0; k<4; k++) {
                if(Bspline[k]<pow(10.,-14.)) Bspline[k]=0.0;
	}
}
