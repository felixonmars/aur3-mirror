//	author: Martin Schmitz <martin.schmitz@uni-dortmund.de>
//	Dortmund, 2012
//	==========

#include <Frontend.h>
#include <sstream>
#include "TProfile.h"
#include "trueedata.h"
#include <TLatex.h>
#include<TGraphErrors.h>

#include<TrueeCovariance.h>

using namespace std;

Frontend::Frontend(string filename){

    InputObject = new Input();

    pathcheck = ReadIn(filename);


    fResultFile = new TFile(InputObject->getoutputpath()+"TrueeResultFile.root", "RECREATE");



    TDirectory *corrplotdir =     fResultFile->mkdir("Correlationplots");
    corrplotdir->mkdir("Obs_Obs");
    corrplotdir->mkdir("Obs_X");
    fResultFile->cd();

    fResultFile->mkdir("CheckUnfolding");
    fResultFile->mkdir("DataPointCorrelation");

    fResultFile->mkdir("Data MC comparisons");
    //   fResultFile->mkdir("PullResults");
    fResultFile->mkdir("TestResults");
    fResultFile->mkdir("RealDataResults");
    fResultFile->mkdir("MonteCarlo_Information");
    fResultFile->Close();







    // fCorrelationFile = new TFile(InputObject->getoutputpath()+"Correlations.root", "RECREATE");

    //fCorrelationFile->Close();

    ii = 0;
    jj = 0;
    ll = 0;

    pullIndex=0;


    corrflag=false;




}

int Frontend::ReadIn(string filename){

    //----------------- input of steering parameters ------------------
    // change path for the steer file "parameter.config", if it is not in the "build/bin"-directory:
    if(filename == " ")
        pathSteerFile = "./parameter.config";
    else
        pathSteerFile = filename;

    Int_t pathCheck = InputObject->ParameterInput(pathSteerFile);
    if(pathCheck == 0)
        return 0;


    Pullmode = InputObject->GetPullmode();
    // define user function
    //Double_t (*func)(Double_t);

    funcFlag = InputObject->GetMCFuncFlag();
    if(funcFlag == 1) {
        formula = InputObject->GetMCFormula();
        binMin = InputObject->GetWantedXLowLimit();
        binMax = InputObject->GetWantedXHighLimit();
        func = new TF1("mcUserFunction", formula, binMin, binMax);
        //-------- plot function of generated MC events ----------------------
        fUserFunction = new TFile("PlotUserFunction.root", "RECREATE");
        userFunction = func;
        userFunction->SetTitle("user defined f(x) function (generated MC events)");
        userFunction->Write();
        fUserFunction->Close();
        fUserFunction->Delete();
    }


    // initialize parameters
    NrBinsResult = InputObject->GetNrBinsResult();
    NrBinsResultMaxUser = InputObject->getNrBinsResultMaxUser();
    nr2DHistos = NrBinsResultMaxUser - NrBinsResult + 1;

    NrKnotsMaxUser = InputObject->getNrKnotsMaxUser();

    NrDegreeOfFreedomMaxUser = InputObject->getNrDegreeOfFreedomMaxUser();
    NrDegreeOfFreedomStart = InputObject->GetNrDegreeOfFreedom();
    BackEventNr = 0;
    NrBinsMCMax = InputObject->GetNrBinsMCMax();

    // create histograms for parameter checking

    infoLCurve.open("info-L-Curve-numbers.dat");
    infoLCurve<<"information about the coding of entries in the L-Curve-like plots"<<endl;
    MinUnfFit = 0.0;


    NrKnotsStart = InputObject->GetNrKnots();
    if(NrKnotsStart <= 0) {
        cerr<<"****** ERROR: (initial) number of knots = "<<NrKnotsStart<<endl;
        return 0;
    }
    if(NrBinsResult == 0 && NrBinsResultMaxUser > 0) {
        cerr<<"****** ERROR: please give either initial and maximum number of bins for the final histogram"<<endl;
        cerr<<"             or only the bin_limits"<<endl;
        cerr<<"             or comment out all binning settings or set them to zero (automatical binning)"<<endl;
        return 0;
    }
    printflag = InputObject->getPrintflag();






    return 1;


}


TrueeResult* Frontend::unfold(int NrBinsResult, int NrDegreeOfFreedom, int NrKnots){



    if(Pullmode && pullIndex ==0)
        pullIndex++;

    if(printflag > 0){
        cout << "\n \n \n*************************************";
        cout <<   "\n*\tnumber of degrees of freedom = "<<NrDegreeOfFreedom<<
                  "\n*\tnumber of Bins = "<<NrBinsResult<<
                  "\n*\tnumber of Knots = "<<NrKnots<<endl;

        if(Pullmode){
            cout<<"*\tpull number = "<<pullIndex<<endl;
        }
        cout << "*************************************"<<endl;

    }

    InputObject->setNrKnots(NrKnots);
    InputObject->setNrDegreeOfFreedom(NrDegreeOfFreedom);
    InputObject->setNrBinsResult(NrBinsResult);
    InputObject->SourceFilesInput(pullIndex);

    Pass1Object = new Preprocessor(InputObject);

    //--------------- read data, determine min and max values of variables --------------
    Pass1Object->ReadWrite("DATA");
    Pass1Object->ReadWrite("MOCA");

    if(corrflag) {
        for(int i = 0; i < InputObject->GetNrAllMeasuredVariables(); i++){
            Plot_MCInformation("DATA", InputObject->getNameObsY(i),i);
            for(int j = i+1; j < InputObject->GetNrAllMeasuredVariables(); j++){
                Plot_XYCorrelation_Observables("MOCA",InputObject->getNameObsY(i),InputObject->getNameObsY(j),i,j);
            }
        }
        if(InputObject->getTestmode()){
            for(int i = 0; i < InputObject->GetNrAllMeasuredVariables(); i++){
                Plot_XYCorrelation_Observables("MOCA",InputObject->getNameObsY(i),InputObject->getNameWantedX(),i,-1);

            }
        }
        //------------ efficiency output on the screen ----------------
        if(InputObject->getPrintflag() == 1 && jj == 0)
            Pass1Object->StatisticAndEfficiency();


        corrflag=false;
    }


    if(BackEventNr!=0) {
        Pass1Object->ReadWrite("BKGD");
    }
    //---------- check bin limits, define min and max values ----------------
    Pass1Object->DetermineLimits();

    //---------- fit spline function to the f(x)-MC histogram --------
    //if(funcFlag == 0) { // this condition refers only to fit, but here also smoothing happens
    // this method should be split into two
    Pass1Object->FitMCHistogram();
    //}
    //---------------- for the f(x)-MC function -----------------
    NrBinsMCMax = InputObject->GetNrBinsMCMax();
    Double_t Coeff[NrBinsMCMax];
    for(Int_t a=0; a<NrBinsMCMax; ++a) {
        Coeff[a]=Pass1Object->getCoeff(a);
    }
    NrBinsMC = Pass1Object->GetNrBinsMC();
    // get MC f(x) function of generated events (user defined or from spline fit)
    // without the normalization factor Gamma
    FxFunctionMC *MCFunctionFxCheck = new FxFunctionMC(InputObject, Coeff, 1, NrBinsMC, func);
    //----------- Normalization -----------------
    Pass1Object->Normalization(MCFunctionFxCheck);
    delete MCFunctionFxCheck;
    // get MC f(x) function with normalization factor Gamma
    FxFunctionMC *MCFunctionFx = new FxFunctionMC(InputObject, Coeff, (Pass1Object->getGamma()), NrBinsMC, func);

    Processor *Pass2Object = new Processor(InputObject, Pass1Object, MCFunctionFx);
    //-------------- preparations for the 3 dimensional histograms --------
    Pass2Object->PrepareWeights(funcFlag);
    //------------- fill n-dimensional histograms -----------------
    for(Int_t loop = 0; loop<2; ++loop) {
        Pass2Object->ClearHistogramSpace(loop);
        Pass2Object->FillHistogram("DATA", loop);

        Pass2Object->FillHistogram("MOCA", loop);

        if(BackEventNr != 0)
            Pass2Object->FillHistogram("BKGD", loop);
        if(loop == 0){

            Pass2Object->SetCompactIndex();
        }
    }

    //------------- unfolding fit ----------------------

    Pass2Object->RegUnfolding(InputObject);

    // -------------- find optimal parameters (NrKnots, NrBins, NrDegFree) ---------------
    NrDegreeOfFreedom = InputObject->GetNrDegreeOfFreedom();
    if(Pullmode == 0) {

        //hLCurve->Fill(Pass2Object->GetFitMin(), Pass2Object->getChi2pValue50(), jj+1);
        infoLCurve<<jj+1<<":\t"<<"bins = "<<NrBinsResult<<" knots = "<<NrKnots<<" degFree = "<<NrDegreeOfFreedom<<" corr. = "<<(Pass2Object->getChi2pValue50());
        if((InputObject->getTestmode()) == 1) {

            Pass2Object->Comparisons("test", InputObject);
            //if(jj == 0) MinUnfFit=Pass2Object->getRealChi();
            //else if(MinUnfFit > (Pass2Object->getRealChi())) MinUnfFit = Pass2Object->getRealChi();
            //          infoLCurve<<" tm-chi2 = "<<(Pass2Object->getChi2TestModeCompare())<<" kolm. = "<<(Pass2Object->getKolmogorovValue());
        }
        infoLCurve<<endl;
    }
    else if(pullIndex > 0){

        Pass2Object->Comparisons("pull", InputObject);
    }


    vector<double> temp_result;
    vector<double> temp_result_error;
    vector<double> temp_mc_truth;

    vector<double> temp_nondiffresult;
    vector<double> temp_nondiffresult_error;
    vector<double> temp_bincenter;

    for(int i = 0; i < NrBinsResult; ++i){
        temp_result.push_back(Pass2Object->get_BinContentResult(i));

        temp_result_error.push_back(Pass2Object->get_BinErrorResult(i));

        temp_nondiffresult.push_back(Pass2Object->Getnondiff_Result(i));

        temp_nondiffresult_error.push_back(Pass2Object->Getnondiff_Error(i));

        temp_bincenter.push_back(Pass2Object->GetBinCenter(i));

        if(InputObject->getTestmode() == true || (InputObject->GetPullmode() == true && pullIndex >0))
            temp_mc_truth.push_back(Pass2Object->get_RealContent(i));
    }

    TrueeResult *TR = new TrueeResult();
    TR->add(temp_result,temp_result_error,temp_mc_truth,Pass2Object->getChi2pValue50(),Pass2Object->getKolmogorovValue(),Pass2Object->getChi2TestModeCompare(),NrBinsResult, NrKnots, NrDegreeOfFreedom, Pass2Object->GetFitMin(),Pass2Object->GetRegularizationTerm());
    TR->set_bincenter(temp_bincenter);
    TR->set_ndiff_error_of_result(temp_nondiffresult_error);
    TR->set_ndiff_result(temp_nondiffresult);
    // ---------- check unfolded result by reweighting the MC observables and comparing with data -----------------

    if(jj == 0) {
        nrBinsMin = NrBinsResult;
        Pass2Object->ResetHistogram();

        Pass2Object->CheckUnfolding("DATA");

        Pass2Object->CheckUnfolding("MOCA");

        if(BackEventNr > 0) {
            Pass2Object->CheckUnfolding("BKGD");
        }

        Pass2Object->PrintHistogram(InputObject);

    }


    delete MCFunctionFx;
    delete Pass2Object;
    delete Pass1Object;
    jj++; ll++;

    infoLCurve.close();

    ii++;

    if(InputObject->GetPullmode() ==true)
        pullIndex++;



    return TR;

}

vector<TrueeResult*> Frontend::testmode(){

    vector<TrueeResult*> Resultvector;

    int maxndf = InputObject->getNrDegreeOfFreedomMaxUser();
    int minndf = InputObject->GetNrDegreeOfFreedom();

    int minbins = InputObject->GetNrBinsResult();
    int maxbins = InputObject->getNrBinsResultMaxUser();

    int minknots = InputObject->GetNrKnots();
    int maxknots = InputObject->getNrKnotsMaxUser();
    //unfold(minbins,minndf,minknots);
    bool covariance = false;
    if(covariance){
        TrueeCovariance* cov = new TrueeCovariance();

        cov->SetPath((string) InputObject->GetSourceFileMC(0),(string) InputObject->GetSourceTreeMC(0));
        cov->SetWantedX((string) InputObject->getNameWantedX());
        cov->SetCorrLimit(0.5);
        cov->SetLogX(InputObject->getLogOptionX());

        TFile *fPull = TFile::Open(InputObject->getoutputpath()+"TrueeResultFile.root", "UPDATE", "", 0);


        TCanvas* covariancecanvas = cov->GetCorrelationPlot();

        covariancecanvas->Write();

        fPull->Close();
    }

    //Resultvector.resize((maxbins-minbins-1)*(maxknots-minknots+1)*(maxndf-minndf+1));
    corrflag = true;
    for(int bins =minbins; bins <= maxbins; ++bins){
        for(int knots = minknots; knots <= maxknots; ++knots){
            for(int ndf = minndf; ndf <= maxndf; ndf++){

                Resultvector.push_back(unfold(bins,ndf,knots));
                if(ndf == minndf&&knots==minknots&&bins==minbins){
                    corrflag = false;
                }
            }
        }
    }



    return Resultvector;
}

vector< vector<TrueeResult*> > Frontend::pullmode(){

    vector< vector<TrueeResult*> > Pullmode_Results;

    Int_t maxndf = InputObject->getNrDegreeOfFreedomMaxUser();
    Int_t minndf = InputObject->GetMinNrDegreeOfFreedom();

    Int_t minbins = InputObject->GetMinNrBinsResult();
    Int_t maxbins = InputObject->getNrBinsResultMaxUser();

    Int_t minknots = InputObject->GetMinNrKnots();
    Int_t maxknots = InputObject->getNrKnotsMaxUser();
    Int_t pulls = InputObject->GetNrPulls();
    Int_t NrBinsResult = InputObject->GetNrBinsResult();


    corrflag = true;

    //for(Int_t bins =minbins; bins <= maxbins; ++bins){
        for(Int_t knots = minknots; knots <= maxknots; ++knots){
            for(Int_t ndf = minndf; ndf <= maxndf; ndf++){
                vector<TrueeResult*> Resultvector_for_one_loop;
                for(Int_t i = 0; i < pulls; i++){
                    InputObject->setNrBinsResult(NrBinsResult);
                    Resultvector_for_one_loop.push_back(unfold(NrBinsResult,ndf,knots));
                    if(ndf == minndf&&knots==minknots){
                        corrflag = false;
                    }
                }
                Pullmode_Results.push_back(Resultvector_for_one_loop);
            }
        }
  //  }
    return Pullmode_Results;


}

vector<TrueeResult*> Frontend::result_suppression(vector<TrueeResult*> TestResults){

    //
    // get the maximum values
    //
    double MaxDPC = InputObject->GetResultSuppression_DPC();
    double MaxKolmo = InputObject->GetResultSuppression_Kolmogorov();
    double MaxChi2 = InputObject->GetResultSuppression_ChiSquare();

    for(int i = 0; i < TestResults.size(); ++i){

        if( ( MaxDPC < TestResults.at(i)->get_DPC()  && MaxDPC != -1) || ( MaxChi2 < TestResults.at(i)->get_chisquare()   && MaxChi2 != -1) || ( MaxKolmo  > TestResults.at(i)->get_kolmogorov()  && MaxKolmo != -1)){
            TestResults.erase(TestResults.begin()+i);
            i--;    // removed one element, need that so every element of the new vector was checked
        }
    }

    return TestResults;


}



void Frontend::plot_testmode(vector<TrueeResult *> Resultvector){

    TFile *fCheckParameters;
    fCheckParameters = new TFile(InputObject->getoutputpath()+"TrueeResultFile.root", "UPDATE");


    TDirectory *qualdir =     fCheckParameters->mkdir("Testmode_Overview");
    fCheckParameters->cd("Testmode_Overview");



    /***************************************
   *   find plotlimits                             *
    ***************************************/


    double min_kolmogorov, max_kolmogorov;
    double min_DPC = 1e10;
    double max_DPC = -1e10;
    double min_chisquare = 1e10;
    double max_chisquare = -1e10;
    int min_bins =1000;
    int max_bins=-1;
    int min_knots =1000;
    int max_knots=-1;
    int min_ndf =1000;
    int max_ndf=-1;
    stringstream ss;


    for(int k = 0; k < Resultvector.size();++k){
        if(Resultvector.at(k)->get_bins() < min_bins)  min_bins = Resultvector.at(k)->get_bins();
        if(Resultvector.at(k)->get_bins() > max_bins)  max_bins = Resultvector.at(k)->get_bins();
        if(Resultvector.at(k)->get_knots() < min_knots)  min_knots = Resultvector.at(k)->get_knots();
        if(Resultvector.at(k)->get_knots() > max_knots)  max_knots = Resultvector.at(k)->get_knots();
        if(Resultvector.at(k)->get_ndf() < min_ndf)  min_ndf = Resultvector.at(k)->get_ndf();
        if(Resultvector.at(k)->get_ndf() > max_ndf)  max_ndf = Resultvector.at(k)->get_ndf();
        if(Resultvector.at(k)->get_chisquare() > max_chisquare) max_chisquare = Resultvector.at(k)->get_chisquare();
        if(Resultvector.at(k)->get_chisquare() < min_chisquare) min_chisquare = Resultvector.at(k)->get_chisquare();

    }


    vector<TCanvas *> QualPlots;
    stringstream title;

    for(int i = max_bins; i >= min_bins; --i){
        title << "Quality overview for " << i << " bins";
        QualPlots.push_back(new TCanvas(title.str().c_str(),title.str().c_str(),1280,960));
        title.str("");
    }

    /***************************************
    *   plot L-Curve                              *
    ***************************************/

    TH2D *hLCurveTestMode = new TH2D("likeLCurveTest","test like L-curve (subsequently weighted) - label is 1000*knots+ndf",100, min_chisquare, max_chisquare, 100, 0,0);
    double label;
    for(int k = 0; k < (int) Resultvector.size();++k){
        label = 1e3*Resultvector.at(k)->get_knots()+Resultvector.at(k)->get_ndf();
        hLCurveTestMode->Fill(Resultvector.at(k)->get_chisquare(),Resultvector.at(k)->get_DPC(),label);
    }

    hLCurveTestMode->SetOption("text");
    hLCurveTestMode->SetMarkerStyle(3);
    hLCurveTestMode->SetMarkerColor(4);
    hLCurveTestMode->SetMarkerSize(1.7);
    hLCurveTestMode->GetYaxis()->SetTitle("data point correlation");
    hLCurveTestMode->GetXaxis()->SetTitle("unfolded result #Chi^{2}");

    hLCurveTestMode->Write();

    // plot L-Curve (bin wise)

    cTestModeLCurve="likeLCurveTest_nrBins_";
    for(int i = max_bins; i >= min_bins; --i){
        ss<<cTestModeLCurve<<i;

        TH2D* temp = new TH2D (ss.str().c_str(),"(Binwise) L-Curve - label is 1000*knots+ndf",100,0,0,100,0,0);

        temp->GetYaxis()->SetTitle("data point correlation");
        temp->GetXaxis()->SetTitle("unfolded result #Chi^{2}");
        temp->SetOption("text");
        temp->SetMarkerStyle(3);
        temp->SetMarkerColor(4);
        temp->SetMarkerSize(1.7);
        hTestCompareLCurve.push_back(temp);
        ss.str("");
    }

    for(int k = 0; k < Resultvector.size();++k){
        label = 1e3*Resultvector.at(k)->get_knots()+Resultvector.at(k)->get_ndf();
        hTestCompareLCurve.at(max_bins-Resultvector.at(k)->get_bins())->Fill(Resultvector.at(k)->get_chisquare(),Resultvector.at(k)->get_DPC(),label);

    }
    for(int k = 0; k<hTestCompareLCurve.size();k++){
        hTestCompareLCurve.at(k)->Write();
    }

    /***************************************
    *   plot Reg-Curve                              *
    ***************************************/

    TH2D *hRCurveTestMode = new TH2D("RegCurveTest","test like Reg-curve - label is 1000*knots+ndf",100, 0, 0, 100, 0,0);
    //double label;
    for(int k = 0; k < (int) Resultvector.size();++k){
        label = 1e3*Resultvector.at(k)->get_knots()+Resultvector.at(k)->get_ndf();
        //cout << Resultvector.at(k)->GetFitMin() <<"\t"<<Resultvector.at(k)->GetRegTerm()<<endl;
        if(Resultvector.at(k)->GetRegTerm() != 0)
            hRCurveTestMode->Fill(Resultvector.at(k)->GetFitMin(),Resultvector.at(k)->get_DPC(),label);
    }

    hRCurveTestMode->SetOption("text");
    hRCurveTestMode->SetMarkerStyle(3);
    hRCurveTestMode->SetMarkerColor(4);
    hRCurveTestMode->SetMarkerSize(1.7);
    hRCurveTestMode->GetYaxis()->SetTitle("data point correlation");
    hRCurveTestMode->GetXaxis()->SetTitle("fit minimum [a.u]");

    hRCurveTestMode->Write();

//    // plot L-Curve (bin wise)

//    cTestModeLCurve="likeLCurveTest_nrBins_";
//    for(int i = max_bins; i >= min_bins; --i){
//        ss<<cTestModeLCurve<<i;

//        TH2D* temp = new TH2D (ss.str().c_str(),"(Binwise) L-Curve - label is 1000*knots+ndf",100,0,0,100,0,0);

//        temp->GetYaxis()->SetTitle("data point correlation");
//        temp->GetXaxis()->SetTitle("unfolded result #Chi^{2}");
//        temp->SetOption("text");
//        temp->SetMarkerStyle(3);
//        temp->SetMarkerColor(4);
//        temp->SetMarkerSize(1.7);
//        hTestCompareLCurve.push_back(temp);
//        ss.str("");
//    }

//    for(int k = 0; k < Resultvector.size();++k){
//        label = 1e3*Resultvector.at(k)->get_knots()+Resultvector.at(k)->get_ndf();
//        hTestCompareLCurve.at(max_bins-Resultvector.at(k)->get_bins())->Fill(Resultvector.at(k)->get_chisquare(),Resultvector.at(k)->get_DPC(),label);

//    }
//    for(int k = 0; k<hTestCompareLCurve.size();k++){
//        hTestCompareLCurve.at(k)->Write();
//    }





    // Kolmo vs Knots && Ndf per bin
    cTestModeKolmog="Kolmogorov_nrBins_";
    for(int i = max_bins; i >= min_bins; --i){
        ss<<cTestModeKolmog<<i;

        TH2D* temp = new TH2D (ss.str().c_str(),"Kolmogorov vs. parameter",2*(max_ndf-min_ndf+2), min_ndf-1-0.25,max_ndf+1-0.25,2*(max_knots-min_knots+2), min_knots-1-0.25, max_knots+1-0.25);

        temp->GetYaxis()->SetTitle("number of knots");
        temp->GetXaxis()->SetTitle("number of degrees of freedom");
        temp->SetOption("colz");
        hKolmogorovTest.push_back(temp);
        ss.str("");
    }

    for(int k = 0; k < Resultvector.size();++k){

        hKolmogorovTest.at(max_bins-Resultvector.at(k)->get_bins())->Fill(Resultvector.at(k)->get_ndf(),Resultvector.at(k)->get_knots(),Resultvector.at(k)->get_kolmogorov());

    }
    for(int k = 0; k<hKolmogorovTest.size();k++){
        hKolmogorovTest.at(k)->Write();
    }


    // chisquare vs Knots && Ndf per bin
    cTestModeChi2="chisquare_nrBins_";
    for(int i = max_bins; i >= min_bins; --i){
        ss<<cTestModeChi2<<i;

        TH2D* temp = new TH2D (ss.str().c_str(),"chi square vs. parameter",2*(max_ndf-min_ndf+2), min_ndf-1-0.25,max_ndf+1-0.25,2*(max_knots-min_knots+2), min_knots-1-0.25, max_knots+1-0.25);

        temp->GetYaxis()->SetTitle("number of knots");
        temp->GetXaxis()->SetTitle("number of degrees of freedom");
        temp->SetOption("colz");
        hTestCompareChi2.push_back(temp);
        ss.str("");
    }

    for(int k = 0; k < Resultvector.size();++k){

        hTestCompareChi2.at(max_bins-Resultvector.at(k)->get_bins())->Fill(Resultvector.at(k)->get_ndf(),Resultvector.at(k)->get_knots(),Resultvector.at(k)->get_chisquare());

    }
    for(int k = 0; k<hTestCompareChi2.size();k++){
        hTestCompareChi2.at(k)->Write();
    }

    // DPC vs Knots && Ndf per bin
    cDataPointCorr="DPC_nrBins_";
    for(int i = max_bins; i >= min_bins; --i){
        ss<<cDataPointCorr<<i;

        TH2D* temp = new TH2D (ss.str().c_str(),"DPC vs. parameter",2*(max_ndf-min_ndf+2), min_ndf-1-0.25,max_ndf+1-0.25,2*(max_knots-min_knots+2), min_knots-1-0.25, max_knots+1-0.25);

        temp->GetYaxis()->SetTitle("number of knots");
        temp->GetXaxis()->SetTitle("number of degrees of freedom");
        temp->SetOption("colz");
        hTestCompareDPC.push_back(temp);
        ss.str("");
    }

    for(int k = 0; k < Resultvector.size();++k){

        hTestCompareDPC.at(max_bins-Resultvector.at(k)->get_bins())->Fill(Resultvector.at(k)->get_ndf(),Resultvector.at(k)->get_knots(),Resultvector.at(k)->get_DPC());

    }
    for(int k = 0; k< hTestCompareDPC.size();k++){
        hTestCompareDPC.at(k)->Write();
    }

    fCheckParameters->cd();

    for(int i = max_bins; i >= min_bins; --i){

        int j = i -min_bins;



        QualPlots.at(j)->Divide(2,2);
        QualPlots.at(j)->cd(1);
        hTestCompareDPC.at(j)->SetStats(0);
        hTestCompareDPC.at(j)->Draw("colz");

        QualPlots.at(j)->cd(2);
        hTestCompareChi2.at(j)->SetStats(0);
        hTestCompareChi2.at(j)->Draw("colz");

        QualPlots.at(j)->cd(3);
        hKolmogorovTest.at(j)->SetStats(0);
        hKolmogorovTest.at(j)->Draw("colz");

        QualPlots.at(j)->cd(4);
        hTestCompareLCurve.at(j)->SetStats(0);
        hTestCompareLCurve.at(j)->Draw("text");

        QualPlots.at(j)->Write();

    }
    fCheckParameters->Close();

}

void Frontend::plot_pullmode(vector<vector<TrueeResult *> > Pullmode_Result){

    Current_Pullresult =  &Pullmode_Result;
    TString PullBaseName = "pull_dist_setting_";
    stringstream ss, ss2;
    TFile *fPull = TFile::Open(InputObject->getoutputpath()+"TrueeResultFile.root", "UPDATE", "", 0);

    TDirectory *pulldir =     fPull->mkdir("PullResults");
    TDirectory *qualdir =     pulldir->mkdir("Quality_Plots");

    //fPull->cd("Pullresults");
    //vector < vector <TH2D* > > hPulldistributions;




    for(int setting = 0; setting < Pullmode_Result.size();  ++setting){        // each setting is one set of parameters (ndf,knots,bins)

        Current_Pullresult_setting = &Pullmode_Result.at(setting);
        ss2 <<"Bins_"<< Pullmode_Result.at(setting).at(0)->get_bins()<<"_Knots_" << Pullmode_Result.at(setting).at(0)->get_knots()<< "_ndf_"<< Pullmode_Result.at(setting).at(0)->get_ndf();
        TString Settingname = ss2.str().c_str();
        ss2.str("");
        pulldir->mkdir(Settingname);
        fPull->cd("PullResults/"+Settingname);



        vector<TH2D*> hPulldist_for_one_setting;
        vector<TH2D*> h_tu_dist_for_one_setting;
        vector<TH1D*> hPulldist_procjection_for_one_setting;




        ////////////////////////////////////////////////////////////
        // find draw limits
        ////////////////////////////////////////////////////////////
        vector<double> maxerror;
        vector<double> minerror;
        vector<double> max_y;
        vector<double> min_y;

        vector<double> max_unfolded;
        vector<double> min_unfolded;
        vector<double> max_true;
        vector<double> min_true;

        double min_kolmogorov = 2;
        double max_kolmogorov=-1;
        double min_chisquare = 1e3;
        double max_chisquare = -1;
        double min_DPC = 1e3;
        double max_DPC=-1;

        double mintrue = 1e6;
        double maxtrue=-1e6;

        double minunfolded=1e6;
        double maxunfolded=1e6;

        for(int k = 0; k < Pullmode_Result.at(setting).at(0)->get_bins(); ++k){
            minerror.push_back(1e10);
            maxerror.push_back(-1);
            min_y.push_back(1e10);
            max_y.push_back(-1);

            max_unfolded.push_back(-1);
            min_unfolded.push_back(1e10);

            max_true.push_back(-1);
            min_true.push_back(1e10);
        }
        for(int i = 0; i < Pullmode_Result.at(setting).size(); ++i){
            for(int k = 0; k < Pullmode_Result.at(setting).at(i)->get_bins(); ++k){


                double error = Pullmode_Result.at(setting).at(i)->get_error_of_result(k);
                double mctruth = Pullmode_Result.at(setting).at(i)->get_mc_truth(k);
                double result = Pullmode_Result.at(setting).at(i)->get_result(k);


                maxerror.at(k) = max(maxerror.at(k),error);
                minerror.at(k) = min(minerror.at(k),error);
                max_y.at(k) = max(maxerror.at(k),(mctruth - result) / error);
                min_y.at(k) = min(minerror.at(k),(mctruth - result) / error);

                max_unfolded.at(k) = max(max_unfolded.at(k), result);
                min_unfolded.at(k) = min(min_unfolded.at(k), result);

                maxtrue = max(result,maxtrue);
                mintrue =  min(mintrue,result);

                minunfolded = min(mctruth,minunfolded);
                maxunfolded = max(mctruth,maxunfolded);

                min_true.at(k) = min(mctruth,min_true.at(k));
                max_true.at(k) = max(mctruth,max_true.at(k));
            }
            double kolmo = Pullmode_Result.at(setting).at(i)->get_kolmogorov();
            min_kolmogorov = min(min_kolmogorov, kolmo);
            max_kolmogorov = max(max_kolmogorov, kolmo);

            double chisquare = Pullmode_Result.at(setting).at(i)->get_chisquare();
            min_chisquare = min(min_chisquare, chisquare);
            max_chisquare = max(max_chisquare, chisquare);

            double DPC = Pullmode_Result.at(setting).at(i)->get_DPC();
            min_DPC = min(min_DPC, DPC);
            max_DPC = max(max_DPC, DPC);


        }


        ////////////////////////////////////////////////////////////
        //  Initialize the histos to plot
        ////////////////////////////////////////////////////////////

        for(Int_t i = 0; i<Pullmode_Result.at(setting).at(0)->get_bins(); ++i){

            ss << PullBaseName<<setting<<"_bin_"<<i;
            int pullbins;
            if(Pullmode_Result.at(setting).size() > 500)
                pullbins = 100;
            else if(Pullmode_Result.at(setting).size() > 100)
                pullbins = Pullmode_Result.at(setting).size()/5;
            else
                pullbins = 20;
            temp = new TH2D(ss.str().c_str(), "pull distribution", 400, minerror.at(i), maxerror.at(i), pullbins,-10, 10);
            temp->SetOption("colz");
            temp->GetYaxis()->SetTitle("(true - unfolded) / error");
            temp->GetXaxis()->SetTitle("error");

            hPulldist_for_one_setting.push_back(temp);

            ss.str("");
            ss << PullBaseName<<setting<<"_t/u-Distribution_"<<"_bin_"<<i;

            tu_overview.push_back(new TCanvas(ss.str().c_str(),ss.str().c_str(),1024,768));
            min_true.at(i)*=.9999;
            max_true.at(i)*=1.0001;
            min_unfolded.at(i)*=.9999;
            max_unfolded.at(i)*=1.0001;
            TH2D*  temp2 = new TH2D(ss.str().c_str(),ss.str().c_str(), 20, min_true.at(i), max_true.at(i),20, min_unfolded.at(i),max_unfolded.at(i));
            temp2->SetTitle(ss.str().c_str());
            temp2->SetName(ss.str().c_str());
            temp2->GetYaxis()->SetTitle("unfolded");
            temp2->GetXaxis()->SetTitle("true");
            //temp2->SetMarkerStyle(2);
            h_tu_dist_for_one_setting.push_back(temp2);

            ss.str("");
        }

        ////////////////////////////////////////////////////////////
        // draw pull distributions for every bin
        ////////////////////////////////////////////////////////////
        for(int i = 0; i < Pullmode_Result.at(setting).size(); ++i){
            for(int k = 0; k < Pullmode_Result.at(setting).at(i)->get_bins(); ++k){


                double error = Pullmode_Result.at(setting).at(i)->get_error_of_result(k);
                double mctruth = Pullmode_Result.at(setting).at(i)->get_mc_truth(k);
                double result = Pullmode_Result.at(setting).at(i)->get_result(k);

                hPulldist_for_one_setting.at(k)->Fill(error, (mctruth - result) / error);
                h_tu_dist_for_one_setting.at(k)->Fill(mctruth, result);
                //h_tu_dist_for_one_setting.at(k)->SetPointError(i,0,error);

            }
        }
        ////////////////////////////////////////////////////////////
        // draw projections for every bin
        ////////////////////////////////////////////////////////////


        for(int j = 0; j < hPulldist_for_one_setting.size(); ++j){
            ss << PullBaseName<<setting<<"_bin_"<<j<<"_projection";
            hPulldist_procjection_for_one_setting.push_back(hPulldist_for_one_setting.at(j)->ProjectionY(ss.str().c_str(), 1, 400, "l"));
            ss.str("");
        }

        ////////////////////////////////////////////////////////////
        // draw Distribution of kolmogorv-values
        ////////////////////////////////////////////////////////////

        kolmogorov_dist = new TH1D("Kolmogorov_Distribution", "Kolmogorov Distribution",110,-0.1,1.1);
        for(int i = 0; i < Pullmode_Result.at(setting).size(); ++i){
            kolmogorov_dist->Fill(Pullmode_Result.at(setting).at(i)->get_kolmogorov());
        }
        ////////////////////////////////////////////////////////////
        // draw Distribution of chisquare-values
        ////////////////////////////////////////////////////////////

        chisquare_dist = new TH1D("chisquare_Distribution", "#Chi^{2} Distribution",100,0.9*min_chisquare,1.1*max_chisquare);
        for(int i = 0; i < Pullmode_Result.at(setting).size(); ++i){
            chisquare_dist->Fill(Pullmode_Result.at(setting).at(i)->get_chisquare());
        }

        ////////////////////////////////////////////////////////////
        // draw Distribution of DPC-values
        ////////////////////////////////////////////////////////////

        DPC_dist = new TH1D("DPC_Distribution", "DPC Distribution",100,0,1.1*max_DPC);
        for(int i = 0; i < Pullmode_Result.at(setting).size(); ++i){
            DPC_dist->Fill(Pullmode_Result.at(setting).at(i)->get_DPC());
        }

        ////////////////////////////////////////////////////////////
        // draw distribution of pull means
        ////////////////////////////////////////////////////////////
        Pullmean_dist = new TH1D("Pullmean_Distribution", "Pull means",Pullmode_Result.at(setting).at(0)->get_bins(),0,Pullmode_Result.at(setting).at(0)->get_bins());
        for(int i = 0; i <  hPulldist_procjection_for_one_setting.size(); ++i){
            Pullmean_dist->Fill(i, hPulldist_procjection_for_one_setting.at(i)->GetMean());
        }
        ////////////////////////////////////////////////////////////
        // draw distribution of pull rms
        ////////////////////////////////////////////////////////////
        PullRMS_dist = new TH1D("PullRMS_Distribution", "Pull RMS",Pullmode_Result.at(setting).at(0)->get_bins(),0,Pullmode_Result.at(setting).at(0)->get_bins());
        for(int i = 0; i <  hPulldist_procjection_for_one_setting.size(); ++i){
            PullRMS_dist->Fill(i, hPulldist_procjection_for_one_setting.at(i)->GetRMS());
        }

        ////////////////////////////////////////////////////////////
        // print a summary
        ////////////////////////////////////////////////////////////

        print_pullmode(&hPulldist_procjection_for_one_setting);

        plot_pull_qualityplots(&hPulldist_procjection_for_one_setting);

        ////////////////////////////////////////////////////////////
        // make it pretty
        ////////////////////////////////////////////////////////////


        Pullmean_dist->SetStats(false);
        PullRMS_dist->SetStats(false);

        Pullmean_dist->GetXaxis()->SetTitle("Bin");
        Pullmean_dist->GetYaxis()->SetTitle("Mean of pull distribution in units of sigma");

        PullRMS_dist->GetXaxis()->SetTitle("Bin");
        PullRMS_dist->GetYaxis()->SetTitle("RMS of pull distribution");

        DPC_dist->GetXaxis()->SetTitle("data point correlation");
        DPC_dist->GetYaxis()->SetTitle("#");

        kolmogorov_dist->GetXaxis()->SetTitle("Kolmogorov");
        kolmogorov_dist->GetYaxis()->SetTitle("#");

        chisquare_dist->GetXaxis()->SetTitle("#Chi^{2}");
        chisquare_dist->GetYaxis()->SetTitle("#");
        for(int i=0; i < Pull_quality_DPC.size(); ++i){
            Pull_quality_DPC.at(i)->SetOption("colz");
            Pull_quality_DPC.at(i)->GetXaxis()->SetTitle("#knots");
            Pull_quality_DPC.at(i)->GetYaxis()->SetTitle("#ndf");
            Pull_quality_DPC.at(i)->GetZaxis()->SetTitle("DPC");
            Pull_quality_DPC.at(i)->SetStats(false);

            Pull_quality_kolmo.at(i)->SetOption("colz");
            Pull_quality_kolmo.at(i)->GetXaxis()->SetTitle("#knots");
            Pull_quality_kolmo.at(i)->GetYaxis()->SetTitle("#ndf");
            Pull_quality_kolmo.at(i)->GetZaxis()->SetTitle("Kolmogorov");
            Pull_quality_kolmo.at(i)->SetStats(false);

            Pull_quality_chi.at(i)->SetOption("colz");
            Pull_quality_chi.at(i)->GetXaxis()->SetTitle("#knots");
            Pull_quality_chi.at(i)->GetYaxis()->SetTitle("#ndf");
            Pull_quality_chi.at(i)->GetZaxis()->SetTitle("#Chi^{2}");
            Pull_quality_chi.at(i)->SetStats(false);

            Pull_quality_means.at(i)->SetOption("colz");
            Pull_quality_means.at(i)->GetXaxis()->SetTitle("#knots");
            Pull_quality_means.at(i)->GetYaxis()->SetTitle("#ndf");
            Pull_quality_means.at(i)->SetStats(false);

            Pull_quality_rms.at(i)->SetOption("colz");
            Pull_quality_rms.at(i)->GetXaxis()->SetTitle("#knots");
            Pull_quality_rms.at(i)->GetYaxis()->SetTitle("#ndf");
            Pull_quality_rms.at(i)->SetStats(false);
        }

        ////////////////////////////////////////////////////////////
        // save everything
        ////////////////////////////////////////////////////////////


        for(int i = 0; i < hPulldist_for_one_setting.size(); ++i){
            hPulldist_for_one_setting.at(i)->Write();
            hPulldist_procjection_for_one_setting.at(i)->Write();


            TF1 *optline = new TF1("bisecting line","x",mintrue,maxtrue);
            optline->SetLineColor(kRed);
            tu_overview.at(i)->cd();
            h_tu_dist_for_one_setting.at(i)->GetYaxis()->SetTitle("unfolded");
            h_tu_dist_for_one_setting.at(i)->GetXaxis()->SetTitle("true");
            //            double xmax = max( maxtrue,maxunfolded);
            //            double xmin = min(mintrue,minunfolded);
            //            h_tu_dist_for_one_setting.at(i)->GetXaxis()->SetRangeUser(xmin,xmax);
            //            h_tu_dist_for_one_setting.at(i)->GetYaxis()->SetRangeUser(xmin,xmax);
            h_tu_dist_for_one_setting.at(i)->Draw("colz");
            optline->Draw("same");
            tu_overview.at(i)->Write();

        }
        Pullmean_dist->Draw("");
        PullRMS_dist->Draw("");
        kolmogorov_dist->Write();
        chisquare_dist->Write();
        DPC_dist->Write();
        Pullmean_dist->Write();
        PullRMS_dist->Write();



    }
    fPull->cd("PullResults");

    for(int i=0; i < Pull_quality_DPC.size(); ++i){
        Pull_overview.at(i)->Divide(3,2);
        Pull_overview.at(i)->cd(1);
        Pull_quality_chi.at(i)->Draw("colz");

        Pull_overview.at(i)->cd(2);
        Pull_quality_kolmo.at(i)->Draw("colz");

        Pull_overview.at(i)->cd(3);
        Pull_quality_DPC.at(i)->Draw("colz");

        Pull_overview.at(i)->cd(4);
        Pull_quality_means.at(i)->Draw("colz");

        Pull_overview.at(i)->cd(5);
        Pull_quality_rms.at(i)->Draw("colz");

        Pull_overview.at(i)->Write();
    }
    fPull->cd("PullResults/Quality_Plots");

    for(int i; i < Pull_quality_DPC.size(); ++i){
        Pull_quality_chi.at(i)->Write();
        Pull_quality_kolmo.at(i)->Write();
        Pull_quality_DPC.at(i)->Write();
        Pull_quality_means.at(i)->Write();
        Pull_quality_rms.at(i)->Write();
    }

    fPull->Close();
}

void Frontend::print_pullmode(vector<TH1D*>*  hPulldist_procjection_for_one_setting){

    double mean_dev = 0;
    double rms_dev = 0;
    double mean;
    double rms;

    for(int i = 0; i < hPulldist_procjection_for_one_setting->size();++i ){
        mean = hPulldist_procjection_for_one_setting->at(i)->GetMean();
        rms = hPulldist_procjection_for_one_setting->at(i)->GetRMS();
        if(mean < 0)
            mean*=-1;
        mean_dev=max(mean,mean_dev);
        if(rms < 1)
            rms=(1-rms);
        else
            rms=-1*(1-rms);
        rms_dev= max(rms_dev, rms);

    }
    if(printflag > 0){
        cout << "\n";
        cout << "******************************"<<endl;
        cout << "* results of pullmode    "<<endl;
        cout<< "* Bins: "<<Current_Pullresult_setting->at(0)->get_bins()<<endl;
        cout<< "* Knots: "<<Current_Pullresult_setting->at(0)->get_knots()<<endl;
        cout<< "* Ndf: "<<Current_Pullresult_setting->at(0)->get_ndf()<<endl;

        cout << "******************************"<<endl;
        cout << "\n";



        cout
                <<"(Mean) data point correlation: \t"<<DPC_dist->GetMean()<<" +/- "<<DPC_dist->GetRMS()     <<"\n"
               <<"(Mean) kolmogorov: \t "<< kolmogorov_dist->GetMean() << " +/- "<<kolmogorov_dist->GetRMS()    <<"\n"
              <<"(Mean) chi square: \t"<<   chisquare_dist->GetMean()<<" +/- " << chisquare_dist->GetRMS()  <<"\n"
             <<"Max of deviation of pull mean to 0: \t "<<  mean_dev   <<"\n"
            <<"Max of deviation of pull RMS to 1: \t "<<   rms_dev  <<"\n";
    }

}

void Frontend::plot_pull_qualityplots(vector<TH1D*>*  hPulldist_procjection_for_one_setting){

    // fPull->mkdir("quality_plots");
    // fPull->cd("quality_plots");


    Int_t maxndf = InputObject->getNrDegreeOfFreedomMaxUser();
    Int_t minndf = InputObject->GetMinNrDegreeOfFreedom();

    Int_t minbins = InputObject->GetMinNrBinsResult();
    Int_t maxbins = InputObject->getNrBinsResultMaxUser();

    int minknots = InputObject->GetMinNrKnots();
    int maxknots = InputObject->getNrKnotsMaxUser();

    int bins = Current_Pullresult_setting->at(0)->get_bins();
    int knots = Current_Pullresult_setting->at(0)->get_knots();
    int ndf = Current_Pullresult_setting->at(0)->get_ndf();

    double mean_dev = 0;
    double rms_dev = 0;
    double mean;
    double rms;

    for(int i = 0; i < hPulldist_procjection_for_one_setting->size();++i ){

        mean = hPulldist_procjection_for_one_setting->at(i)->GetMean();

        rms = hPulldist_procjection_for_one_setting->at(i)->GetRMS();

        if(mean < 0)
            mean*=-1;
        mean_dev= max(mean,mean_dev);

        if(rms < 1)
            rms=(1-rms);
        else
            rms=-1*(1-rms);
        rms_dev= max(rms_dev, rms);

    }
    stringstream title;

    minknots--;
    maxknots++;
    int knot_bins = 2*(maxknots-minknots);

    if(Pull_overview.size() == 0) {
        for(int i = 0; i<=maxbins-minbins;++i){
            title <<"Pullmode overview for "<<i+minbins<<" Bins";
            Pull_overview.push_back(new TCanvas(title.str().c_str(),title.str().c_str(),1280,960));
            title.str("");
        }
    }

    if(Pull_quality_DPC.size() == 0) {
        for(int i = 0; i<=maxbins-minbins;++i){
            title <<"DPC vs knots/ndf for "<<i+minbins<<" Bins";
            Pull_quality_DPC.push_back(new TH2D(title.str().c_str(), title.str().c_str(),knot_bins,minknots -0.25,maxknots-0.25,2*(maxndf-minndf+1),minndf-0.25,maxndf+1-0.25));
            title.str("");
        }
    }
    if(Pull_quality_chi.size() == 0){
        for(int i = 0; i<=maxbins-minbins;++i){
            title <<"chisquare vs knots/ndf for "<<i+minbins<<" Bins";
            Pull_quality_chi.push_back(new TH2D(title.str().c_str(),title.str().c_str(),knot_bins,minknots -0.25,maxknots-0.25,2*(maxndf-minndf+1),minndf-0.25,maxndf+1-0.25));
            title.str("");
        }
    }
    if(Pull_quality_kolmo.size() == 0){
        for(int i = 0; i<=maxbins-minbins;++i){
            title <<"Kolmogorov vs knots/ndf for "<<i+minbins<<" Bins";
            Pull_quality_kolmo.push_back(new TH2D(title.str().c_str(),title.str().c_str(),knot_bins,minknots -0.25,maxknots-0.25,2*(maxndf-minndf+1),minndf-0.25,maxndf+1-0.25));
            title.str("");
        }
    }
    if(Pull_quality_means.size() == 0){
        for(int i = 0; i<=maxbins-minbins;++i){
            title <<"Max deviation of pull mean to 0 vs knots/ndf "<<i+minbins<<" Bins";
            Pull_quality_means.push_back(new TH2D(title.str().c_str(),title.str().c_str(),knot_bins,minknots-0.25,maxknots-0.25,2*(maxndf-minndf+1),minndf-0.25,maxndf+1-0.25));
            title.str("");
        }
    }
    if(Pull_quality_rms.size() == 0){
        for(int i = 0; i<=maxbins-minbins;++i){
            title <<"Max deviation of pull rms to 1 vs knots/ndf "<<i+minbins<<" Bins";
            Pull_quality_rms.push_back( new TH2D(title.str().c_str(), title.str().c_str(),knot_bins,minknots-0.25,maxknots-0.25,2*(maxndf-minndf+1),minndf-0.25,maxndf+1-0.25));
            title.str("");
        }
    }

    Pull_quality_DPC.at(maxbins-bins)->Fill(knots,ndf, DPC_dist->GetMean());
    Pull_quality_chi.at(maxbins-bins)->Fill(knots,ndf, chisquare_dist->GetMean());
    Pull_quality_kolmo.at(maxbins-bins)->Fill(knots,ndf, kolmogorov_dist->GetMean());
    Pull_quality_means.at(maxbins-bins)->Fill(knots,ndf, mean_dev);
    Pull_quality_rms.at(maxbins-bins)->Fill(knots,ndf, rms_dev);




}

void Frontend::Plot_MCInformation(string type, TString var1,int num1){

    std::vector<TrueeEvent* > DATA = InputObject->GetData()->MonteCarlo_Data;
    std::vector<TrueeEvent* > MOCA = InputObject->GetData()->Real_Data;

    TFile* fileA = new TFile(InputObject->getoutputpath()+"TrueeResultFile.root", "UPDATE");
    fileA->cd("Data MC comparisons");

    ////////////////////////////////////////////////////////////
    // find min/max
    ////////////////////////////////////////////////////////////

    double min,max;
    min = 1e10;
    max = -1;
    for(int i = 0; i < DATA.size(); ++i){
        min = std::min(min,DATA.at(i)->get_y(num1));
        max = std::max(max,DATA.at(i)->get_y(num1));
    }
    for(int i = 0; i < MOCA.size(); ++i){
        min = std::min(min,MOCA.at(i)->get_y(num1));
        max = std::max(max,MOCA.at(i)->get_y(num1));
    }

    ////////////////////////////////////////////////////////////
    // initialize plots
    ////////////////////////////////////////////////////////////
    stringstream ss;
    ss << "Data / MC (weighted) comparisons for "<<var1<<" Canvas";
    TCanvas* T = new TCanvas(ss.str().c_str(),ss.str().c_str(),1280,960);
    ss << " Moca";
    TH1D* MOCA_Plot = new TH1D(ss.str().c_str(),ss.str().c_str(), 75,min,max);
    ss.str("");
    ss << "Data / MC (weighted) comparisons for "<<var1;
    TH1D* DATA_Plot = new TH1D(ss.str().c_str(),ss.str().c_str(),75,min,max);
    ss.str("");




    ////////////////////////////////////////////////////////////
    // Fill
    ////////////////////////////////////////////////////////////
    for(int i = 0; i < DATA.size(); ++i){
        DATA_Plot->Fill(DATA.at(i)->get_y(num1),DATA.at(i)->get_weight());
    }

    for(int i = 0; i < MOCA.size(); ++i){
        MOCA_Plot->Fill(MOCA.at(i)->get_y(num1),MOCA.at(i)->get_weight());
    }

    //     for(int i = 0; i <= DATA_Plot->GetNbinsX(); ++i){
    //         DATA_Plot->SetBinError(i,sqrt(DATA_Plot->GetBinContent(i)));
    //    }

    for(int i = 0; i <= MOCA_Plot->GetNbinsX(); ++i){
        DATA_Plot->SetBinError(i,sqrt(MOCA_Plot->GetBinContent(i)));
    }
    ////////////////////////////////////////////////////////////
    // Make it pretty
    ////////////////////////////////////////////////////////////
    DATA_Plot->GetXaxis()->SetTitle(var1);
    DATA_Plot->GetYaxis()->SetTitle("#");

    DATA_Plot->SetLineWidth(2);
    DATA_Plot->SetMarkerStyle(2);
    DATA_Plot->SetMarkerColor(2);
    DATA_Plot->SetLineColor(2);
    MOCA_Plot->Scale(DATA_Plot->GetSum()/MOCA_Plot->GetSum());

    MOCA_Plot->SetLineWidth(2);
    MOCA_Plot->SetMarkerStyle(2);


    DATA_Plot->SetStats(0);

    TLegend *leg= new TLegend(0.15, 0.8, .35, 0.95);

    leg->AddEntry(DATA_Plot,"Data (scaled)", "l");
    leg->AddEntry(MOCA_Plot,"Monte Carlo (scaled)","p");

    ss.str("");
    ss<<DATA_Plot->GetTitle()<<     "\t  Kolmogorov:  "<<DATA_Plot->KolmogorovTest(MOCA_Plot)<<"\t  Chisquare: "<<DATA_Plot->Chi2Test(MOCA_Plot, "CHI2/NDFWW");

    DATA_Plot->SetTitle(ss.str().c_str());



    leg->Draw("");

    DATA_Plot->Draw("PE");
    MOCA_Plot->Draw("same");

    leg->Draw("");

    T->Write();
    fileA->Close();
    ss.str("");

}

void Frontend::Plot_XYCorrelation_Observables(string type, TString var1, TString var2,int num1,int num2){
    double weight, VAR1,VAR2;
    double var1_min =1e20,var1_max=-1,var2_min=1e20,var2_max=-1;

    TFile *fileA = 0;

    std::vector<TrueeEvent* > aux;
    if(type == "MOCA") {
        fileA = new TFile(InputObject->getoutputpath()+"TrueeResultFile.root", "UPDATE");
        aux = InputObject->GetData()->MonteCarlo_Data;
    }
    // in the test mode it is possible (reasonable) to check correlation for real data, too
    else if(type == "DATA") {
        fileA = new TFile(InputObject->getoutputpath()+"TrueeResultFile.root", "UPDATE");
        aux = InputObject->GetData()->Real_Data;
    }



    // fCorrelationFile = new TFile(InputObject->getoutputpath()+"Correlations.root", "UPDATE");
    if(num2 != -1){
        fileA->cd("Correlationplots/Obs_Obs");
    }
    else{
        fileA->cd("Correlationplots/Obs_X");
    }


    for(int i = 0; i < aux.size();++i){
        VAR1= aux.at(i)->get_y(num1);
        if(num2 != -1){
            VAR2 = aux.at(i)->get_y(num2);
        }
        else{
            VAR2 = aux.at(i)->get_x();
        }

        var1_min = min(var1_min,VAR1);
        var1_max = max(var1_max,VAR1);

        var2_min = min(var2_min,VAR2);
        var2_max = max(var2_max,VAR2);

    }
    TString title = "Correlation_"+var1+"_"+var2;
    //TH2F* Corr = new TH2F("Correlation_"+var1+"_"+var2,"Correlation_"+var1+"_"+var2,100,0.9*var1_min,1.1*var1_min,100,0.9*var2_min,1.1*var2_max);
    TH2F* Corr = new TH2F("Correlation_"+var1+"_"+var2,"Correlation_"+var1+"_"+var2,100,0,0,100,0,0);
    TProfile* CorrProf = new TProfile(title+"_profile" , title, 100, 0.,0.);

    Corr->SetXTitle(var1);
    Corr->SetYTitle(var2);
    Corr->SetStats(false);
    TCanvas *can = new TCanvas("correlation_"+var1+"_"+var2,"correlation_"+var1+"_"+var2,1024,768);
    for(int i = 0; i < aux.size();++i){
        VAR1= aux.at(i)->get_y(num1);
        if(num2 != -1){
            VAR2 = aux.at(i)->get_y(num2);
        }
        else{
            VAR2 = aux.at(i)->get_x();
        }
        weight = aux.at(i)->get_weight();
        Corr->Fill(VAR1,VAR2,weight);
        CorrProf->Fill(VAR1,VAR2,weight);

    }

    Corr->Draw("colz");
    can->Write();

    CorrProf->Draw("");
    CorrProf->Write();
    //fileA->Write();
    fileA->Close();

}

void Frontend::plot_datamode(vector<TrueeResult *> Resultvector){

    TFile *fCheckParameters;
    fCheckParameters = new TFile(InputObject->getoutputpath()+"TrueeResultFile.root", "UPDATE");
    fCheckParameters->cd("RealDataResults");

//    TDirectory *qualdir =     fCheckParameters->mkdir("Testmode_Overview");
//    fCheckParameters->cd("Testmode_Overview");

    TH2D *hRCurveTestMode = new TH2D("Data L-Curve","L-Curve on data - label is 1000*knots+ndf",100, 0, 0, 100, 0,0);
    double label;
    for(int k = 0; k < (int) Resultvector.size();++k){
        label = 1e3*Resultvector.at(k)->get_knots()+Resultvector.at(k)->get_ndf();
        //cout << Resultvector.at(k)->GetFitMin() <<"\t"<<Resultvector.at(k)->GetRegTerm()<<endl;
        if(Resultvector.at(k)->GetRegTerm() != 0)
            hRCurveTestMode->Fill(Resultvector.at(k)->GetFitMin(),Resultvector.at(k)->get_DPC(),label);
    }

    hRCurveTestMode->SetOption("text");
    hRCurveTestMode->SetMarkerStyle(3);
    hRCurveTestMode->SetMarkerColor(4);
    hRCurveTestMode->SetMarkerSize(1.7);
    hRCurveTestMode->GetYaxis()->SetTitle("data point correlation");
    hRCurveTestMode->GetXaxis()->SetTitle("fit minimum [a.u]");

    hRCurveTestMode->Write();

}
