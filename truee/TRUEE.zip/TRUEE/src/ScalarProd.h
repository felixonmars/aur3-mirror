//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009


#ifndef SCALARPROD_H_
#define SCALARPROD_H_
#include "Rtypes.h"
Double_t ScalarProd(Double_t *VectorX, Double_t *VectorY, Int_t N);

#endif /* SCALARPROD_H_ */
