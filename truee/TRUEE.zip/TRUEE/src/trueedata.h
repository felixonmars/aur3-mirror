#ifndef TRUEEDATA_H
#define TRUEEDATA_H


#include "trueeevent.h"
#include <iostream>
using namespace std;


/*!
    *  \brief     data handling class

    ￼*  \details   This class contains all the data you put into TRUEE
    *  \author Martin Schmitz <martin.schmitz@uni-dortmund.de


    *  \date April 2012
*/


class TrueeData
{
public:
    TrueeData();
    ~TrueeData(){

    }

//    std::vector<TrueeEvent* > GetReal_Data(){ return Real_Data;}
//    std::vector<TrueeEvent* > GetReal_Data_after_pp(){ return Real_Data_after_pp;}
//    std::vector<TrueeEvent* > GetBG_Data(){ return BG_Data;}



    void erase();

    std::vector<TrueeEvent* > MonteCarlo_Data;
    std::vector<TrueeEvent* > BG_Data;
    std::vector<TrueeEvent* > Real_Data;



    std::vector<TrueeEvent* > MonteCarlo_Data_after_pp;
    std::vector<TrueeEvent* > BG_Data_after_pp;
    std::vector<TrueeEvent* > Real_Data_after_pp;

};

#endif // TRUEEDATA_H
