//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef AverageOfFunction_h
#define AverageOfFunction_h

#include "Rtypes.h"
#include "FxFunctionMC.h"

	Double_t AverageOfFunction(Double_t x1=0, Double_t x2=0, Double_t func(Double_t)=0);
	Double_t AverageOfFunction(Double_t x1, Double_t x2, FxFunctionMC *MCFunctionFx);

#endif //AverageOfFunction_h
