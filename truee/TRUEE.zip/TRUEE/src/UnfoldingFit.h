//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

#ifndef UnfoldingFit_h
#define UnfoldingFit_h

#include "Rtypes.h"
#include <iostream>
#include "Input.h"
#include "RegularizationMath.h"
#include "Preprocessor.h"
#include "LinearAlgebra.h"
#include "Minimize.h"
#include "FxFunctionMC.h"
#include "Functions.h"
#include "TH1.h"
#include "TFile.h"
#include "AverageOfFunction.h"

class UnfoldingFit {

public:

	UnfoldingFit();
	UnfoldingFit(Input *InputObject, Preprocessor *Pass1Object, Int_t prodNrBins, Int_t nrNonZeroBins, FxFunctionMC *mcFunctionFx);
	virtual ~UnfoldingFit();
	void Fit(Double_t *H);
	void FunctionGradientHessian(Int_t index, Double_t *H);
	void Result(Int_t NrBins, Double_t *BinContentResult, Double_t *CovarMatrixResult);
	void Scale(Int_t NrBins, Double_t *binLimit, Double_t *binContent, Double_t *VC);
	void CheckCovarianceMatrix(Int_t N, Double_t *V, Double_t *VV, Double_t *U);

	Double_t GetCoefficient(Int_t KnotIndex) { return Coefficient[KnotIndex];}
	void SetCoefficient(Double_t *Coefficient, Int_t KnotIndex) { this->Coefficient[KnotIndex]=Coefficient[KnotIndex];}
	Double_t GetCoefficientResult(Int_t KnotIndex) { return CoefficientResult[KnotIndex];}
	Double_t GetCovarianceMatrix(Int_t KnotIndex) { return CovarianceMatrix[KnotIndex];}
	Double_t GetChi2pValue50() { return Chi2pValue50;}
	Double_t GetFitMin() {return fitMin;}
    Double_t GetRegularizationTerm(){return RegularizationTerm;}
	Double_t getNewLimitsOfBinsResult(Int_t Index) { return LimitsOfBinsResult[Index];}
	Double_t getNrDegFreeForTau() { return NrDegFreeForTau;}
	Double_t getTransfMatrix(Int_t Index) {	return TransfMatrix[Index];}
	//void setTransfMatrix(Double_t *TransfMatrix, Int_t Index) { this->TransfMatrix[Index] = TransfMatrix[Index]; }
//	Double_t GetWantedXHighLimitResult() { return WantedXHighLimitResult;}
//	Double_t GetWantedXLowLimitResult() { return WantedXLowLimitResult;}

	Int_t getNrDegreeOfFreedomAutom() { return NrDegreeOfFreedomAutom;}

	Int_t getNewNrBins() { return NewNrBins; }


	Float_t getNrKnotsResult() { return NrKnotsResult;}

	// ClassDef(UnfoldingFit,1)

private:

	Bool_t FXpositive;
	Bool_t print;

	Int_t iVeto;
	Int_t NewNrBins;
	Int_t NrBinsResult;
	Int_t NrConstraints;//=NCNS
	Int_t NrDegreeOfFreedom;
	Int_t NrDegreeOfFreedomAutom;// = NDFA, determined, if nr of degree of freedom is not defined
	Int_t NrIndepLinComb;
	Int_t NrKnots;
	Int_t NrKnotsMax;
	Int_t NrNonZeroBins;
	Int_t ProdNrBins;


	Double_t Coefficient[63];// = XX
	Double_t CoefficientResult[63];
	Double_t CovarianceMatrix[(63*63+63)/2];
	Double_t fitMin; // minimum of the unfolding fit
    Double_t RegularizationTerm;
	Double_t Chi2pValue50;
	Double_t Function;
	Double_t FXconstraint[10];//=FCNS
	Double_t Gradient[63];
	Double_t Hessian[(63+63*63)/2];
	Double_t LimitsOfBinsResult[241];
	Double_t LuminosityFactor;
	Double_t NrDegFreeForTau;// number of degrees of freedom for the current value of Tau (=XDFR)
	Double_t RegMatrix[4000];// scratch storage
	//Double_t ScratchMatrix[63*63];
	Double_t SD;
	Double_t SF;
	Double_t Tau;
	Double_t TransfMatrix[63*63];// = UM;
	Double_t WantedXHighLimit;
	//Double_t WantedXHighLimitResult;
	Double_t WantedXLowLimit;
	//Double_t WantedXLowLimitResult;
	Double_t Xconstraint[10];
	Float_t NrKnotsResult;

	RegularizationMath *RegularizationMathObject;

	Input *inputObject;
	Functions *SplineCalc;
	LinearAlgebra *MatrixTrafo;
	Minimize *MinObject;
	//rpass1 *pass1Object;
	FxFunctionMC *MCFunctionFx;
	TFile *CovarianceFile;
};

#endif //UnfoldingFit_h
