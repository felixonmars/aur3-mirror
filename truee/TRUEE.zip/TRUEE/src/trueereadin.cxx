//	author: Martin Schmitz <martin.schmitz@uni-dortmund.de>
//	Dortmund, 2012
//	==========

#include "trueereadin.h"
#include <cmath>
#include "Input.h"




using namespace std;

TrueeReadIn::TrueeReadIn()
{

}

TrueeReadIn::TrueeReadIn(double wantedXLowLimit, double wantedXHighLimit, TString NameWantedX, TString *NameObsY, int nrAllMeasuredVariables, int nrMocaTypes, Input* In) {

        BackEventNr = 0;
        nameWantedX = NameWantedX;
        NrAllMeasuredVariables = nrAllMeasuredVariables;

        for(int i = 0; i < NrAllMeasuredVariables; ++i) {
                nameObsY[i] = NameObsY[i];
        }
        NrMocaTypes = nrMocaTypes;
        WantedXHighLimit = wantedXHighLimit;
        WantedXLowLimit = wantedXLowLimit;
        InputObject = In;
        printflag = In->getPrintflag();

}

void TrueeReadIn::ReadInRootTreeTest(const std::string &rootTreeSourceFile, const std::string &rootSourceFileBG, const std::string &SourceTreeName, const std::string &SourceTreeNameBG, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, double fraction, TRandom3 *searchEventFraction, int NTupleIndex, string outpath) {
        // read in the root files with data, MC or background
        // Write n-tuples to file A (TreeA)

        cout << "## new readin class in called ##"<<endl;
        weight = 1;// can be modified for data, MC or background (here bg weight = fraction*weight)
        x=0.0;
        double y[NrAllMeasuredVariables];
        eventIndexMC=0;
        eventIndexRD=0;
        eventIndexBG=0;
        for(int i=0; i<NrAllMeasuredVariables; ++i) {
                y[i]=0.0;
        }
        if(printflag < 1){
            cout<<"\nread in MC test events from the RootTree"<<endl;
            cout<<"========================================"<<endl;
        }
        cout << "THIS ONE IS RUNNING - yay 2323  "<<endl;

        // make possible to read different variable types and cast to double (there must be a better way!)
        int xTypeIdent = 0; // type identifier: 1 = int, 2 = float, 3 = double
        int wTypeIdent = 0; // weight type identifier: 1 = int, 2 = float, 3 = double
        int yTypeIdent[NrAllMeasuredVariables]; // type identifier: 1 = int, 2 = float, 3 = double


        // if x,w or y are integers, those variables are used.
        int x_int = 0;
        int w_int = 0;
        int y_int[NrAllMeasuredVariables];

        // if x,w or y are floats, those variables are used.
        Float_t x_float = 0;
        Float_t w_float = 0;
        Float_t y_float[NrAllMeasuredVariables];

        // if x,w or y are doubles, those variables are used.
        double x_double = 0;
        double w_double = 0;
        double y_double[NrAllMeasuredVariables];

        // ---------- fill events from RootTree source file ----------------
        // if existent, all background events are filled in the data and in the background file
        // and weighted by 2 to scale down background
        // open RootTree file and set BranchAddress for all variables (observables)
        TChain *MCfileSource = new TChain(SourceTreeName.c_str());
        MCfileSource->Add(rootTreeSourceFile.c_str());
        MCfileSource->SetBranchStatus("*",0); // deactivate all branches
        // check the leaf type for the sought-after x variable
        CheckLeafType(MCfileSource, BranchWantedX.c_str(), xTypeIdent, x_int, x_float, x_double);
        // check the leaf type for the individual event weight
        if(BranchEventWeight != "no_weight") {
                CheckLeafType(MCfileSource, BranchEventWeight, wTypeIdent, w_int, w_float, w_double);
        }

        for(int j=0; j<NrAllMeasuredVariables; ++j) {
                // check the leaf type for the measured observables
                CheckLeafType(MCfileSource, BranchMeasurVariable[j].c_str(), yTypeIdent[j], y_int[j], y_float[j], y_double[j]);
        }

        //-------- fill MC and pseudo RD files with fractions of MC events ------
        // every first event is accepted, start counting at 0
        int NrEntries = static_cast<int>(MCfileSource->GetEntries());
        //Full_data.resize(NrEntries);
        Bool_t go = 0; // boolian to reject events with log10(0)
        for(int AB=0; AB<(NrEntries); AB++) {
                weight = 1.0;
                MCfileSource->GetEntry(AB);
                if(xTypeIdent == 1) x = static_cast<double>(x_int);
                else if(xTypeIdent == 2) x = static_cast<double>(x_float);
                else if(xTypeIdent == 3) x = static_cast<double>(x_double);
                else {
                        x = -10000000;// no type determined?
                        cerr<<"no type determined for sought-after variable"<<endl;
                }
                if(BranchEventWeight != "no_weight") {
                        if(wTypeIdent == 1) weight = static_cast<double>(w_int);
                        else if(wTypeIdent == 2) weight = static_cast<double>(w_float);
                        else if(wTypeIdent == 3) weight = static_cast<double>(w_double);
                        else {
                                weight = -10000000; // no type determined
                                cerr<<"no type determined for weight"<<endl;
                        }
                }
                go = 0;
                for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {
                        if(yTypeIdent[ij] == 1) y[ij] = static_cast<double>(y_int[ij]);
                        else if(yTypeIdent[ij] == 2) y[ij] = static_cast<double>(y_float[ij]);
                        else if(yTypeIdent[ij] == 3) y[ij] = static_cast<double>(y_double[ij]);
                        else {
                                y[ij] = -10000000; // no type determined?
                                cerr<<"no type determined for observable: "<<y[ij]<<endl;
                        }
                        if(logOption[ij] == 1) {
                                if(y[ij] > 0) {
                                        y[ij]=log10(y[ij]);
                                }
                                else {
                                        go = 1;
                                        break;
                                }
                        }
                }
                if(logOptionX == 1) {
                        if(x > 0) {
                                x=log10(x);
                        }
                        else go = 1;
                }
                if(go == 1) continue;
                TrueeEvent* temp_event = new TrueeEvent();
                temp_event->SetWeight(weight);
                temp_event->set_x(x);
                for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {
                    temp_event->add_y(y[ij]);
                }
                Full_data.push_back(temp_event);



        }



        // ---------- fill tree with background data from RootTree source file ----------------
        // open RootTree file and set BranchAddress for all variables
        int yTypeIdentBG[NrAllMeasuredVariables]; // type identifier for background: 1 = int, 2 = float, 3 = double
        int wTypeIdentBG; // type identifier of weight for background: 1 = int, 2 = float, 3 = double
        int y_intBG[NrAllMeasuredVariables];
        int w_intBG;
        Float_t y_floatBG[NrAllMeasuredVariables];
        Float_t w_floatBG;
        double y_doubleBG[NrAllMeasuredVariables];
        double w_doubleBG;
        TChain *BGfileSource = 0;
        TFile *BGfileA;
        int NrEntriesBG=0;
        if(NTupleIndex == (NrMocaTypes-1) && rootSourceFileBG != "no_BG") {
                BGfileSource = new TChain(SourceTreeNameBG.c_str());
                BGfileSource->Add(rootSourceFileBG.c_str());
                BGfileSource->SetBranchStatus("*",0); // deactivate all branches
                // check the leaf type for the individual event weight
                if(BranchEventWeight != "no_weight") {
                        CheckLeafType(BGfileSource, BranchEventWeight, wTypeIdentBG, w_intBG, w_floatBG, w_doubleBG);
                }

                for(int j=0; j<NrAllMeasuredVariables; ++j) {
                        // check the leaf type for the measured observables
                        CheckLeafType(BGfileSource, BranchMeasurVariable[j].c_str(), yTypeIdentBG[j], y_intBG[j], y_floatBG[j], y_doubleBG[j]);
                }


                NrEntriesBG = static_cast<int>(BGfileSource->GetEntries());
                for(int AB=0; AB<NrEntriesBG; AB++) {
                        weight = 1.0;
                        BGfileSource->GetEntry(AB);
                        go = 0;
                        for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {
                                if(BranchEventWeight != "no_weight") {
                                        if(wTypeIdentBG == 1) weight = static_cast<double>(w_intBG);
                                        else if(wTypeIdentBG == 2) weight = static_cast<double>(w_floatBG);
                                        else if(wTypeIdentBG == 3) weight = static_cast<double>(w_doubleBG);
                                        else {
                                                weight = -10000000; // no type determined
                                                cerr<<"no type determined for weight"<<endl;
                                        }
                                }
                                if(yTypeIdentBG[ij] == 1) y[ij] = static_cast<double>(y_intBG[ij]);
                                else if(yTypeIdentBG[ij] == 2) y[ij] = static_cast<double>(y_floatBG[ij]);
                                else if(yTypeIdentBG[ij] == 3) y[ij] = static_cast<double>(y_doubleBG[ij]);
                                else {
                                        y[ij] = -10000000; // no type determined?
                                        cerr<<"no type determined for observable: "<<y[ij]<<endl;
                                }
                                if(logOption[ij] == 1) {
                                        if(y[ij] > 0) {
                                                y[ij]=log10(y[ij]);// can be modified
                                        }
                                        else {
                                                go = 1;
                                                break;
                                        }
                                }
                        }
                        if(go == 1) continue;
                        BackEventNr = BackEventNr + weight;
                        eventIndexBG++;
                        TrueeEvent* temp_event = new TrueeEvent();
                        temp_event->SetWeight(weight);
                        temp_event->set_x(x);
                        for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {
                            temp_event->add_y(y[ij]);
                        }
                        BG_Data.push_back(temp_event);

                }
        }



        cout << "going to pull "<<endl;
        Pull(fraction, searchEventFraction);
        cout<<"number of events MC: "<<MonteCarlo_Data.size()<<endl;
        cout<<"number of events rd: "<<Real_Data.size()<<endl;
        cout<<"number of events bg: "<<BG_Data.size()<<endl;
        MCfileSource->Delete();
        if(rootSourceFileBG != "no_BG") BGfileSource->Delete();

}


void TrueeReadIn::CheckLeafType(TChain *fileName, const std::string &branchName, int &typeIdent, int &type_int, Float_t &type_float, double &type_double) {
        // check the type of the leaf to read the right type and set the branch address
        string integer_t = "int";
        string integer = "int";
        string floating_t = "Float_t";
        string floating = "float";
        string doubles_t = "double";
        string doubles = "double";
        fileName->SetBranchStatus(branchName.c_str(), 1);
        if(fileName->GetLeaf(branchName.c_str())->GetTypeName() == integer || fileName->GetLeaf(branchName.c_str())->GetTypeName() == integer_t) {
                fileName->SetBranchAddress(branchName.c_str(), &type_int);
                typeIdent = 1;
        }
        else if(fileName->GetLeaf(branchName.c_str())->GetTypeName() == floating || fileName->GetLeaf(branchName.c_str())->GetTypeName() == floating_t) {
                fileName->SetBranchAddress(branchName.c_str(), &type_float);
                typeIdent = 2;
        }
        else if(fileName->GetLeaf(branchName.c_str())->GetTypeName() == doubles || fileName->GetLeaf(branchName.c_str())->GetTypeName() == doubles_t) {
                fileName->SetBranchAddress(branchName.c_str(), &type_double);
                typeIdent = 3;
        }
}


void TrueeReadIn::ReadInRootTree(const std::string &rootTreeSourceFile, const std::string &SourceTreeName, const std::string &label, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, int NTupleIndex, string output) {
        // read in the root files with data, MC or background
        // Write n-tuples to file A (TreeA)
        weight = 1.0;// can be modified for data, MC or background
        double countw=0.0;
        int eventNonZero=0;
        double x=0.0;
        double y[NrAllMeasuredVariables];
        int eventIndex=0;
        for(int i=0; i<NrAllMeasuredVariables; ++i) {
                y[i]=0.0;
        }
        if(printflag < 1){
            cout<<"\nread in events from the RootTree"<<endl;
            cout<<"================================"<<endl;
            cout<<label<<"\n-----"<<endl;
        }
        //---------------- create RootTree file and set branches ------------------
        TFile *fileA = 0;
        TTree *TreeA = 0; // tree with data used in pass1
        TH1D *hWeightedMC = 0;// weighted MC x distribution to check the distribution form

        // ---------- fill TreeA with data from RootTree source file ----------------
        // open RootTree file and set BranchAddress for all user defined variables
        TChain *fileSource = new TChain(SourceTreeName.c_str());
        fileSource->Add(rootTreeSourceFile.c_str());
        fileSource->SetBranchStatus("*",0); // deactivate all branches
        // make possible to read different variable types and cast to double (there must be a better way!)
        int xTypeIdent = 0; // type identifier: 1 = int, 2 = float, 3 = double
        int wTypeIdent = 0; // type identifier weight: 1 = int, 2 = float, 3 = double
        int yTypeIdent[NrAllMeasuredVariables]; // type identifier: 1 = int, 2 = float, 3 = double
        int x_int = 0;
        int w_int = 0;
        int y_int[NrAllMeasuredVariables];
        Float_t x_float = 0.0;
        Float_t w_float = 0.0;
        Float_t y_float[NrAllMeasuredVariables];
        double x_double = 0.0;
        double w_double = 0.0;
        double y_double[NrAllMeasuredVariables];
        if(label=="MOCA") {
                // check the leaf type for the sought-after x variable
                CheckLeafType(fileSource, BranchWantedX, xTypeIdent, x_int, x_float, x_double);
                // check the leaf type for the individual event weight
        }
        if(BranchEventWeight != "no_weight") {
                CheckLeafType(fileSource, BranchEventWeight, wTypeIdent, w_int, w_float, w_double);
        }
        for(int j=0; j<NrAllMeasuredVariables; ++j) {
                // check the leaf type for the measured observables
                CheckLeafType(fileSource, BranchMeasurVariable[j].c_str(), yTypeIdent[j], y_int[j], y_float[j], y_double[j]);
        }
        fileA->cd();
        int NrEntries = static_cast<int>(fileSource->GetEntries());
        Bool_t go = 0; // boolian to reject events with log10(0)
        for(int AB=0; AB<NrEntries; AB++) {
                weight = 1.0;
                fileSource->GetEntry(AB);
                go = 0;
                for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {
                        if(yTypeIdent[ij] == 1) y[ij] = static_cast<double>(y_int[ij]);
                        else if(yTypeIdent[ij] == 2) y[ij] = static_cast<double>(y_float[ij]);
                        else if(yTypeIdent[ij] == 3) y[ij] = static_cast<double>(y_double[ij]);
                        else {
                                y[ij] = -10000000; // no type determined?
                                cerr<<"no type determined for observable: "<<y[ij]<<endl;
                        }
                        if(logOption[ij] == 1) {
                                if(y[ij] > 0) {
                                        y[ij]=log10(y[ij]);
                                }
                                else {
                                        go = 1;
                                        break;
                                }
                        }
                        // read event weights from root tree
                        if(BranchEventWeight != "no_weight") {
                                if(wTypeIdent == 1) weight = static_cast<double>(w_int);
                                else if(wTypeIdent == 2) weight = static_cast<double>(w_float);
                                else if(wTypeIdent == 3) weight = static_cast<double>(w_double);
                                else {
                                        weight = -10000000; // no type determined
                                        cerr<<"no type determined for weight"<<endl;
                                }
                        }
                }
                if(go == 1) continue;
                if(label=="DATA") {
                        TreeA->Fill();
                }
                else if(label=="MOCA") {
                        if(xTypeIdent == 1) x = static_cast<double>(x_int);
                        else if(xTypeIdent == 2) x = static_cast<double>(x_float);
                        else if(xTypeIdent == 3) x = static_cast<double>(x_double);
                        else {
                                x = -10000000;// no type determined?
                                cerr<<"no type determined for sought-after variable"<<endl;
                        }
                        if(logOptionX == 1) {
                                if(x > 0) {
                                        x=log10(x); //TODO events < 0 => ?
                                }
                                else continue;
                        }
                        hWeightedMC->Fill(x, weight);
                        TreeA->Fill();
                }
                else if (label=="BKGD") {
                        TreeA->Fill();
                }
                eventIndex++;
                if(weight != 0) eventNonZero++;
                countw=countw+weight;
        }
        TreeA->Write("", TObject::kOverwrite); // restock the existing tree for several (MC) data types
        if(label == "MOCA") hWeightedMC->Write("", TObject::kOverwrite);
        fileA->Close();
        if(label == "BKGD") BackEventNr = countw;
        cout<<"number of events: "<<eventIndex<<endl;
        cout<<"number of events (weight != 0): "<<eventNonZero<<endl;
        cout<<"total sum of weights: "<<countw<<endl;
        cout<<"weight factor (nr of events / sum of weights) = "<<eventIndex/countw<<endl;
        cout<<"weight factor non zero (nr of events (weight != 0) / sum of weights) = "<<eventNonZero/countw<<endl;
        fileSource->Delete();
}


void TrueeReadIn::Pull(double fraction, TRandom3* searchEventFraction){


    const double randomNumber = searchEventFraction->Uniform(0, 1);
    MonteCarlo_Data.erase(MonteCarlo_Data.begin(),MonteCarlo_Data.end());
    Real_Data.erase(Real_Data.begin(),Real_Data.end());
    cout << "::: Fulldata::: "<<Full_data.size()<<endl;
    for(int j = 0; j < Full_data.size(); ++j){
                    if(randomNumber >= fraction) {
                        MonteCarlo_Data.push_back(Full_data.at(j));
                    }
                    else {
                        Real_Data.push_back(Full_data.at(j));
                    }
    }
    for(int j = 0; j < BG_Data.size(); j++)
        Real_Data.push_back(BG_Data.at(j));
}
