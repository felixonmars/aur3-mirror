//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

// Second pass of unfolding program
#include "Processor.h"
#include "math.h"
#include "TH3.h"
#include "TMath.h"
#include "TLegend.h"
#include "SmoothSplineFit.h"
#include "TMatrixD.h"
//#include "TDecompSVD.h"
#include "TPad.h"
#include "trueedata.h"
//#include "TMath.h"
#include <fstream>
#include "TPad.h"
#include "TF1.h"


using namespace std;

Processor::Processor(){

}

Processor::Processor(Input *InputObject, Preprocessor *Pass1Object, FxFunctionMC *mcFunctionFx) {
    //pullmode = InputObject->GetPullmode();
    print                           = InputObject->getPrintflag();
    MCFunctionFx                    = mcFunctionFx;
    SplineCalc                      = Pass1Object->getSplineCalc();
    BackWeight                      = Pass1Object->getBackWeight();
    fitMin                          = 0.0;
    JNULL                           = 0;
    JXflag                          = Pass1Object->getJXflag();
    LuminosityFactor                = Pass1Object->GetLuminosityFactor();
    NrMocaTypes                     = InputObject->GetNrMocaTypes();
    NrDataTypes                     = InputObject->GetNrDataTypes();

    for(Int_t a=0; a<NrMocaTypes; ++a)
    {
        MocaLumi[a]                 = InputObject->GetMocaLumi(a);
        MocaWeight[a]               = InputObject->GetMocaWeight(a);
    }
    for(Int_t a = 0; a < NrDataTypes; ++a)
    {
        DataLumi[a]                 = InputObject->getDataLumi(a);
    }

    NrBinsMC                        = Pass1Object->GetNrBinsMC();
    NrKnots                         = InputObject->GetNrKnots();
    NrKnotsMax                      = InputObject->GetNrKnotsMax();
    NrOfFitVariables                = InputObject->GetNrOfFitVariables();
    for(Int_t a=0; a<NrOfFitVariables; ++a)
    {
        NrBinsFitVar[a]             = InputObject->GetNrBinsFitVar(a);
        IndexFitVariable[a]         = InputObject->GetIndexFitVariable(a);
        FitVarLowLimit[a]           = Pass1Object->getFitVarLowLimit(a);
        FitVarHighLimit[a]          = Pass1Object->getFitVarHighLimit(a);
    }
    NrAllMeasuredVariables          = InputObject->GetNrAllMeasuredVariables();
    nameWantedX                     = InputObject->getNameWantedX();

    for(Int_t i=0; i<NrAllMeasuredVariables; ++i)
    {
        nameObsY[i]                 = InputObject->getNameObsY(i);
        JYflag[i]                   = Pass1Object->getJYflag(i);
        MaxValueRound[i]            = Pass1Object->getMaxValueRound(i);
        MinValueRound[i]            = Pass1Object->getMinValueRound(i);
    }

    MaxValueXRound                  = Pass1Object->getMaxValueXRound();
    MinValueXRound                  = Pass1Object->getMinValueXRound();

    NrBinsResult                    = InputObject->GetNrBinsResult();
    SumLumiData                     = Pass1Object->getSumLumiData();
    X                               = 0;


    for(Int_t c=0; c<NrBinsMC; ++c) {
        ValueFxMC[c]                = Pass1Object->GetValueFxMC(c);
        ErrorFxMC[c]                = Pass1Object->GetErrorFxMC(c);
        FittedValueFxMC[c]          = Pass1Object->GetFittedValueFxMC(c);
    }

    WantedXLowLimit                 = InputObject->GetWantedXLowLimit();
    WantedXHighLimit                = InputObject->GetWantedXHighLimit();

    pass1Object                     = Pass1Object;

    for(Int_t d = 0; d<4*(NrKnotsMax-3); ++d) {
        WeightEntryMC[d]            = 1.0;
    }

}
Processor::~Processor() {
}
void Processor::PrepareWeights(Bool_t funcFlag) {


    if(print > 1) cout<<"\nprepare weights for monte carlo histogram\n========================================="<<endl;
    for(Int_t i = 0; i<NrBinsMC; ++i) {
        WeightEntryMC[i]            = 1.0;// = HUW
        if(ValueFxMC[i]             !=0.0 && FittedValueFxMC[i] != 0.0) {
            // HUW = HUH and HUF
            WeightEntryMC[i]        = FittedValueFxMC[i]/ValueFxMC[i];

        }
    }
    //------------------ ...and fill array with user function---------------
    if(print > 1) cout<<"fill histogram content array with mc f(x)-function"<<endl;
    /*for(Int_t j = 0; j<NrBinsMC; ++j) {
                X = WantedXLowLimit+(static_cast<Double_t>(j)+0.5)*(WantedXHighLimit-WantedXLowLimit)/static_cast<Double_t>(NrBinsMC);
                XHistoValuesMC[j] = MCFunctionFx->getMCFxFunction(X);// =HUP
                //	cout<<"XHistoValuesMC"<<j+1<<"="<<XHistoValuesMC[j]<<endl;
        }*/



    ProdNrBins                      = 1;
    for(Int_t k = 0; k<NrOfFitVariables; ++k)
    {
        ProdNrBins                  = ProdNrBins*NrBinsFitVar[k];
    }
}

void Processor::ClearHistogramSpace(Int_t loop) {
    // H is the bin content of the n-dim. histogram
    for(Int_t ii = loop*ProdNrBins; ii<500000; ++ii) {
        H[ii]                       = 0.0;
    }
}

void Processor::FillHistogram(const std::string &name, Int_t loop) {

    //TODO divide this into 3 methods: RD, MC and BG
    if(print > 1) cout<<"\nfill "<<NrOfFitVariables<<"-dim. variable-histogram with "<<name<<" events"<<"\n===============================================\n"<<"loop = "<<loop<<endl;
    //---------------- create files for unfolding histograms -----------------
    Double_t weight                 = 0;
    Double_t WantedX                = 0;

    if(name == "DATA")
    {
        aux                         =  pass1Object->GetInput()->GetData()->Real_Data_after_pp;
    }
    else if(name == "MOCA")
    {
        aux                         = pass1Object->GetInput()->GetData()->MonteCarlo_Data_after_pp;
    }
    Double_t NrEntries              = aux.size();



    Int_t NN                        = 0;    // NN BinNrProduct of fit variables
    Int_t II                        = 0;
    Int_t BinNumberIn1DHisto        = 0;
    bool outside                    = 0;

    // --------------- 2-dim histograms to demonstrate the response matrix determination -------
    //	if(loop==0) {
    //		ex1 = new TExec("ex1","gStyle->SetPalette(1)");
    //		if(name=="DATA") {
    //			c2dimRDmit0 = new TCanvas("2dimRDmit0", "",600,600);
    //			h2dimRDmit0 = new TH2D("h2dimRDmit0", "RD Var1 vs Var0. Alle Bins", NrBinsFitVar[0], FitVarLowLimit[0], FitVarHighLimit[0], NrBinsFitVar[1], FitVarLowLimit[1], FitVarHighLimit[1]);
    //			c2dimRDmit0->cd();
    //		}
    //		else if(name=="MOCA") {
    //			c2dimMCmit0 = new TCanvas("2dimMCmit0", "",600,600);
    //			h2dimMCmit0 = new TH2D("h2dimMCmit0", "MC Var1 vs Var0. Alle Bins", NrBinsFitVar[0], FitVarLowLimit[0], FitVarHighLimit[0], NrBinsFitVar[1], FitVarLowLimit[1], FitVarHighLimit[1]);
    //			c2dimMCmit0->cd();
    //		}
    //	}

    //--------------- get events from tree B ------------------

    for(int BC = 0; BC<NrEntries; ++BC) {
        if(name == "MOCA")
        {
            WantedX                 = aux.at(BC)->get_x();
        }
        for(Int_t a = 0; a<NrAllMeasuredVariables; ++a){
            y[a]                    = aux.at(BC)->get_y(a);

        }
        weight                      = aux.at(BC)->get_weight();
        NTupleIndex                 = aux.at(BC)->get_NTupleIndex();

        // determine linear index of this event for a NrOfFitVariables-dim. distribution
        LinEventIndex               = 1;    // =IN
        NN                          = 1;
        outside                     = 0;
        for(int K = 0; K<NrOfFitVariables; K++)   //NrOfFitVariables = NrAllVariables from inputvariables
        {
            // BinNumberIn1DHisto is the index of the bin in which the value y lies on the y-axis
            BinNumberIn1DHisto      = static_cast<int>(1.0+(y[IndexFitVariable[K]]-FitVarLowLimit[K])/(FitVarHighLimit[K]-FitVarLowLimit[K])*static_cast<double>(NrBinsFitVar[K]));
            // entries outside the bin limits are ignored
            if(BinNumberIn1DHisto<1 || BinNumberIn1DHisto>NrBinsFitVar[K]) {
                outside             = true;
                cout<<"Value of the fit variable is outside the bin limits. Ignore event "<<endl;
                break;
            }
            // final LinEventIndex looks like this:
            // LinEventIndex = 1 + bin1 + bin2*NrBinsFitVar[1] + bin3*NrBinsFitVar[1]*NrBinsFitVar[2]
            // where bin1, bin2 and bin3 is the event bin at the related y axis
            LinEventIndex           = LinEventIndex+(BinNumberIn1DHisto-1)*NN;
            NN                      = NN*NrBinsFitVar[K];
        }
        if(outside == 1) continue;

        // modify weight for Monte Carlo
        if(name == "MOCA") {
            // BinNumberIn1DHisto is index of the bin where the x value is. Maximum number of bins is 120
            ///////////////////
            BinNumberIn1DHisto = static_cast<Int_t>(1.0+(WantedX-WantedXLowLimit)/(WantedXHighLimit-WantedXLowLimit)*NrBinsMC);//*120.0);//TODO not 120 but NrBinsMC
            //	L = static_cast<Int_t>(1.0+(WantedX-WantedXLowLimit)/(WantedXHighLimit-WantedXLowLimit)*120.0);//////
            //if(L>=1 && L<=120) weight=weight*WeightEntryMC[L-1];//TODO not 120 but NrBinsMC
            if(BinNumberIn1DHisto>=1 && BinNumberIn1DHisto<=NrBinsMC) weight=weight*WeightEntryMC[BinNumberIn1DHisto-1];//TODO not 120 but NrBinsMC
            weight = weight*MocaWeight[NTupleIndex]*SumLumiData;
            if(weight == 0) {
                cout<<"Weight="<<weight<<" MocaWeight="<<MocaWeight[NTupleIndex]<<" SumLumiData="<<SumLumiData<<" weightEntryMC="<<WeightEntryMC[BinNumberIn1DHisto-1]<<" L="<<BinNumberIn1DHisto<<endl;
                //	cout<<"wantedX="<<WantedX<<", WantedLow="<<WantedXLowLimit<<", WantedHigh="<<WantedXHighLimit<<endl;
            }
            if(MocaLumi[NTupleIndex]!=0.0) weight=weight/MocaLumi[NTupleIndex];

        }

        // filling bins ...
        //TODO divide H in real data, MC and BG (first try with references)
        // const Double_t*& Hdata= H+1*ProdNrBins-1;
        // Hdata[LinEventIndex]
        if(loop == 0) {
            // in first loop complete nf-dimensional histograms
            if(name == "DATA")
            {
                //h2dimRDmit0->Fill(y[0],y[1],weight);

                H[LinEventIndex+1*ProdNrBins-1]     = H[LinEventIndex+1*ProdNrBins-1]+weight;
                //if(H[LinEventIndex+1*ProdNrBins-1] == 0) cout<<":::::: gewicht in DATA "<<weight<<endl;
                //if(eventIndex==specialEventIndex) specialBin=LinEventIndex+ProdNrBins-1;
            }
            else if(name == "MOCA")
            {
                //h2dimMCmit0->Fill(y[0],y[1],weight);
                // moca as weight, weight^2
                H[LinEventIndex+2*ProdNrBins-1]     = H[LinEventIndex+2*ProdNrBins-1]+weight;
                H[LinEventIndex+3*ProdNrBins-1]     = H[LinEventIndex+3*ProdNrBins-1]+weight*weight;
            }
        }
        else
        {
            // second loop. Only non-zero bins in the histograms
            // translate bin index into new compact bin index
            LinEventIndex                           = nonZeroIndex[LinEventIndex-1];
            if(LinEventIndex == 0)
            {
                if(name == "DATA" || name == "MOCA")
                {
                    cerr<<"*****!!!!!!!!!should never happen!!"<<endl;
                }
                continue;
            }
            // ... this should never happen for data or moca
            if(name == "DATA")
            {
                H[LinEventIndex+ProdNrBins-1]       = H[LinEventIndex+ProdNrBins-1]+weight;
            }
            else if(name == "MOCA")
            {
                // moca - find four weights for four splines
                SplineCalc->SplineFuncValue(WantedX, NrKnots, WantedXLowLimit, WantedXHighLimit, JNULL, spline);

                II                                  = ProdNrBins+NrNonZeroBins*2+(LinEventIndex-1)*NrKnots+JNULL;
                for(Int_t J = 0; J<4; J++)
                {
                    H[II+J] = H[II+J]+weight*spline[J];
                    //					cout<<(II+J+1)<<" H="<<H[II+J]<<endl;
                }
            }
            else if(name == "BKGD") {
                // background - reweight
                weight                              = weight*BackWeight;
                H[LinEventIndex+ProdNrBins+NrNonZeroBins-1] += weight;
            }
        }
    }// end of input

    //fileB->Close();

    //cout<<"LinEventIndex="<<LinEventIndex<<endl;
    //	if(loop==0) {
    //		if(name=="DATA") {
    //			h2dimRDmit0->Draw("colz");
    //			ex1->Draw();
    //			c2dimRDmit0->Update();
    //			c2dimRDmit0->Print("./RDmit0.root");
    //		}
    //		else if(name=="MOCA") {
    //			h2dimMCmit0->Draw("colz");
    //			ex1->Draw();
    //			c2dimMCmit0->Update();
    //			c2dimMCmit0->Print("./MCmit0.root");
    //		}
    //	}
    aux.clear();

}
void Processor::SetCompactIndex() {
    // reset counter of the bins of the n-dim. histogram
    if(print > 1)
    {
        cout<<"\nset compact index to use only non zero bins in variable-histograms"<<endl;
    }
    int JJ                      = 0;
    for(Int_t r = 0; r<2; r++)
    {
        relErrorSum[r]          = 0.0;
        errorSum[r]             = 0.0;
    }
    // loop on all bins and check content
    NrNonZeroBins               = 0;
    for(Int_t I = 0; I<ProdNrBins; I++) {
        if(H[ProdNrBins+I] == 0.0 && H[2*ProdNrBins+I] == 0.0)
        {
            // data and moca bin empty - pointer set to zero
            nonZeroIndex[I]     = 0;
        }
        else {
            // non-empty bin - pointer defined
            NrNonZeroBins++;
            nonZeroIndex[I]     = NrNonZeroBins;// nonZeroIndex counts the bins with MC or data content
            // bin index for relative error of data ...
            JJ = 11;
            if(H[ProdNrBins+I] != 0.0)
            {
                // relative error of data
                relError        = 1.0/sqrt(fabs(H[ProdNrBins+I]));
                JJ              = static_cast<Int_t>(1.0+10.0*relError);
                if(JJ>10)
                {
                    JJ          = 10;
                }
              }

            relError            = TMath::Min(1.0, relError);
            if(JJ != 11)
            {
                relErrorSum[0]  = relErrorSum[0]+relError;
                errorSum[0]     = errorSum[0]+1.0;
            }
            // bin index for relative error of moca ...
            JJ                  = 11;
            if(H[2*ProdNrBins+I] != 0.0) {
                // relative error of moca
                relError        = sqrt(H[3*ProdNrBins+I])/fabs(H[2*ProdNrBins+I]);
                JJ              = static_cast<Int_t>(1.0+10.0*relError);
                if(JJ>10)
                {
                    JJ = 10;
                }
            }

            relError = TMath::Min(1.0, relError);
            if(JJ != 11) {
                relErrorSum[1]  = relErrorSum[1]+relError;
                errorSum[1]     = errorSum[1]+1.0;
            }
        }
    }
}


void Processor::RegUnfolding(Input *InputObject) {
    if(print > 0)
        cout<<"\nregularized unfolding starting\n=============================="<<endl;
    double Gamma                = pass1Object->getGamma();// normalization factor
    int NrDegreeOfFreedom       = InputObject->GetNrDegreeOfFreedom();
    //------------------- Unfolding fit ------------------------
    UnfoldingFit *Runfit        = new UnfoldingFit(InputObject, pass1Object, ProdNrBins, NrNonZeroBins, MCFunctionFx);

    if(NrBinsResult == 0)
    {
        // bin limits will be determined automatically
        Runfit->Fit(H); // unfolding fit
        // determine binned and scaled result
        Runfit->Result(0, BinContentResult, CovarMatrixResult);
        NrBinsResult            = Runfit->getNewNrBins();

        if(print > 1)
        {
            cout<<" recommended: NrBinsResult = "<<NrBinsResult<<endl;
        }
    }
    else {
        // number of bins for the final histogram is defined by the user
        Runfit->Fit(H); // unfolding fit
        // determine binned and scaled result
        Runfit->Result(NrBinsResult, BinContentResult, CovarMatrixResult);
    }
    fitMin = Runfit->GetFitMin();
    RegularizationTerm = Runfit->GetRegularizationTerm();
    //InputObject->setNrBinsNext(NrBinsResult);
    //--------- covariance matrix is saved as TMatrixD --------
    TMatrixD covMatrix(NrBinsResult, NrBinsResult);
    //-------------- print covariance matrix on the screen ----------
    Int_t ikj=0;
    for(Int_t ik = 0; ik<NrBinsResult; ++ik) {
        for(Int_t ij = 0; ij<=ik; ++ij) {
            CovarMatrixResult[ikj] = CovarMatrixResult[ikj]/Gamma;
            // diagonal elements are multiplied twice
            if(ik == ij) CovarMatrixResult[ikj] = CovarMatrixResult[ikj]/Gamma;
            covMatrix(ik, ij) = CovarMatrixResult[ikj];
            // fill all non diagonal elements
            // the symmetric CovarMatrixResult is saved in a compact mode, diagonal elements are saved only once
            if(ik != ij) covMatrix(ij, ik) = CovarMatrixResult[ikj];
            ikj++;
        }
    }

    ikj = 0;
    if(print > 1) {
        cout<<"\ncovariance matrix:"<<"\n------------------"<<endl;
        for(Int_t ik = 0; ik<NrBinsResult; ++ik) {
            for(Int_t ij = 0; ij<=ik; ++ij) {
                cout<<CovarMatrixResult[ikj]<<"   ";
                ikj++;
            }
            cout<<endl;
        }
    }
    ikj = 0;
    // calculate statistical uncertainties in every bin (square root of diagonal elements of covariance matrix)
    for(Int_t ik = 0; ik<NrBinsResult; ++ik) {
        BinErrorResult[ik] = sqrt(fabs(CovarMatrixResult[ikj+ik]));
        ikj = ikj+ik+1;
    }
    //------- this values will be needed in the main function
    Chi2pValue50 = Runfit->GetChi2pValue50();
    fitMin = Runfit->GetFitMin();
    Bool_t logOptionX = InputObject->getLogOptionX();

    Double_t nrDegFreeAutomaticallyDetermined = Runfit->getNrDegFreeForTau();
    if(InputObject->GetNrDegreeOfFreedom() == 0) InputObject->setNrDegreeOfFreedom(TMath::Nint(nrDegFreeAutomaticallyDetermined));
    for(Int_t b = 0; b<=NrBinsResult; ++b) {
        LimitsOfBinsResult[b] = Runfit->getNewLimitsOfBinsResult(b);
        //if(logOptionX == 1) LimitsOfBinsResult[b] = pow(10, LimitsOfBinsResult[b]);
    }
    if(print > 0){
        cout<<"\nbin contents of the final histogram"<<endl;
        cout<<"-----------------------------------"<<endl;
    }
    NrKnotsResult = Runfit->getNrKnotsResult();

    // get coefficients for the CheckUnfolding-Method
    for(Int_t ji = 0; ji<NrKnotsResult; ++ji) {
        Coefficient[ji] = Runfit->GetCoefficient(ji);
        //cout<<ji<<"th coefficient = "<<Coefficient[ji]<<endl;
    }

    //-------------------- store results in ResultFile ----------------------
    TFile *ResultFile;
    ResultFile = TFile::Open(pass1Object->GetInput()->getoutputpath()+"TrueeResultFile.root", "UPDATE", "", 0);
    ResultFile->cd("RealDataResults");
    // for histogram of the resulting event numbers
    Double_t eventNrInBin[NrBinsResult];
    Double_t errEventNrInBin[NrBinsResult];
    Double_t binWidth[NrBinsResult];
    if(InputObject->GetIgnoreLastBin())
        NrBinsResult--;
    for(Int_t i = 0; i<NrBinsResult; ++i) {
        if(logOptionX == 1)
            binWidth[i] = pow(10, LimitsOfBinsResult[i+1])-pow(10, LimitsOfBinsResult[i]);
        else
            binWidth[i] = LimitsOfBinsResult[i+1]-LimitsOfBinsResult[i];
        /*if(BinContentResult[i] < 0) {
                        cerr<<"***** bin content "<<i<<" is negative\nresult is not saved"<<endl;
                        ResultFile->Close();
                        // set values for 2-dim. checking histos to negative
                        // negative values do not appear, since the scale starts at > 0
                        Chi2pValue50 = -0.01;
                        KolmogorovValue = -0.01;
                        Chi2TestModeCompare = -0.01;
                        delete Runfit;
                        return;
                }*/
        BinContentResult[i] = BinContentResult[i]/Gamma;//*binWidth[i]/Gamma;//TODO hier noch mal checken mit verschiedenen Lumis und Weights
        //BinErrorResult[i] = BinErrorResult[i];//*binWidth[i]/Gamma;
        eventNrInBin[i] = BinContentResult[i]*binWidth[i];
        errEventNrInBin[i] = BinErrorResult[i]*binWidth[i];
        ////// neu /////////
        /*if(logOptionX == 1) {
                        Double_t binWidthLog = pow(10, LimitsOfBinsResult[i+1]) - pow(10, LimitsOfBinsResult[i]);
                        BinContentResult[i] = BinContentResult[i] * binWidth[i] / binWidthLog;
                        BinErrorResult[i] = BinErrorResult[i] * binWidth[i] / binWidthLog;
                }*/
        ////// neu /////////
        if(print > 0)
            cout<<"bin content["<<i<<"] = "<<BinContentResult[i]<<" +/- "<<BinErrorResult[i]<<endl;
    }
    // tree is filled with bin contents and bin limits as one "event"
    // covariance matrix is saved as TMatrixD in a branch
    TString treename;
    TString resultTitle = InputObject->getProjectTitle();
    TString resultName;
    TString eventsName;
    TString covarMatrixName;
    if(NrDegreeOfFreedom == 0) {
        treename.Form("ResultsTree_bins_%i_knots_%i_degFreeAutom_%f", NrBinsResult, NrKnots, nrDegFreeAutomaticallyDetermined);
        resultName.Form("result_bins_%i_knots_%i_degFreeAutom_%f", NrBinsResult, NrKnots, nrDegFreeAutomaticallyDetermined);
        eventsName = "events_" + resultName;
        covarMatrixName.Form("covar_matrix_bins_%i_knots_%i_degFree_%f", NrBinsResult, NrKnots, nrDegFreeAutomaticallyDetermined);
    }
    else {
        treename.Form("ResultsTree_bins_%i_knots_%i_degFree_%i", NrBinsResult, NrKnots, NrDegreeOfFreedom);
        resultName.Form("result_bins_%i_knots_%i_degFree_%i", NrBinsResult, NrKnots, NrDegreeOfFreedom);
        eventsName = "events_" + resultName;
        covarMatrixName.Form("covar_matrix_bins_%i_knots_%i_degFree_%i", NrBinsResult, NrKnots, NrDegreeOfFreedom);
    }

    TTree *ResultsTree = new TTree(treename, "bin limits, bin number and bin contents");
    char BranchBinLimit[NrBinsResult+1];
    char VariableBinLimit[NrBinsResult+1];
    for(Int_t a = 0; a<=NrBinsResult; ++a) {
        sprintf(BranchBinLimit, "LimitsOfBinsResult%d", a);
        sprintf(VariableBinLimit, "LimitsOfBinsResult%d/D", a);
        ResultsTree->Branch(BranchBinLimit, &LimitsOfBinsResult[a], VariableBinLimit);
    }
    char BranchBinContent[NrBinsResult];
    char BranchBinError[NrBinsResult];
    char VariableBinContent[NrBinsResult];
    char VariableBinError[NrBinsResult];
    for(Int_t a = 0; a<NrBinsResult; ++a) {
        sprintf(BranchBinContent, "BinContentResult%d", a);
        sprintf(BranchBinError, "BinErrorResult%d", a);
        sprintf(VariableBinContent, "BinContentResult%d/D", a);
        sprintf(VariableBinError, "BinErrorResult%d/D", a);
        ResultsTree->Branch(BranchBinContent, &BinContentResult[a], VariableBinContent);
        ResultsTree->Branch(BranchBinError, &BinErrorResult[a], VariableBinError);
    }
    //	ResultsTree->Branch("covMatrix", "TMatrixD", &covMatrixPointer, 64000, 0);
    ResultsTree->Fill();
    ResultsTree->Write();
    TString covNameTMatrixD = "T" + covarMatrixName;
    covMatrix.Write(covNameTMatrixD);
    // unfolded spectrum is saved also as a histogram
    //################ test: global correlation coefficient ##########
    // ------ calculate global correlation coefficient -----
    /*TMatrixD toInvertCovMatrix = covMatrix; // create a copy of covariance matrix to invert
        TDecompSVD svdCovMatrix(toInvertCovMatrix); // create svd of covariance matrix
        TMatrixD inverseCovMatrix = svdCovMatrix.Invert(); // create inverse of covariance matrix
       <<"------------ diagonal elements ------"<<endl;
        Double_t rho = 0.0; // global correlation coefficient
        Double_t meanRho = 0.0; // mean value of all global corr. coeff. over all bins
        for(Int_t ij = 0; ij<NrBinsResult; ++ij) {
                cout<<ij<<" svd = "<<(inverseCovMatrix(ij,ij))<<" uninverse = "<<(covMatrix(ij,ij))<<endl;
                Double_t diagElementCovMatrix = covMatrix(ij,ij);
                Double_t diagElementInvCovMatrix = inverseCovMatrix(ij, ij);
                rho = sqrt(1-1/(diagElementCovMatrix*diagElementInvCovMatrix));
                if(rho != rho) rho = 20; //
        //	if(rho > 1) rho = 1;
                cout<<ij<<" global corr. coeff. = "<<rho<<endl;
                meanRho = meanRho + rho;
        }
        meanRho = meanRho/NrBinsResult;
        cout<<"***********"<<meanRho<<endl;*/
    // ################## test did not work. inversion wrong? ###
    TH1D *hResult = new TH1D(resultName, resultTitle, NrBinsResult, LimitsOfBinsResult);
    TH1D *hEventsResult = new TH1D(eventsName, resultTitle, NrBinsResult, LimitsOfBinsResult);
    TH2D *hCovarMatrix = new TH2D(covarMatrixName,"covariance matrix", NrBinsResult, 0, NrBinsResult, NrBinsResult, 0, NrBinsResult);
    ikj = 0;
    for(Int_t i = 0; i<NrBinsResult; ++i) {
        hResult->Fill((LimitsOfBinsResult[i]+LimitsOfBinsResult[i+1])/2, BinContentResult[i]);
        hResult->SetBinError(i+1, BinErrorResult[i]);
        hEventsResult->Fill((LimitsOfBinsResult[i]+LimitsOfBinsResult[i+1])/2, eventNrInBin[i]);
        hEventsResult->SetBinError(i+1, errEventNrInBin[i]);

        bincenter[i] = (LimitsOfBinsResult[i]+LimitsOfBinsResult[i+1])/2;
        nondiff_Result[i] =  eventNrInBin[i];
        nondiff_Error[i] = errEventNrInBin[i];

        for(Int_t ij = 0; ij<=i; ++ij) {
            hCovarMatrix->SetBinContent(i+1,ij+1,CovarMatrixResult[ikj]);
            hCovarMatrix->SetBinContent(ij+1,i+1,CovarMatrixResult[ikj]);
            ikj++;
        }
    }
    //if(logOptionX == 1) gPad->SetLogy();
    hResult->SetXTitle(nameWantedX);
    TString yAxisName = "f(" + nameWantedX + ")";
    hResult->SetYTitle(yAxisName);
    hEventsResult->SetXTitle(nameWantedX);
    hEventsResult->SetYTitle("# events");
    //ResultFile->Write();
    hResult->Write();
    hEventsResult->Write();
    ResultFile->Close();
    delete Runfit;
}
void Processor::Comparisons(TString mode, Input *InputObject) {
    //////////////////////////////////////////////////////////////////////////////////////////
    Double_t fraction = InputObject->GetDataFraction();// fraction of pseudo data

    Double_t binWidth;
    Int_t NrDegreeOfFreedom = InputObject->GetNrDegreeOfFreedom();
    Bool_t logOptionX = InputObject->getLogOptionX();
    //--------------------- test/mode: compare unfolded result with the real distribution -----------------
    Double_t IntegralReal = 0;
    Double_t logLimits[NrBinsResult+1];
    /*	for(Int_t b = 0; b<=NrBinsResult; ++b) {
                logLimits[b] = pow(10, LimitsOfBinsResult[b]);
        }*/

    if(InputObject->GetMCFuncFlag() == 1) {
        // if the user f(x) function is defined, use a fraction of it
        // scale real content
        for(Int_t aha = 0; aha<NrBinsResult; ++aha) {
            realContent[aha] = fraction/(1-fraction);// scale the "generated RD" function considering fraction
        }
        Scale(NrBinsResult, LimitsOfBinsResult, realContent);// scale to "generated RD" function
        for(Int_t aha = 0; aha<NrBinsResult; ++aha) {
            if(print > 0){
                cout<<"scaled real bin content["<<aha<<"] = "<<realContent[aha]<<endl;
            }
            IntegralReal = IntegralReal+realContent[aha];
        }
    }
    else {
        // if no user f(x) function is define, read the RDfileA.root and create histogram of real distribution
        TH1D *hRealDist = new TH1D("RealDistribution", "", NrBinsResult, LimitsOfBinsResult);
        // -------- get true event distribution ---------
        Double_t weight = 0.0;
        Double_t wantedX = 0.0;
        Int_t NTupleIndex = 0;
        Int_t nrDataTypes = InputObject->GetNrDataTypes();
        Double_t DataWeight[nrDataTypes];
        for(Int_t i = 0; i<nrDataTypes; ++i) {
            DataWeight[i] = InputObject->GetDataWeight(i);
        }
        TFile *RDfileA = new TFile(pass1Object->GetInput()->getoutputpath()+"TrueeResultFile.root", "UPDATE");

        aux =  pass1Object->GetInput()->GetData()->Real_Data_after_pp;

        double nrEntries = aux.size();

        for(Int_t j = 0; j<nrEntries; ++j) {
            wantedX = aux.at(j)->get_x();
            weight = aux.at(j)->get_weight();

            weight = weight * DataWeight[NTupleIndex];

            //if(logOptionX == 0) {
            hRealDist->Fill(wantedX, weight);///wantedX));
            /*}
                        else {
                                hRealDist->Fill(pow(10, wantedX), (weight));// / pow(10, wantedX)));
                        }*/
            //TODO consider Luminosity as well!!!
        }
        if(print > 0)
            cout<<"\nbin content of the real distribution"<<"\n------------------------------------"<<endl;
        for(Int_t aha = 0; aha<NrBinsResult; ++aha) {
            if(logOptionX == 1)
                binWidth = pow(10, LimitsOfBinsResult[aha+1])-pow(10, LimitsOfBinsResult[aha]);
            else
                binWidth = LimitsOfBinsResult[aha+1]-LimitsOfBinsResult[aha];
            realContent[aha] = hRealDist->GetBinContent(aha+1)/binWidth;
            IntegralReal = IntegralReal+realContent[aha];
            if(print > 0)
                cout<<"real bin content["<<aha<<"] = "<<realContent[aha]<<endl;
        }
        RDfileA->Close();
        hRealDist->Delete();
    }

    //if(mode == "") {



    /* This one is moved to the frontend
                // --------------- for the pull mode the event contents are compared -----------
                Double_t realEventNrInBin[NrBinsResult];
                Double_t eventNrInBin[NrBinsResult];
                Double_t errEventNrInBin[NrBinsResult];
                for(Int_t i = 0; i<NrBinsResult; ++i) {
                        if(logOptionX == 1)
                                binWidth = pow(10, LimitsOfBinsResult[i+1])-pow(10, LimitsOfBinsResult[i]);
                        else
                                binWidth = LimitsOfBinsResult[i+1]-LimitsOfBinsResult[i];
                        realEventNrInBin[i] = realContent[i] * binWidth;
                        eventNrInBin[i] = BinContentResult[i] * binWidth;
                        errEventNrInBin[i] = BinErrorResult[i] * binWidth;
                }
                //------------ draw pull distributions for every bin --------------
                TFile *fPull = TFile::Open("PullDistributions.root", "UPDATE", "", 0);
                TH2D *hPull[NrBinsResult];
                TH1D *hPullProjection[NrBinsResult];
                TH1D *hRelativeDiffBin[NrBinsResult];
                TString pullName;
                for(Int_t i = 0; i<NrBinsResult; ++i) {
                        pullName.Form("pull_dist_bin_%i", i+1);
                        hPull[i] = (TH2D*)fPull->Get(pullName);
                        hPull[i]->Fill(errEventNrInBin[i],(realEventNrInBin[i]-eventNrInBin[i])/errEventNrInBin[i]);
                        hPull[i]->GetYaxis()->SetTitle("(true - unfolded) / error");
                        hPull[i]->GetXaxis()->SetTitle("error");
                        hPull[i]->GetYaxis()->SetRangeUser(-5, 5);
                        hPull[i]->Write("", TObject::kOverwrite);
                        // y projection of the pull distribution
                        pullName = "projection_" + pullName;
                        hPullProjection[i] = (TH1D*)fPull->Get(pullName);
                        hPullProjection[i]->Fill((realEventNrInBin[i]-eventNrInBin[i])/errEventNrInBin[i]);
                        hPullProjection[i]->GetXaxis()->SetTitle("(true - unfolded)/error");
                        hPullProjection[i]->Write("", TObject::kOverwrite);
                }
                for(Int_t i = 0; i<NrBinsResult; ++i) {
                        // relative difference between unfolded and true
                        pullName.Form("relative_difference_bin_%i", i+1);
                        hRelativeDiffBin[i] = (TH1D*)fPull->Get(pullName);
                        Double_t error = TMath::Max(realEventNrInBin[i], 1.0);
                        hRelativeDiffBin[i]->Fill((realEventNrInBin[i]-eventNrInBin[i])/error);
                        hRelativeDiffBin[i]->GetXaxis()->SetTitle("(true - unfolded)/max(true,1)");
                        hRelativeDiffBin[i]->GetYaxis()->SetTitle("# events");
                        hRelativeDiffBin[i]->Write("", TObject::kOverwrite);
                }
                fPull->Close();
                */


    //}
    if(mode == "test"|| mode=="pull") {
        //------------ create file to save comparison histograms --------------
        TFile *fCompare = TFile::Open(pass1Object->GetInput()->getoutputpath()+"TrueeResultFile.root", "UPDATE", "", 0);
        fCompare->cd("TestResults");
        TString canvasName;
        canvasName.Form("unfolded_vs_real_bins_%i_knots_%i_degFree_%i", NrBinsResult, NrKnots,NrDegreeOfFreedom);

        TCanvas *can = new TCanvas(canvasName, "",1024, 768);
        can->cd();
        //can->Divide(1,2);

        TPad* TP1 = new TPad("resultplot","resultplot",0,0,1,0.35);
        TPad* TP2 = new TPad("diffplot","diffplot",0,0.36,1,1);

        TP1->Draw();
        TP2->Draw();
        //can->SetFillColor(0);
        //------------ create histograms of real distribution and unfolded result -------------

        TString resultTitle = InputObject->getProjectTitle();
        TH1D *hResultClone = new TH1D("resultClone","", NrBinsResult, LimitsOfBinsResult);
        TH1D *hRealDistClone = new TH1D("realDistClone",resultTitle, NrBinsResult, LimitsOfBinsResult);
        TH1D* hDiffResultClone = new TH1D("hDiffResultClone", "Relative difference between unfolded distribution and MC truth" ,NrBinsResult,LimitsOfBinsResult);
        Chi2TestModeCompare = 0;
        for(Int_t i=0; i<NrBinsResult; ++i) {
            //Chi2TestModeCompare = Chi2TestModeCompare + pow((BinContentResult[i]-realContent[i])/BinErrorResult[i],2);
            Double_t error = 0.0;
            if(realContent[i] <= 0) {
                error = TMath::Max(1.0, realContent[i]);
            } else error = realContent[i];
            Chi2TestModeCompare = Chi2TestModeCompare + pow((BinContentResult[i]-realContent[i])/sqrt(error),2);
            //}
            //else Chi2TestModeCompare = Chi2TestModeCompare + pow((BinContentResult[i]-realContent[i])/sqrt(realContent[i]),2);
            hResultClone->Fill((LimitsOfBinsResult[i]+LimitsOfBinsResult[i+1])/2, BinContentResult[i]);
            hResultClone->SetBinError(i+1, BinErrorResult[i]);
            hRealDistClone->Fill((LimitsOfBinsResult[i]+LimitsOfBinsResult[i+1])/2, realContent[i]);
            hRealDistClone->SetBinError(i+1, 0);
            //hRealDistClone->Sumw2();
            if(realContent[i]!= 0)
            {
                hDiffResultClone->SetBinContent(i+1,(BinContentResult[i]-realContent[i])/realContent[i]);

                hDiffResultClone->SetBinError(i+1, 1/realContent[i]*BinErrorResult[i]);
            }
            //hDiffResultClone =&(*hResultClone / *hRealDistClone);
        }

        //hDiffResultClone = (TH1D*) hRealDistClone->Clone("MC/unfolded");
        //hDiffResultClone->Sumw2();
        //hDiffResultClone->Divide(hResultClone);
        Chi2TestModeCompare = Chi2TestModeCompare/static_cast<Double_t>(NrBinsResult);
        Double_t IntegralUnf = 0;
        for(Int_t aha = 0; aha<NrBinsResult; ++aha) {
            IntegralUnf = IntegralUnf+BinContentResult[aha];
        }
        hResultClone->SetLineColor(2);
        hResultClone->SetLineWidth(2);
        //hResultClone->SetMarkerStyle(20);
        //hResultClone->SetMarkerColor(2);
        hRealDistClone->SetLineColor(4);
        hRealDistClone->SetLineWidth(2);
        hRealDistClone->SetLineStyle(7);
        hRealDistClone->SetXTitle(nameWantedX);
        TString yName = "estimated f(" + nameWantedX + ")";
        hRealDistClone->SetYTitle(yName);

        hDiffResultClone->SetStats(false);
        hDiffResultClone->SetXTitle(nameWantedX);
        hDiffResultClone->SetYTitle("#frac{unfolded - MC}{MC}");
        hDiffResultClone->SetLineWidth(2);
        hDiffResultClone->SetLineColor(kRed);

        Double_t minValueTrueHisto = hRealDistClone->GetMinimum();
        Double_t maxValueTrueHisto = hRealDistClone->GetMaximum();
        Double_t minValueUnfHisto = hResultClone->GetMinimum();
        Double_t maxValueUnfHisto = hResultClone->GetMaximum();
        Double_t minY = TMath::Min(minValueTrueHisto, minValueUnfHisto);
        Double_t maxY = TMath::Max(maxValueTrueHisto, maxValueUnfHisto);
        if(minY > 0)
            hRealDistClone->GetYaxis()->SetRangeUser(0.5*minY, 1.5*maxY);
        else
            hRealDistClone->GetYaxis()->SetRangeUser(pow(10., -7.), 1.5*maxY);
        // following values will be filled in the 2-dim. parameter histograms
        // in truee.cxx to find an appropriate parameter set
        KolmogorovValue = 0;
        if(print > 0)
            cout<<"\nIntegral of unfolded distribution = "<<IntegralUnf<<"\nIntegral of real distribution = "<<IntegralReal<<endl;
        // compare distribution shapes with Kolmogorov test
        KolmogorovValue = hRealDistClone->KolmogorovTest(hResultClone);
        //  if(mode =="test"){
        TLegend *Leg = new TLegend(0.7,0.8,1,1);
        Leg->AddEntry(hRealDistClone, "true distribution", "l");
        Leg->AddEntry(hResultClone, "unfolded distribution", "LEP");
        Leg->SetFillColor(0);
        Leg->SetLineColor(0);
        TP2->cd();

        hRealDistClone->Draw();
        hResultClone->Draw("same");

        if(logOptionX == 1) gPad->SetLogy();

        hRealDistClone->Draw();
        hResultClone->Draw("same");

        Leg->Draw("same");
        // can->Update();
        TP1->cd();
        TF1 *zeroline = new TF1("zeroline","0",-1e6,1e6);
        zeroline->SetLineWidth(2);

        hDiffResultClone->SetFillColor(kRed);
        hDiffResultClone->Draw() ;
        zeroline->Draw("same");
        //can->Update();
        can->Write();
        //   }

        delete can;
        if(logOptionX == 1) gPad->SetLogy(false);
        //delete TP1;
        //delete TP2;
        fCompare->Close();

    }
}

void Processor::Scale(Int_t NrBins, Double_t *binLimit, Double_t *binContent) {
    // multiply all data by average function value of generated function
    Double_t Fac;
    for(Int_t i = 0; i<NrBins; ++i) {
        Fac = LuminosityFactor*AverageOfFunction(binLimit[i], binLimit[i+1], MCFunctionFx);

        binContent[i] = Fac*binContent[i];
    }
}

// --------------------- original pass 3 --------------------------
// the MC events are reweighted by unfolded result
// the distributions of observables (MC and data) are compared
// distributions of all MC observables (not only used fit variables) should match with data
void Processor::ResetHistogram() {
    // RPASS3
    //cout<<"\nreset histogram array\n====================="<<endl;
    // reset histogram buffer
    for(Int_t k = 0; k<NrAllMeasuredVariables; ++k) {
        //TODO variables instead of numbers?
        for(Int_t i = 0; i<120; ++i) {
            HistData[i][k] = 0.0;
            HistMoca[i][k] = 0.0;
            HistBack[i][k] = 0.0;
        }
    }
}

void Processor::CheckUnfolding(const std::string &name) {
    // RPASS3
    // create arrays with reweighted bin contents
    if(print >1)
        cout<<"\nchecking of unfolding starting\n===============================\n"<<name<<"\n----"<<endl;
    Int_t L = 0;
    Double_t weight = 0;
    Double_t WantedX = 0;
    Double_t NewNrKnots = 0;
    TFile *fileB = 0;
    TTree *TreeB = 0;
    if(name == "DATA") {
        aux =  pass1Object->GetInput()->GetData()->Real_Data_after_pp;
    }
    else if(name == "MOCA") {
        aux = (pass1Object->GetInput()->GetData()->MonteCarlo_Data_after_pp);
    }
    else if(name == "BKGD") {
        aux = ( pass1Object->GetInput()->GetData()->BG_Data_after_pp);
    }
    double NrEntries = aux.size();

    Functions *splineCalc = new Functions();

    //--------------- get events from TreeB (fileB) ------------------
    for(Int_t BC = 0; BC<NrEntries; ++BC) {
        if(name=="MOCA") WantedX = aux.at(BC)->get_x();
        for(int i =0; i<NrAllMeasuredVariables; ++i){
            y[i] = aux.at(BC)->get_y(i);

        }

        weight = aux.at(BC)->get_weight();
        // cout << y[1]<<endl;

        // reweighting
        //         cout << "reweight"<<endl;
        if(name == "MOCA") {
            // monte carlo - modify weight by unfolding fit result
            L = static_cast<Int_t>(1.0+(WantedX-WantedXLowLimit)/(WantedXHighLimit-WantedXLowLimit)*static_cast<Double_t>(NrBinsMC));
            if(L>=1 && L<=NrBinsMC) weight = weight*WeightEntryMC[L];
            weight = weight*MocaWeight[NTupleIndex]*SumLumiData;

            // weight from unfolding fit
            NewNrKnots = NrKnotsResult+0.5;
            weight = weight*splineCalc->FunctionValueFx(WantedX,Coefficient, static_cast<Int_t>(NewNrKnots),WantedXLowLimit, WantedXHighLimit);
            if(MocaLumi[NTupleIndex] != 0.0) weight = weight/MocaLumi[NTupleIndex];
        }
        else if(name == "BKGD") {
            // background
            weight = weight*BackWeight;
        }

        // loop on all measured quantities
        for(Int_t j = 0; j<NrAllMeasuredVariables; ++j) {
            if(JYflag[j] != 0) {
                // bin number ...
                L = static_cast<Int_t>(1.0+(y[j]-MinValueRound[j])/(MaxValueRound[j]-MinValueRound[j])*120.0);
                if(L>=1 && L<=120) {
                    // ... and add to histogram
                    if(name == "DATA") HistData[L-1][j] = HistData[L-1][j]+weight;
                    else if(name == "MOCA") HistMoca[L-1][j] = HistMoca[L-1][j]+weight;
                    else if(name == "BKGD") HistBack[L-1][j] = HistBack[L-1][j]+weight;
                }
            }
        }
    } // end of data

    if(name == "BKGD") {
        for(Int_t j = 0; j<NrAllMeasuredVariables; ++j) {
            if(JYflag[j] != 0) {
                // add background to moca
                for(Int_t i = 0; i<120; ++i) {
                    HistMoca[i][j] = HistMoca[i][j]+HistBack[i][j];
                }
            }
        }
    }

    //fileB->Close();
    delete splineCalc;
}
void Processor::PrintHistogram(Input *InputObject) {

    // fill histograms with reweighted bin contents
    TFile *fCheckUnfold = new TFile(pass1Object->GetInput()->getoutputpath()+"TrueeResultFile.root", "UPDATE");
    fCheckUnfold->cd("CheckUnfolding");
    TCanvas *cCheckUnfold[NrAllMeasuredVariables];
    TH1D *hCheckUnfoldMC[NrAllMeasuredVariables];
    TH1D *hCheckUnfoldRD[NrAllMeasuredVariables];
    Double_t xValue = 0.0;
    Double_t HistMocaY[120];
    Double_t HistDataY[120];
    TString sName;
    Double_t chi2 = 0.0;// chi^2 to compare MC and data
    Int_t ndfForChi2 = 0;// number of deg. of freedom of the chi^2
    for(Int_t i = 0; i < NrAllMeasuredVariables; ++i) {
        chi2 = 0.0;
        ndfForChi2 = 0;
        // SmoothSplineFit *smoothHistoMC = new SmoothSplineFit();
        //SmoothSplineFit *smoothHistoRD = new SmoothSplineFit();
        sName = "Check_unfolding_" + nameObsY[i];
        cCheckUnfold[i] = new TCanvas(sName, "", 600, 800);
        cCheckUnfold[i]->cd();
        sName.Form("Check_unfolding_mc_%i_", i);
        sName = sName + nameObsY[i];
        hCheckUnfoldMC[i] = new TH1D(sName, "", 120, MinValueRound[i], MaxValueRound[i]);
        sName.Form("Check_unfolding_rd_%i_", i);
        sName = sName + nameObsY[i];
        hCheckUnfoldRD[i] = new TH1D(sName, "", 120, MinValueRound[i], MaxValueRound[i]);
        // transformation to get 1-dimenional histogram from array
        for(Int_t j = 0; j < 120; ++j) {
            HistMocaY[j] = HistMoca[j][i];
            HistDataY[j] = HistData[j][i];
        }
        // smooth distribution by spline fit
        // smoothHistoMC->SmoothAndFit(HistMocaY, 120);
        // smoothHistoRD->SmoothAndFit(HistDataY, 120);
        //------------------- fill histograms -------------------------
        for(Int_t j = 0; j < 120; ++j) {
            xValue = MinValueRound[i]+(static_cast<Double_t>(j)-0.5)*(MaxValueRound[i]-MinValueRound[i])/static_cast<Double_t>(120);
            hCheckUnfoldMC[i]->Fill(xValue, HistMocaY[j]);
            hCheckUnfoldRD[i]->Fill(xValue, HistDataY[j]);
            // ------- calculate Chi^2 -----------
            if(HistDataY[j] != 0) {
                // since statistics for MC can be higher than for data due to event weights
                // only bins containing data events are taken into account
                chi2 = chi2 + pow((HistMocaY[j]-HistDataY[j]), 2)/HistDataY[j];
                ndfForChi2++;
            }
        }
        // ******** test KLD, Hell.Distance and Logl to compare distributions *******
        /*Double_t pMC = 0.0;// for KL divergence and Hellinger distance
                Double_t qRD = 0.0;// for KL divergence and Hellinger distance
                Double_t kld = 0.0;
                Double_t hellDist = 0.0;
                Double_t logl = 0.0;
                Int_t ndfLogl = 120;
                for(Int_t j = 0; j < 120; ++j) {
                        pMC = HistMocaY[j]/(hCheckUnfoldMC[i]->GetSumOfWeights());
                        qRD = HistDataY[j]/(hCheckUnfoldRD[i]->GetSumOfWeights());
                        if(pMC > 0)
                logl = logl + (pMC - qRD*log(pMC));
                if(pMC == 0.0){pMC = 1.E-20;}
                if(qRD == 0.0){qRD = 1.E-20;}
                kld = kld + ((pMC - qRD)*log10(pMC/qRD));
                hellDist = hellDist + 0.5*pow(sqrt(pMC) - sqrt(qRD), 2);
                }*/
        TString histoTitle;
        chi2 = chi2/(ndfForChi2-1);
        Double_t kolm = hCheckUnfoldMC[i]->KolmogorovTest(hCheckUnfoldRD[i]);
        histoTitle.Form("MC weighted with unfolded function. #Chi^{2} = %f, Kolm. = %f", chi2, kolm);
        hCheckUnfoldMC[i]->SetLineColor(2);
        hCheckUnfoldMC[i]->SetLineWidth(2);
        hCheckUnfoldMC[i]->SetTitle(histoTitle);
        hCheckUnfoldMC[i]->GetXaxis()->SetTitle(nameObsY[i]);
        hCheckUnfoldMC[i]->GetYaxis()->SetTitle("# events");
        Double_t minMC = hCheckUnfoldMC[i]->GetMinimum();
        Double_t maxMC = hCheckUnfoldMC[i]->GetMaximum();
        Double_t minRD = hCheckUnfoldRD[i]->GetMinimum();
        Double_t maxRD = hCheckUnfoldRD[i]->GetMaximum();
        Double_t minY = TMath::Min(minMC, minRD);
        Double_t maxY = TMath::Max(maxMC, maxRD);
        if(minY > 0)
            hCheckUnfoldMC[i]->GetYaxis()->SetRangeUser(0.5*minY, 1.1*maxY);
        else
            hCheckUnfoldMC[i]->GetYaxis()->SetRangeUser(pow(10., -7.), 1.1*maxY);
        hCheckUnfoldMC[i]->Draw();
        //hCheckUnfoldRD[i]->SetLineColor(3);
        hCheckUnfoldRD[i]->SetLineStyle(5);
        hCheckUnfoldRD[i]->SetLineWidth(3);
        hCheckUnfoldRD[i]->Draw("same");
        TLegend *Leg = new TLegend(0.7,0.8,1,1);
        Leg->AddEntry(hCheckUnfoldMC[i], "MC reweighted", "l");
        Leg->AddEntry(hCheckUnfoldRD[i], "real data", "l");
        Leg->SetFillColor(0);
        Leg->Draw("same");
        cCheckUnfold[i]->Write();
        //delete smoothHistoMC;
        //delete smoothHistoRD;
    }
    fCheckUnfold->Close();
}
