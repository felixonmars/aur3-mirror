#include<TrueeCorrelationMatrix.h>
#include<TChain.h>
#include<TString.h>
#include<iostream>
#include<TMath.h>
TrueeCorrelationMatrix::TrueeCorrelationMatrix() {
    Limit = -1;
    Log = false;
}

TH2F* TrueeCorrelationMatrix::GetCorrelationMatrix(){
    read_data();
    TH2F* CorrelationMatrix = new TH2F("Correlationmatrix","Correlationmatrix",Graphs.size(),-0.5,Graphs.size()-0.5,Graphs.size(),-0.5,Graphs.size()-0.5);
    for(unsigned int i = 0; i < Graphs.size(); ++i){
        CorrelationMatrix->GetXaxis()->SetBinLabel(i+1,Observables.at(i));
        CorrelationMatrix->GetYaxis()->SetBinLabel(i+1,Observables.at(i));
        for(unsigned int j = i+1; j < Graphs.size(); ++j){
            double aux = Graphs.at(i).at(j)->GetCorrelationFactor();
            if(aux<= 1. && aux >= -1.){
                CorrelationMatrix->Fill(i,j,Graphs.at(i).at(j)->GetCorrelationFactor());
                if(i!=j)
                    CorrelationMatrix->Fill(j,i,Graphs.at(i).at(j)->GetCorrelationFactor());
            }
        }

    }
    return CorrelationMatrix;
}

void TrueeCorrelationMatrix::read_data(){
    data.erase(data.begin(),data.end());        //reset
    Graphs.erase(Graphs.begin(),Graphs.end());   //reset
    Observables.erase(Observables.begin(),Observables.end());

    TChain* inChain = new TChain(Treename.c_str());
    inChain->Add(Path.c_str());


    TObjArray* BranchList = inChain->GetListOfBranches();
    for(int j = 0; j < BranchList->GetSize(); ++j){
        Observables.push_back(BranchList->At(j)->GetName());
    }
    Observables.resize(100);
    Graphs.resize(Observables.size());
    data.resize(Observables.size());

    for(unsigned int i = 0; i < Graphs.size(); ++i){
        Graphs.at(i).resize(Observables.size());
    }

    for(unsigned int j = 0; j < Observables.size(); ++j){

        inChain->SetBranchAddress(Observables.at(j),&data.at(j));
        for(unsigned int i = j; i < Observables.size();++i){
            Graphs.at(j).at(i) = new TGraph();
        }
    }
    double Entries;
    if(Limit != -1)
        Entries = TMath::Min(Limit,(double) inChain->GetEntries());
    else
        Entries = inChain->GetEntries();

    for(int k = 0; k < Entries; ++k){

        inChain->GetEntry(k);
        for(unsigned int j = 0; j < Observables.size(); ++j){
            for(unsigned int i = j; i < Observables.size(); ++i){
                if(data.at(j)>0 && data.at(i)>0)
                    Graphs.at(j).at(i)->SetPoint(k,TMath::Log10(data.at(j)),TMath::Log10(data.at(i)));
                else
                    Graphs.at(j).at(i)->SetPoint(k,data.at(j),data.at(i));


            }
        }
    }


}

