//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

// various linear algebra calculations

#include "LinearAlgebra.h"
#include "math.h"

using namespace std;

LinearAlgebra::LinearAlgebra() {
}

LinearAlgebra::~LinearAlgebra() {
}

void LinearAlgebra::General2MatrixMult(Double_t *A, Double_t *B, Double_t *C, Int_t N, Int_t M, Int_t L) {
	// GMAB (original)
	// Multiply general n-by-m matrix and general m-by-l matrix  to  form
	// general n-by-l matrix
	//	 C  :=    A   *    B
	//  N*L      N*M      M*L
	Double_t Sum;
	Int_t ij=0;
	Int_t ik=0;
	Int_t jk=0;

	for(Int_t k=1; k<=N; ++k) {
		for(Int_t i=1; i<=L; ++i) {
			jk=i;
			Sum=0.0;
			for(Int_t j=1; j<=M; ++j) {
				Sum=Sum+A[ij+j-1]*B[jk-1];
				jk=jk+L;
			}
			C[ik]=Sum;
			ik=ik+1;
		}
		ij=ij+M;
	}
}

void LinearAlgebra::GeneralSymGeneralTMatrixMult(Double_t *V, Double_t *A, Double_t *W, Int_t N, Int_t M) {
	// SMAVA (original)
	// Multiply symmetric N-by-N matrix from the left with general M-by-N
	// matrix and from the right with the transposed of the same general
	// matrix to form symmetric M-by-M matrix (used for error propagation).
	Double_t Cik;
	Int_t ij=0;
	Int_t ijs=0;
	Int_t il=-N;
	Int_t jk=0;
	Int_t lk=0;
	Int_t lkl=0;

	for(Int_t i=0; i<(M*M+M)/2; ++i) {
		W[i]=0.0;
	}

	for(Int_t i=1; i<=M; ++i) {
		ijs=ijs+i-1;
		il=il+N;
		lkl=0;
		for(Int_t k=1; k<=N; ++k) {
			Cik=0.0;
			lkl=lkl+k-1;
			lk=lkl;
			for(Int_t l=1; l<=k; ++l) {
				lk=lk+1;
				Cik=Cik+A[il+l-1]*V[lk-1];
			}
			for(Int_t l=k+1; l<=N; ++l) {
				lk=lk+l-1;
				Cik=Cik+A[il+l-1]*V[lk-1];
			}
			jk=k;
			ij=ijs;
			for(Int_t j=1; j<=i; ++j) {
				W[ij]=W[ij]+Cik*A[jk-1];
				ij=ij+1;
				jk=jk+N;
			}
		}
	}
}
void LinearAlgebra::SquareSymMatrix(Double_t *V, Double_t *VQ, Int_t N) {
	// SMQU (original)
	// calculate square of symmetric matrix V:  VQ:= V * V

	Double_t Sum;
	Int_t ij=0;
	Int_t ik=0;
	Int_t jk=0;

	for(Int_t i=1; i<=N; ++i) {
		for(Int_t j=1; j<=i; ++j) {
			ij=ij+1;
			Sum=0.0;
			ik=(i*i-i)/2;
			jk=(j*j-j)/2;
			for(Int_t k=1; k<=N; ++k) {
				if(k<=i) ik=ik+1;
				if(k<=j) jk=jk+1;
				Sum=Sum+V[ik-1]*V[jk-1];
				if(k>=i) ik=ik+k;
				if(k>=j) jk=jk+k;
			}
			VQ[ij-1]=Sum;
		}
	}
}

void LinearAlgebra::TransposeMatrix(Double_t *A, Double_t *B, Int_t N, Int_t M) {
	// GMTR (original)
	// Transpose N-by-M matrix A --> B
	for(Int_t i=0; i<M; ++i) {
		for(Int_t j=0; j<N; ++j) {
			B[i*N+j]=A[j*M+i];
		}
	}
}

void LinearAlgebra::SymGeneralMult(Double_t *V, Double_t *A, Double_t *B, Int_t N, Int_t M) {
	// SMVA (original)
	//  multiply symmetric N-by-N matrix and general N-by-M matrix
	//	 B   :=    V   *    A
	//	 N*M       N*N      N*M

	Double_t Sum;
	Int_t ij=0;
	Int_t ijs=1;
	Int_t ikb=0;
	Int_t jk=0;
	for(Int_t i=1; i<=N; ++i) {
		for(Int_t k=1; k<=M; ++k) {
			Sum=0.0;
			ij=ijs;
			jk=k;
			for(Int_t j=1; j<=N; ++j) {
				Sum=Sum+V[ij-1]*A[jk-1];
				if(j<i) {
					ij=ij+1;
				}
				else {
					ij=ij+j;
				}
				jk=jk+M;
			}
			B[ikb]=Sum;
			ikb=ikb+1;
		}
		ijs=ijs+i;
	}
}

void LinearAlgebra::EigenHouseholder(Double_t *V, Int_t nrKnots, Double_t *Eigenvalue, Double_t *EigenvecMatr, Int_t Direction) {
	// SMHHL (original)
	// Determination of eigenvalues and eigenvectors by Householder method
	//	      Method:
	// Reduce symmetric matrix V to tridiagonal form using Householder
	// transformations, and, by call to OrderEigenvalues, diagonalization of tridiagonal matrix
	// Eigenvalue(I)   = diagonal elements
	// EigenvecMatr(I,J) = transformations matrix (eigenvectors)
	// Direction   <  0  means eigenvalues in decreasing order
	// Direction   >= 0  means eigenvalues in increasing order

	Double_t tol=pow(10, -15);
	Double_t U[nrKnots][nrKnots];
	Int_t I = 0;
	Int_t ij = 0;
	Int_t ijk = 0;
	Int_t j1 = 0;
	Int_t L = 0;
	Double_t E[400];
	Double_t F = 0.0;
	Double_t G = 0.0;
	Double_t H = 0.0;
	Double_t HH = 0.0;
	Double_t SH = 0.0;// H square
	for(Int_t i=0; i<nrKnots; ++i) {
		Eigenvalue[i]=0;
//		cout<<i<<" eigen="<<Eigenvalue[i]<<endl;
		for(Int_t j=0; j<=i; ++j) {
			U[i][j]=V[ij];
//			cout<<"V("<<ij+1<<")="<<V[ij]<<endl;
			V[ij]=0.0;
			ij=ij+1;
		}
	}
//	cout<<"also U="<<U[1][7]<<endl;
	for(Int_t ii=2; ii<=nrKnots; ++ii) {
		I=nrKnots+2-ii;
		L=I-2;
		F=U[I-1][I-2];
		G=0.0;
		if(L!=0) {
			for(Int_t k=1; k<=L; ++k) {
				if(fabs(U[I-1][k-1])>tol) G=G+U[I-1][k-1]*U[I-1][k-1];
			}
			H=G+F*F;
		}
		// if G too small for orthogonality to be guaranteed,
		// the transformation is skipped
		if(G<tol) {
			E[I-1]=F;
			H=0.0;
		}
		else {
			L=L+1;
			SH=sqrt(H);
			if(F>=0.0) SH=-SH;
			G=SH;
			E[I-1]=SH;
			H=H-F*G;
			U[I-1][I-2]=F-G;
			F=0.0;
			for(Int_t J=1; J<=L; ++J) {
				U[J-1][I-1]=U[I-1][J-1]/H;
				G=0.0;
				// form element of a u
				for(Int_t K=1; K<=J; ++K) {
					if(fabs(U[J-1][K-1])>tol && fabs(U[I-1][K-1])>tol) {
						G=G+U[J-1][K-1]*U[I-1][K-1];
					}
				}
				j1=J+1;
				for(Int_t k=j1; k<=L; ++k) {
					if(fabs(U[k-1][J-1])>tol && fabs(U[I-1][k-1])>tol) {
						G=G+U[k-1][J-1]*U[I-1][k-1];
					}
				}
				E[J-1]=G/H;
				F=F+G*U[J-1][I-1];
			}
			// form k
			HH=F/(H+H);
			// form reduced a
			for(Int_t m=1; m<=L; ++m) {
				F=U[I-1][m-1];
				E[m-1]=E[m-1]-HH*F;
				G=E[m-1];
				for(Int_t n=1; n<=m; ++n) {
					U[m-1][n-1]=U[m-1][n-1]-F*E[n-1]-G*U[I-1][n-1];
				}
			}
		}
		Eigenvalue[I-1]=H;
	}
	Eigenvalue[0]=0.0;
	E[0]=0.0;
	ijk=0;
//		for(Int_t i=0; i<nrKnots; ++i) {
//			cout<<i<<" vor ordnen D="<<Eigenvalue[i]<<endl;
//			for(Int_t j=0; j<nrKnots; ++j) {
//				cout<<ijk<<" vorher UU="<<U[j][i]<<" i und j = "<<i<<" "<<j<<endl;
//				ijk++;
//			}
//		}
//	cout<<"hier U="<<U[7][1]<<endl;
	// accumulation of transformation matrices
	for(Int_t p=1; p<=nrKnots; ++p) {
		L=p-1;
		if(Eigenvalue[p-1]!=0.0) {
			for(Int_t q=1; q<=L; ++q) {
				G=0.0;
				for(Int_t r=1; r<=L; ++r) {
					G=G+U[p-1][r-1]*U[r-1][q-1];
				}
				for(Int_t r=1; r<=L; ++r) {
//					if(r==8 && q==2) cout<<"U="<<U[r-1][q-1]<<" G="<<G<<" U="<<U[r-1][p-1]<<endl;
					U[r-1][q-1]=U[r-1][q-1]-G*U[r-1][p-1];

				}
			}
		}
		Eigenvalue[p-1]=U[p-1][p-1];
		U[p-1][p-1]=1.0;
		for(Int_t s=1; s<=L; ++s) {
			U[p-1][s-1]=0.0;
			U[s-1][p-1]=0.0;
		}
	}
	ijk=0;
	for(Int_t i=0; i<nrKnots; ++i) {
//		cout<<i<<" vor ordnen E="<<E[i]<<endl;
		for(Int_t j=0; j<nrKnots; ++j) {
			EigenvecMatr[ijk]=U[j][i];
//			cout<<ijk<<" UU="<<U[j][i]<<" i und j = "<<i<<" "<<j<<endl;
			ijk++;
		}
	}
	OrderEigenvalues(nrKnots,Eigenvalue,E,EigenvecMatr,Direction);
//	ijk=0;
//	for(Int_t i=0; i<nrKnots; ++i) {
//		cout<<i<<" nach ordnen D="<<Eigenvalue[i]<<endl;
//		for(Int_t j=0; j<nrKnots; ++j) {
//			cout<<ijk<<" UU="<<EigenvecMatr[ijk]<<endl;
//			ijk++;
//		}
//	}
}

void LinearAlgebra::OrderEigenvalues(Int_t nrKnots, Double_t *Eigenvalue, Double_t *E, Double_t *EigenvecMatr, Int_t Direction) {
	// TQHHL (original)
	Float_t eps=pow(10, -6);
	Double_t B;
	Double_t C;
	Double_t F;
	Double_t G;
	Double_t H;
	Double_t P;
	Double_t R;
	Double_t S;
	Double_t U[nrKnots][nrKnots];
	Int_t ij=0;
	Int_t ijk=0;

	for(Int_t i=0; i<nrKnots; ++i) {
		for(Int_t j=0; j<nrKnots; ++j) {
			U[j][i]=EigenvecMatr[ij];
//			cout<<ij<<" U("<<j+1<<","<<i+1<<")="<<U[j][i]<<endl;
			ij=ij+1;
		}
	}
	Int_t I;
	Int_t irev;
	Int_t j;
	Int_t m;
	Int_t M1;
	Int_t one=1;
	if(Direction>=0) {
		//  increasing order of eigenvalues
		irev=1;
	}
	else {
		// decreasing order of eigenvalues
		irev=0;
	}
	for(Int_t i=1; i<nrKnots; ++i) {
		E[i-1]=E[i];
	}
	E[nrKnots-1]=0.0;
	B=0.0;
	F=0.0;
	for(Int_t l=1; l<=nrKnots; ++l) {
		j=0;
		H=eps*(fabs(Eigenvalue[l-1])+fabs(E[l-1]));
		if(B<H) B=H;

		// look for small sub-diagonal element
		for(m=l; m<=nrKnots; ++m) {
			one=1;
			if(fabs(E[m-1])<=B) {
				one=2;
				break;
			}
		}
		if(one==1) m=l;
		if(m==l) {
			Eigenvalue[l-1]=Eigenvalue[l-1]+F;
			continue;
		}

		// next iteration
		do {
			if(j==30) return;
			j++;
			G=Eigenvalue[l-1];
			P=(Eigenvalue[l]-G)/(2.0*E[l-1]);
			R=sqrt(1.0+P*P);
			Eigenvalue[l-1]=E[l-1];
			if(P<0.0) Eigenvalue[l-1]=Eigenvalue[l-1]/(P-R);
			if(P>=0.0) Eigenvalue[l-1]=Eigenvalue[l-1]/(P+R);
			H=G-Eigenvalue[l-1];
			for(Int_t i=l+1; i<=nrKnots; ++i) {
				Eigenvalue[i-1]=Eigenvalue[i-1]-H;
			}
			F=F+H;
			// QL transformation
			P=Eigenvalue[m-1];
			C=1.0;
			S=0.0;
			M1=m-1;
			for(Int_t ii=l; ii<=M1; ++ii) {
				I=M1+l-ii;
				G=C*E[I-1];
				H=C*P;
				if(fabs(P)>=fabs(E[I-1])) {
					C=E[I-1]/P;
					R=sqrt(1.0+C*C);
					E[I]=S*P*R;
					S=C/R;
					C=1.0/R;
				}
				else {
					C=P/E[I-1];
					R=sqrt(1.0+C*C);
					E[I]=S*E[I-1]*R;
					S=1.0/R;
					C=C/R;
				}
				P=C*Eigenvalue[I-1]-S*G;
				Eigenvalue[I]=H+S*(C*G+S*Eigenvalue[I-1]);

				// form vector
				for(Int_t k=1; k<=nrKnots; ++k) {
					H=U[k-1][I];
					U[k-1][I]=S*U[k-1][I-1]+C*H;
					U[k-1][I-1]=C*U[k-1][I-1]-S*H;
				}
			}
			E[l-1]=S*P;
			Eigenvalue[l-1]=C*P;
		} while(fabs(E[l-1])>B);
		Eigenvalue[l-1]=Eigenvalue[l-1]+F;
	}
	Int_t K;
	for(Int_t n=1; n<=nrKnots; ++n) {
		K=n;
		P=Eigenvalue[n-1];
		// search for largest/smallest eigenvalue
		for(Int_t J=n; J<=nrKnots; ++J) {
			if(irev==0 && Eigenvalue[J-1]<=P) continue;
			if(irev==1 && Eigenvalue[J-1]>=P) continue;
			K=J;
			P=Eigenvalue[J-1];
		}
		if(K!=n) {
			// exchange
			Eigenvalue[K-1]=Eigenvalue[n-1];
			Eigenvalue[n-1]=P;
			for(Int_t J=0; J<nrKnots; ++J) {
				P=U[J][n-1];
				U[J][n-1]=U[J][K-1];
				U[J][K-1]=P;
			}
		}
	}
	for(Int_t i=0; i<nrKnots; ++i) {
		for(Int_t j=0; j<nrKnots; ++j) {
			EigenvecMatr[ijk]=U[j][i];
//			cout<<ijk+1<<" Matrix="<<EigenvecMatr[ijk]<<" "<<j<<" "<<i<<endl;
			ijk=ijk+1;
		}
	}
}
