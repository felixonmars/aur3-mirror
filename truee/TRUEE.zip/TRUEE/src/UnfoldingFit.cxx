//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

#include "UnfoldingFit.h"
#include "ScalarProd.h"
#include "math.h"
#include "TMath.h"
#include "TRandom3.h"
#include "TF1.h"


using namespace std;

UnfoldingFit::UnfoldingFit() {
}

UnfoldingFit::UnfoldingFit(Input *InputObject, Preprocessor *Pass1Object, Int_t prodNrBins, Int_t nrNonZeroBins, FxFunctionMC *mcFunctionFx) {
    print                           = InputObject->getPrintflag();
    inputObject                     = InputObject;
    FXpositive                      = InputObject->GetFXpositive();
    MCFunctionFx                    = mcFunctionFx;
    LuminosityFactor                = Pass1Object->GetLuminosityFactor();
    fitMin                          = 0.0;
    NrConstraints                   = InputObject->GetNrConstraints();//=NCNS
    NrDegreeOfFreedom               = InputObject->GetNrDegreeOfFreedom();
    NrKnots                         = InputObject->GetNrKnots();
    NrKnotsMax                      = InputObject->GetNrKnotsMax();
    NrNonZeroBins                   = nrNonZeroBins;
    ProdNrBins                      = prodNrBins;

    for(Int_t a=0; a<NrConstraints; ++a)
    {
        Xconstraint[a]              = InputObject->GetXconstraint(a);
        FXconstraint[a]             = InputObject->GetFXconstraint(a);//=FCNS
    }
    NrBinsResult                    = InputObject->GetNrBinsResult();
    for(Int_t b=0; b<=NrBinsResult; ++b)
    {
        LimitsOfBinsResult[b]       = InputObject->GetLimitsOfBinsResult(b);
    }

    //------------- reset coefficients -----------------
    for(Int_t i = 0; i<NrKnotsMax; i++)
    {
        Coefficient[i]              = 0.0;
        CoefficientResult[i]        = 0.0;
        Gradient[i]                 = 0.0;
    }
    for(Int_t i = 0; i<NrKnotsMax*NrKnotsMax; ++i)
    {
        TransfMatrix[i]             = 0;
    }
    for(Int_t i = 0; i<(63+63*63)/2; ++i)
    {
        CovarianceMatrix[i]         = 0.0;
        Hessian[i]                  = 0.0;
    }
    for(Int_t i = 0; i<4000; ++i)
    {
        RegMatrix[i]                = 0.0;
    }
    WantedXHighLimit                = InputObject->GetWantedXHighLimit();
    WantedXLowLimit                 = InputObject->GetWantedXLowLimit();


    SplineCalc                      = Pass1Object->getSplineCalc();
    RegularizationMathObject        = new RegularizationMath(InputObject, SplineCalc);
    MatrixTrafo                     = new LinearAlgebra();
    MinObject                       = new Minimize();
};


UnfoldingFit::~UnfoldingFit() {
    delete MatrixTrafo;
    delete MinObject;
    delete RegularizationMathObject;
};



void UnfoldingFit::Fit(Double_t *H) {

    // unfolding fit (original RUNFIT)
    // the fit uses the one-, two- or three-dimensional distribution of events.
    // The Monte Carlo distribution plus background distribution is fitted to the data distribution
    // In the first iteration the least squares method is used, to determine initial values of the fit parameter
    // The following iterations are based on the poisson statistic of data events
    // and use the maximum likelihood method.
    // The function value is a chi square for the first iteration
    // and similar to a chi square for the following iterations


    Double_t Fmax;
    Double_t FunctionReg;// this is the final likelihood function with regularization term which has to be minimized
    Double_t RegTerm[NrKnotsMax];// regularization term
    Double_t SumGradient;// = AVR

    Double_t test                   = 0.0;
    Double_t testl                  = 0.0;

    Double_t Amplitude[NrKnotsMax];// = AM
    Double_t EigenvalueRegMatrix[NrKnotsMax];// = DE

    for(Int_t i = 0; i<NrKnotsMax; i++) {
        Amplitude[i]                = 0.0;
        EigenvalueRegMatrix[i]      = 0.0;
    }
    //Int_t  LG=0;
    Int_t IVR;
    Int_t IPR;
    Int_t loopbreak                 = 0;
    Int_t NC=-1;
    //NrKnots=inputObject->GetNrKnots();
    //Int_t M=(NrKnots-1);
    Int_t IT                        = 0;

    if(NrKnots == 0)
    {
        cerr<<"****** ERROR: number of knots is = "<<NrKnots<<endl;
    }

    if(print > 1)
    {
        cout<<"Parameters:\n-----------"<<"\nnumber of knots = "<<NrKnots<<"\nx low limit = "<<WantedXLowLimit<<"\nx high limit = "<<WantedXHighLimit<<endl;
        if(NrDegreeOfFreedom == 0)
        {
            cout<<"number of degrees of freedom will be determined automatically"<<endl;
        }
        else
        {
            cout<<"number of degrees of freedom = "<<NrDegreeOfFreedom<<endl;
        }
    }

    //------------------- specify constraints for positive result values ----------------------------
    if(FXpositive)
    {
        RegularizationMathObject->ConstraintFlags(0.0, 0.0);
    }
    //-------------- specify all constraint value/ function pairs --------------
    for(Int_t l=0; l<NrConstraints; l++)
    {
        RegularizationMathObject->ConstraintFlags(Xconstraint[l],FXconstraint[l]/MCFunctionFx->getMCFxFunction(Xconstraint[l])/LuminosityFactor);
    }

    //TODO print screen
    //====================== start next iteration =======================
    if(print > 1)
    {
        cout<<"\nunfolding fit starting (max. 12 iterations)\n"<<endl;
    }
    while(IT<13) {
        loopbreak                   = 0;
        IT++;
        //	cout<<"------------------- iteration = "<<IT<<" -------------------"<<endl;
        // calculate function, gradient, Hessian
        //IT=1 oder 2: least squares, >2: max likelihood
        FunctionGradientHessian(IT, H);// H bin contents of n-dim histograms from pass2
        // define regularization matrix RegMatrix ...
        RegularizationMathObject->DefRegularizationMatrix(RegMatrix);

        // calculate contribution from regularization term RegTerm without Tau
        MatrixTrafo->GeneralSymGeneralTMatrixMult(RegMatrix,Coefficient,RegTerm,NrKnots,1);
        // calculation of Coefficients and nr of deg. free. for a new value of Tau:
        RegularizationMathObject->CalculateCoeff(TransfMatrix, Hessian, Gradient, Coefficient, Amplitude, EigenvalueRegMatrix, Tau, NrDegFreeForTau, NrIndepLinComb);
        //	TransfMatrix contains coefficients of orthonormalized functions (?)


        // determine number of degrees of freedom
        if(IT<6) {
            if(NrDegreeOfFreedom>0) {
                NrDegreeOfFreedomAutom  =NrDegreeOfFreedom;
            }
            else if(NrDegreeOfFreedom<0 && IT<=2) {
                NrDegreeOfFreedomAutom  =-NrDegreeOfFreedom;
            }
            else NrDegreeOfFreedomAutom =static_cast<Int_t>(NrDegFreeForTau+1.0);
        }
        //cout<<"chosen ndf: "<< NrDegreeOfFreedomAutom<<endl;
        NrDegreeOfFreedomAutom          =TMath::Min(NrDegreeOfFreedomAutom,30);
        RegularizationMathObject->DetermineTau(TransfMatrix, Gradient,Coefficient,Amplitude,EigenvalueRegMatrix, Tau,Fmax,iVeto,static_cast<Double_t>(NrDegreeOfFreedomAutom));

        FunctionReg=Function+0.5*Tau*RegTerm[0];

        // initial values set to step vector
        if(IT==1) {
            // first iteration
            SumGradient                 = 0.0;
            IVR                         = 0;
            for(Int_t j=0; j<NrKnots; j++) {
                if(Gradient[j]<0.0)
                {
                    IVR                 = 1;
                }
                SumGradient             = SumGradient+Gradient[j];
                Coefficient[j]          = Gradient[j];
            }
            if(IVR==0)
                continue;
            SumGradient                 = SumGradient/static_cast<Double_t>(NrKnots);

            for(Int_t k=0; k<NrKnots; k++) {
                Coefficient[k]          = SumGradient;
            }
            continue;
        }
        if(IT>3 && iVeto==0 && (TMath::Max(test, testl)<0.02 || test==0.0)) {
            if(print > 1) cout<<"CONVERGENCE! Recommended number of degrees of freedom from noise analysis is: "<<NrDegFreeForTau<<endl;
            break;
        }
        if(IT==12) {
            if(print > 1) cout<<"\nno convergence after 12 iterations - continue without"<<endl;
            break;
        }

        // minimization along step vector, restricted to keep
        // nonnegative content in each knot interval
        IPR                             = 2;

        // start-init-MINST for minimum search
        //  search in positive direction only
        MinObject->Initialize(0.0, Fmax, IPR);
        Double_t FAC=0.0;
        do {
            FunctionGradientHessian(-IT, H);
            RegularizationMathObject->DefRegularizationMatrix(RegMatrix);
            MatrixTrafo->GeneralSymGeneralTMatrixMult(RegMatrix,Coefficient,RegTerm,NrKnots,1);
            FunctionReg=Function+0.5*Tau*RegTerm[0];

            RegularizationTerm = 0.5*Tau*RegTerm[0];

            MinObject->SearchMinimum(FunctionReg,FAC,NC);
            for(Int_t m=0; m<NrKnots; m++) {
                Coefficient[m]=Coefficient[m]+FAC*Gradient[m];
                //	cout<<IT<<" "<<m<<" coeff = "<<Coefficient[m]<<endl;
            }
            loopbreak++;
            if(loopbreak == 100) {
                cerr<<"***** infinite loop in UnfoldingFit => new iteration *****"<<endl;
                break;
            }
        } while(NC<0);
        // minst convergence or non-convergence
        testl=test;
        test=MinObject->getFunctionChange();

        fitMin = FunctionReg;
        cout << FunctionReg << "\t"<<Function<<"\t"<< RegularizationTerm<< endl;


        //... next iteration
    }
    //--------- convergence reached or break ---------

    //------------- get covariance matrix ----------------
    RegularizationMathObject->CovarianceMatrix(TransfMatrix, Hessian);
    //RegularizationMathObject->CovarianceMatrix(TransfMatrix, CovarianceMatrix);
    FunctionGradientHessian(-IT, H);
    // store result: number of knots, limits, ...

    NrKnotsResult=static_cast<Float_t>(NrKnots);
    //WantedXLowLimitResult = WantedXLowLimit;
    //WantedXHighLimitResult = WantedXHighLimit;
    for(Int_t m=0; m<NrKnots; ++m) {
        CoefficientResult[m]=Coefficient[m];
        //cout<<m<<" coeff = "<<CoefficientResult[m]<<endl;
    }
    for(Int_t n=0; n<((NrKnots*NrKnots+NrKnots)/2); ++n) {
        CovarianceMatrix[n]= Hessian[n];
        //cout<<"hesse = "<<Hessian[n]<<" cov = "<<CovarianceMatrix[n]<<endl;
    }
}

void UnfoldingFit::FunctionGradientHessian(Int_t index, Double_t *H) {
    // RUNFUN
    // calculate function value, gradient and hessian
    // for least squares sum (abs(index)<3), or
    // for maximum likelihood sum (abs(index)>2)
    // for index<0 calculate only the function value
    //Int_t specialBin=inputObject->GetSpecialBin();
    Int_t indexMC;
    Double_t Hmc[NrKnotsMax];
    Double_t rhsFredholm                = 0.0;
    //	Double_t D=0.0;
    Double_t FuncSum                    = 0.0;
    //SF=0.0;
    //SD=0.0;
    Int_t IJ;

    Double_t weight                     = 1.0;
    //-------- clear gradient and Hessian ----------------
    if(index>0) {
        IJ=0;
        for(Int_t i=0; i<NrKnots; i++) {
            Gradient[i]                 = 0.0;
            for(Int_t j=0; j<=i; j++) {
                Hessian[IJ]             = 0.0;
                IJ                      = IJ+1;
            }
        }
    }
    // loop over all bins
    indexMC                             = ProdNrBins+NrNonZeroBins+NrNonZeroBins;

    for(Int_t l=0; l<NrNonZeroBins; l++)
    {
        // data and...
        //	D=H[ProdNrBins+l];
        //SD=SD+D;
        for(Int_t trafo=0; trafo<NrKnots; trafo++) {
            Hmc[trafo]                  = H[indexMC+trafo];
        }
        // ... and fitted events (background + Monte Carlo)
        // rhsFredholm = b + Aa = background + Matrix*coeff
        rhsFredholm                     = H[ProdNrBins+NrNonZeroBins+l] + ScalarProd(Coefficient, Hmc, NrKnots);
        //SF=SF+F;
        if(H[ProdNrBins+l]!=0.0 || rhsFredholm!=0.0)
        {
            // data events and/or fitted events in bin
            if(fabs(index)<=1 || rhsFredholm<1.0)
            {
                // least square sum
                weight                  = 1.0/TMath::Max(1.0, H[ProdNrBins+l]);
                // function sum: sum((b + Aa - g_m)^2) => least squares sum
                FuncSum                 = FuncSum+weight*pow((rhsFredholm-H[ProdNrBins+l]),2);
                if(index>0) {
                    // calculate ...
                    IJ=0;
                    for(Int_t i=0; i<NrKnots; i++)
                    {
                        // ... gradient = sum((b + Aa - g)*A)
                        Gradient[i]     = Gradient[i]+weight*(H[ProdNrBins+l]-rhsFredholm)*H[indexMC+i];

                        for(Int_t j=0; j<=i; j++)
                        {
                            // ... and hessian = A*A
                            Hessian[IJ] = Hessian[IJ]+weight*H[indexMC+i]*H[indexMC+j];
                            IJ=IJ+1;
                        }
                    }
                }
            }
            else {
                // Poisson (maximum likelihood) sum
                if(H[ProdNrBins+l]==0.0) {
                    FuncSum             = FuncSum+2.0*rhsFredholm-1.0;
                }
                else {
                    // constants (H[ProdNrBins+l]) added, to have likelihood fcn like chisqr
                    FuncSum             = FuncSum-2.0*(H[ProdNrBins+l]*log(rhsFredholm/H[ProdNrBins+l])-(rhsFredholm-H[ProdNrBins+l]));
                }
                if(index>0) {
                    // calculate ...
                    IJ=0;
                    for(Int_t k=0; k<NrKnots; k++) {
                        // ... gradient ...
                        Gradient[k]     = Gradient[k]+(H[ProdNrBins+l]/rhsFredholm-1.0)*H[indexMC+k];
                        // cout<<k+1<<" Gradient="<<Gradient[k]<<endl;
                        for(Int_t ll=0; ll<=k; ll++) {
                            // ... hessian
                            Hessian[IJ] = Hessian[IJ]+H[ProdNrBins+l]*H[indexMC+k]/rhsFredholm*H[indexMC+ll]/rhsFredholm;
                            //							cout<<IJ+1<<"He="<<Hessian[IJ]<<" D="<<H[ProdNrBins+l]<<" F="<<rhsFredholm<<endl;
                            //							cout<<"H="<<H[indexMC+k]<<" H="<<H[indexMC+ll]<<endl;
                            IJ          = IJ+1;
                        }
                    }
                }
            }
        }
        indexMC=indexMC+NrKnots;
    }
    Function=FuncSum;
}

void UnfoldingFit::Result(Int_t NrBins, Double_t *BinContentResult, Double_t *CovarMatrixResult) {
    // RURSLT
    // RUN result in x bins for NB bins in bin limits
    //     NrBins = 0  automatic bin limits
    //	   NrBins < 0  equidistant bins
    //	   NrBins > 0  bins limits from user

    //if(NrBins==0) {
    //	 cout<<"\ncalculation of the unfolding results"<<endl;
    //	 cout<<"===================================="<<endl;
    //}
    //	inputObject->setWantedXHighLimit(WantedXHighLimit);
    //	inputObject->setWantedXLowLimit(WantedXLowLimit);

    NewNrBins = NrBins;// NewNrBins = NN
    Double_t S[NrKnots];
    if(NewNrBins == 0) {
        // automatic bin definition
        NewNrBins = NrDegreeOfFreedom;
        // cout<<"in result NewNrBins = "<<NewNrBins<<endl;
        if(NewNrBins <= 0) NewNrBins = NrDegreeOfFreedomAutom;
        if(NewNrBins == 0) NewNrBins = 12;

        // trafo
        Int_t &nn = NewNrBins;
        //		cout<<"======== transf. matrix"<<endl;
        //		for(Int_t i = 0; i<NrKnots*NrKnots; ++i) {
        //			//if(i>=168)
        //			cout<<i+1<<" "<<TransfMatrix[i]<<endl;
        //		}
        //		cout<<"\n"<<endl;
        // TransfMatrix contains eigenvectors.
        // Use eigenvector of the first non-significant fourier coeff. (from TransfMatrix) to determine bin limits
        RegularizationMathObject->DetermineBinLimits(NewNrBins+1,TransfMatrix, nn, LimitsOfBinsResult, NrKnotsMax);
        NewNrBins=nn;


        //		// cout<<" automatically determined bin limits:"<<endl;
        //		for(Int_t i=1; i<NewNrBins; ++i) {
        //			// cout<<i<<" limit="<<LimitsOfBinsResult[i]<<endl;
        //		}
        // check failure ...
        if(NewNrBins>0) {
            if(LimitsOfBinsResult[0]==LimitsOfBinsResult[NewNrBins]) NewNrBins=-NewNrBins;
        }
        else {
            NewNrBins=NrDegreeOfFreedom;
            if(NewNrBins<=0) NewNrBins=NrDegreeOfFreedomAutom;
            NewNrBins=-NewNrBins;
        }
    }
    else if(NewNrBins>0) {
        // copy from argument

        //TODO for the parameter loop in truee.cxx:
        // the subsequent binning is equidistant
        for(Int_t i=0; i<=NewNrBins; ++i) {
            LimitsOfBinsResult[i]=inputObject->GetLimitsOfBinsResult(i);
            //LimitsOfBinsResult[i] = WantedXLowLimit+i*binWidth;
        }
        if(LimitsOfBinsResult[0] == LimitsOfBinsResult[1]) {
            // if max nr of bins is given
            Double_t binWidth = (WantedXHighLimit-WantedXLowLimit)/NewNrBins;
            for(Int_t i=0; i<=NewNrBins; ++i) {
                LimitsOfBinsResult[i] = WantedXLowLimit+i*binWidth;
            }
        }

    }
    if(NewNrBins<0) {
        // equidistant bins
        NewNrBins=-NewNrBins;
        // ... calculate equidistant bin limits
        LimitsOfBinsResult[0]=WantedXLowLimit;
        for(Int_t j=1; j<NewNrBins; ++j) {
            LimitsOfBinsResult[j]=WantedXLowLimit+static_cast<Double_t>(j)*(WantedXHighLimit-WantedXLowLimit)/static_cast<Double_t>(NewNrBins);
        }
        LimitsOfBinsResult[NrBins]=WantedXHighLimit;// here NewNrBins
    }
    // ... reset output array ...
    for(Int_t k=0; k<NewNrBins; ++k) {
        BinContentResult[k]=0.0;
    }
    for(Int_t ik=0; ik<(NewNrBins*NewNrBins+NewNrBins)/2; ++ik) {
        CovarMatrixResult[ik]=0.0;
    }

    // ... and insert bin number

    NrKnots = static_cast<Int_t>(NrKnotsResult+0.5);
    inputObject->setNrKnots(NrKnots);

    if(NrKnots<=0) {
        cerr<<"*****number of knots result is < = 0, ="<<NrKnots<<endl;
        return;
    }
    // correct outer bin boundaries
    if(LimitsOfBinsResult[0]<WantedXLowLimit) LimitsOfBinsResult[0]=WantedXLowLimit;
    if(LimitsOfBinsResult[NewNrBins]>WantedXHighLimit) LimitsOfBinsResult[NewNrBins]=WantedXHighLimit;
    // define matrix for transformation to bin contents
    Int_t IJ=0;
    // set_up transformation matrix ScratchMatrix
    Double_t ScratchMatrix[NewNrBins*NrKnots];
    for(Int_t J = 0; J < NewNrBins*NrKnots; ++J) {
        ScratchMatrix[J] = 0.0;
    }
    for(Int_t J=0; J<NewNrBins; ++J) {
        // integration between bin boundaries
        SplineCalc->SplineFuncIntegral(LimitsOfBinsResult[J], LimitsOfBinsResult[J+1], CoefficientResult, NrKnots, WantedXLowLimit, WantedXHighLimit);
        for(Int_t I=0; I<NrKnots; ++I) {
            // matrix element S(I) is spline weight determined in SplineFuncIntegral (=espi)
            S[I]=SplineCalc->getS(I);
            ScratchMatrix[IJ]=S[I]/(LimitsOfBinsResult[J+1]-LimitsOfBinsResult[J]);// ScratchMatrix is a SplineMatrix now
            //// cout<<"\t"<<ScratchMatrix[IJ];
            IJ++;
        }
        //// cout<<endl;
    }

    // transform to bin content RC ... . Spline-Weights * coefficients
    MatrixTrafo->General2MatrixMult(ScratchMatrix, CoefficientResult, BinContentResult, NewNrBins, NrKnots, 1);

    MatrixTrafo->GeneralSymGeneralTMatrixMult(CovarianceMatrix,ScratchMatrix,CovarMatrixResult,NrKnots,NewNrBins);

    // finally scale data by (user defined) generated function
    Scale(NewNrBins,LimitsOfBinsResult,BinContentResult,CovarMatrixResult);

    // analysis of covariance matrix
    //if(inputObject->GetPullmode() == 0) {
    CheckCovarianceMatrix(NewNrBins, CovarMatrixResult, ScratchMatrix, Hessian);
    //}
}

void UnfoldingFit::Scale(Int_t NrBins, Double_t *binLimit, Double_t *binContent, Double_t *VC) {
    // MBYFUN
    // multiply all data by average function value of generated function
    Double_t Fac;
    Int_t ij;
    Bool_t logOptionX = inputObject->getLogOptionX();
    Bool_t funcFlag = inputObject->GetMCFuncFlag();
    for(Int_t i = 0; i<NrBins; ++i) {
        Fac = LuminosityFactor*AverageOfFunction(binLimit[i], binLimit[i+1], MCFunctionFx);
        if(logOptionX == 1 && funcFlag == 0) Fac = Fac * (binLimit[i+1] - binLimit[i])/(pow(10, binLimit[i+1]) - pow(10, binLimit[i]));
        binContent[i] = Fac*binContent[i];
        ij = (i*i+i-2)/2;
        for(Int_t j = 0; j<NrBins; ++j) {
            if(j<=i) ij = ij+1;
            VC[ij] = Fac*VC[ij];
            if(i==j) VC[ij] = Fac*VC[ij];
            if(j>=i) ij=ij+j+1;
        }
    }
}


void UnfoldingFit::CheckCovarianceMatrix(Int_t N, Double_t *V, Double_t *VV, Double_t *U) {
    // ANACOV = analysis of covariance matrix
    // gaussian deviations of the unfolded distribution are simulated 5000 times
    // for every deviation a chi^2 value (Chi2SimDeviation) and a p-value are calculated
    // distribution of pValue50=static_cast<Int_t>(1.0+pValue*50.0) is filled in histogram
    // flat distribution means covariance matrix can be assumed to be diagonal and
    // correlations between data points can be neglected
    Double_t GaussValue[N];// random Gaussian value to calculate deviations
    Double_t binContentDeviation[N];
    Double_t pValue;
    Double_t ConditionNr;
    Double_t factor;
    Double_t Media;
    Double_t pValue50BinContent[50];// = HANA
    Double_t ScaledProb;
    Double_t sumProb;
    Double_t sumSquareProb;
    Double_t Chi2SimDeviation;
    Double_t sum1;
    Double_t sum2;
    Double_t trafoU[63][63];
    Double_t Variance;
    Int_t pValue50;
    Int_t ij;
    Int_t maxBinContent;// p-value*50 with maximum occurrence

    Int_t Nr[50];
    Int_t nrDataSets=5000; // = NRANS random data sets
    TRandom3 *randomGaus = new TRandom3();
    // transform VV to matrix U for MC generation
    for(Int_t k = 0; k < ((N*N+N)/2); ++k) {
        VV[k]=V[k];
    }

    Double_t eigenValueCovMatrix[N];
    Double_t eigenValueMin = 0.0;
    // calculate eigenvalues and eigenvectors of the covariance matrix
    MatrixTrafo->EigenHouseholder(VV,N,eigenValueCovMatrix,U,-1);

    // cout<<"Eigenvalues of covariance matrix"<<endl;
    // transpose matrix
    Int_t trafo=0;
    for(Int_t i=0; i<N; ++i) {
        for(Int_t j=0; j<N; ++j) {
            trafoU[i][j]=U[trafo];// transform and transpose coevally!
            //	// cout<<i+1<<","<<j+1<<"U(IJ)="<<trafoU[i][j]<<endl;
            trafo++;
        }
        //// cout<<"\t"<<eigenValueCovMatrix[i];
    }
    ConditionNr=eigenValueCovMatrix[0]/eigenValueCovMatrix[N-1];
    // cout<<"condition number = "<<ConditionNr<<endl;

    for(Int_t l=0; l<N; ++l) {
        if(eigenValueCovMatrix[l]>0.0) eigenValueMin = eigenValueCovMatrix[l];
        factor=sqrt(TMath::Max(0.0,eigenValueCovMatrix[l]));
        for(Int_t m=0; m<N; ++m) {
            trafoU[l][m]=factor*trafoU[l][m];
        }
    }

    // prepare histogram of probabilities
    for(Int_t n=0; n<50; ++n) {
        pValue50BinContent[n]=0.0;// = HANA
    }

    // loop on nrDataSets cases
    sum1=0.0;
    sum2=0.0;
    trafo=0;
    for(Int_t r=0; r<N; ++r) {
        for(Int_t s=0; s<N; ++s) {
            U[trafo]=trafoU[s][r];
            trafo++;
        }
    }
    for(Int_t L=0; L<nrDataSets; ++L) {
        // start with GaussValue = N independent Gaussians
        for(Int_t I=0; I<N; ++I) {
            GaussValue[I]=randomGaus->Gaus(0,1);
        }
        // transform GaussValue to binContentDeviation
        MatrixTrafo->General2MatrixMult(U,GaussValue,binContentDeviation,N,N,1);
        // sum pseudo chi square
        Chi2SimDeviation=0.0;
        ij=0;
        for(Int_t p=0; p<N; ++p) {
            ij=ij+p+1;
            Chi2SimDeviation=Chi2SimDeviation+pow(binContentDeviation[p],2)/V[ij-1];
        }

        // ... and probability from chi square
        pValue=TMath::Prob(Chi2SimDeviation,N);// = PR
        // ... into histogram
        pValue50=static_cast<Int_t>(1.0+pValue*50.0);
        pValue50=TMath::Max(1,TMath::Min(pValue50,50));
        pValue50BinContent[pValue50-1]=pValue50BinContent[pValue50-1]+1;
        Chi2SimDeviation=Chi2SimDeviation/static_cast<Double_t>(N);
        sum1=sum1+pValue;
        sum2=sum2+Chi2SimDeviation;
    }

    ScaledProb=0;
    maxBinContent=0;
    for(Int_t B=0; B<50; ++B) {
        if(maxBinContent<=pValue50BinContent[B]) {
            maxBinContent=static_cast<Int_t>(pValue50BinContent[B]);
        }
    }
    // cout<<"maximum probability = "<<maxBinContent<<endl;
    for(Int_t C=0; C<50; ++C) {
        Nr[C]=static_cast<Int_t>(10*pValue50BinContent[C]/maxBinContent);
        ScaledProb=ScaledProb+Nr[C];
    }
    Media=ScaledProb/50;
    // cout<<"media = "<<Media<<" N="<<N<<endl;
    Int_t meanBinContent;
    meanBinContent=0;
    for(Int_t K=0; K<50; ++K) {
        meanBinContent=static_cast<Int_t>(meanBinContent+pValue50BinContent[K]/50);
    }
    //cout<<"meanBinContent = "<<meanBinContent<<endl;
    sumProb=0;
    sumSquareProb=0;
    for(Int_t L=0; L<50; ++L) {
        sumProb=sumProb+pValue50BinContent[L];
        sumSquareProb=sumSquareProb+pow(pValue50BinContent[L],2);
    }
    //	 cout<<"sum of probabilities = "<<sumProb<<endl;
    //	 cout<<"sum of squared probabilities = "<<sumSquareProb<<endl;
    Variance=0;
    for(Int_t M=0; M<50; ++M) {
        Variance=Variance+(sumSquareProb-pow(sumProb,2)/50)/50;
    }
    // cout<<"variance = "<<Variance<<endl;
    Chi2pValue50=0;
    for(Int_t P=0; P<50; ++P) {
        //Chi2pValue50=Chi2pValue50+pow((pValue50BinContent[P]-meanBinContent),2)/Variance;
        //Chi2pValue50=Chi2pValue50+pow((pValue50BinContent[P]-100),2);
        Chi2pValue50=Chi2pValue50+fabs(pValue50BinContent[P]-100);
    }
    Chi2pValue50 = Chi2pValue50/ 50;
    // cout<<"Chi2pValue50 = "<<Chi2pValue50<<endl;
    if(print > 0){
        if(Media<=4)  cerr<<"\n***** Warning: strong data point correlation\n"<<endl;
    }
    //Chi2pValue50 = 1.0/Media;
    //TODO instead of media bincontent > 250?
    //sum1=sum1/static_cast<Double_t>(nrDataSets);
    //sum2=sum2/static_cast<Double_t>(nrDataSets);

    // print histogram
    CovarianceFile = TFile::Open(inputObject->getoutputpath()+"TrueeResultFile.root","UPDATE");
    CovarianceFile->cd("DataPointCorrelation");

    TString ChiName;
    TString ChiTitle;
    //	NrDegreeOfFreedom = inputObject->GetNrDegreeOfFreedom();
    NrKnots = inputObject->GetNrKnots();
    if(NrDegreeOfFreedom == 0) {
        ChiName.Form("pValue50 dist. bins=%i, knots=%i, degFreeAutom=%f", NewNrBins, NrKnots, NrDegFreeForTau);
        ChiTitle.Form("probability_bins_%i_knots_%i_degFreeAutom_%f", NewNrBins, NrKnots, NrDegFreeForTau);
    }
    else {
        ChiName.Form("pValue50 dist. bins=%i, knots=%i, degFree=%i", NewNrBins, NrKnots, NrDegreeOfFreedom);
        ChiTitle.Form("probability_bins_%i_knots_%i_degFree_%i", NewNrBins, NrKnots, NrDegreeOfFreedom);
    }
    TH1D *pValue50Distribution = new TH1D(ChiTitle,ChiName,51,0,50);
    for(Int_t a=0; a<50; ++a) {
        pValue50Distribution->Fill(a+1,pValue50BinContent[a]);
    }
    pValue50Distribution->Scale(1/pValue50Distribution->GetMaximum());
    CovarianceFile->Write();
    CovarianceFile->Close();
    randomGaus->Delete();
}
