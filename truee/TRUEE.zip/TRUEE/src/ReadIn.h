//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef ReadIn_h
#define ReadIn_h
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "Rtypes.h"
#include "TFile.h"
#include "TTree.h"
#include "TH1.h"
#include "TChain.h"
#include "TRandom3.h"
#include "TBranch.h"
#include "TRandom3.h"
#include "Input.h"
#include "trueereader.h"





class ReadIn{

public:

	ReadIn();
        ReadIn(Double_t wantedXLowLimit, Double_t wantedXHighLimit, TString NameWantedX, TString *nameObsY, Int_t nrAllMeasuredVariables, Int_t nrMocaTypes, Input* In);
	virtual ~ReadIn();

        //void ReadInAscii(const std::string &asciiSourceFile, const std::string &label, Int_t ColumnWantedVariable,  Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex, std::string outpath);

        void Read(const std::string &rootTreeSourceFile, const std::string &SourceTreeName, const std::string &label, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex);

        //void ReadInAsciiTest(const std::string &asciiSourceFile, const std::string &asciiSourceFileBG, Int_t ColumnWantedVariable, Bool_t *logOption, Bool_t logOptionX, Double_t fraction, TRandom3 *searchEventFraction, Int_t NTupleIndex, std::string outpath);

        void ReadTest(const std::string &rootTreeSourceFile, const std::string &rootSourceFileBG, const std::string &SourceTreeName, const std::string &SourceTreeNameBG, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Double_t fraction, TRandom3 *searchEventFraction,  Int_t NTupleIndex,std::string outpath,std::string type);

        Double_t GetBackEventNr(){return BackEventNr;}
        Double_t GetMocaEventNr(){return MocaEventNr;}
        Double_t GetDataEventNr(){return DataEventNr;}

	//void MakeObsHistogram(const std::string &label, Double_t fraction, const std::string &rootTreeSourceFile, const std::string &SourceTreeName, const std::string &BranchMeasurVariable, const std::string &branchEventWeight, Bool_t logOption, Int_t NTupleIndex);

        inline void CheckLeafType(TChain *fileName, const std::string &branchName, Int_t &typeIdent, Int_t &type_int, Float_t &type_float, Double_t &type_double);

       void Pull(double fraction,TRandom3* searchEventFraction, bool use_different_mc);

private:


	// ClassDef(ReadIn,1)




        // read in settings
        Double_t WantedXLowLimit;
        Double_t WantedXHighLimit;
        Double_t BackEventNr;
        Double_t DataEventNr;
        Double_t MocaEventNr;
        Int_t NrAllMeasuredVariables;
        Int_t NrMocaTypes;
        TString nameWantedX;
        TString nameObsY[32];

        bool SplittedEvents;

        // some variables

        double weight;
        double x;

        int eventIndexMC;
        int eventIndexRD;
        int eventIndexBG;


        // misc

        int printflag;
        Input* InputObject;
};

#endif //ReadIn_h
