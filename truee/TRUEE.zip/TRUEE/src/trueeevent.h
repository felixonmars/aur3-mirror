#ifndef TRUEEEVENT_H
#define TRUEEEVENT_H
#include<vector>

/*!
    *  \brief     contains a single event (example)

    ￼*  \details  This is a storage class containing a single event.
    *  This is used by TrueeData to store the data you put in.
    *  \author Martin Schmitz <martin.schmitz@uni-dortmund.de


    *  \date April 2012
*/


class TrueeEvent
{
public:
    TrueeEvent(){
           // weight = 1.0;
            NTupleIndex = 1;
    }
    ~TrueeEvent(){
        y.clear();
    }

    //~TrueeEvent(){ }
    void SetWeight(double w){weight =w;}
    void set_x(double X){x =X;}
    void add_y(double Y){y.push_back(Y);}
    void set_NTupleIndex(int T){NTupleIndex = T;}
    void SetEventID(int E){eventid = E;}

    int GetEventID(){return eventid;}
    double get_weight(){return weight;}
    double get_x(){return x;}
    double get_y(int i){return y.at(i);}
    double get_y_size(){return y.size();}
    int get_NTupleIndex(){return NTupleIndex;}
    std::vector<double> get_y(){return y;}

private:
    double weight;
    double x;
    std::vector<double> y;
    int NTupleIndex;                                                            ///< File number
    int eventid;
};

#endif // TRUEEEVENT_H
