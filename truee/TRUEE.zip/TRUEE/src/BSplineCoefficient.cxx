//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

// Calculation of B-spline coefficients coeff from equidistant function values (Y).
// The B-spline coefficients coeff(1)...coeff(N) are calculated from N given
// equidistant function values Y(1)...Y(N). The not-a-knot condition
// is assumed at both sides (i.e. no discontinuity in third
// derivative at first and last inner knot).

#include "BSplineCoefficient.h"
#include <iostream>

using namespace std;

// ClassImp(BSplineCoefficient)

BSplineCoefficient::BSplineCoefficient(){};
BSplineCoefficient::~BSplineCoefficient(){};

void BSplineCoefficient::getCoeff(Double_t *Y, Double_t *coeff, Int_t N) {
// USPC (original)
	Double_t H[N];
	Double_t G[N];
	Double_t lastCoeff = 0;// original: G[N]=H[1,N], H[N]=H[2,N]

	for(Int_t i = 1; i < N; ++i) {
		G[i] = Y[i]-Y[i-1];
	}

	H[0] = 0.5*(5.0*G[1]+G[2]);
	H[1] = 3.0*(G[1]+G[2])-H[0];
	G[1] = 2.0;
	for(Int_t j = 2; j < (N-1); ++j) {
		H[j] = (-H[j-1]/G[j-1])+3.0*(G[j+1]+G[j]);
		G[j] = 4.0-(1.0/G[j-1]);
	}

	H[N-1] = 0.5*(5.0*G[N-1]+Y[N-2]-Y[N-3]);
	G[N-1] = 1.0-(2.0/G[N-2]);

	// backward ...
	H[N-1] = (-2.0*H[N-2]/G[N-2]+H[N-1])/G[N-1];
	for(Int_t k = (N-2); k >= 1; --k) {
		H[k] = (H[k]-H[k+1])/G[k];
	}
	H[0] = H[0]-2.0*H[1];

	//   ... and forward solution
	lastCoeff = Y[N-1]+Y[N-1]-Y[N-2]-(2.0*H[N-1]+H[N-2])/3.0;

	for(Int_t l = 0; l < (N-1); ++l) {
		coeff[l] = Y[l]+Y[l]-Y[l+1]+(2.0*H[l]+H[l+1])/3.0;
	}
	coeff[N-1] = lastCoeff;
}
