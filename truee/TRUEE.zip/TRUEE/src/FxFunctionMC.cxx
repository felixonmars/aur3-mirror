//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#include "FxFunctionMC.h"
#include "AverageOfFunction.h"
#include <iostream>
#include "Preprocessor.h"
#include "math.h"
#include "TF1.h"

using namespace std;

// ClassImp (FxFunctionMC)


FxFunctionMC::FxFunctionMC(){}
//FxFunctionMC::FxFunctionMC(Input *InputObject, Double_t *Coefficient, Double_t gamma, Int_t nrBinsMC, Double_t (*func)(Double_t)) {
FxFunctionMC::FxFunctionMC(Input *InputObject, Double_t *Coefficient, Double_t gamma, Int_t nrBinsMC, TF1 *func) {
	UserFxFunctionMC = func;
	Gamma = gamma;
	WantedXLowLimit = InputObject->GetWantedXLowLimit();
	WantedXHighLimit = InputObject->GetWantedXHighLimit();
	NrBinsMCMax = InputObject->GetNrBinsMCMax();
	NrBinsMC = nrBinsMC;
	for(Int_t a = 0; a < NrBinsMCMax; ++a) {
		Coeff[a] = Coefficient[a];
	}
	Defin = 0;
	userDefFxFuncFlag = InputObject->GetMCFuncFlag();
}
FxFunctionMC::~FxFunctionMC(){
}

Double_t FunctionValue(Double_t X, Double_t *A, Int_t N, Double_t XlowLimit, Double_t XhighLimit) {
	// USPF (original)
	// Compute function value or derivative for B-spline function
	// X   = abscissa value
	// A(0)...A(N-1) = B-spline coefficients
	// XlowLimit,XhighLimit = range of B-spline function
	// Extrapolation is done for X outside the range XlowLimit,XhighLimit.

	Double_t R = 0;
	Double_t Z = 0;
	Double_t value = 0;
	Int_t i = 0;
	// R = (X - Xlow)/binWidth. R = 0, 1, ..., N-1
	R = static_cast<Double_t>(N-1)*(X-XlowLimit)/(XhighLimit-XlowLimit);
	Int_t r = static_cast<Int_t>(R);
	i = TMath::Max(1,TMath::Min(r,N-3));
	// Z = (X - lastKnot)/knotDistance
	Z = R-i;
	// value is the linear combination of 4 b-splines at the x-value X
	value = (A[i-1]+4.0*A[i]+A[i+1]+Z*(3.0*(A[i+1]-A[i-1])+Z*(3.0*(A[i-1]-2.0*A[i]+A[i+1])+Z*(3.0*A[i]-A[i-1]-3.0*A[i+1]+A[i+2]))))/6.0;
	return value;
}
Double_t FxFunctionMC::getMCFxFunction(Double_t x) {
	// USFUN (original)
	// This function returns the value of the function f(x) for the
	// true (undisturbed) argument value x, which has been used to create the Monte Carlo events.
	// The default values (essentially) returns a function value
	// according to the x-distribution of the Monte Carlo events,
	// assuming, that no generated events are lost.
	Double_t function(x);
	if(userDefFxFuncFlag == 1) {
		function = UserFxFunctionMC->Eval(x);
	}
	else {
		// new limits as ranges for the b-spline function
		// new xLowLimit = WantedXLowLimit + 1/2 binwidth
		Double_t xLowLimit = (static_cast<Double_t>(NrBinsMC+NrBinsMC-1)*WantedXLowLimit+WantedXHighLimit)/static_cast<Double_t>(NrBinsMC+NrBinsMC);
		// new xHighLimit = WantedXHighLimit - 1/2 binwidth
		Double_t xHighLimit = (WantedXLowLimit+static_cast<Double_t>(NrBinsMC+NrBinsMC-1)*WantedXHighLimit)/static_cast<Double_t>(NrBinsMC+NrBinsMC);
		// function value is a lin. comb. of 4 cubic b-splines at x
		// splines are determined in logarithmic scale, if x is logarithmic, therefore:
		//if(logOptionX == 1) function = Gamma*FunctionValue(log10(x),Coeff,NrBinsMC, xLowLimit, xHighLimit);
		//else
		function = Gamma*FunctionValue(x,Coeff,NrBinsMC,xLowLimit,xHighLimit);
	}
	return function;
}
