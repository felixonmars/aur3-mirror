#include<string>
#include<TH1F.h>
#include<TH2F.h>
#include<TChain.h>
#include<TCanvas.h>
class TrueeCovariance{

public:

    /*
     *	Just the Constructor
     */
    TrueeCovariance(){logX = false; logY = false; CorrLimit = 0; }

    /*
     *  Set the path to your MC file. This should be a rootfile
     */

    void SetPath(std::string p,std::string treename);

    /*
     *	Set the WantedX (most likely your sought variable)
     */

    void SetWantedX(std::string X){ WantedX = X;}
    /*
        *	Get the Covarianceplot
        */
    TCanvas* GetCorrelationPlot();

    /*
        *	Should your WantedX be log(WantedX)?
        */
    void SetLogX(bool log) { logX = log; }

    /*
        *	Should all your observabls be log(obs) ?
        */

    void SetLogY(bool log) { logY = log; }

    /*
        *	Delete every Observable with abs(Correlation) < border
        */

    void SetCorrLimit(double border) { CorrLimit = border; }
    /*
     *  load the data
     */

    void  load();
  private:

    TH1F* GetFullCorrPlot();
    TH1F* GetNonZeroCorrPlot();
    TH1F* GetHigherLimitCorrPlot();
    TH1F* GetHighlyCorrPlot();

    std::vector<double> GetCorrelation(std::vector<TString> Obs);
    std::vector<TH1F*> CorrelationPlots;

    std::vector<TString> Observables;
    std::vector<double> Correlations;

    std::string Path;
    std::string treename;

    std::string WantedX;
    TChain* inChain;

    bool logX;
    bool logY;
    double CorrLimit;
};
