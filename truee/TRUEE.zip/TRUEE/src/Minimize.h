//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef MINIMIZE_H_
#define MINIMIZE_H_

#include "Rtypes.h"
#include "SplineFunction.h"

class Minimize {
public:
	Minimize();
	virtual ~Minimize();

	void Initialize(Double_t xlim1, Double_t xlim2, Int_t Flag);
	void SearchMinimum(Double_t F, Double_t &dxa, Int_t &NC);
	Double_t getFunctionChange() { return FunctionChange;}

private:
	Double_t C[5][11];
	Double_t casy;
	Double_t currentXValue;// = XC

	Double_t FunctionChange;// = DFUNST
	Double_t goldSectionXValue;// = XT
	Double_t lastXValue;// =XL
	Double_t nextXValue;// = XN
	Double_t SecondDerivative;// = SECDST
	Double_t SlopeRatio;// = SLPR

	Double_t StepLimitXneg;// = XLIMN
	Double_t StepLimitXpos;// = XLIMP
	Double_t Tau;
	Double_t TotalStep;// = DPARST
	Double_t X[11];
	Double_t Y[11];

	Int_t NrEvaluations; // = NEVAST
	Int_t PrintFlag;

	SplineFunction *SplineCoeff;

	Int_t IC;// just a flag
	Int_t imin;
	Int_t ibeg;
	Double_t BiasX;
	Double_t Dis;
	Double_t DX;
	Double_t DXlast;
	Double_t H;
	Double_t Xdis;
	Double_t AF;
	Double_t CC;
	Double_t FP;
	Double_t FPP;
	Double_t FQ;
	Double_t RF;
	Double_t sum1;
	Double_t sum2;

	Double_t asym;
	Double_t asyl;
};

#endif /* MINIMIZE_H_ */
