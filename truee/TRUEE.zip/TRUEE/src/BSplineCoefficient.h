//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef BSplineCoefficient_h
#define BSplineCoefficient_h

#include "Rtypes.h"

class BSplineCoefficient {

public:
	BSplineCoefficient();
	virtual ~BSplineCoefficient();
	void getCoeff(Double_t *Y, Double_t *coeff, Int_t N);
	// ClassDef(BSplineCoefficient,1)

};

#endif //BSplineCoefficient_h
