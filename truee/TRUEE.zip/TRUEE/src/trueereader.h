#ifndef TRUEEREADER_H
#define TRUEEREADER_H

#include "Input.h"
#include "TRandom3.h"

class TrueeReader
{
public:
    TrueeReader();
    virtual ~TrueeReader(){}
    virtual void Read(const std::string &Sourcefile, const std::string &SourceTreeName, const std::string &label, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex){}
    virtual void ReadTest(const std::string &Sourcefile, const std::string &SourceTreeName, const std::string &label, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex, std::string type){}
    void Pull(double fraction,TRandom3* searchEventFraction, bool use_different_mc);

protected:

    int         printflag;
    Input*      InputObject;

};

#endif // TRUEEREADER_H
