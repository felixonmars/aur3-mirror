//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

// various calculations for the regularization

#include "RegularizationMath.h"
#include "math.h"
#include "ScalarProd.h"

using namespace std;

RegularizationMath::RegularizationMath(){
}

RegularizationMath::RegularizationMath(Input *InputObject, Functions *splineCalc) {
	NrKnotsMax = InputObject->GetNrKnotsMax();
	SplineCalc = splineCalc;
	MatrixMult = new LinearAlgebra();
	nrKnots = InputObject->GetNrKnots();
	xLowLimit = InputObject->GetWantedXLowLimit();
	xHighLimit = InputObject->GetWantedXHighLimit();
	nrConstraints = 0;
	MC = 0;
	icfl = 0;
	FxLeftFlag = InputObject->GetZeroLeft();
	FxRightFlag = InputObject->GetZeroRight();
	linWeight = InputObject->GetLinWeight();
	for(Int_t i = 0; i<63; ++i) {
		DiagHessValuesDimin[i] = 0.0;
		ScratchVector[i] = 0.0;
	}
	for(Int_t j = 0; j<10; ++j) {
		CN[j] = 0.0;
	}
	for(Int_t k = 0; k<110; ++k) {
		IC[k] = 0;
	}
	for(Int_t l = 0; l<(63*63); ++l) {
		ScratchMatrixA[l] = 0.0;
		ScratchMatrixB[l] = 0.0;
	}
}

RegularizationMath::~RegularizationMath() {
	delete MatrixMult;
}

void RegularizationMath::ConstraintFlags(Double_t Xvalue, Double_t FXvalue) {
	// RSOLFC (original)
	// Add flags for constraint
	// function(Xvalue) = FXvalue   forced
	// special case Xvalue = FXvalue = 0 means: function non-negative forced (FXpositive=1)
	Int_t IA;
	Float_t DX;
	if(Xvalue==0.0 && FXvalue==0.0) {
		// positivity constraint
		// set flag to one
		icfl=1;
	}
	else if (MC<10){
		MC=MC+1;
		nrConstraints=MC;
		DX=(xHighLimit-xLowLimit)/static_cast<Float_t>(nrKnots-3);
		IA=static_cast<Int_t>((Xvalue-xLowLimit)/DX+1.0);
		// force 1 <= IA <= nrKnots-3
		IA=TMath::Min(TMath::Max(1,IA), nrKnots-3);
		IC[MC-1]=IA;
		CN[MC-1]=FXvalue*24.0;
	}
}
void RegularizationMath::DefRegularizationMatrix(Double_t *SC) {
	// RSOLRM (original)
	// define regularization matrix (SC)
	Double_t CC[6]={70.0, 40.0, 10.0, 0.0, 30.0, 15.0};
	Double_t CB[6]={74.0, 40.0, 6.0, 12.0, 22.0, -7.0};
	Double_t CD[6];
	Double_t factor1;
	Double_t factor2;
	Double_t factor3;
	Int_t IR=0;
	//--------------- square of second derivative ----------------------
	Int_t IJ=0;
	for (Int_t i = 0; i < nrKnots; ++i) {
		IR=nrKnots-i;
		for (Int_t j = 0; j <= i; ++j) {
			if(i==j){
				// diagonal
				SC[IJ]=80.0;
				if(FxLeftFlag != 1 && i<3) {
					SC[IJ]=SC[IJ]-CC[i];
				}
				if(FxRightFlag != 1 && IR<=3) {
					SC[IJ]=SC[IJ]-CC[IR-1];
				}
			}
			else if(i==j+1){
				// off-diagonal +1
				SC[IJ]=-45.0;
				if(FxLeftFlag != 1 && i<3) {
					SC[IJ]=SC[IJ]+CC[3+i];
				}
				if(FxRightFlag != 1 && IR<=2) {
					SC[IJ]=SC[IJ]+CC[3+IR];
				}
			}
			else if(i==j+3){
				// off-diagonal +3
				SC[IJ]=5.0;
			}
			else{
				// all remaining elements are zero
				SC[IJ]=0.0;
			}
			IJ=IJ+1;
		}
	}

	//----------- square of first derivative -----------------
	factor1=80.0*linWeight;
	factor2=15.0*linWeight;
	factor3=24.0*linWeight;

	// scale first derivative by linWeight
	for (Int_t k = 0; k < 6; ++k) {
		CD[k]=linWeight*CB[k];
	}

	IJ=0;
	for(Int_t l=0; l<nrKnots; ++l) {
		IR=nrKnots-l;
		for(Int_t m=0; m<=l; ++m) {
			if(l==m) {
				// diagonal
				SC[IJ]=SC[IJ]+factor1;
				if(FxLeftFlag != 1 && l<3) {
					SC[IJ]=SC[IJ]-CD[l];
				}
				if(FxRightFlag != 1 &&  IR<=3) {
					SC[IJ]=SC[IJ]-CD[IR-1];
				}
			}
			else if(l==m+1){
				// off-diagonal +1
				SC[IJ]=SC[IJ]-factor2;
				if(FxLeftFlag != 1 && l<3) {
					SC[IJ]=SC[IJ]+CD[3+l];
				}
				if(FxRightFlag != 1 && IR<=2) {
					SC[IJ]=SC[IJ]+CD[3+IR];
				}
			}
			else if(l==m+2){
				// off-diagonal +2
				SC[IJ]=SC[IJ]-factor3;
				if(FxLeftFlag != 1 && l<3) {
					SC[IJ]=SC[IJ]+CD[3];
				}
				if(FxRightFlag != 1 && l==nrKnots-1) {
					SC[IJ]=SC[IJ]+CD[3];
				}
			}
			else if(l==m+3){
				// off-diagonal +3
				SC[IJ]=SC[IJ]-linWeight;
			}
			IJ=IJ+1;
		}
	}
}
void RegularizationMath::CalculateCoeff(Double_t *CoeffMatrix, Double_t *Hessian, Double_t *Gradient, Double_t *x, Double_t *Amplitude, Double_t *Eigenvalue, Double_t &tau, Double_t &NrDegFree, Int_t &NrIndepLinCombs){
	// RSOLRT (original)
	// determine K'th orthogonal function, K = 1...M
	// The K'th function is first defined as the legendre polynomial of order (K-1).
	// It is orthonormalized with metric H by subtraction of
	// the components of all previous orthogonal functions. The spline
	// coefficients are stored in the K'th row of the matrix CoeffMatrix.
	// The amplitude for the K'th function is calculated by
	//	                				  T
	//	           Amplitude(K) = Gradient  CoeffMatrix (ROW K)
	// transformation of Hessian matrix to diagonal
	Int_t iPosEigenv=0;
	Double_t EigenvalueFactor=0.0;

	// copy Hessian to scratch storage
	for(Int_t k=0; k<(nrKnots*nrKnots+nrKnots)/2; k++){
		ScratchMatrixA[k]=Hessian[k];
	}
	// transformation of Hessian to diagonal form
	MatrixMult->EigenHouseholder(ScratchMatrixA,nrKnots,DiagHessValuesDimin,CoeffMatrix,-1);
	// DiagHessValuesDimin = diagonal values, decreasing in size
	// eventually reduce size of matrix, ignoring all negative (!)
	// eigenvalues and the smallest positive eigenvalue
	// define M for this purpose
	iPosEigenv=0;
	for(Int_t i=0; i<nrKnots; ++i){
//		cout<<i<<" DGH="<<DiagHessValuesDimin[i]<<endl;
		//	SmallDiagHessValues[i]=DiagHessValuesDimin[i];// dgm = dgh
		if(DiagHessValuesDimin[i]>0.0){
			// index of positive eigenvalue
			iPosEigenv=i+1;
		}
	}
	M=iPosEigenv-1;

	// number of independent linear combinations
	NrIndepLinCombs=M;// = NIKN
	Int_t IJ=0;
	for (Int_t j = 0; j < M; ++j) {
		//	EigenvalueFactor=1.0/sqrt(SmallDiagHessValues[j]);
		EigenvalueFactor=1.0/sqrt(DiagHessValuesDimin[j]);
		// EigenvalueFactor=0 for all negative and the smallest positive EV
		if(j>=iPosEigenv) EigenvalueFactor=0.0;
		for (Int_t I = 0; I < nrKnots; ++I) {
			CoeffMatrix[IJ]=CoeffMatrix[IJ]*EigenvalueFactor;
			IJ++;
		}
	}

	// ------------------------------------------------------------------
	// complete transformation to system, which is diagonal in reg. matr.
	// matrix CoeffMatrix and amplitudes are redefined

	// define regularization matrix
	DefRegularizationMatrix(ScratchMatrixA);

	// transform ScratchMatrixA (here regularization matrix C) using matrix CoeffMatrix -> ScratchMatrixB
	MatrixMult->GeneralSymGeneralTMatrixMult(ScratchMatrixA, CoeffMatrix, ScratchMatrixB, nrKnots, M);
	// now ScratchMatrixB contains regularization matrix C

	// spectral decomposition of regularization matrix C (increasing order of eigenvalues)
	MatrixMult->EigenHouseholder(ScratchMatrixB,M,Eigenvalue,ScratchMatrixA,+1);
	//  Eigenvalue(.) = diagonal matrix
	// ScratchMatrixA = rotation matrix (eigenvectors)

	//  insert exact zeros as eigenvalues, if appropriate
	if(FxLeftFlag == 0 && FxRightFlag == 0) {
		Eigenvalue[0]=0.0;
		if(linWeight==0.0) Eigenvalue[1]=0.0;
	}

	// form complete transformation matrix ScratchMatrixB and store in CoeffMatrix
	MatrixMult->General2MatrixMult(ScratchMatrixA, CoeffMatrix, ScratchMatrixB, M, M, nrKnots);
	IJ=0;
	for (Int_t p = 0; p < M; ++p) {
		for (Int_t q = 0; q < nrKnots; ++q) {
			CoeffMatrix[IJ]=ScratchMatrixB[IJ];
			IJ++;
		}
	}
	// now in array CoeffMatrix the matrix
	// CoeffMatrix2T * Eigenvalue^(-1/2) * CoeffMatrix1T
	// is stored

	// transform gradient
//	for(Int_t au=0; au<M*nrKnots; ++au) {
//		cout<<au+1<<" U="<<CoeffMatrix[au]<<" G="<<Gradient[au]<<endl;
//	}
	MatrixMult->General2MatrixMult(CoeffMatrix, Gradient, ScratchVector, M, nrKnots, 1);
//	for(Int_t au=0; au<M*nrKnots; ++au) {
//			cout<<au+1<<" U="<<CoeffMatrix[au]<<" G="<<Gradient[au]<<" SCV="<<ScratchVector[au]<<endl;
//	}
	// transform previous solution vector
	MatrixMult->SymGeneralMult(Hessian, x, ScratchMatrixA, nrKnots, 1);
	MatrixMult->General2MatrixMult(CoeffMatrix, ScratchMatrixA, Amplitude, M, nrKnots, 1);
	// add both to obtain normalized amplitudes
	for(Int_t r=0; r<M; ++r){
		Amplitude[r]=Amplitude[r]+ScratchVector[r];
//		cout<<r+1<<" Amp="<<Amplitude[r]<<" SCV="<<ScratchVector[r]<<" U="<<CoeffMatrix[r]<<" G="<<Gradient[r]<<endl;
	}

	//  Now the vector Amplitude contains the vector of unregularized solution

	/*	   ------------------------------------------------------------------
	 *     Determine estimate of TAU by following method:
	 *
	 *     For a given value of TAU the difference
	 *        Amplitude(i)**2 - (damped Amplitude(i))**2
	 *     can be considered as the random noise, which on average should  be
	 *     1. Thus one could determine the value of TAU, for which the random
	 *     noise  contributions  are 1 on average. Sometimes there are larger
	 *     values of amplitudes at a high index, which disturb the algorithm.
	 *     Therefore the contributions are weighted by
	 *        3/(3+TAU*Eigenvalue(i))
	 *     which is nearly one in the region of  significant  amplitudes  and
	 *     also in the transition region, but small in the noise region.
	 *
	 *     NOISE = Amplitudei**2 - (DAMPED Amplitudei)**2
	 *           = Amplitudei**2 * (1 - 1/(1+TAU*Eigenvaluei)**2)
	 *           = Amplitudei**2 * (TAU*Eigenvaluei)*(2+TAU*Eigenvaluei)/(1+TAU*Eigenvaluei)**2
	 *     expected is NDF = SUM of noise
	 *     stop SUM if 0.001 < tau Eigenvalue < 10.0*/
	Double_t fun;
	Double_t dfun;
	Double_t TauMultEigenv;
	Double_t tauWeight;
	Double_t noise;
	Double_t dtau;
	Double_t DA;
	Double_t DB;
	Int_t IA=0;
	Int_t IB=0;
	for (Int_t J = 2; J < M; ++J) {
		if(Eigenvalue[J]>0.0){
			// try this value for tau
			tau=1.0/Eigenvalue[J];
			//	// cout<<J<<"tau=1/Eigenvalue(J)="<<tau<<endl;
			fun=0.0;
			IA=0;
			IB=0;
			for (Int_t I = 0; I < M; ++I) {
				TauMultEigenv=tau*Eigenvalue[I];
				// cout<<"######### TauMultEigenv="<<TauMultEigenv;
				if(TauMultEigenv>0.001 && TauMultEigenv<10.0){
					if(IA==0) IA=I+1;
					tauWeight=3.0/(3.0+TauMultEigenv);
					noise=pow(Amplitude[I],2)*(2.0+TauMultEigenv)*TauMultEigenv/pow((1.0+TauMultEigenv),2)-1.0;
					fun=fun+tauWeight*noise;
					// cout<<"\tFun (>0?) = "<<fun<<endl;
					IB=I+1;
				}
			}
			if(fun<0.0) break;
		}
	}

	//   FUN is negative the first time. Use the current value  of  TAU  as
	//    estimate and improve TAU by iterative method.

	Int_t IT=0;
	do {
		IT++;
		fun=0.0;
		dfun=0.0;
		for (Int_t s = (IA-1); s < IB; ++s) {
			TauMultEigenv=tau*Eigenvalue[s];
			tauWeight=3.0/(3.0+TauMultEigenv);
			//// cout<<"Eigenvalue="<<Eigenvalue[s]<<"\tTau="<<tau<<endl;
			noise=pow(Amplitude[s],2)*(2.0+TauMultEigenv)*TauMultEigenv/pow((1.0+TauMultEigenv),2)-1.0;
			// function and ...
			fun=fun+tauWeight*noise;
			DA=-Eigenvalue[s]*tauWeight/(3.0+TauMultEigenv);
			DB=pow(Amplitude[s],2)*2.0*Eigenvalue[s]/pow((1.0+TauMultEigenv),3);
			// ... and derivative
			dfun=dfun+tauWeight*DB+DA*noise;
		}
		if(dfun==0.0){
			dtau=0.0;
		}
		else{
			dtau=-fun/dfun;
		}
		tau=tau+dtau;
	}while(fabs(dtau)>tau*1.0*pow(10,-5) && IT<=10);

	// convergence reached
	// Determine number of degree of freedom for the current value of tau
	NrDegFree=0.0;
	for(Int_t t=0; t<M; ++t){
		NrDegFree=NrDegFree+1.0/(1.0+tau*Eigenvalue[t]);
	}
}

void RegularizationMath::CovarianceMatrix(Double_t *U, Double_t *CovMatrix) {
	// RSOLVS
	/*  calculate covariance matrix by the formula
                               T                                 		  1
	    CovMatrix = U ScratchMatrixB' U    with    ScratchMatrixB' = ---------------
																 II  (1+TAU*D(I))**2
	 */

	// square of symmetric matrix ScratchMatrixB = ScratchMatrixA^2
	// ScratchMatrixA = 1/(1+tau*D[i]) from DetermineTau
	MatrixMult->SquareSymMatrix(ScratchMatrixA, ScratchMatrixB, M);

	// transpose of matrix ScratchMatrixA = U^T
	MatrixMult->TransposeMatrix(U, ScratchMatrixA, M, nrKnots);

	// product A*B*A = CovMatrix
	MatrixMult->GeneralSymGeneralTMatrixMult(ScratchMatrixB, ScratchMatrixA, CovMatrix, M, nrKnots);
}

void RegularizationMath::DetermineTau(Double_t *U, Double_t *Gradient, Double_t *X, Double_t *A, Double_t *Eigenvalue, Double_t &Tau, Double_t &Fmax, Int_t &iVeto, Double_t NrDegFree) {
	// RSOLEQ
	// determine tau and solve equations, observing constraints
	Double_t A2[100];
	Double_t SymmetricA[100];
	Double_t Asm;
	Double_t B1[100];
	Double_t B2[100];
	Double_t dTau;
	Double_t delta;
	Double_t EL;
	Double_t FCA;
	Double_t FD;
	Double_t FN;
	Double_t fneg;
	Double_t FS;
	Double_t FP;
	Int_t IA;
	Int_t ineg;
	Int_t it;
	Int_t ME;
	Int_t one=1;
	Tau=0.0;
	if(NrDegFree > 0.0 && NrDegFree < static_cast<Double_t>(M)) {
		// loop to find starting value for tau
		for(Int_t j=1; j<M-1; ++j) {
			if(Eigenvalue[j]!=0.0) {
				Tau=1.0/Eigenvalue[j];
				FS=-NrDegFree;
				for(Int_t i=0; i<M; ++i) {
					FS=FS+1.0/(1.0+Tau*Eigenvalue[i]);
				}
				one=1;
				if(FS>0.0) {
					// Newton refinement of tau
					it=0;
					one=2;
					do  {
						it=it+1;
						FS=-NrDegFree;
						FP=0.0;
						for(Int_t k=0; k<M; ++k) {
							FS=FS+1.0/(1.0+Tau*Eigenvalue[k]);
							FP=FP+Eigenvalue[k]/pow((1.0+Tau*Eigenvalue[k]),2);
						}
						dTau=FS/FP;
						delta=fabs(dTau/Tau);
						Tau=Tau+dTau;
					}while(delta>pow(10, -5) && it<10);
					break;
				}
			}
		}
		if(one==1) Tau=0.0;
	}

	//	 Calculate expected change of function value test and step vector g
	//	     using regularization parameter tau by the formulas
	//
	//	                                      1
	//	      G = U A' - X     with A' =  ---------- A(I)
	//	                             I    1+TAU*Eigenvalue(I)
	//
	//	                   T
	//	      test= 0.5 * g  * (gradient - tau C x)    C = regularization matrix


	ir=0;
	iVeto=0;

	// define inverse matrix
	Int_t ij=0;
	Int_t IM;
	Int_t two=2;
	while(1) {
		ij=0;
		for(Int_t l=0; l<M; ++l) {
//			if(l == 0)  cout<<"D(0)="<<Eigenvalue[l]<<" M="<<M<<endl;
			A2[l]=A[l];
			for(Int_t m=0; m<=l; ++m) {
				ScratchMatrixA[ij]=0.0;
				ij=ij+1;
			}
			// diagonal element not zero
			ScratchMatrixA[ij-1]=1.0/(1.0+Tau*Eigenvalue[l]);
		}
		// same value of M
		ME=M;

		// add known constraints
		for(Int_t n=0; n<nrConstraints; ++n) {
			IA=IC[n];
			for(Int_t p=0; p<M; ++p) {
				ij=p*nrKnots+IA-1;
				if((n+1)>MC) {
					// positivity constraint
					B1[p]=U[ij];
				}
				else {
					// function value constraint
					B1[p]=U[ij]+11.0*(U[ij+1]+U[ij+2])+U[ij+3];
				}
			}
			// update inverse matrix
			B1[ME]=0.0;
			MatrixMult->SymGeneralMult(ScratchMatrixA, B1, B2, ME, 1);
			EL=-1.0/ScalarProd(B1, B2, ME);
			ij=0;
			for(Int_t q=0; q<ME; ++q) {
				for(Int_t r=0; r<=q; ++r) {
					ScratchMatrixA[ij]=ScratchMatrixA[ij]+EL*B2[q]*B2[r];
					ij=ij+1;
				}
			}
			for(Int_t s=0; s<ME; ++s) {
				ScratchMatrixA[ij]=-EL*B2[s];
				ij=ij+1;
			}
			ScratchMatrixA[ij]=EL;
			ME++;
			if((n+1)>MC) {
				// positivity constraint
				A2[ME-1]=0.0;
			}
			else {
				// function value constraint
				A2[ME-1]=CN[n];
			}
		}

		// solve system by multiplication ...
		MatrixMult->SymGeneralMult(ScratchMatrixA, A2, SymmetricA, ME, 1);
		// ... and back by rotation to Gradient
		MatrixMult->General2MatrixMult(SymmetricA, U, Gradient, 1, M, nrKnots);// AS = A symmetrisch
		//for(Int_t ia=0; ia<nrKnots; ++ia) cout<<ia+1<<" G="<<Gradient[ia]<<endl;
		if(ir!=0) break;
		// maximum step
		Fmax=5.0;
		if(icfl==0) break;
		// check negative content or step to negative content
		ineg=0;
		fneg=0.0;
		for(Int_t t=0; t<nrKnots; ++t) {//40
			two=2;
			for(Int_t u=MC; u<nrConstraints; ++u) {
				if(IC[u] == (t+1)) {
					two=3;
					break;
				}
			}
			if(two==3) continue;
			FN=X[t];
			FD=Gradient[t]-FN;
			if(FD!=0.0) {
				FCA=-FN/FD;
				//cout<<"FN="<<FN<<" FD="<<FD<<endl;
				if(FCA < 0.1 && FD < 0.0) {
					if(ineg==0 || FD<fneg) {
						// set flat ineg to index with largest negative value
						ineg=t+1;
						fneg=FD;
					}
				}
				else if(FCA>0.0) {
					// determine Fmax as maximum allowed step vector
					Fmax=TMath::Min(Fmax, FCA);
				}
			}
		}
		if(ineg!=0) {
			// add zero costraint and ...
			if(nrConstraints>=110) break;
			nrConstraints=nrConstraints+1;
			iVeto=1;
			// ... store index which could go negative ...
			IC[nrConstraints-1]=ineg;
			// ... and repeat setting up equations
			continue;
		}
		// check, whether one constraint can be removed (step positive)
		IM=0;
		Asm=0.0;
		for(Int_t v=MC; v<nrConstraints; ++v) {
			// check Lagrangian
			if(ir!=0 || SymmetricA[v+M]>Asm) {
				ir=v+1;
				Asm=SymmetricA[v+M];
			}
		}
		if(ir==0 || Asm<0.0) break;
		// remove constraint ...
		for(Int_t w=ir; w<nrConstraints; ++w) {
			IC[w-1]=IC[w];
		}
		nrConstraints=nrConstraints-1,
				iVeto=1;
		// and repeat setting up equations
	}

	// finally calculation of step as difference
	for(Int_t I=0; I<nrKnots; ++I) {
//		cout<<I+1<<" G="<<Gradient[I]<<" X="<<X[I]<<endl;
		Gradient[I]=Gradient[I]-X[I];
	}
	// cout<<"nr of constraints = "<<nrConstraints<<endl;
}

void RegularizationMath::DetermineBinLimits(Int_t K, Double_t *U, Int_t &nrBins, Double_t *binLimit, Int_t NrKnotsMax) {
	// RSOLVB
	// Determine bin limits from extrema of K'th eigenvector
	// K'th fourier coefficient is the first non-significant coeff.
	// each eigenvector has nrKnots elements
	binLimit[0]=xLowLimit;// defined by the user
	// Double_t eigenvectorK[NrKnotsMax*NrKnotsMax];
	Double_t eigenvectorK[nrKnots];
	// extract all the K'th eigenvector out of the eigenvector matrix U
	//cout<<"eigenvektoren:"<<endl;
	for(Int_t trafo=0; trafo<nrKnots; ++trafo) {
	//for(Int_t trafo=0; trafo<NrKnotsMax*NrKnotsMax-(K-1)*nrKnots; ++trafo) {
		//cout<<"he?"<<endl;
		eigenvectorK[trafo]=U[(K-1)*nrKnots+trafo];
		//cout<<((K-1)*nrKnots+trafo)<<" "<<eigenvectorK[trafo]<<endl;
	}
//	cout<<endl;
	// determine spline function value at left edge of f(x)
	Double_t FxLeft=SplineCalc->FunctionValueFx(xLowLimit,eigenvectorK,nrKnots,xLowLimit,xHighLimit);

	Int_t L=1;
	Double_t XLeft=xLowLimit;
	Double_t FxNext;
	Double_t xNext;
	do {
		// next argument with first derivative = 0.0
		xNext=SplineCalc->NextXValue(XLeft, eigenvectorK,nrKnots,xLowLimit,xHighLimit);
	//	cout<<"x next = "<<xNext<<endl;
		// ... and function value at this argument
		FxNext=SplineCalc->FunctionValueFx(xNext, eigenvectorK,nrKnots,xLowLimit,xHighLimit);
		if(xNext<=xHighLimit) {
			if(FxLeft*FxNext<0.0) {
				// different sign of derivative
				binLimit[L]=xNext;
				L=L+1;
				FxLeft=FxNext;
			}
			XLeft=xNext;
		}
	}while(xNext<=xHighLimit);
	// right edge
	FxNext=SplineCalc->FunctionValueFx(xHighLimit,eigenvectorK,nrKnots,xLowLimit,xHighLimit);
	if(FxLeft*FxNext>0.0) L=L-1;
	binLimit[L]=xHighLimit;
	// final number of bins+1 is number of bin limits
	nrBins=L;
}


