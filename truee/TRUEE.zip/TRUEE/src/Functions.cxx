//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

// various functions for calculations with splines

#include "Functions.h"
#include "TMath.h"
#include "math.h"
#include <iostream>

using namespace std;

Functions::Functions() {
	delta = 0;
	BMatrix = new BandMatrix();
}

Functions::~Functions() {
	delete BMatrix;
}
Double_t Functions::FValueOfDerivatives(Double_t X, Double_t *A, Int_t N, Double_t XlowLimit, Double_t XhighLimit, Int_t nrDerivative) {
	// ESPD (original)
	// calculate spline function value of nrDerivative'th derivative
	// The result is for all cases a  linear  combination  of B-spline coefficients (A)
	// For X outside the limits the X value is assumed at the limit.

	Double_t factor;
	Double_t FunctionValue;
	Double_t U;
	Double_t V;
	if(nrDerivative > 3 || nrDerivative < 0) {
		I0 = -1;
		FunctionValue = 0.0;
		if(nrDerivative+1 == 0) FunctionValue = SplineFuncIntegral(XlowLimit,X,A,N,XlowLimit,XhighLimit);
		return FunctionValue;
	}

	Double_t knotDistance = (XhighLimit-XlowLimit)/static_cast<Double_t>(N-3);
	Double_t XI = (X-XlowLimit)/knotDistance;
	if(XI < 0.0) {
		// outside low
		I0 = 0;
		V = 0.0;
	}
	else {
		I0 = static_cast<Int_t>(XI);
		if(I0 > N-4) {
			// outside high
			I0 = N-4;
			V = 1.0;
		}
		else {
			// inside
			V = XI-static_cast<Double_t>(I0);
		}
	}

	U = 1.0-V;
	if(nrDerivative == 1) {
		// first derivative
		factor = 0.5/knotDistance;
		S[0] = -factor* U*U;
		S[1] = -factor*(1.0+(2.0*V-U)*U);
		S[2] = factor*(1.0+(2.0*U-V)*V);
		S[3] = factor* V*V;
	}
	else if(nrDerivative == 2) {
		// second derivative
		factor = 1.0/(knotDistance*knotDistance);
		S[0] = factor* U;
		S[1] = factor*(V-2.0*U);
		S[2] = factor*(U-2.0*V);
		S[3] = factor* V;
	}
	// final sum
	FunctionValue = A[I0]*S[0]+A[I0+1]*S[1]+A[I0+2]*S[2]+A[I0+3]*S[3];
	return FunctionValue;
}
Double_t Functions::SplineFuncIntegral(Double_t X1, Double_t X2, Double_t *A, Int_t N, Double_t XlowLimit, Double_t XhighLimit) {
	// ESPI (original)

// Integral of spline function between X1 and X2
// The integral over the spline function is calculated between the
// limits X1 and X2. A limit below XlowLimit (above XhighLimit) is  replaced  by  XlowLimit (XhighLimit).
// The result is a linear combination of B-spline coefficients (A).
// Integral = sum(i=1...n0) S(i)*A(i)

	Double_t V;
	Double_t U;
	Double_t T[4];
	Double_t B = 0.0;

	Double_t TB[][3] =
	{
			{11.0, 22.0, 23.0},
			{11.0, 12.0, 12.0},
			{1.0, 1.0, 1.0}
	};

	Double_t BT[4] = {1.0,12.0,23.0,24.0};

	// clear array of weights
	for(Int_t i = 0; i < N; i++) {
		S[i] = 0.0;
	}

	N0 = 0;
	Double_t knotDistance = (XhighLimit-XlowLimit)/static_cast<Double_t>(N-3);

	// lower limit of integration
	Double_t XJ = X1;

	for(Int_t j = 0; j < 2; ++j) {
		// transform to coordinate v relative to knots
		XJ = (XJ-XlowLimit)/knotDistance;
		if(XJ >= 0.0) {
			I0 = static_cast<Int_t>(XJ);
			if(I0 <= N-4) V = XJ-static_cast<Double_t>(I0);
			else {
				I0 = N-4;
				V = 1.0;
			}

			U = 1.0-V;
			// calculate contribution from last knot interval
			T[0] = 1.0-pow(U,4);
			T[1] = 11.0-(((-3.0*U+4.0)*U+6.0)*U+4.0)*U;
			T[2] = (((-3.0*V+4.0)*V+6.0)*V+4.0)*V;
			T[3] = pow(V,4);

			// add contributions from previous knot intervals
			if(I0 >= 1) {
				T[0] = T[0]+TB[0][TMath::Min(I0,3)-1];
				T[1] = T[1]+TB[1][TMath::Min(I0,3)-1];
				T[2] = T[2]+TB[2][TMath::Min(I0,3)-1];
			}
			// subtract or add to array s(i)
			for(Int_t k = 0; k < I0+4; ++k) {
				if(k <= (I0-1)) B = BT[TMath::Min(k,3)];
				else B = T[k-I0];

				if(j == 0) S[k] = -B;
				else S[k] = S[k]+B;

				N0 = TMath::Max(N0, I0+4);
			}
		}
		// upper limit of integration
		XJ = X2;
	}

	// integral by sum
	Double_t sum = 0.0;
	for(Int_t l = 0; l < N; ++l) {
                if(S[l] > pow(10., -10.)) {
			sum = sum+A[l]*S[l];
			S[l] = S[l]*knotDistance/24.0;
		}
		else S[l] = 0.0;
	}
	Double_t integral = sum*knotDistance/24.0;
	return integral;
}

void Functions::LeastSquareFit(Double_t *Y, Double_t *YVariance, Int_t NrBinsMC, Double_t XlowLimit, Double_t XhighLimit, Int_t NrKnots, Double_t *FIntegral, Double_t *A){
	// ESPQ (original)
	// least square fit of spline to histogram
	// NrBinsMC corresponds to 4 bins per knot

	Double_t Q[5][63];
	Double_t WT = 0;
	Double_t sum;

	// reset matrices
	for(Int_t j = 0; j < NrKnots; ++j) {
		A[j] = 0.0;
		for(Int_t i = 0; i < 5; ++i) {
			Q[i][j] = 0.0;
		}
	}

	// find minimum value of variance (not zero)
	Double_t VarianceMin = 0.0;
	for(Int_t k = 0; k < NrBinsMC; ++k) {
		if(YVariance[k] != 0.0) {
			if(VarianceMin == 0.0) VarianceMin = YVariance[k];
			VarianceMin = TMath::Min(VarianceMin, YVariance[k]);
		}
	}

	if(VarianceMin == 0.0) VarianceMin = 1.0;

	// loop all bins
	Double_t XL, XR = XlowLimit;
	for(Int_t l = 0; l < NrBinsMC; ++l) {
		// left and right bin limits
		XL = XR;
		XR = XlowLimit+(XhighLimit-XlowLimit)*static_cast<Double_t>(l+1)/static_cast<Double_t>(NrBinsMC);
		// nonzero bin content
		WT = 1.0/VarianceMin;
		if(YVariance[l] != 0) WT = 1.0/YVariance[l];
		// integration over bin XL ... XR
		sum = SplineFuncIntegral(XL,XR,A,NrKnots,XlowLimit,XhighLimit);
		// add to normal equations
		for(Int_t m = 0; m < (N0-I0); ++m) {
			A[I0+m] = A[I0+m]+WT*S[I0+m]*Y[l];
			for(Int_t n = m; n < (N0-I0); ++n) {
				Q[n-m][I0+m] = Q[n-m][I0+m]+WT*S[I0+m]*S[I0+n];
			}
		}
	}
	// solve system with band matrix
	BMatrix->GetSolution(Q, 5, NrKnots, A, delta);
	// loop to calculate fitted bin content
	XR = XlowLimit;
	for(Int_t p = 0; p < NrBinsMC; ++p) {
		// left and right bin limits
		XL = XR;
		XR = XlowLimit+(XhighLimit-XlowLimit)*static_cast<Double_t>(p+1)/static_cast<Double_t>(NrBinsMC);
		// integration over bin XL ... XR
		FIntegral[p] = SplineFuncIntegral(XL,XR,A,NrKnots,XlowLimit,XhighLimit);
	}

	// renormalize spline coefficients
	for(Int_t q = 0; q < NrKnots; ++q) {
		A[q] = A[q]*(XhighLimit-XlowLimit)/static_cast<Double_t>(NrBinsMC);
	}
}

void Functions::SplineFuncValue(Double_t X, Int_t N, Double_t XlowLimit, Double_t XhighLimit, Int_t &I, Double_t *Spline) {
	// ESPB (original)
	// determines individual spline function values: Spline[i] inside XlowLimit ... XhighLimit

	Double_t U;
	Double_t V;
	Double_t knotDistance = (XhighLimit-XlowLimit)/static_cast<Double_t>(N-3);
	Double_t XI = (X-XlowLimit)/knotDistance;
	if(XI < 0.0) {
		// outside low
		I = 0;
		V = 0.0;
	}
	else {
		I = static_cast<Int_t>(XI);
		if(I > (N-4)) {
			// outside high
			I = N-4;
			V = 1.0;
		}
		else {
			// inside
			V = XI-static_cast<Double_t>(I);
		}
	}
	U = 1.0-V;
	// function values of the four splines
	Spline[0] = U*U*U/6.0;
	Spline[1] = (1.0+3.0*(1.0+U*V)*U)/6.0;
	Spline[2] = (1.0+3.0*(1.0+U*V)*V)/6.0;
	Spline[3] = V*V*V/6.0;
}

Double_t Functions::FunctionValueFx(Double_t X, Double_t *A, Int_t N, Double_t XlowLimit, Double_t XhighLimit) {
	// ESPF (original)
	// calculate function value at x (Spline function with coefficients A)
	//TODO merge this method with FValueOfDerivatives?
	//Int_t ND = 0;
	Double_t Function;
	Double_t knotDistance = (XhighLimit-XlowLimit)/static_cast<Double_t>(N-3);
	Double_t XI = (X-XlowLimit)/knotDistance;
	Double_t U;
	Double_t V;
	if(XI < 0.0) {
		// outside low
		I0 = 0;
		V = 0.0;
	}
	else {
		I0 = static_cast<Int_t>(XI);
		if(I0 > N-4) {
			// outside high
			I0 = N-4;
			V = 1.0;
		}
		else {
			// inside
			V = XI-static_cast<Double_t>(I0);
		}
	}
	U = 1.0-V;

	// function value
	S[0] = U*U*U/6.0;
	S[1] = (1.0+3.0*(1.0+U*V)*U)/6.0;
	S[2] = (1.0+3.0*(1.0+U*V)*V)/6.0;
	S[3] = V*V*V/6.0;
	// final sum
	Function = A[I0]*S[0]+A[I0+1]*S[1]+A[I0+2]*S[2]+A[I0+3]*S[3];
	return Function;
}

Double_t Functions::NextXValue(Double_t XLeft, Double_t *A, Int_t nrKnots, Double_t xLowLimit, Double_t xHighLimit) {
	// ESPX (original)
	// Calculate next x-value with given function value f(x).
	// First derivative of the f(XValue) is 0

	Double_t knotDistance = (xHighLimit-xLowLimit)/static_cast<Double_t>(nrKnots-3);
	Double_t step = 0.1*knotDistance;
	Double_t XValue = xHighLimit+knotDistance;
	Double_t firstDerivX1;
	Double_t firstDerivX2;
	Double_t secondDerivXX;
	Double_t firstDerivXX;
	Double_t X1;
	Double_t X2;
	Double_t XX;
	Double_t quotient;

	Int_t IT = 0;
	Int_t NrDerivative = 1;

	if(XLeft > xHighLimit) return XValue;
	if(XLeft <= xLowLimit) {
		XX = xLowLimit;
	}
	else {
		XX = XLeft+step;
	}
//	for(Int_t i=0; i<nrKnots; ++i)
//		cout<<A[i]<<" ";
//	cout<<endl;

	//--------- loop to find first derivatives with opposite sign (change of gradient) -----------
	X1 = XX;
	// determine first derivative at the value X1
	firstDerivX1 = FValueOfDerivatives(X1, A, nrKnots, xLowLimit, xHighLimit, NrDerivative);
	do {
		// search for X2 along the x axis in 0.3*knotDistance steps with opposite gradient
		X2 = TMath::Min(xHighLimit, X1+3.0*step);
		firstDerivX2 = FValueOfDerivatives(X2, A, nrKnots, xLowLimit, xHighLimit, NrDerivative);
		if(firstDerivX1*firstDerivX2 > 0.0) {
			// still same signs of two function values
			if(X2 == xHighLimit) return XValue;
			X1 = X2;
			firstDerivX1 = firstDerivX2;
		}
	}while(firstDerivX1*firstDerivX2 > 0.0);// while gradient signs are the same

	// enclosed
	if(firstDerivX1 == firstDerivX2) return XValue;


	//------------ find minimum or maximum of f(XX) between X1 ... X2 by the Newton method --------------
	// approximate solution
	XX = (X1*firstDerivX2-X2*firstDerivX1)/(firstDerivX2-firstDerivX1);// XX is a value between X1 and X2

	while(IT <= 10) {
		// first derivative of f(XX) function
		firstDerivXX = FValueOfDerivatives(XX, A, nrKnots, xLowLimit, xHighLimit, NrDerivative);
		// second derivative of f(XX) function
		secondDerivXX = FValueOfDerivatives(XX, A, nrKnots, xLowLimit, xHighLimit, NrDerivative+1);
		if(secondDerivXX != 0.0) {
			// correction
			quotient = -firstDerivXX/secondDerivXX;
			XX = XX+quotient;
			IT++;
                        if(IT < 2 || fabs(quotient) > step*pow(10., -3.)) continue;
			XValue = XX;// minimum or maximum found at XX
		}
		break;
	}
	return XValue;
}
