#include "trueecsvreader.h"
#include <cmath>

using namespace std;

TrueeCSVReader::TrueeCSVReader(int nrAllMeasuredVariables, Input *in)
{
            NrAllMeasuredVariables = nrAllMeasuredVariables;
            InputObject = in;
            seperator = ",";

            printflag = InputObject->getPrintflag();
}

void TrueeCSVReader::Read(const std::string &Sourcefile, const std::string &SourceTreeName, const std::string &label, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex){

    if(printflag > 41){
        cout <<"Going to read from CSV source file"<<endl;
    }
    std::vector<std::string> title;
    std::vector<std::string> aux;

    in.open(Sourcefile.c_str());

   /////////////////////////////////////////////////////
   // get the first raw and finds the coloumn position /
   /////////////////////////////////////////////////////

    if(printflag > 41){
        cout <<"Going to determine Positions for each obs/wantedx/weight"<<endl;
    }

    title = getline(in);

    if(label == "MOCA")
        Pos_WantedX = getcoloumn(BranchWantedX,title);
    if(BranchEventWeight != "no_weight"){
        Pos_Weight = getcoloumn(BranchEventWeight,title);
    }
    for(int i = 0; i < NrAllMeasuredVariables; ++i){
        Pos_Obs.push_back(getcoloumn(BranchMeasurVariable[i],title));

    }


    /////////////////////////////////////////////////////
    // read data                                        /
    /////////////////////////////////////////////////////

    if(printflag > 41){
        cout <<"Going to read every event"<<endl;
    }

    while(!in.eof()){
        aux = getline(in);
        if(aux.size() == 0)
            break;
        TrueeEvent* temp_event = new TrueeEvent();
        double X;

        if(BranchEventWeight != "no_weight"){
            temp_event->SetWeight(convert(aux.at(Pos_Weight)));
        }
        else
            temp_event->SetWeight(1);

        X = convert(aux.at(Pos_WantedX));

        if(logOptionX){
            if(X > 0)
                X = log10(X);
            else
                break;
        }
        temp_event->set_x(X);

        for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {

            X = convert(aux.at(Pos_Obs.at(ij)));
            if(logOption[ij]){
                if(X > 0)
                    X = log10(X);
                else
                    break;
            }
            temp_event->add_y(X);

        }

        temp_event->set_NTupleIndex(NTupleIndex);

        /////////////////////////////////////////////////////
        // add to trueedata                                 /
        /////////////////////////////////////////////////////


        if(printflag > 41){
            cout <<"Going to add events to full data"<<endl;
        }

        if(label=="DATA") {
             InputObject->GetData()->Real_Data.push_back(temp_event);
        }
        else if(label=="MOCA") {
            InputObject->GetData()->MonteCarlo_Data.push_back(temp_event);
        }
        else if (label=="BKGD") {
            InputObject->GetData()->BG_Data.push_back(temp_event);
        }

    }

    in.close();

}

void TrueeCSVReader::ReadTest(const std::string &Sourcefile, const std::string &SourceTreeName, const std::string &label, const std::string &BranchWantedX, const std::string *BranchMeasurVariable, const std::string &BranchEventWeight, Bool_t *logOption, Bool_t logOptionX, Int_t NTupleIndex, std::string type){

    if(printflag > 41){
        cout <<"Going to read from CSV source file (testmode)"<<endl;
    }
    std::vector<std::string> title;
    std::vector<std::string> aux;

    in.open(Sourcefile.c_str());

   /////////////////////////////////////////////////////
   // get the first raw and finds the coloumn position /
   /////////////////////////////////////////////////////

    if(printflag > 41){
        cout <<"Going to determine positions for each obs/wantedx/weight"<<endl;
    }

    title = getline(in);

    Pos_WantedX = getcoloumn(BranchWantedX,title);

    if(BranchEventWeight != "no_weight"){
        Pos_Weight = getcoloumn(BranchEventWeight,title);
    }
    for(int i = 0; i < NrAllMeasuredVariables; ++i){
        Pos_Obs.push_back(getcoloumn(BranchMeasurVariable[i],title));

    }


    /////////////////////////////////////////////////////
    // read data                                        /
    /////////////////////////////////////////////////////

    if(printflag > 41){
        cout <<"Going to read every event"<<endl;
    }

    while(!in.eof()){
        aux = getline(in);
        if(aux.size() == 0)
            break;
        TrueeEvent* temp_event = new TrueeEvent();
        double X;

        if(BranchEventWeight != "no_weight"){
            temp_event->SetWeight(convert(aux.at(Pos_Weight)));
        }
        else
            temp_event->SetWeight(1);

        X = convert(aux.at(Pos_WantedX));

        if(logOptionX){
            if(X > 0)
                X = log10(X);
            else
                break;
        }
        temp_event->set_x(X);

        for(int ij=0; ij<NrAllMeasuredVariables; ++ij) {

            X = convert(aux.at(Pos_Obs.at(ij)));
            if(logOption[ij]){
                if(X > 0)
                    X = log10(X);
                else
                    break;
            }
            temp_event->add_y(X);

        }

        temp_event->set_NTupleIndex(NTupleIndex);

        /////////////////////////////////////////////////////
        // add to trueedata                                 /
        /////////////////////////////////////////////////////


        if(printflag > 41){
            cout <<"Going to add events to full data"<<endl;
        }


        if (label=="BKGD") {
            InputObject->GetData()->BG_Data.push_back(temp_event);
        }
        else if(type == "USUAL")
            InputObject->Full_data.push_back(temp_event);
        else if(type == "DIFFMC")
            InputObject->Full_MC.push_back(temp_event);

    }

    in.close();

}

std::vector<std::string> TrueeCSVReader::getline(std::istream& str)
{
    std::vector<std::string>   result;
    std::string                line;
    std::getline(str,line);

    std::stringstream          lineStream(line);
    std::string                cell;

    while(std::getline(lineStream,cell,seperator.c_str()[0]))
    {
        result.push_back(cell);
    }
    return result;
}

int TrueeCSVReader::getcoloumn(string name, vector<string> title){

    for(int i = 0; i < title.size(); ++i){
        cout << title.at(i)<<endl;
        if(name == title.at(i))
            return i;
    }

    cerr << "Can not find observable/WantedX "<<name<<endl;
    return -1;

}

double TrueeCSVReader::convert(string S){

    stringstream ss;
    double frac;
    ss << S;
    ss >> frac;

    return frac;
}



























