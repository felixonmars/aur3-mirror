//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

// Calculate average value of function func(x) in (x1,x2)
// for the integration by the simpsons rule.
// Simpsons rule: integrate a function whose value is known at equally spaced steps
#include "AverageOfFunction.h"
#include <iostream>
#include "math.h"

using namespace std;

Double_t AverageOfFunction(Double_t x1, Double_t x2, Double_t func(Double_t)) {
	// this method for function as parameter
	Double_t average = 0;
	Double_t averageLast = 0;
	Double_t function;
	Double_t sum;
	Double_t x;
	Int_t N = 16;

	for(Int_t l = 0; l < 8; ++l) {
		sum = 0.0;
		// form simpson sum
		for(Int_t i = 0; i <= N; ++i) {
			// set N (even) equidistant x-Values (min. x-value = x1, max. x-value = x2)
			x = (static_cast<Double_t>(N-i)*x1+static_cast<Double_t>(i)*x2)/static_cast<Double_t>(N);
			// determine function value at point x
			function = func(x);
			if(i == 0 || i == N) {
				sum = sum+function;
			}
			else if(i%2 == 0) {
				sum = sum+2*function;
			}
			else {
				sum = sum+4*function;
			}
		}

		averageLast = average;
		average = sum/static_cast<Double_t>(3*N);
		// estimate precision by comparison with previous value
		if(l >= 1) {
			if(sqrt((average-averageLast)*(average-averageLast)) <= 0.0005*(average+averageLast)) {
				return average;
			}
		}
		N = N+N;
	}
	return average;
}

Double_t AverageOfFunction(Double_t x1, Double_t x2, FxFunctionMC *MCFunctionFx) {
	// this method for FxFunctionMC-object as parameter
	Double_t average = 0;
	Double_t averageLast = 0;
	Double_t function;
	Double_t sum;
	Double_t x;
	Int_t N = 16;

	for(Int_t l = 0; l < 8; ++l) {
		sum = 0.0;
		// form simpson sum
		for(Int_t i = 0; i <= N; ++i) {
			// set N (even) equidistant x-Values (min. x-value = x1, max. x-value = x2)
			x = (static_cast<Double_t>(N-i)*x1+static_cast<Double_t>(i)*x2)/static_cast<Double_t>(N);
			// determine function value at point x
			function = MCFunctionFx->getMCFxFunction(x);
			if(i == 0 || i == N) {
				sum = sum+function;
			}
			else if(i%2 == 0) {
				sum = sum+2*function;
			}
			else {
				sum = sum+4*function;
			}
		}

		averageLast = average;
		average = sum/static_cast<Double_t>(3*N);
		// estimate precision by comparison with previous value
		if(l >= 1) {
			if(sqrt((average-averageLast)*(average-averageLast)) <= 0.0005*(average+averageLast)) {
				return average;
			}
		}
		N = N+N;
	}
	return average;
}
