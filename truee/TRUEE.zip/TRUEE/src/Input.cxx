//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#include "Input.h"
//#include "TRandom3.h"
//#include "trueereadin.h"
#include "ReadIn.h"
#include "trueecsvreader.h"

using namespace std;
Input::Input() {
    ignore_last_bin =false;

    branchEventWeight = "no_weight";
    ColumnWantedVariable = 0;
    TreeBG = 0;
    TreeMC = 0;
    TreeRD = 0;
    BackEventNr = 0;
    FXpositive = 0;
    LinWeight = 0.0;
    //indexFinestFitVar = 0;
    nameWantedX.Form("sought_variable_x");
    outputpath = "";

    mcFuncFlag = 0;
    NrAllMeasuredVariables = 0;
    NrConstraints = 0;
    //nrBinsNext = 0;
    NrBinsResult = 0;
    NrBinsResultMax = 120;
    NrBinsResultMaxUser = 0;
    NrDataTypes = 1;
    NrDegreeOfFreedom = 0;
    NrDegreeOfFreedomMaxUser = 0;
    NrKnots = 0;
    NrKnotsMax = 63;
    NrKnotsMaxUser = 1;
    NrBinsMCMax = 4*(NrKnotsMax-3);// NHU = NrBinsMCMax
    NrOfFitVariables = 0;
    NrMocaTypes = 1;
    nrPulls = 1;
    print = 1;
    randomseed = 0;
    fraction = 0.5;
    SourceFileBG = "no_BG";
    SmoothX = 0;
    SumLumiData = 0.0;
    WantedXHighLimit = 0.0;
    WantedXLowLimit = 0.0;
    XMCLumi = 1.0;
    zeroLeft = 0;
    zeroRight = 0;
    MaxNrVariables = 32;
    testmode = 0;
    pullmode = 0;
    //------------------ set luminosity, weight and limits to zero ----------------------
    for(Int_t i = 0; i < MaxNrVariables; ++i) {
        DataLumi[i] = 1;
        MocaLumi[i] = 1;
        MocaWeight[i] = 1;
        NrBinsMeasuredVar[i] = 0;
        MeasuredVarHighLimit[i] = 0;
        MeasuredVarLowLimit[i] = 0;
        LimitsOfBinsResult[i] = 0;
        logOption[i] = 0;
        nameObsY[i].Form("observable_%i",i);
    }
    logOptionX = 0;
    for(Int_t ij = 0; ij < 5; ++ij) {
        IndexFitVariable[ij] = 0;
        NrBinsFitVar[ij] = 0;
        FitVarHighLimit[ij] = 0;
        FitVarLowLimit[ij] = 0;
    }
    for (Int_t j = 0; j < 10; ++j) {
        Xconstraint[j] = 0;
        FXconstraint[j] = 0;
    }

    Rawdata = new TrueeData();
    csvseperator = ",";

    ResultSuppression_Kolmogorov =-1;
    ResultSuppression_ChiSquare = -1;
    ResultSuppression_DPC = -1;
}

Input::~Input() {
}

Int_t Input::ParameterInput(TString steerFilePath) {
    // some keywords to read the parameter.config file
    Int_t index;
    string keyword;
    char projectName[256] = "no_title";
    char input[256];
    char *word;
    const char *comment = "#";
    const char *mode = "mode:";
    const char *pull = "pull";
    const char *data_fraction = "pseudo_data_fraction:";
    const char *test = "test";
    const char *randomflag = "random";
    const char *printflag = "printflag:";
    const char *title = "title:";
    const char *number_all_variables = "number_all_variables:";
    const char *number_data_types = "number_data_types:";
    const char *data_luminosity = "data_luminosity:";
    const char *source_file_data = "source_file_data:";
    const char *roottree_data = "roottree_data:";
    const char *number_moca_types = "number_moca_types:";
    const char *moca_luminosity = "moca_luminosity:";
    const char *moca_weight = "moca_weight:";
    const char *mc_func = "mc_func:";
    const char *source_file_moca = "source_file_moca:";
    const char *roottree_moca = "roottree_moca:";
    const char *source_file_back = "source_file_back:";
    //	const char *number_back_events = "number_back_events:";
    const char *roottree_back = "roottree_back:";
    const char *column_x = "column_x:";
    const char *branch_x = "branch_x:";
    const char *branch_event_weight = "branch_event_weight:";
    const char *limits_x = "limits_x:";
    const char *branch_y = "branch_y:";
    const char *number_y_bins = "number_y_bins:";
    const char *limits_y = "limits_y:";
    const char *log_ = "log";
    const char *number_deg_free = "number_deg_free:";
    const char *number_knots = "number_knots:";
    const char *number_bins = "number_bins:";
    const char *fx_positive = "fx_positive:";
    const char *smooth_x = "smooth_x:";
    const char *zero_left = "zero_left:";
    const char *zero_right = "zero_right:";
    const char *constraints = "constraints:";
    const char *weight_first = "weight_first:";
    const char *bin_limits = "bin_limits:";
    const char *max_number_bins = "max_number_bins:";
    const char *max_number_deg_free = "max_number_deg_free:";
    const char *max_number_knots = "max_number_knots:";
    const char *output_path = "output_path:";
    const char *cut_variable = "cut_variable:";
    const char *use_diff_mc = "use_different_mc:";
    const char *seperator = "csv_seperator:";

    const char *suppression_DPC = "result_suppression_DPC:";
    const char *suppression_kolmo = "result_suppression_Kolmogorov:";
    const char *suppression_chi2 = "result_suppression_chi2:";



    Int_t indexBins = 0;
    Int_t indexBranchMoca = 0;
    Int_t indexLimits = 0;
    Int_t indexLumiData = 0;
    Int_t indexLumiMoca = 0;
    Int_t indexSourceData = 0;
    Int_t indexSourceMoca = 0;
    Int_t indexTreeData = 0;
    Int_t indexTreeMoca = 0;
    Int_t indexWeightMoca = 0;
    //============================= read steering parameters from parameters.config ============================
    ifstream infile;
    infile.open(steerFilePath);
    if(!infile) {
        cerr<<"***** no parameter.config-file in the user defined directory.\n      Check the path in your truee.cxx-file.\n      (Template for parameter.config-file is in the build/bin-directory)"<<endl;
        return 0;
    }
    if(!infile.good()) {
        cerr<<"***** not able to read parameter.config-file."<<endl;
        return 0;
    }
    while (infile.good()) {
        if(!infile.good()) break;
        infile.getline(input,256); // get one line of the file parameter.config
        word = strtok(input, " "); // break the string into words (and numbers) (breaking point = blank). word is one token
        if(word != NULL) keyword = word;
        index = 0;
        while(word != NULL) {
            // skip comment lines
            if(*word == *comment) {
                break;
            }
            // put the name of the project together
            else if(keyword == title) {
                if(index == 1) strcpy(projectName, word);// first token of the project title
                else if(index > 1) {
                    strcat(projectName, " ");// place " " between words
                    strcat(projectName, word);// next token of the project title
                }
            }
            // get run mode (test or real unfolding)
            else if(keyword == mode) {
                if(index == 1) {
                    string modeWord = word;
                    if(modeWord == test) testmode = 1;
                    else if(modeWord == pull) {
                        pullmode = 1;
                        randomseed = 1;
                    }
                }
                else if(index == 2) {
                    string randomflagstring = word;
                    if(pullmode == 1) nrPulls = atoi(word);
                    else if(testmode == 1 && randomflagstring == randomflag) randomseed = 1;
                }
            }
            // get fraction to produce pseudo data in test or pull mode
            else if(keyword == data_fraction) {
                if(index == 1) fraction = atof(word);
            }
            // get printflag
            else if(keyword == printflag) {
                if(index == 1) print = atoi(word);
            }
            // get the number of all measured variables
            else if(keyword == number_all_variables) {
                if(index == 1) NrAllMeasuredVariables = atoi(word);
            }
            // get number of data types (if more then one data type is used)
            else if(keyword == number_data_types) {
                if(index == 1) NrDataTypes = atoi(word);
            }
            // get luminosity for every data type
            else if(keyword == data_luminosity) {
                if(index == 1) {
                    DataLumi[indexLumiData] = atof(word);
                    indexLumiData++;
                }
            }
            // get source file for real data
            else if(keyword == source_file_data) {
                if(index == 1) {
                    SourceFileRD[indexSourceData] = word;
                    indexSourceData++;
                }
            }
            // get RootTree-name, if real data is stored in a RootTree
            else if(keyword == roottree_data) {
                if(index == 1) {
                    SourceTreeRD[indexTreeData] = word;
                    TreeRD=1;
                    indexTreeData++;
                }
            }
            // get number of MC types (if more then one MC type is used)
            else if(keyword == number_moca_types) {
                if(index == 1) NrMocaTypes = atoi(word);
            }
            // get MC luminosity for every MC type
            else if(keyword == moca_luminosity) {
                if(index == 1) {
                    MocaLumi[indexLumiMoca] = atof(word);
                    indexLumiMoca++;
                }
            }
            // get MC weight for every MC type
            else if(keyword == moca_weight) {
                if(index == 1) {
                    MocaWeight[indexWeightMoca] = atof(word);
                    indexWeightMoca++;
                }
            }
            // get source file for MC simulations
            else if(keyword == source_file_moca) {
                if(index == 1) {
                    SourceFileMC[indexSourceMoca] = word;
                    indexSourceMoca++;
                }
            }
            // get RootTree-name, if MC simulations are stored in a RootTree
            else if(keyword == roottree_moca) {
                if(index == 1) {
                    SourceTreeMC[indexTreeMoca] = word;
                    TreeMC=1;
                    indexTreeMoca++;
                }
            }
            // get source file for background events
            else if(keyword == source_file_back) {
                if(index == 1) {
                    SourceFileBG = word;
                }
            }
            // get RootTree-name, if background events are stored in a RootTree
            else if(keyword == roottree_back) {
                if(index == 1) {
                    SourceTreeBG = word;
                    TreeBG=1;
                }
            }
            // get column index of the wanted variable, if real data or MC is stored in an ASCII-file
            else if(keyword == column_x) {
                if(index == 1) ColumnWantedVariable = atoi(word);
                if(index == 2) {
                    string logStatus = word;
                    if(logStatus == log_) logOptionX = 1;
                }
            }
            // get branch name of the wanted variable, if real data or MC is stored in a RootTree
            else if(keyword == branch_x) {
                if(index == 1) BranchWantedX = word;
                if(index == 2) {
                    string logStatus = word;
                    if(logStatus == log_) logOptionX = 1;
                }
            }
            // get branch name of the individual event weight, if present
            else if(keyword == branch_event_weight) {
                if(index == 1) branchEventWeight = word;
            }

            // get user defined x-limits for the unfolded interval
            else if(keyword == limits_x) {
                if(index == 1) WantedXLowLimit = atof(word);
                if(index == 2) WantedXHighLimit = atof(word);
            }
            // get branch name of measured variables, if real data or MC is stored in a RootTree
            else if(keyword == branch_y) {
                if(index == 1) {
                    BranchMeasurVariable[indexBranchMoca] = word;
                    indexBranchMoca++;
                }
            }
            // get number of bins of measured variables
            else if(keyword == number_y_bins) {
                if(index == 1) {
                    NrBinsMeasuredVar[indexBins] = atoi(word);
                    indexBins++;
                }
                if(index == 2) {
                    string logStatus = word;
                    if(logStatus == log_) logOption[indexBins-1] = 1;
                }
            }
            // get user defined y-limits for measured variables
            else if(keyword == limits_y) {
                if(index == 1) MeasuredVarLowLimit[indexLimits] = atof(word);
                if(index == 2) {
                    MeasuredVarHighLimit[indexLimits] = atof(word);
                    indexLimits++;
                }
            }
            // get number of degrees of freedom to control the influence of regularization (optional)
            else if(keyword == number_deg_free) {
                if(index == 1){
                    MinNrDegreeOfFreedom =atoi(word);
                    NrDegreeOfFreedom = atoi(word);
                }
            }
            // get number of knots to control number of bins in MC f(x)-histogram
            else if(keyword == number_knots) {
                if(index == 1){
                    MinNrKnots = atoi(word);
                    NrKnots = atoi(word);
                }
            }
            // get option for positive result histogram values
            else if(keyword == fx_positive) {
                if(index == 1) FXpositive = atoi(word);
            }
            // get smooth option for MC f(x) histogram
            else if(keyword == smooth_x) {
                if(index == 1) SmoothX = atoi(word);
            }
            // get constraint for left histogram limit
            else if(keyword == zero_left) {
                if(index == 1) zeroLeft = atoi(word);
            }
            // get constraint for right histogram limit
            else if(keyword == zero_right) {
                if(index == 1) zeroRight = atoi(word);
            }
            // get constraint pairs x and f(x)
            else if(keyword == constraints) {
                if(index > 0 && index%2 == 1) {
                    Xconstraint[NrConstraints] = atof(word);
                }
                if(index > 0 && index%2 == 0) {
                    FXconstraint[NrConstraints] = atof(word);
                    NrConstraints++;
                }
            }
            // get weight for first derivative contributing to regularization
            else if(keyword == weight_first) {
                if(index == 1) LinWeight = atof(word);
            }
            // get bin limits for the final histogram
            else if(keyword == bin_limits) {
                if(index > 0) LimitsOfBinsResult[index-1] = atof(word);
                NrBinsResult = index-1;
            }
            // get minimum number of bins for the final histogram
            else if(keyword == number_bins) {
                if(index > 0 && NrBinsResult == 0){
                    NrBinsResult = atoi(word);
                    MinNrBinsResult = atoi(word);
                }
            }
            // get maximum number of bins for the final histogram (for the parameter loop in main function)
            else if(keyword == max_number_bins) {
                if(index == 1) NrBinsResultMaxUser = atoi(word);
            }
            // get maximum number of deg.of freedom for final histogram (for the parameter loop in main function)
            else if(keyword == max_number_deg_free) {
                if(index == 1) NrDegreeOfFreedomMaxUser = atoi(word);
            }
            // get maximum number of knots (for the parameter loop in main function)
            else if(keyword == max_number_knots) {
                if(index == 1) NrKnotsMaxUser = atoi(word);
            }
            // get user defined MC f(x) generated function
            else if(keyword == mc_func) {
                if(index == 1) {
                    mcFormula = word;
                    mcFuncFlag = 1;
                }
            }
            else if(keyword == output_path){
                if(index==1){
                    outputpath = word;
                }
            }
            else if(keyword == use_diff_mc) {

                if(index == 1) Use_different_MC = atoi(word);
            }
            else if(keyword == seperator) {

                if(index == 1) csvseperator = word;
            }
            else if(keyword == cut_variable){
                if(index==1){
                    Cutvariable = word;
                }
                if(index==2)
                    CutMin = atof(word);
                if(index==3)
                    CutMax = atof(word);

            }
            else if(keyword == suppression_DPC) {

                if(index == 1) ResultSuppression_DPC = atoi(word);
            }
            else if(keyword == suppression_kolmo) {

                if(index == 1) ResultSuppression_Kolmogorov = atoi(word);
            }
            else if(keyword == suppression_chi2) {
                if(index == 1) ResultSuppression_ChiSquare = atoi(word);
            }



            word = strtok(NULL, " "); // take next token or set word to NULL
            index++;

        }
    }
    infile.close();
    if((TreeBG == 0 && TreeMC == 0 && TreeRD == 0) && indexBins !=
            NrAllMeasuredVariables) {
        cerr<<"****** ERROR: the defined number of observables (number_all_variables: "<<NrAllMeasuredVariables<<")"<<endl;
        cerr<<"              is different than the number of entered observables("<<indexBins<<")"<<endl;
        return 0;
    }
    else if((TreeBG == 1 || TreeMC == 1 || TreeRD == 1) && indexBranchMoca != NrAllMeasuredVariables) {
        cerr<<"****** ERROR: the defined number of observables(number_all_variables: "<<NrAllMeasuredVariables<<")"<<endl;
        cerr<<"              is different than the number of entered observables("<<indexBranchMoca<<")"<<endl;
        return 0;
    }
    if(NrAllMeasuredVariables > 32) {
        cerr<<"****** ERROR: the defined number of observables (number_all_variables: "<<NrAllMeasuredVariables<<")"<<endl;
        cerr<<"              is higher than maximum: "<<MaxNrVariables<<endl;
        return 0;
    }
    if(getPrintflag() > 0){
        cout<<"=========================================================\n"<<endl;
        cout<<"=============   ";
        puts(projectName);// project name is assembled of several tokens. Display the title on the terminal
        projectTitle = projectName;
        cout<<"=========================================================\n"<<endl;
    }

    //-------- set names for variable and observables to branch names --------
    if(TreeRD || TreeMC || TreeBG) {
        nameWantedX = BranchWantedX;
        for(Int_t i = 0; i < NrAllMeasuredVariables; ++i) {
            nameObsY[i] = BranchMeasurVariable[i];
        }
    }

    //--------------------- bin limits and branch names for fit variables -------------------------
    for(Int_t k = 0; k<NrAllMeasuredVariables; ++k) {
        if(NrBinsMeasuredVar[k]>0) {
            FitVarHighLimit[NrOfFitVariables] = MeasuredVarHighLimit[k];
            FitVarLowLimit[NrOfFitVariables] = MeasuredVarLowLimit[k];
            IndexFitVariable[NrOfFitVariables] = k;
            NrBinsFitVar[NrOfFitVariables] = NrBinsMeasuredVar[k];// NrBinsFitVar[] = NBV
            NrOfFitVariables++;//NDV = IndesFitVariable[], NV = NrOfFitVariables
        }
    }
    //------------------- luminosity (and weight) for different data and MC types ----------
    for(Int_t k = 0; k<NrMocaTypes; k++) {
        if(MocaWeight[k]==0.0) MocaWeight[k] = 1.0;
        if(MocaLumi[k]==0.0) XMCLumi = 0.0;
        if(MocaLumi[k]!=0.0 && XMCLumi!=0.0) XMCLumi = MocaLumi[k];
    }

    if(testmode == 1) {
        NrDataTypes = NrMocaTypes;
        for(Int_t j = 0; j<NrMocaTypes; j++) {
            if(MocaLumi[j] != 0.0) {
                DataLumi[j] = MocaLumi[j];
            }
            else {
                DataLumi[j] = 1.0;
            }
            SumLumiData = SumLumiData+DataLumi[j];// integrated luminosity of quasi-real data
            DataWeight[j] = MocaWeight[j];
        }
        /*for(Int_t i = 0; i<2; ++i) {
   // find fit variable with finest binning to rescale MC to describe data
   if(NrBinsFitVar[i]<NrBinsFitVar[i+1]) indexFinestFitVar = i+1;
  }*/
    }
    else {
        for(Int_t j = 0; j<NrDataTypes; j++) {
            SumLumiData = SumLumiData+DataLumi[j];// integrated luminosity of real data
            DataWeight[j] = 1.0;
        }
    }
    if(NrBinsResultMaxUser < NrBinsResult) {
        NrBinsResultMaxUser = NrBinsResult;
    }
    // ------------------------------ printout of the parameters -------------------------------------
    if(testmode == 1) {
        if(getPrintflag() > 0){
            cout<<"+++ running in TEST mode +++"<<endl;
            if(fraction != 0.5) cout<<"fraction of events for pseudo data: "<<fraction<<endl;
        }
    }
    else if(pullmode == 1) {
        if(getPrintflag() > 0){
            cout<<"+++ running in PULL mode with "<<nrPulls<<" pseudo data sets +++"<<endl;
            if(fraction != 0.5) cout<<"fraction of events for pseudo data: "<<fraction<<endl;
        }
    }
    if(print > 1) {
        cout<<"\nreal data luminosity and source files for every data type"<<endl;
        cout<<"---------------------------------------------------------"<<endl;
        cout<<"number of data types:\t"<<NrDataTypes<<endl;
        for(Int_t i = 0; i<NrDataTypes; i++) {
            cout<<"rd luminosity:\t"<<DataLumi[i]<<endl;
            cout<<"rd source file:\t"<<SourceFileRD[i]<<endl;
            if(TreeRD) cout<<"rd source root tree:\t"<<SourceTreeRD[i]<<endl;
        }

        cout<<"\nmonte carlo luminosities, weights and source files for every MC type"<<endl;
        cout<<"--------------------------------------------------------------------"<<endl;
        cout<<"number of MC types:\t"<<NrMocaTypes<<endl;
        for(Int_t j = 0; j<NrMocaTypes; j++) {
            cout<<"MC luminosity:\t"<<MocaLumi[j]<<endl;
            cout<<"MC weight:\t"<<MocaWeight[j]<<" for this type"<<endl;
            cout<<"MC source file:\t"<<SourceFileMC[j]<<endl;
            if(TreeMC) cout<<"MC source root tree:\t"<<SourceTreeMC[j]<<endl;
        }
        if(SourceFileBG != "no_BG") {
            cout<<"\nbackground parameters"<<endl;
            cout<<"---------------------"<<endl;
            cout<<"background source file:\t"<<SourceFileBG<<endl;
        }
        cout<<"\nsetting for the unfolding"<<endl;
        cout<<"-------------------------"<<endl;
        if(TreeRD != 1 || TreeMC != 1)
            cout<<"wanted variable column index:\t"<<ColumnWantedVariable<<endl;
        if(TreeRD == 1 || TreeMC == 1) {
            cout<<"wanted variable branch name:\t"<<BranchWantedX<<endl;
        }
        if(logOptionX == 1) cout<<"^^^^^ logarithmic input"<<endl;
        cout<<"number of degrees of freedom:\t"<<NrDegreeOfFreedom<<endl;
        cout<<"number of knots:\t"<<NrKnots<<endl;
        if(NrBinsResult != 0) {
            cout<<"number of bins result:\t"<<NrBinsResult<<endl;
        }
        else cout<<"(initial) number of bins will be determined automatically"<<endl;
        cout<<"unfolding limits: \t"<<WantedXLowLimit<<",\t"<<WantedXHighLimit<<endl;
        cout<<"\nnumber of all measured observables:\t"<<NrAllMeasuredVariables<<endl;
        for(Int_t k = 0; k<NrAllMeasuredVariables; ++k)  {
            cout<<"\nobservable index: "<<k<<endl;
            if(TreeRD == 1 || TreeMC == 1) cout<<"observable branch name: "<<BranchMeasurVariable[k]<<endl;
            cout<<"number of bins (observable "<<k<<"): "<<NrBinsMeasuredVar[k]<<endl;
            if(logOption[k] == 1) cout<<"^^^^^ logarithmic input"<<endl;
        }
        cout<<"\nnumber of fit variables:\t"<<NrOfFitVariables<<endl;
        for(Int_t l = 0; l<NrOfFitVariables; ++l)  {
            cout<<"index of fit variable:\t"<<IndexFitVariable[l]<<"\tlimits:\t"<<FitVarLowLimit[l]<<",\t"<<FitVarHighLimit[l]<<endl;
        }
        cout<<endl;
        cout<<"\noptions for the final histogram"<<endl;
        cout<<"-------------------------------"<<endl;
        if(FXpositive == 1) cout<<"allow only positive values for f(x)"<<endl;
        if(SmoothX == 1) cout<<"smooth MC-f(x) histogram"<<endl;
        if(zeroLeft == 1) cout<<"f(x) = zero on the left side"<<endl;
        if(zeroRight == 1) cout<<"f(x) = zero on the right side"<<endl;
        if(NrConstraints > 0) {
            cout<<"number of constraints (x values and their user assigned f(x) values):\t"<<NrConstraints<<endl;
            for(Int_t l = 0; l<NrConstraints; l++) {
                cout<<"\tx = "<<Xconstraint[l]<<"\tf(x) = "<<FXconstraint[l]<<endl;
            }
        }
        if(LinWeight > 0) cout<<"linear weight:\t"<<LinWeight<<endl;
        if(NrBinsResult > 0) {
            if(LimitsOfBinsResult[0] != LimitsOfBinsResult[NrBinsResult]) {
                cout<<"\nbin limits for final histogram"<<endl;
                cout<<"------------------------------"<<endl;
                for(Int_t i = 0; i<=NrBinsResult; i++) {
                    cout<<"\t"<<LimitsOfBinsResult[i];
                }
                cout<<endl;
            }
        }
        if(mcFuncFlag == 1) cout<<"\nuser defined MC f(x) generated function =\t"<<mcFormula<<endl;
    }
    return 1;
}

void Input::SourceFilesInput(Int_t pullIndex) {


    //Rawdata->erase();

    ReadInFiles = new ReadIn(WantedXLowLimit, WantedXHighLimit, nameWantedX, nameObsY, NrAllMeasuredVariables, NrMocaTypes,this);
    TrueeCSVReader *csvreader = new TrueeCSVReader(NrAllMeasuredVariables,this);
    csvreader->setSeperator(csvseperator);
    Rawdata->erase();
    //Full_data.clear();

    //delete Rawdata;
    //Rawdata = new TrueeData();
    //TrueeReadIn *TrueeReadInFiles = new TrueeReadIn(WantedXLowLimit, WantedXHighLimit, nameWantedX, nameObsY, NrAllMeasuredVariables, NrMocaTypes,this);

    if(testmode == 0 && pullmode ==0) {


        for(Int_t n = 0; n<NrDataTypes; n++) {
            if(TreeRD)
                ReadInFiles->Read(SourceFileRD[n].c_str(), SourceTreeRD[n].c_str(), "DATA", BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, n);
            else
                csvreader->Read(SourceFileRD[n].c_str(), SourceTreeRD[n].c_str(), "DATA", BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, n);

        }
        for(Int_t p = 0; p<NrMocaTypes; p++) {
            if(TreeMC)
                ReadInFiles->Read(SourceFileMC[p].c_str(), SourceTreeMC[p].c_str(), "MOCA", BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, p);
            else
                csvreader->Read(SourceFileMC[p].c_str(), SourceTreeMC[p].c_str(), "MOCA", BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, p);

        }
        if(SourceFileBG != "no_BG") {
            if(TreeBG)
                ReadInFiles->Read(SourceFileBG.c_str(), SourceTreeBG.c_str(), "BKGD", BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, 0);
            else
                csvreader->Read(SourceFileBG.c_str(), SourceTreeBG.c_str(), "BKGD", BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, 0);
        }
    }
    else {
        TRandom3 *searchEventFraction = new TRandom3();
        if(randomseed == 0)	searchEventFraction->SetSeed(1000);
        else if(randomseed == 1) searchEventFraction->SetSeed();


        // in test mode read MC simulated events only
        if(read_files == false) {
            for(Int_t p = 0; p<NrMocaTypes; p++) {
                if(!TreeMC){
                    csvreader->ReadTest(SourceFileMC[p].c_str(), SourceTreeMC[p].c_str(), "MOCA", BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, p,"USUAL");// background not tested for pullmode
                    csvreader->ReadTest(SourceFileBG.c_str(), SourceTreeBG.c_str(), "BKGD", BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, 0,"USUAL");
                }
                else
                    ReadInFiles->ReadTest(SourceFileMC[p].c_str(), SourceFileBG.c_str(), SourceTreeMC[p].c_str(), SourceTreeBG.c_str(), BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, fraction, searchEventFraction, p, outputpath,"USUAL");// background not tested for pullmode
                read_files = true;
                this->GetData()->MonteCarlo_Data.reserve(this->Full_data.size());
                this->GetData()->Real_Data.reserve(this->Full_data.size());

            }

            if(Use_different_MC == true){
                for(Int_t n = 0; n<NrDataTypes; n++) {
                    if(!TreeMC)
                        csvreader->ReadTest(SourceFileRD[n].c_str(), SourceTreeRD[n].c_str(), "DATA", BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, n,"DIFFMC");

                    else
                        ReadInFiles->ReadTest(SourceFileRD[n].c_str(), SourceFileBG.c_str(), SourceTreeRD[n].c_str(), SourceTreeBG.c_str(), BranchWantedX.c_str(), BranchMeasurVariable, branchEventWeight, logOption, logOptionX, fraction, searchEventFraction, n, outputpath,"DIFFMC");// background not tested for pullmode
                }
            }
        }


        ReadInFiles->Pull(fraction, searchEventFraction, Use_different_MC);
        //else cerr << "ASCII is temporally not supported"<<endl;


        searchEventFraction->Delete();
    }

    BackEventNr = ReadInFiles->GetBackEventNr();
    DataEventNr = ReadInFiles->GetDataEventNr();
    MocaEventNr = ReadInFiles->GetMocaEventNr();
    delete ReadInFiles;
}

// create histograms to reweight the MC pseudo data to RD
/////////////////////////////////////////////
/*	for(Int_t n = 0; n<NrDataTypes; n++) {
   //if(!TreeRD) ReadInFiles->MakeObsHistogram(SourceFileRD[n].c_str(),)
   if(TreeRD) ReadInFiles->MakeObsHistogram("DATA", 1,  SourceFileRD[n].c_str(), SourceTreeRD[n].c_str(), BranchMeasurVariable[IndexFitVariable[indexFinestFitVar]], branchEventWeight, logOption[IndexFitVariable[indexFinestFitVar]], n);
  }
  for(Int_t n = 0; n<NrMocaTypes; n++) {
   //if(!TreeMC) ReadInFiles->MakeObsHistogram(SourceFileMC[n].c_str(),)
   if(TreeMC) ReadInFiles->MakeObsHistogram("MOCA", fraction,  SourceFileMC[n].c_str(), SourceTreeMC[n].c_str(), BranchMeasurVariable[IndexFitVariable[indexFinestFitVar]], branchEventWeight, logOption[IndexFitVariable[indexFinestFitVar]], n);
  }
  if(SourceFileBG != "no_BG") {
   //if(!TreeBG) ReadInFiles->MakeObsHistogram(SourceFileBG.c_str(),)
   if(TreeBG) ReadInFiles->MakeObsHistogram("BKGD", 1, SourceFileBG.c_str(), SourceTreeBG.c_str(), BranchMeasurVariable[IndexFitVariable[indexFinestFitVar]], branchEventWeight, logOption[IndexFitVariable[indexFinestFitVar]], 0);
  }*/
/////////////////////////////////////////////





