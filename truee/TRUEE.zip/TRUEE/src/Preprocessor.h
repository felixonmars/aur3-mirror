//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

#ifndef Preprocessor_h
#define Preprocessor_h

#include "TH1.h"
#include "TH2.h"
#include "AverageOfFunction.h"
#include "BSplineCoefficient.h"
#include "FxFunctionMC.h"
#include "SmoothSplineFit.h"
#include "Functions.h"
#include "TFile.h"
#include "TCanvas.h"
#include "TBranch.h"
#include "Input.h"
//#include "trueedata.h"

class TrueeData;

class Preprocessor
{

public:

        Preprocessor();
        virtual ~Preprocessor();
        Preprocessor(Input *InputObject);

        //void CheckXYCorrelation(const std::string &name);
	void ReadWrite(const std::string &name);
	void StatisticAndEfficiency();
	void DetermineLimits();
	void FitMCHistogram();
	void Normalization(FxFunctionMC *MCFunctionFx);
	void RoundLimits(Double_t &leftLimit, Double_t &rightLimit);

	Double_t getBackWeight() { return BackWeight;}
	Double_t getCoeff(Int_t SplineIndex) { return Coeff[SplineIndex];}
	Double_t GetErrorFxMC(Int_t BinIndex) { return ErrorFxMC[BinIndex]; }
	Double_t GetFittedValueFxMC(Int_t BinIndex) { return FittedValueFxMC[BinIndex]; }
	Double_t getFitVarHighLimit(Int_t index) { return FitVarHighLimit[index]; }
	Double_t getFitVarLowLimit(Int_t index) { return FitVarLowLimit[index]; }
	Double_t getGamma() {return Gamma;}
	Double_t GetLuminosityFactor()  {  return LuminosityFactor;  }
	Double_t getMaxValueRound(Int_t variableIndex) { return MaxValueRound[variableIndex]; }
	Double_t getMinValueRound(Int_t variableIndex) { return MinValueRound[variableIndex];}
	Double_t getMaxValueXRound() { return MaxValueXRound;}
	Double_t getMinValueXRound() { return MinValueXRound;}

	Double_t getSumLumiData() { return SumLumiData; }
	Double_t GetValueFxMC(Int_t BinIndex) { return ValueFxMC[BinIndex]; }

	Int_t getJXflag() { return JXflag;}
	Int_t getJYflag(Int_t index) { return JYflag[index];}
	Int_t GetNrBinsMC() { return NrBinsMC; }

	Functions *getSplineCalc() { return SplineCalc;}
        Input* GetInput() {return InputObject;}
private:
        int print;
	Bool_t SmoothX;
	Double_t aspmc[63];
	Double_t BackWeight;
	Double_t Coeff[240];
	Double_t DataLumi[32];
	Double_t DataWeight[32];
	Double_t Div;
	Double_t ErrorFxMC[240];//TODO TClonesArray TObjArray
	Double_t FittedValueFxMC[240];
	Double_t FitVarHighLimit[5];
	Double_t FitVarLowLimit[5];
	Double_t Gamma;
	Double_t LuminosityFactor;
	Double_t MaxValue[32];
	Double_t MaxValueRound[32];
	Double_t MaxValueX;
	Double_t MaxValueXRound;
	Double_t MinValue[32];
	Double_t MinValueRound[32];
	Double_t MinValueX;
	Double_t MinValueXRound;
	Double_t MocaLumi[32];
	Double_t MocaWeight[32];

	Double_t SumAbsWeightBack;
	Double_t SumAbsWeightData[32];
	Double_t SumAbsWeightMoca[32];
	Double_t SumLumiData;
	Double_t SumLumiMoca;
	Double_t SumPosWeightBack;
	Double_t SumPosWeightData[32];
	Double_t SumPosWeightMoca[32];
	Double_t SumPosWeight2Back;
	Double_t SumPosWeight2Data[32];
	Double_t SumPosWeight2Moca[32];
	Double_t ValueFxMC[240];
	Double_t WantedX;
	Double_t WantedXHighLimit;
	Double_t WantedXLowLimit;
	Double_t XMCLumi;
	Double_t y[32];
	Double_t BackEventNr;
    Double_t DataEventNr;
    Double_t MocaEventNr;
	Int_t IndexFitVariable[5];

	Int_t JXflag;
	Int_t JYflag[32];
	Int_t NrEntries;
	Int_t NrKnots;
	Int_t NrKnotsMax;
	Int_t NrDataTypes;
	Int_t NrMocaTypes;
	Int_t NrAllMeasuredVariables;
	Int_t NrBinsMC;
	Int_t NrBinsMCMax;
	Int_t NrBinsResult;
	Int_t NrOfFitVariables;
	Int_t NTupleIndex;

        Input *InputObject;
	Functions *SplineCalc;

	TString nameWantedX;
	TString nameObsY[32];

        std::vector<TrueeEvent* > aux;

};


#endif //rpass1_h
