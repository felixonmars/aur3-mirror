//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

#ifndef Processor_h
#define Processor_h

#include "TFile.h"
#include "TTree.h"
#include "Input.h"
#include "Preprocessor.h"
#include "Functions.h"
#include "UnfoldingFit.h"
#include "FxFunctionMC.h"
#include "TH1D.h"
#include "TH2D.h"
#include "TH3D.h"
#include "TCanvas.h"
#include "TExec.h"

#include "trueeevent.h"

class Processor {

public:

    Processor();
    Processor(Input *InputObject, Preprocessor *Pass1Object, FxFunctionMC *mcFunctionFx);
    virtual ~Processor();


    /**
     *  prepare weights for monte carlo
     *  &
     *  determine total number of bins => ProdNrBins (=NPROD)
     */
    void PrepareWeights(Bool_t funcFlag);


    void ClearHistogramSpace(Int_t loop);
    //	void CreateHistogram(const std::string &name);
    void FillHistogram(const std::string &name, Int_t loop);
    void SetCompactIndex();
    void RegUnfolding(Input *InputObject);
    void Comparisons(TString mode, Input *InputObject);
    void Scale(Int_t NrBins, Double_t *binLimit, Double_t *binContent);
    void ResetHistogram();
    void CheckUnfolding(const std::string &name);
    void PrintHistogram(Input *inputObject);


    Double_t getChi2pValue50() { return Chi2pValue50;}
    Double_t getChi2TestModeCompare() { return Chi2TestModeCompare;}
    Double_t getKolmogorovValue() {return KolmogorovValue;}
    Double_t getWeightEntryMC(Int_t index) { return WeightEntryMC[index];}

    Double_t get_BinContentResult(int i){ return BinContentResult[i];}
    Double_t get_BinErrorResult(int i){ return BinErrorResult[i];}
    Double_t get_RealContent(int i){return realContent[i];}

    Double_t GetBinCenter(int i ){return bincenter[i];}
    Double_t Getnondiff_Result(int i ){return nondiff_Result[i];}
    Double_t Getnondiff_Error (int i ){return nondiff_Error[i];}
    Double_t Getnondiff_MCtrutht(int i ){return nondiff_MCtruth[i];}

    Double_t GetRegularizationTerm(){return RegularizationTerm;}
    Double_t GetFitMin(){return fitMin;}

    Int_t GetNrBinsResult() { return NrBinsResult;}
private:
    int print;
    Double_t BackWeight;
    Double_t BinContentResult[240];
    Double_t BinErrorResult[240];
    Double_t Chi2pValue50;
    Double_t Chi2TestModeCompare;
    Double_t Coefficient[63];
    Double_t CovarMatrixResult[(63*63+63)/2];
    Double_t DataLumi[32];
    Double_t ErrorFxMC[240];
    Double_t fitMin;
    Double_t FittedValueFxMC[240];
    Double_t FitVarHighLimit[5];
    Double_t FitVarLowLimit[5];
    Double_t H[500000];// bin content of the n-dimensional histogram
    Double_t HistBack[120][32];
    Double_t HistData[120][32];
    Double_t HistMoca[120][32];
    Double_t LimitsOfBinsResult[241];
    Double_t LuminosityFactor;
    Double_t MaxValueRound[32];
    Double_t MinValueRound[32];
    Double_t MaxValueXRound;
    Double_t MinValueXRound;
    Double_t MocaLumi[32];
    Double_t MocaWeight[32];
    Double_t relError;
    Double_t errorSum[2];
    Double_t relErrorSum[2];
    Double_t spline[4];
    Double_t SumLumiData;
    Double_t ValueFxMC[240];
    Double_t WantedXHighLimit;
    Double_t WantedXLowLimit;
    Double_t WeightEntryMC[240];
    Double_t X;
    //Double_t XW[527];
    Double_t KolmogorovValue;
    Double_t XHistoValuesMC[240];// HUP = XHistoValuesMC
    Double_t y[32];
    Double_t realContent[240];

    Double_t nondiff_Result[240];
    Double_t nondiff_Error[240];
    Double_t nondiff_MCtruth[240];
    Double_t bincenter[240];

    Double_t RegularizationTerm;


    Float_t NrKnotsResult;

    //	Int_t specialEventIndex;
    //	Int_t specialBin;
    Int_t IndexFitVariable[5];
    Int_t JNULL;
    Int_t JXflag;
    Int_t JYflag[32];
    Int_t LinEventIndex;// LinEventIndex = IN

    Int_t nonZeroIndex[50000];
    Int_t NrBinsResult;
    Int_t NrBinsMC;
    Int_t NrDataTypes;
    Int_t NrMocaTypes;
    Int_t NrKnots;
    Int_t NrKnotsMax;
    Int_t NrNonZeroBins;
    Int_t NrOfFitVariables;
    Int_t NrBinsFitVar[5];
    Int_t NrAllMeasuredVariables;
    Int_t NTupleIndex;
    Int_t ProdNrBins;
    Bool_t pullmode;


    Functions *SplineCalc;
    Preprocessor *pass1Object;
    FxFunctionMC *MCFunctionFx;
    TH2D *h2dimRDmit0;
    TH2D *h2dimMCmit0;
    TCanvas *c2dimRDmit0;
    TCanvas *c2dimMCmit0;

    TString nameWantedX;
    TString nameObsY[32];

    std::vector<TrueeEvent* > aux;
};

#endif //rpass2_h
