//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef FitPolynomial_h
#define FitPolynomial_h

#include "Rtypes.h"

class FitPolynomial {

public:

	FitPolynomial();
	virtual ~FitPolynomial();
	void FitOfOrthPolyn(Double_t *Y,Double_t *Z, Double_t *W, Int_t N, Double_t *c);

	// ClassDef(FitPolynomial,1)

};

#endif //FitPolynomial_h
