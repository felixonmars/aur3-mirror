//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

#ifndef SmoothingOperation_h
#define SmoothingOperation_h

#include "Rtypes.h"

class SmoothingOperation {
public:

	SmoothingOperation();
	virtual ~SmoothingOperation();



	void SetZeroValue(Double_t *Z, Int_t N=0);
	void SetMedian3E(Double_t *Z, Int_t N=0);
	void smooth(Double_t *Z, Int_t N=0);
	void SetMedian5(Double_t *Z, Int_t N=0);
	void SetMedian3C(Double_t *Z, Int_t N=0);
	void CorrFlatAreas(Double_t *Z, Int_t N=0);
	void SetAverage3(Double_t *Z, Int_t N=0);
	Double_t SumUp(Double_t *Z, Int_t N=0);
	void GetAbs(Double_t *Z, Int_t N=0);
	void FourthDerivative(Double_t *Z, Int_t N=0);

// ClassDef(SmoothingOperation,1)
private:
	Double_t ZL;
	Double_t ZN;
	Double_t ZM;
	Double_t ZE;

	};

#endif //SmoothingOperation_h
