//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================


#include "Minimize.h"
#include "math.h"
#include "TMath.h"
#include <iostream>

Minimize::Minimize() {
	casy=0.05;
	Tau=0.618033886;
	for(Int_t i=0; i<11; ++i) {
		X[i]=0.0;
		Y[i]=0.0;
	}
	SplineCoeff = new SplineFunction();
}

Minimize::~Minimize() {
	delete SplineCoeff;
}
using namespace std;
void Minimize::Initialize(Double_t xlim1, Double_t xlim2, Int_t Flag) {
	// MINSTI (original)
	// initialize limits and print flag
	StepLimitXneg=-fabs(xlim1);
	StepLimitXpos=fabs(xlim2);
	if(StepLimitXpos==0.0 && StepLimitXneg==0.0) {
		StepLimitXpos=5.0;
		StepLimitXneg=-5.0;
	}
	PrintFlag=Flag;
	NrEvaluations=0;
}

void Minimize::SearchMinimum(Double_t F, Double_t &dxa, Int_t &NC) {
	// MINST (original)
	// Minimizer for onedimensional functions.
	// Searches for the minimum of F(x).
	// The function is evaluated up to 11 times
	// Increasing or decreasing steps are taken, until a function value lower than fun(XSTART) is found.
	// Then the minimum is searched for near the minimum of a function, interpolating all previous function values.
	// The following convergence criteria are used:

	// 1) the  slope of the  interpolating function is reduced to 1/100 of the slope at X START;
	// 2) the relative function variation of the last 3 function evaluations if about 1.0E-6.

	// Application for n-dimensional minimization: MINST may be used to
	// find the minimum along the direction of the Newton step.
	// In  this case X (and XSTART) and ST are  n-dimensional  vectors,  while  DX (and SDX) remains a scalar.
	// For  a  Newton  step  ST  the  minimum should be near XSTART+ST...

        Double_t epsMax=pow(10., -6.);// = EPSMA
	Double_t slpMin=0.01;

	NC=-1;

	//  initialization for NrEvaluations = 0
	if(NrEvaluations == 0) {
		currentXValue = 0.0;
		IC = 0;
	}

	// insert new function value at correct place (ins)
	Int_t ins=1;
	Int_t two=2;

	for(ins=1; ins<=NrEvaluations; ++ins) {
		if(currentXValue < X[ins-1]) {
			for(Int_t j=NrEvaluations-1; j>=ins-1; --j) {
				X[j+1]=X[j];
				Y[j+1]=Y[j];
			}
			two=1;
			break;
		}
	}
	if(two == 2) ins=NrEvaluations+1;
	NrEvaluations=NrEvaluations+1;

	// currentXValue is current internal x-value
	X[ins-1]=currentXValue;
	Y[ins-1]=F;

	// find smallest function value
	Int_t one=1;
	while(one<2) {
		one=2;
		imin=1;
		ibeg=1;
		for(Int_t i=1; i<NrEvaluations; ++i) {
			if(X[i]==0.0) ibeg=i+1;
			if(Y[i]<Y[imin-1]) imin=i+1;
			if(X[i]-X[i-1]<0.00001) {
				// remove double entry
				for(Int_t k=i+1; k<NrEvaluations; ++k) {
					X[k-1]=X[k];
					Y[k-1]=Y[k];
				}
				NrEvaluations=NrEvaluations-1;
				one=1;
				break;
			}
		}
	}
	// check roundoff error region for last three points
	if(NrEvaluations >= 3) {
		FQ=(F+FP+FPP)/3.0;
		RF=sqrt(0.5*(pow((F-FQ),2)+pow((FP-FQ),2)+pow((FPP-FQ),2)))/(fabs(FQ)+1.0);
		AF=(fabs(F)+fabs(FP)+fabs(FPP))/3.0;
		if(AF != 0.0) {
			AF=sqrt(0.5*(pow((F-FQ),2)+pow((FP-FQ),2)+pow((FPP-FQ),2)))/AF;
		}
		// test following statement
		RF=AF;
		if(RF <= epsMax) {
			NC=0;
			if(PrintFlag!=0) {
				SplineCoeff->CoefficientFromXY(X, Y, C, NrEvaluations);
			}
			DX=X[imin-1]-currentXValue;
			F=Y[imin-1];
			// estimate second derivative
			sum1=0.0;
			sum2=0.0;
			for(Int_t l=0; l<NrEvaluations; ++l) {
				CC=pow(C[4][l]-C[4][imin-1], 2);
				sum1=sum1+CC*(C[0][0]-C[0][imin-1]);
				sum2=sum2+CC*CC;
			}
			SecondDerivative=0.0;
			if(sum2!=0.0) SecondDerivative=2.0*sum1/sum2;
			// set common values
			FunctionChange=C[0][ibeg-1]-C[0][imin-1];
			TotalStep=C[4][imin-1];

			dxa=DX;
			return;
		}
	}

	// save last DX
	DXlast=DX;

	// currentXValue is current value, determine now nextXValue = next value
	if(NrEvaluations == 1) {
		// second point (first point was at zero)
		nextXValue=TMath::Min(Tau, StepLimitXpos);
		if(nextXValue == 0.0) nextXValue=TMath::Max(-Tau, StepLimitXneg);
	}
	else if(NrEvaluations == 2) {
		// third point
		if(imin == ins) {
			// success - search in same direction with increased step
			DX=DXlast/Tau;
			if(DX > 0.0) {
				//... but to center if at limit
				if(currentXValue == StepLimitXpos) DX=-DX/Tau;
			}
			else {
				if(currentXValue == StepLimitXneg) DX=-DX/Tau;
			}
			nextXValue=currentXValue+DX;
		}
		else {
			// failure - search in opposite direction
			if(DX > 0.0) {
				nextXValue=-1.0;
				if(StepLimitXneg == 0.0) nextXValue=0.5*currentXValue;
			}
			else {
				if(currentXValue == StepLimitXneg) {
					nextXValue=0.5*currentXValue;
				}
			}
		}
	}
	else if(imin == NrEvaluations) {
		// monotonically decreasing function in positive direction
		if(X[NrEvaluations-1] != StepLimitXpos) {
			// ... not at upper limit
			DX=(X[NrEvaluations-1]-X[NrEvaluations-2])/Tau;
			nextXValue=TMath::Min(X[NrEvaluations-1]+DX, StepLimitXpos);
		}
		else {
			// ... at upper limit - backward
			DX=(X[NrEvaluations-2]-X[NrEvaluations-1])*pow(Tau, 3);
			nextXValue=X[NrEvaluations-1]+DX;
		}
	}
	else if(imin == 1) {
		// monotonically decreasing function in negative direction
		if(X[0] != StepLimitXneg) {
			// ... not at lower limit
			DX=(X[0]-X[1])/Tau;
			nextXValue=TMath::Max(X[0]+DX, StepLimitXneg);
		}
		else {
			// ... at lower limit
			DX=(X[1]-X[0])*pow(Tau, 3);
			nextXValue=X[0]+DX;
		}
	}
	else {
		// inner minimum
		SplineCoeff->CoefficientFromXY(X, Y, C, NrEvaluations);
		// slope ratio
		SlopeRatio=fabs(C[1][imin-1]/C[1][ibeg-1]);
		if(SlopeRatio > slpMin) IC=0;
		if(IC == 1) {
			NC=0;
			if(PrintFlag!=0) {
				SplineCoeff->CoefficientFromXY(X, Y, C, NrEvaluations);
			}

			DX=X[imin-1]-currentXValue;
			F=Y[imin-1];
			// estimate second derivative
			sum1=0.0;
			sum2=0.0;
			for(Int_t l=0; l<NrEvaluations; ++l) {
				CC=pow(C[4][l]-C[4][imin-1], 2);
				sum1=sum1+CC*(C[0][0]-C[0][imin-1]);
				sum2=sum2+CC*CC;
			}
			SecondDerivative=0.0;
			if(sum2!=0.0) SecondDerivative=2.0*sum1/sum2;
			// set common values
			FunctionChange=C[0][ibeg-1]-C[0][imin-1];
			TotalStep=C[4][imin-1];
			dxa=DX;
			return;
		}

		// goldSectionXValue = approximate golden section value as alternative
		if((X[imin]-X[imin-1]) > (X[imin-1]-X[imin-2])) {
			goldSectionXValue=X[imin-1]+(Tau-Tau*Tau)*(X[imin]-X[imin-2]);
		}
		else {
			goldSectionXValue=X[imin-1]+(Tau-Tau*Tau)*(X[imin-2]-X[imin]);
		}

		// nextXValue = minimum of interpolating function
		Int_t J=imin-1;
		if(C[1][J] > 0.0) J=J-1;
		Dis=pow(C[2][J],2)-3.0*C[1][J]*C[3][J];
		Xdis=sqrt(Dis)+fabs(C[2][J]);
		H=-C[1][J]/TMath::Sign(Xdis,C[2][J]);
		nextXValue=C[4][J]+H;
		if(SlopeRatio < (0.5*slpMin) && NrEvaluations >= 4) {
			// flag for final step
			IC=1;
		}
		else {
			// add bias to step, to obtain good spacing
			BiasX=C[4][J+1]-C[4][J];
			nextXValue=nextXValue-0.25*BiasX*pow((H/BiasX-0.5),3);
		}
		// step to nextXValue
		DX=nextXValue-currentXValue;
		if(DX == 0.0) {
			NC=0;
			if(PrintFlag!=0) {
				SplineCoeff->CoefficientFromXY(X, Y, C, NrEvaluations);
			}
			DX=X[imin-1]-currentXValue;
			F=Y[imin-1];
			// estimate second derivative
			sum1=0.0;
			sum2=0.0;
			for(Int_t l=0; l<NrEvaluations; ++l) {
				CC=pow(C[4][l]-C[4][imin-1], 2);
				sum1=sum1+CC*(C[0][0]-C[0][imin-1]);
				sum2=sum2+CC*CC;
			}
			SecondDerivative=0.0;
			if(sum2!=0.0) SecondDerivative=2.0*sum1/sum2;
			// set common values
			FunctionChange=C[0][ibeg-1]-C[0][imin-1];
			TotalStep=C[4][imin-1];
			dxa=DX;
			return;
		}

		// calculate asymmetry of new point nextXValue
		if(nextXValue > X[imin-1]) {
			asym=TMath::Min(C[4][imin]-nextXValue, nextXValue-C[4][imin-1])/(C[4][imin]-C[4][imin-1]);
			asyl=TMath::Min(nextXValue-C[4][imin-1], C[4][imin-1]-C[4][imin-2])/(nextXValue-C[4][imin-2]);
		}
		else {
			asym=TMath::Min(C[4][imin-1]-nextXValue, nextXValue-C[4][imin-2])/(C[4][imin-1]-C[4][imin-2]);
			asyl=TMath::Min(C[4][imin]-C[4][imin-1], C[4][imin-1]-nextXValue)/(C[4][imin]-nextXValue);
		}
		if(IC == 0 && TMath::Min(asym, asyl) < casy) {
			// minimum point replaced by golden section point
			nextXValue=goldSectionXValue;
		}
	}
	// next function evaluation
	DX=nextXValue-currentXValue;
	if(NrEvaluations >= 11) {
		NC=1;
		if(PrintFlag != 0) {
			SplineCoeff->CoefficientFromXY(X, Y, C, NrEvaluations);
		}
		DX=X[imin-1]-currentXValue;
		F=Y[imin-1];
		// estimate second derivative
		sum1=0.0;
		sum2=0.0;
		for(Int_t l=0; l<NrEvaluations; ++l) {
			CC=pow(C[4][l]-C[4][imin-1], 2);
			sum1=sum1+CC*(C[0][0]-C[0][imin-1]);
			sum2=sum2+CC*CC;
		}
		SecondDerivative=0.0;
		if(sum2!=0.0) SecondDerivative=2.0*sum1/sum2;
		// set common values
		FunctionChange=C[0][ibeg-1]-C[0][imin-1];
		TotalStep=C[4][imin-1];
		dxa=DX;
		return;
	}
	// save last point
	lastXValue=currentXValue;
	// check limits and define next point currentXValue ...
	if(DX != 0.0) {
		currentXValue=TMath::Min(currentXValue+DX, StepLimitXpos);
	}
	else {
		currentXValue=TMath::Max(currentXValue+DX, StepLimitXneg);
	}
	// ... and step to currentXValue
	DX=currentXValue-lastXValue;
	FPP=FP;
	FP=F;
	dxa=DX;
}
