//	author: Martin Schmitz <martin.schmitz@uni-dortmund.de>
//	Dortmund, 2012
//	======================================================


#ifndef REALITY_H
#define REALITY_H

#include "Input.h"
#include "Preprocessor.h"
#include "Processor.h"
#include "TString.h"
#include "TStyle.h"
#include "math.h"
#include "TF1.h"
#include "TRandom3.h"
#include "TROOT.h"
#include "TStyle.h"
#include "TLegend.h"///////
#include "trueeresult.h"
#include "fstream"
using namespace std;


class Frontend{

    public:
    /**
     * @brief  Main constructor. Use it when you want to use the frontend. The filename is the path to your parameter.config. E.g. /home/truee/parameter.config
     */

        Frontend(string filename);

        /**
         * @brief  Runs the testmode.
         *
         *  The testmode is runnig like this:
         * \code
         *  for(bins)
         *      for(knots)
         *          for(ndf)
         *              Resultvector.push_back(unfold(...))
         * \endcode
         *
         */

        vector<TrueeResult*> testmode();

        /**
         * @brief Runs the pullmode. ReadIn needs to be called first!
         *
         * The testmode is runnig like this:
         * \code
         *  for(bins)
         *      for(knots)
         *          for(ndf)
         *              for(pulls)
         *                  pullvector.pushback(unfold(...))
         *          resultvector.push_back(pullvector)
         * \endcode
         *  In every step of the pull loop it adds one object to the inner vector. in the ndf loop it adds the whole vector of pullresults to the resultvector you will recive. \n
         *  So you can use the vector like this:
         *  \code
         *   resultvector.at(ndf/knots/bins-settingnumber).at(pullnumber)
         * \endcode
         */


        vector< vector<TrueeResult*> > pullmode();

        /**
         * @brief "Cuts" away uneccesarry plots with DPC/Kolmogorov/Chi-square values higher/lower than specified by user
         *
         *  The values can be specified in the conifg file using
         *
         *  result_suppression_DPC: NUMBER
         *
         *  result_suppression_Kolmogorov: NUMBER
         *
         *  result_suppression_chi2: NUMBER
        */

         vector<TrueeResult*> result_suppression(vector<TrueeResult*> TestResults);

        /**
         * @brief plots most of necessary testmode plots
         *
         * This includes:
         *
         *  - L-Curve
         *
         *  - Binwise L-Curve
         *
         *  - Kolmogorovplot for different settings ("patchwork plot" )
         *
         *  - DPCplot for different settings ("patchwork plot" )
         *
         *  - Chisquareplot for different settings ("patchwork plot" )
         *
         *  It does not include the TestModeResult Plots know (those are made in Processor)
        */

        void plot_testmode(vector<TrueeResult*> ResultVector);

        /**
         * @brief plots most of necessary pullmode plots
         *
         * This includes:
         *
         *  - Pull distributions (and there projections)
         *
         *  - Distribution of Kolmogorov for one Setting
         *
         *  - Distribution of DPC for one Setting
         *
         *  - Distribution of chisquare for one Setting
         *
         *  - Distribution of Pullmean and Pullrms
         *
         * It plots the quality plots using plot_pull_qualityplots
         *
         */



        void plot_pullmode(vector<vector<TrueeResult *> > Pullmode_Result);

        void plot_datamode(vector<TrueeResult*> ResultVector);

        Input* get_Input(){return InputObject; }
        void set_Pullmode(bool newPullmode){Pullmode = newPullmode;}
        int GetPathCheck()  {return pathcheck;}

    private:

        /**
         * @brief Simple unfolding for one fixed set of parameters - should not be used by a user!
         *
         *
         */

        TrueeResult* unfold(int bins, int ndf, int knots);


        /**
         *  @brief Reads the parameter.config in filename and sets the important values
         *
         *  This one is called, when Frontend(string ..) is used as well. Be sure that u have called this routine before everything else (either by hand or by using the correct constructor)
         */

        int ReadIn(string filename);


        /*
          * prints the results of pullmode to stdout - should not be used by a user!
          */
        void print_pullmode(vector<TH1D*>*  hPulldist_procjection_for_one_setting);

        /*
          * adds the results for each setting to quality plots - should not be used by a user!
          */

        void plot_pull_qualityplots(vector<TH1D*>*  hPulldist_procjection_for_one_setting);

        void Plot_MCInformation(string type, TString var1,int num1);

        void Plot_XYCorrelation_Observables(string type, TString var1, TString var2,int num1,int num2);

        void Plot_Covariance();


        /*
          *
          */

        vector<vector<TrueeResult *> >*  Current_Pullresult;
        vector<TrueeResult *>*  Current_Pullresult_setting;

        /*
         *  Unfolding Settings
         */
        Bool_t Pullmode;
        TString formula;
        Double_t binMin;
        Double_t binMax;

        Int_t NrBinsResult;
        Int_t NrBinsResultMaxUser;
        Int_t nr2DHistos;
        Int_t NrKnots;// initial value
        Int_t NrKnotsMaxUser;
        Int_t NrDegreeOfFreedom;// initial value
        Int_t NrDegreeOfFreedomMaxUser;
        Int_t NrDegreeOfFreedomStart;
        Double_t BackEventNr;
        Int_t NrBinsMCMax;
        Int_t NrBinsMC;
        Int_t nrBinsMin;
        Int_t NrKnotsStart;

        Int_t nrPulls;
        Bool_t  funcFlag;
        bool printflag;
        int pathcheck;

        int pullIndex;

            /*
             *  Testmode histogramms
             */

        vector<TH2D *> hDataPointCorr;
        vector<TH2D *> hKolmogorovTest;
        vector<TH2D *> hTestCompareChi2;
        vector<TH2D *> hTestCompareDPC;
        vector<TH2D *> hTestCompareLCurve;
        TH2D *hLCurve;
        TH2D *hLCurveTestMode;

            /*
            *  Pullmode histogramms
            */

        TH1D* kolmogorov_dist;
        TH1D* chisquare_dist;
        TH1D* DPC_dist;
        TH1D* Pullmean_dist;
        TH1D* PullRMS_dist;
        TH2D* temp;

        vector<TH2D*> Pull_quality_chi;
        vector<TH2D*> Pull_quality_DPC;
        vector<TH2D*> Pull_quality_kolmo;
        vector<TH2D*> Pull_quality_means;
        vector<TH2D*> Pull_quality_rms;

        vector<TCanvas*> Pull_overview;
        vector<TCanvas*> tu_overview;

            /*
             *  Used Files
             */

        TFile *fUserFunction;
        TFile *CovarianceFile;
        TFile *fCheckParameters;
        TFile *fCompare;
        TFile *fPull;
        TFile *fCorrelationFile;

        TFile *fResultFile;
        ofstream infoLCurve;

            /*
             *  Other Stuff
             */

        Input *InputObject;
        TString pathSteerFile;      // path to parameter.config

        TF1 *func;
        TF1 *userFunction;

        Preprocessor* Pass1Object;


            /*
            *  flags
            */

        bool corrflag;          // flag if TRUEE should print x/y-corr.

            /*
            *  Strings we need
            */

        TString cTestModeKolmog;
        TString cTestModeChi2;
        TString cDataPointCorr;
        TString cTestModeLCurve;
        TString pullName;

            /*
             *  Some things i dont really know...
            */
        Double_t MinUnfFit;

        Int_t ii;
        Int_t jj;
        Int_t ll;






};

#endif // REALITY_H
