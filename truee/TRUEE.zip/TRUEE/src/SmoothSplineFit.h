//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

#ifndef SmoothSplineFit_h
#define SmoothSplineFit_h

#include "SearchFitPeaks.h"
#include "BandMatrix.h"
#include "FitPolynomial.h"
#include "SmoothingOperation.h"
#include "Rtypes.h"

class SmoothSplineFit {
public:

	SmoothSplineFit();
	virtual ~SmoothSplineFit();

	void SmoothAndFit(Double_t *y, Int_t NrYValues);
	void Smooth(Double_t *Y, Int_t N, Double_t *Z);
	void SplineFit(Double_t *Y, Int_t N, Double_t *Z);
	void calculateBSpline4Function(Double_t X, Double_t *Bspline);

	// ClassDef(SmoothSplineFit,1)

private:
	Double_t A[100];
	Double_t B[4];
	Double_t der[100];
	Double_t IntegAbsValue4Deriv[256];// = FD
	Int_t  NrKnotsSplineFit;// = NKNOT
	Double_t KnotPosition[104];// = T(mknot)
	Int_t NrNonZeroY;
	Double_t SumNonZeroYValues;
	Double_t SumNonZeroZValues; // Z = transformed Y values
	//------------ intern peak parameter ------------
	Double_t PeakAbscissa;//TODO delete unused parameters
	Double_t PeakOrdinate;
	Double_t PeakBackgr;
	Double_t PeakIntegral;
	Double_t PeakSigma;
	Double_t PeakFWHM;// full width at half maximum
	Double_t LeftFWHMAbscissa;
	Double_t LeftFWHMOrdinate;
	Double_t Q[500];// matrix Q saved as 1 dim. array

	Double_t RightFWHMAbscissa;
	Double_t RightFWHMOrdinate;
	Double_t LeftBackgrAbscissa;
	Double_t LeftBackgrOrdinate;
	Double_t RightBackgrAbscissa;
	Double_t RightBackgrOrdinate;
	Double_t LeftBackgrBin;
	Double_t RightBackgrBin;


	Int_t I0;

	SearchFitPeaks *Peak;
	SmoothingOperation *SmoothObject;

	BandMatrix *Matrix;
	FitPolynomial *Fit;


};

#endif //SmoothSplineFit_h
