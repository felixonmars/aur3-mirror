//	author: Martin Schmitz <martin.schmitz@uni-dortmund.de>
//	Dortmund, 2012
//	==========

#ifndef TRUEERESULT_H
#define TRUEERESULT_H

#include<vector>
#include<iostream>

/*!
    *   \brief   Contains the result of a single iteration of TRUEE
    ￼     \details   Besides the actual numbers for the result and your mc all the quality parameters are saved in an instance of this class. This is used in the plotting routines and as a interface for the TRUEE user
    *   \author Martin Schmitz <martin.schmitz@uni-dortmund.de>
    *   \date April 2012
*/


class TrueeResult
{
public:
    TrueeResult();

    void add(std::vector<double> Result, std::vector<double> Result_error,std::vector<double> MC_truth, double dpc, double kolmo, double chi, int Bins, int Knots, int Ndf, double fitmin, double regterm);

        void print();                                                                       //!< Simple print function printing everything to the stdout - mainly for debugging reasons.

    //void plot();

    // Getter
    const double get_kolmogorov(){ return kolmogorov;}      //!< kolmogorov value of MC vs Data in testmode
    const double get_chisquare(){return chisquare;}             //!< chisquare value of MC vs Data in testmode
    const double get_DPC(){return DPC;}                             //!< DPC value for this unfolding

    const int get_ndf(){return ndf;}                                         //!< NDF setting of this iteration
    const int get_knots(){return knots;}                                  //!< Knots setting of this iteration
    const int get_bins(){return bins;}                                      //!< Number of bins in the output histogram for this iteration

    const double get_result(int i ) { return result.at(i); }
    const double get_error_of_result(int i){return error_of_result.at(i);}
    const double get_mc_truth(int i ){return mc_truth.at(i);}

    double GetFitMin(){return fitmin;}
    double GetRegTerm(){return RegTerm;}



    void set_ndiff_result( std::vector<double> newndiff_result){ ndiff_result = newndiff_result; }
    void set_ndiff_error_of_result(std::vector<double> newndiff_error_of_result){ndiff_error_of_result = newndiff_error_of_result; }

    void set_bincenter(std::vector<double> newbincenter){ bincenter = newbincenter;}
private:
    // results
    std::vector<double> result;                                                     /*!< (differential) Unfoldingresult */
    std::vector<double> error_of_result;
    std::vector<double> mc_truth;

    std::vector<double> ndiff_result;                                                     /*!< (nondifferential) Unfoldingresult */
    std::vector<double> ndiff_error_of_result;
    std::vector<double> ndiff_mc_truth;
    std::vector<double> bincenter;


    double kolmogorov;
    double chisquare;
    double DPC;
    double fitmin;
    double RegTerm;

    int bins;
    int knots;
    int ndf;

    bool testmode;

};

#endif // TRUEERESULT_H
