//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

// simple smoothing operations on histograms

#include <iostream>
#include "SmoothingOperation.h"
#include "TMath.h"
#include "math.h"

// ClassImp(SmoothingOperation)
using namespace std;


Double_t dian3(Double_t a, Double_t b, Double_t c) {
	// Median of values a, b, c
	Double_t abc[3];
	abc[0] = TMath::Min(a,b);
	abc[1] = TMath::Min(b,c);
	abc[2] = TMath::Min(c,a);
	return TMath::MaxElement(3,abc);
}

SmoothingOperation::SmoothingOperation(){
	ZL = 0;
	ZN = 0;
	ZM = 0;
	ZE = 0;
};
SmoothingOperation::~SmoothingOperation(){};

void SmoothingOperation::SetZeroValue(Double_t *Z, Int_t N) {
	// reset to zero
	for(Int_t i = 0; i<N; ++i) {
		Z[i] = 0;
	}
}

void SmoothingOperation::SetMedian3E(Double_t *Z, Int_t N) {
	if(N<4) {
		cout<<"\nN is less then 4"<<endl;
		return;
	}
	else {
		//(3) replace each value by median of 3 values
		ZL = Z[0];
		for(Int_t j = 0; j<(N-2); ++j) {
			ZN = dian3(Z[j],Z[j+1],Z[j+2]);
			Z[j] = ZL;
			ZL = ZN;
		}

		Z[N-2] = ZL;
		// extrapolation at end
		Z[0] = dian3(Z[0], Z[1], 3*Z[1]-2*Z[2]);
		Z[N-1] = dian3(Z[N-1], Z[N-2], 3*Z[N-2]-2*Z[N-3]);
	}
}

void SmoothingOperation::smooth(Double_t *Z, Int_t N) {
	if(N<4) {
		cout<<"\nN is less then 4"<<endl;
		return;
	}
	else {
		// (G) conditional hanning
		ZL = Z[0];// first and last values remain unchanged
		for(Int_t k = 0; k<(N-2); ++k) {
			if((Z[k+1]-Z[k])*(Z[k+1]-Z[k+2])<0) {
				// strictly increasing or decreasing
				ZN = Z[k+1];
			}
			else ZN = 0.25*(Z[k]+Z[k+1]+Z[k+1]+Z[k+2]); // smoothing by increasing or decreasing of Z[k+1]
			Z[k] = ZL;
			ZL = ZN;
		}
		Z[N-2] = ZL;
	}
}

void SmoothingOperation::SetMedian5(Double_t *Z, Int_t N) {
	if(N<4) {
		cout<<"\nN is less then 4"<<endl;
		return;
	}
	else {
		// (5) replace by median of 5
		Double_t ZI[N];
		Int_t minimum;
		Int_t maximum;
		ZL = Z[0];
		ZN = dian3(Z[0],Z[1],Z[2]);
		ZE = dian3(Z[N-3],Z[N-2],Z[N-1]);
		ZM = 0.0;
		for(Int_t l = 0; l<(N-4); ++l) {
			minimum = 0;
			if(Z[l]>Z[l+4]) minimum = 4;
			maximum = 4-minimum;// =4 or =0
			for(Int_t K = 1; K<=3; ++K) {
				if(Z[l+K]<Z[l+minimum]) {
					ZI[K-1] = Z[l+minimum];
					minimum = K;
				}
				else if(Z[l+K]<Z[l+maximum]) {
					ZI[K-1] = Z[l+K];
				}
				else {
					ZI[K-1] = Z[l+maximum];
					maximum = K;
				}
			}
			ZM = dian3(ZI[0], ZI[1], ZI[2]);
			Z[l] = ZL;
			ZL = ZN;
			ZN = ZM;
		}
		Z[N-4] = ZN;
		Z[N-3] = ZM;
		Z[N-2] = ZE;
	}
}

void SmoothingOperation::SetMedian3C(Double_t *Z, Int_t N) {
	if(N<4) {
		cout<<"\nN is less then 4"<<endl;
		return;
	}
	else {
		// (3C) replace each value by median of 3 values with copy at edges
		ZL = Z[0];// first and last values remain unchanged
		for(Int_t m = 0; m<(N-2); ++m) {
			ZN = dian3(Z[m], Z[m+1], Z[m+2]);
			Z[m] = ZL;
			ZL = ZN;
		}
		Z[N-2] = ZL;
	}
}

void SmoothingOperation::CorrFlatAreas(Double_t *Z, Int_t N) {
	if(N<4) {
		cout<<"\nN is less then 4"<<endl;
		return;
	}
	else {
		// (Q) correct flat areas of three identical values by quadratic interpolation
		for(Int_t n = 2; n<(N-2); ++n) {
			if(Z[n] == Z[n-1] && Z[n] == Z[n+1]) {
				// flat area ...
				if((Z[n]-Z[n-2])*(Z[n]-Z[n+2])>0) {
					// ... as min or max
					Int_t j = 1;// gradient
					if(fabs(Z[n]-Z[n-2]) > fabs(Z[n]-Z[n+2])) j = (-1); // negative total gradient from n-2 till n+2
					Z[n-j] = Z[n+j]-0.5*(Z[n+2*j]-Z[n-2*j]);// Min or Max is ...
					Z[n] = (8*Z[n+j]-3*Z[n+2*j]+Z[n-2*j])/6;// ... more developed
				}
			}
		}
	}
}

void SmoothingOperation::SetAverage3(Double_t *Z, Int_t N) {
	if(N<4) {
		cout<<"\nN is less then 4"<<endl;
		return;
	}
	else {
		// (H) replace each value by average of 3
		ZL = Z[0];
		for(Int_t p = 0; p<(N-2); ++p) {
			ZN = 0.25*(Z[p]+Z[p+1]+Z[p+1]+Z[p+2]);
			Z[p] = ZL;
			ZL = ZN;
		}
		Z[N-2] = ZL;
	}
}

Double_t SmoothingOperation::SumUp(Double_t *Z, Int_t N) {
	if(N<4) {
		cout<<"\nN is less then 4"<<endl;
		return 0.0000000001*(-1);
	}
	// (S) sum up
	for(Int_t q = 1; q<N; ++q) {
		Z[q] = Z[q-1]+Z[q];
	}
	return Z[N-1];
}

void SmoothingOperation::GetAbs(Double_t *Z, Int_t N) {
	if(N<4) {
		cout<<"\nN is less then 4"<<endl;
		return;
	}
	else {
		// (A) abs
		for(Int_t r = 0; r<N; ++r) {
			Z[r] = fabs(Z[r]);
		}
	}
}

void SmoothingOperation::FourthDerivative(Double_t *Z, Int_t N) {
	if(N<4) {
		cout<<"\nN is less then 4"<<endl;
		return;
	}
	else {
		Double_t eta = 0.5;
		Double_t eta2;
		Double_t derL;
		Double_t der2;
		Double_t secn;
		eta2 = eta*eta;
		// (F) fourth  derivative
		secn = 0.5*(3.0*Z[N-1]-7.0*Z[N-2]+5.0*Z[N-3]-Z[N-4]);
		derL = fabs(sqrt(eta2+secn*secn)-eta)*secn/fabs(secn);
		secn = 0.5*(3.0*Z[0]-7.0*Z[1]+5.0*Z[2]-Z[3]);
		der2 = fabs(sqrt(eta2+secn*secn)-eta)*secn/fabs(secn);
		for(Int_t s = 0; s<N-3; ++s) {
			// using 4-point formula
			secn = Z[s]-Z[s+1]-Z[s+2]+Z[s+3];
			// ... with damping of small values
			Z[s] = der2;
			der2 = fabs(sqrt(eta2+secn*secn)-eta)*secn/fabs(secn);
		}
		Z[N-3] = der2;
		Z[N-2] = derL;
		// again second derivative
		secn = 0.5*(3.0*Z[N-1]-7.0*Z[N-2]+5.0*Z[N-3]-Z[N-4]);
		derL = fabs(sqrt(eta2+secn*secn)-eta)*secn/fabs(secn);
		secn = 0.5*(3.0*Z[1]-7.0*Z[2]+5.0*Z[3]-Z[4]);
		der2 = fabs(sqrt(eta2+secn*secn)-eta)*secn/fabs(secn);
		for(Int_t t = 0; t<N-4; ++t) {
			// using 4-point formula
			secn = Z[t]-Z[t+1]-Z[t+2]+Z[t+3];
			// ... with damping of small values
			Z[t] = der2;
			der2 = fabs(sqrt(eta2+secn*secn)-eta)*secn/fabs(secn);
		}
		Z[N-4] = der2;
		Z[N-3] = derL;
		for(Int_t u = (N-3); u>=0; --u) {
			Z[u+1] = Z[u];
		}
		// natural edge values
		Z[0] = 0;
		Z[N-1] = 0;
	}
}
