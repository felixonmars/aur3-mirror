//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef FxFunctionMC_h
#define FxFunctionMC_h

#include "Rtypes.h"
#include "Input.h"

class FxFunctionMC
{
public:
	FxFunctionMC();
	FxFunctionMC(Input *InputObject, Double_t *Coefficient, Double_t gamma, Int_t nrBinsMC, TF1 *func);
	//FxFunctionMC(Input *InputObject, Double_t *Coefficient, Double_t gamma, Int_t nrBinsMC, Double_t (*func)(Double_t));
	~FxFunctionMC();
//	void checkMCFxFunction();
//	Double_t UserFxFunctionMC(Double_t x);
	Double_t getMCFxFunction(Double_t x);
//	Bool_t getUserDefFxFuncFlag() { return userDefFxFuncFlag;}
private:
	Bool_t Defin;
	TF1 *UserFxFunctionMC;
	//Bool_t Userf;
	Bool_t userDefFxFuncFlag;
	Double_t Coeff[240];
	Double_t WantedXLowLimit;
	Double_t WantedXHighLimit;
	Double_t Gamma;

	Int_t NrBinsMC;
	Int_t NrBinsMCMax;

};
#endif //FxFunctionMC_h
