//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009



#ifndef SPLINEFUNCTION_H_
#define SPLINEFUNCTION_H_
#include "Rtypes.h"
class SplineFunction {
public:
	SplineFunction();
	virtual ~SplineFunction();
	void CoefficientFromXY(Double_t *X, Double_t *Y, Double_t C[][11], Int_t N);


private:
	Double_t G;
	Double_t DX;
	Double_t dvd1;
	Double_t dvd3;

};




#endif /* SPLINEFUNCTION_H_ */
