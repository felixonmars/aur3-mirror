//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef BandMatrix_h
#define BandMatrix_h

#include "Rtypes.h"

class BandMatrix {

public:
	BandMatrix();
	virtual ~BandMatrix();
	void GetSolution(Double_t bandMatrix[][63], Int_t nrBand, Int_t nrRow, Double_t *solution, Double_t &Delta);
};

#endif //BandMatrix_h
