//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009



#include "SplineFunction.h"
#include <iostream>
SplineFunction::SplineFunction() {
}

SplineFunction::~SplineFunction() {
}
using namespace std;
void SplineFunction::CoefficientFromXY(Double_t *X, Double_t *Y, Double_t C[][11], Int_t N) {
// CSPNK
	if(N<3) {
		//cout<<"================== N<3 ============="<<endl;
		return;
	}

	for(Int_t i=0; i<N; ++i) {
		C[0][i]=Y[i];
		C[4][i]=X[i];
	}

	// first differences of x and first divided differences of data
	for(Int_t j=1; j<N; ++j) {
		C[2][j]=C[4][j]-C[4][j-1];
		C[3][j]=(C[0][j]-C[0][j-1])/C[2][j];
	}
	C[3][0]=C[2][2];
	C[2][0]=C[2][1]+C[2][2];
	C[1][0]=((C[2][1]+2.0*C[2][0])*C[3][1]*C[2][2]+C[2][1]*C[2][1]*C[3][2])/C[2][0];

	// generate equations and carry out forward pass of Gauss elimination
	for(Int_t k=1; k<N-1; ++k) {
		G=-C[2][k+1]/C[3][k-1];
		C[1][k]=G*C[1][k-1]+3.0*(C[2][k]*C[3][k+1]+C[2][k+1]*C[3][k]);
		C[3][k]=G*C[2][k-1]+2.0*(C[2][k]+C[2][k+1]);
	}
	if(N==3) {
		//cout<<"================== if N==3============="<<endl;
		// special case of three points
		C[1][N-1]=2.0*C[3][N-1];
		C[3][N-1]=1.0;
		G=-1.0/C[3][N-2];
	}
	else {
		//cout<<"================== Else N<3============="<<endl;
		G=C[2][N-2]+C[2][N-1];
		C[1][N-1]=((C[2][N-1]+2.0*G)*C[3][N-1]*C[2][N-2]+C[2][N-1]*C[2][N-1]*(C[0][N-2]-C[0][N-3])/C[2][N-2])/G;
		G=-G/C[3][N-2];
		C[3][N-1]=C[2][N-2];
	}

	// complete forward pass
	C[3][N-1]=C[3][N-1]+G*C[2][N-2];
	C[1][N-1]=(G*C[1][N-2]+C[1][N-1])/C[3][N-1];

	// backward substitution
	for(Int_t l=N-2; l>=0; --l) {
		C[1][l]=(C[1][l]-C[2][l]*C[1][l+1])/C[3][l];
	}

	// generate coefficients
	for(Int_t m=1; m<N; ++m) {
		DX=C[2][m];
		dvd1=(C[0][m]-C[0][m-1])/DX;
		dvd3=C[1][m-1]+C[1][m]-2.0*dvd1;
		C[2][m-1]=(dvd1-C[1][m-1]-dvd3)/DX;
		C[3][m-1]=(dvd3/DX)/DX;
	}

	// calculation of coefficients at X[N-1] (for completeness)
	DX=C[4][N-1]-C[4][N-2];
	C[1][N-1]=C[1][N-2]+DX*(2.0*C[2][N-2]+DX*3.0*C[3][N-2]);
	C[2][N-1]=C[2][N-2]+DX*3.0*C[3][N-2];
	C[3][N-1]=C[3][N-2];
}



