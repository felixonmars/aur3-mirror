//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

#ifndef RegularizationMath_H_
#define RegularizationMath_H_
#include "Input.h"
#include "LinearAlgebra.h"
#include "Functions.h"

class RegularizationMath {

public:
	RegularizationMath();
	virtual ~RegularizationMath();
	RegularizationMath(Input *InputObject, Functions *splineCalc);
	void ConstraintFlags(Double_t Xvalue, Double_t FXvalue);
	void DefRegularizationMatrix(Double_t *SC);
	void CalculateCoeff(Double_t *CoeffMatrix, Double_t *Hessian, Double_t *Gradient, Double_t *x, Double_t *Amplitude, Double_t *Eigenvalue, Double_t &tau, Double_t &NrDegFree, Int_t &NrIndepLinCombs);
	void CovarianceMatrix(Double_t *U, Double_t *CovMatrix);
	void DetermineTau(Double_t *U, Double_t *Gradient, Double_t *X, Double_t *A, Double_t *D, Double_t &Tau, Double_t &Fmax, Int_t &iVeto, Double_t NrDegFree);
	void DetermineBinLimits(Int_t K, Double_t *U, Int_t &nrBins, Double_t *binLimit, Int_t NrKnotsMax);

private:

	Double_t CN[10];
	Double_t DiagHessValuesDimin[63];// DGH
	Double_t ScratchMatrixA[63*63];
	Double_t ScratchMatrixB[63*63];
	Double_t ScratchVector[63];
//	Double_t SmallDiagHessValues[63];// DGM
	Double_t linWeight;
	Double_t xLowLimit;
	Double_t xHighLimit;

	Int_t IC[110];
	Int_t icfl;
	Int_t FxLeftFlag;
	Int_t ir;
	Int_t FxRightFlag;
	Int_t M;
	Int_t MC;
	Int_t nrKnots;
	Int_t nrConstraints;
	Int_t NrKnotsMax;

	Functions *SplineCalc;
	LinearAlgebra *MatrixMult;

};

#endif /* RegularizationMath_H_ */
