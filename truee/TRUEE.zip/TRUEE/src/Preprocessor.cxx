//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009

//============ first pass of unfolding ==================
// select events, determine limits,
// check correlations between measured and wanted variables, ...
// make function f(x) for MC
//====================================
#include "Preprocessor.h"
#include "math.h"
#include "TMath.h"
#include "TExec.h"
#include "TStyle.h"
#include "TROOT.h"
#include "TF1.h"
#include "TProfile.h"
//#include "TColor.h"


// ClassImp(rpass1)

using namespace std;

Preprocessor::Preprocessor(){};

Preprocessor::Preprocessor(Input *InputObject) {

	Gamma = 1.0;
        this->InputObject = InputObject;
	BackEventNr = InputObject->GetBackEventNr();
    DataEventNr = InputObject->GetDataEventNr();
    MocaEventNr = InputObject->GetMocaEventNr();
	print = InputObject->getPrintflag();

	WantedX = 0.0;
	BackWeight = 1;
	//-------- parameter from input -----------
	NrBinsMCMax = InputObject->GetNrBinsMCMax();
	NrKnots = InputObject->GetNrKnots();
	NrKnotsMax = InputObject->GetNrKnotsMax();
	//aspmc[NrKnots];
	NrBinsResult = InputObject->GetNrBinsResult();
	NrOfFitVariables = InputObject->GetNrOfFitVariables();
	for(Int_t a = 0; a<NrOfFitVariables; ++a) {
		IndexFitVariable[a] = InputObject->GetIndexFitVariable(a);
	}
	NrAllMeasuredVariables = InputObject->GetNrAllMeasuredVariables();
	SmoothX = InputObject->GetSmoothX();
	WantedXLowLimit = InputObject->GetWantedXLowLimit();
	WantedXHighLimit = InputObject->GetWantedXHighLimit();
	for(Int_t b = 0; b<NrOfFitVariables; ++b) {
		FitVarLowLimit[b] = InputObject->GetFitVarLowLimit(b);
		FitVarHighLimit[b] = InputObject->GetFitVarHighLimit(b);
	}


	NrDataTypes = InputObject->GetNrDataTypes();
	NrMocaTypes = InputObject->GetNrMocaTypes();
	XMCLumi = InputObject->GetXMCLumi();
	for(Int_t c = 0; c<NrDataTypes; ++c) {
		DataLumi[c] = InputObject->getDataLumi(c);
		DataWeight[c] = InputObject->GetDataWeight(c);
	}

	for(Int_t c = 0; c<NrMocaTypes; ++c) {
		MocaLumi[c] = InputObject->GetMocaLumi(c);
		MocaWeight[c] = InputObject->GetMocaWeight(c);
	}
	//---------------- set all values of monte carlo X distribution to zero -------------------
	for(Int_t c = 0; c<(4*(NrKnots-3)); c++) Coeff[c] = 0.0;
	for(Int_t a = 0; a<NrBinsMCMax; ++a) {
		ValueFxMC[a] = 0.0;
		ErrorFxMC[a] = 0.0;
		//HUA[a] = 0.0;
	}

	nameWantedX = InputObject->getNameWantedX();
	//------------------ reset experimental limits ----------------------------
	for(Int_t j = 0; j<NrAllMeasuredVariables; ++j) {
		nameObsY[j] = InputObject->getNameObsY(j);
		JYflag[j] = 0; //  = 0, if min/max of Y(j) is not defined, =1, if min/max is defined
		MinValue[j] = 0.0;
		MaxValue[j] = 0.0;
	}
	JXflag = 0;
	MinValueX = 0.0;
	MaxValueX = 0.0;

	SumAbsWeightBack = 0.0;
	SumPosWeightBack = 0.0;
	SumPosWeight2Back = 0.0;

	for(Int_t d = 0; d<NrDataTypes; ++d) {
		SumAbsWeightData[d] = 0.0;
		SumPosWeightData[d] = 0.0;
		SumPosWeight2Data[d] = 0.0;
	}
	for(Int_t e = 0; e<NrMocaTypes; ++e) {
		SumAbsWeightMoca[e] = 0.0;
		SumPosWeightMoca[e] = 0.0;
		SumPosWeight2Moca[e] = 0.0;
	}
	//-------------- number of bins for MC histogram--------------------
        NrBinsMC = 4*(NrKnots-3); // NHA = NrBinsMC, NKN = NrKnots

	//------ sum of weights MC ----------

	LuminosityFactor = 1.0;// FACLUM
	SumLumiMoca = 0.0;
	SumLumiData = InputObject->GetSumLumiData();
	// SumLumiData = datlum, XMCLumi = xmclum // FitVarLowLimit = XYFL

	SplineCalc = new Functions();
};
Preprocessor::~Preprocessor(){
delete SplineCalc;
};

void Preprocessor::ReadWrite(const std::string &name) {
        if(print > 1)
            cout<<"\nselect events for unfolding\n===========================\n"<<name<<"\n-----"<<endl;
        double weight = 1.;
//	// ----------------- create files to store selected events in RootTree B ------------------
//	TFile *fileB = 0;
//        if(name == "DATA") fileB = new TFile(InputObject->getoutputpath()+"RDfileB.root","RECREATE");
//	else if(name == "MOCA") {
//		if(print == 1) cout<<"number of bins of MC-f(x) histogram = "<<NrBinsMC<<endl;
//                fileB = new TFile(InputObject->getoutputpath()+"MCfileB.root","RECREATE");
//	}
//        else if(name == "BKGD") fileB = new TFile(InputObject->getoutputpath()+"BGfileB.root","RECREATE");
//	TTree *TreeB = new TTree("TreeB", "during pass1 modified data from TreeA");

//	Double_t weight = 1.0;
//	//------------------ set branch addresses of variables to be stored -------------------------
//	TreeB->Branch("weight", &weight, "weight/D");
//	TreeB->Branch("NTupleIndex", &NTupleIndex, "NTupleIndex/I");
//	if(name == "MOCA") TreeB->Branch(nameWantedX, &WantedX, "WantedX/D");

//	char Variable[NrAllMeasuredVariables];
//	for(Int_t i = 0; i<NrAllMeasuredVariables; ++i) {
//		sprintf(Variable, "Variable%d/D", i);
//		TreeB->Branch(nameObsY[i], &y[i], Variable);
//	}

        // ------------------ read next event from TreeA ------------\




	if(name == "DATA") {
           aux =  InputObject->GetData()->Real_Data;
	}
	else if(name == "MOCA") {

            aux = InputObject->GetData()->MonteCarlo_Data;
	}
	else if(name == "BKGD") {
            aux =  InputObject->GetData()->BG_Data;
    }
	//------------------ set branch addresses of variables to get from RootTree A--------------------
//	TreeA->SetBranchAddress("weight", &weight);
//	TreeA->SetBranchAddress("NTupleIndex", &NTupleIndex);

//	for(Int_t i = 0; i<NrAllMeasuredVariables; ++i) {
//		TreeA->SetBranchAddress(nameObsY[i], &y[i]);
//	}

        NrEntries = aux.size();


	//------------------ get events from RootTree A ------------------
	Double_t absWeight = 0;// positive and negative weights
	Int_t xOutsideLimits = 0;// MC x values outside of the unfolding limits


	for(Int_t AB = 0; AB<NrEntries; ++AB) {
                 weight =aux.at(AB)->get_weight();



                 for(int i = 0; i < NrAllMeasuredVariables; ++i){

                     y[i] = aux.at(AB)->get_y(i);

                 }
                 NTupleIndex = aux.at(AB)->get_NTupleIndex();
                 if(name == "MOCA")
                     WantedX = aux.at(AB)->get_x();


		// -----------------check user defined bin limits for fit variables-------------------------
		for(Int_t k = 0; k < NrOfFitVariables; ++k) {
			if(FitVarLowLimit[k]<FitVarHighLimit[k]) {
				// bin limits defined
				// exclude events with values outside limits by using negative weight (weight is used later for normalization)
				if(y[IndexFitVariable[k]]<FitVarLowLimit[k] || y[IndexFitVariable[k]]>FitVarHighLimit[k]) weight = (-1)*fabs(weight);
			}
		}

		// --------------------check MC X------------------------------
		if(name == "MOCA" && weight > 0) {
			if(WantedX < WantedXLowLimit || WantedX > WantedXHighLimit) {
				xOutsideLimits = xOutsideLimits+1;// x values outside the user defined limits
			//if(xOutsideLimits <= 5) cout<<WantedX<<" = wanted variable MC outside limits "<< WantedXLowLimit<<",\t"<< WantedXHighLimit<<endl;
			}
		}
		// ------------------ calculate sum of weights ---------------------
		if(name == "DATA") {

			SumAbsWeightData[NTupleIndex] = SumAbsWeightData[NTupleIndex]+fabs(weight);
			if(weight>0.0) {
				SumPosWeightData[NTupleIndex] = SumPosWeightData[NTupleIndex]+weight;
				SumPosWeight2Data[NTupleIndex] = SumPosWeight2Data[NTupleIndex]+weight*weight;
			}
		}
		else if(name == "MOCA") {
			SumAbsWeightMoca[NTupleIndex] = SumAbsWeightMoca[NTupleIndex]+fabs(weight);
			if(weight>0.0) {
				SumPosWeightMoca[NTupleIndex] = SumPosWeightMoca[NTupleIndex]+weight;
				SumPosWeight2Moca[NTupleIndex] = SumPosWeight2Moca[NTupleIndex]+weight*weight;
			}
			// ---------make moca histogram of input x-distribution-----------
			// including ntuples with negative weight
			// 		absWeight = abs(weight)*MocaWeight[0]/(WantedXHighLimit-WantedXLowLimit)*static_cast<Double_t>(NrBinsMC);// unnecessary?
			absWeight = fabs(weight)/(WantedXHighLimit-WantedXLowLimit)*static_cast<Double_t>(NrBinsMC);
			Double_t J = 1.0+(WantedX-WantedXLowLimit)/(WantedXHighLimit-WantedXLowLimit)*static_cast<Double_t>(NrBinsMC);
			Int_t JJ = static_cast<Int_t>(J);
			if(JJ>=1 && JJ<=NrBinsMC) {
				ValueFxMC[JJ-1] = ValueFxMC[JJ-1]+absWeight; // values f(x) MC as sum of weights (ValueFxMC = HUH)
				ErrorFxMC[JJ-1] = ErrorFxMC[JJ-1]+absWeight*absWeight; // errors of f(x) MC (ErrorFxMC = HUS)
				//	if(weight>0.0) HUA[JJ-1] = HUA[JJ-1]+absWeight;// not necessary?
			}
		}
		else if(name == "BKGD") {
			SumAbsWeightBack = SumAbsWeightBack+fabs(weight);// SumAbsWeight...=STAB(6,...)
			if(weight>0.0) {
				SumPosWeightBack = SumPosWeightBack+weight;// SumPosWeight...=STAB(7,...)
				SumPosWeight2Back = SumPosWeight2Back+weight*weight;// SumPosWeight2...=STAB(8,...)
			}
		}
		// --------------------determine min and max values of each variable from data and moca------------------------
		if(weight>0.0 && (name == "DATA" || name == "MOCA")) {
			for(Int_t k = 0; k<NrAllMeasuredVariables; ++k) {
				if(JYflag[k] == 0) {
					// initial min and max values not defined(first loop)
					JYflag[k] = 1;
					MinValue[k] = y[k];
					MaxValue[k] = y[k];
				}
				else {
					MinValue[k] = TMath::Min(MinValue[k],y[k]);
					MaxValue[k] = TMath::Max(MaxValue[k], y[k]);
				}
			}
			if(name == "MOCA") {
				if(JXflag == 0) {
					// first loop
					JXflag = 1;
					MinValueX = WantedX;
					MaxValueX = WantedX;
				}
				else {
					MinValueX = TMath::Min(MinValueX, WantedX);
					MaxValueX = TMath::Max(MaxValueX, WantedX);
				}
			}
		}

                if(weight>0.0){
/*  
                  TrueeEvent* temp = new TrueeEvent();
                    temp->set_weight(aux.at(AB)->get_weight());
                    for(int i = 0; i < NrAllMeasuredVariables; ++i){
                        temp->add_y(aux.at(AB)->get_y(i));

                    }
                   temp->set_NTupleIndex(aux.at(AB)->get_NTupleIndex());
                   */
              //     if(InputObject->getTestmode() || InputObject->GetPullmode()){
                 //     malloc(aux.at(AB)->get_x());

                  // }

                    if(name == "MOCA")
                         InputObject->GetData()->MonteCarlo_Data_after_pp.push_back(aux.at(AB));
                    else if(name == "DATA")
                         InputObject->GetData()->Real_Data_after_pp.push_back(aux.at(AB));
                    else if(name == "BKGD")
                         InputObject->GetData()->BG_Data_after_pp.push_back(aux.at(AB));
                }


	}

	if(name == "MOCA") {
                if(print > 1) cout<<"MC events outside unfolding limits = "<<xOutsideLimits<<endl;
	}
	aux.clear();
}
void Preprocessor::DetermineLimits() {
        if(print > 1) cout<<"\ndetermine limits of variables\n============================="<<endl;
	//----------------------------check bin limits---------
	// for fit variables
	for(Int_t l = 0; l<NrAllMeasuredVariables; l++) {
		if(JYflag[l]!=0) {
			if(MinValue[l]!=MaxValue[l]) {
				// rounded limits for final histograms
				MinValueRound[l] = MinValue[l];
				MaxValueRound[l] = MaxValue[l];
				RoundLimits(MinValueRound[l], MaxValueRound[l]);
			}
			else JYflag[l] = 0;
		}
	}
	if(JXflag!=0) {
		// MC x extrema determined
		if(MinValueX!=MaxValueX) {
			MinValueXRound = MinValueX;
			MaxValueXRound = MaxValueX;
			RoundLimits(MinValueXRound, MaxValueXRound);
                        if(print > 1) cout<<"x limits rounded min = "<<MinValueXRound<<", max = "<<MaxValueXRound<<endl;
		}
		else JXflag = 0;
	}

	//----------------------define missing limits for fit variables--------
	// if FitVarLowLimit and FitVarHighLimit is not set by the user
	for(Int_t m = 0; m<NrOfFitVariables; m++) {
		if(FitVarLowLimit[m] == FitVarHighLimit[m]) {
			FitVarLowLimit[m] = MinValue[IndexFitVariable[m]]*1.0001-0.0001*MaxValue[IndexFitVariable[m]];
			if(FitVarLowLimit[m]<0 && MinValue[IndexFitVariable[m]]>=0) FitVarLowLimit[m] = 0;
			FitVarHighLimit[m] = MaxValue[IndexFitVariable[m]]*1.0001-0.0001*MinValue[IndexFitVariable[m]];
			if(FitVarHighLimit[m]>0 && MaxValue[IndexFitVariable[m]]<=0) FitVarHighLimit[m] = 0;
		}
	}

	//---------------- print min and max values and limits  ---------------------------------
        if(print > 1) {
		cout<<"\nlimits of fit variables, exact and rounded"<<endl;
		cout<<"------------------------------------------"<<endl;
		for(Int_t p = 0; p<NrOfFitVariables; p++) {
			Int_t L = IndexFitVariable[p];
			cout<<L<<"\tfitvariable"<<"\t"<<FitVarLowLimit[p]<<"\t"<<FitVarHighLimit[p]<<"\t"<<MinValueRound[L]<<"\t"<<MaxValueRound[L]<<endl;
		}
	}
}
/*
void Preprocessor::CheckXYCorrelation(const std::string &name) {
	if(print == 1) {
		cout<<"\nchecking correlation between observables and wanted variable"<<endl;
		cout<<"============================================================"<<endl;
		if(name == "MOCA") {
			cout<<"(find X-Y-correlation, profile and projection histograms in MCfileA.root)"<<endl;
		}
		else if(name == "DATA") {
			cout<<"(find X-Y-correlation, profile and projection histograms in RDfileA.root)"<<endl;
		}
		cout<<name<<"\n----"<<endl;
	}
        double weight = 1.;
        TFile *fileA = 0;
        if(name == "MOCA") {
                fileA = new TFile(InputObject->getoutputpath()+"MCfileA.root", "UPDATE");
        }
        // in the test mode it is possible (reasonable) to check correlation for real data, too
        else if(name == "DATA") {
                fileA = new TFile(InputObject->getoutputpath()+"RDfileA.root", "UPDATE");
        }
//	TTree *TreeA = (TTree*)fileA->Get("TreeA");
//	Double_t weight = 1.0;
//	NrEntries = static_cast<Int_t>(TreeA->GetEntries());
//	TreeA->SetBranchAddress("weight", &weight);
//        TreeA->SetBranchAddress("NTupleIndex", &NTupleIndex);
//        TreeA->SetBranchAddress(nameWantedX, &WantedX);
//	for(Int_t i = 0; i<NrAllMeasuredVariables; ++i) {
//		TreeA->SetBranchAddress(nameObsY[i], &y[i]);
//	}
        std::vector<TrueeEvent* >* aux;
        if(name == "DATA") {
           aux =  &InputObject->GetData()->Real_Data;
        }
        else if(name == "MOCA") {

            aux = &InputObject->GetData()->MonteCarlo_Data;
        }

        NrEntries = aux->size();

       // TFile* fCorrelationFile = new TFile(InputObject->getoutputpath()+"Correlations.root", "UPDATE");

	//------------- folder -----------
        gDirectory->cd("/");
        gDirectory->mkdir("correlation");
        gDirectory->mkdir("profile");
        gDirectory->mkdir("projection");
        gDirectory->mkdir("sigma_of_projection");
	//---------------------- histograms variable Y  vs. wanted X-------------------------
	TH2D *hXvsY[NrAllMeasuredVariables];
        Int_t nrFitVariables = InputObject->GetNrOfFitVariables();
	TH2D *hXvsYbinned[nrFitVariables];
	TCanvas *cProj = 0;
	TCanvas *cProjNorm = 0;
	TCanvas *cSigma = 0;
	TCanvas *cSigmaNorm = 0;
	TString histoXYTitle;
	Int_t nrBinsFitVar = 0;
	Int_t nrYBins = 0;
	Int_t nrBinsXHisto = 100;
	Double_t sigma = 0.0;
	Double_t sigmaNorm = 0.0;
	Double_t SigmaMin = 0.0;
	Double_t SigmaMax = 0.0;
	Double_t SigmaNormMin = 0.0;
	Double_t SigmaNormMax = 0.0;
	TProfile *prof[NrAllMeasuredVariables];
	TProfile *profBins[nrFitVariables];
	if(NrBinsResult > 0) nrBinsXHisto = static_cast<Int_t>((MaxValueX-MinValueX)*NrBinsResult/(WantedXHighLimit-WantedXLowLimit));
	TH1D *hProjection[100];
	TH1D *hProjectionNorm[100];
	TH1D *hSigma = 0;
	TH1D *hSigmaNorm = 0;
	TString variableTitle;
        double WantedX;
	for(Int_t j = 0; j<NrAllMeasuredVariables; ++j) {
		histoXYTitle = nameWantedX +"_VS_"+ nameObsY[j] ;
		hXvsY[j] = new TH2D(histoXYTitle, histoXYTitle, 100, MinValue[j], MaxValue[j], 100, MinValueX, MaxValueX);
		// profile plot
		histoXYTitle = nameWantedX + "_VS_" + nameObsY[j] + "_profile";
		prof[j] = new TProfile(histoXYTitle, "profile without bin limits", 100, MinValue[j], MaxValue[j], MinValueX, MaxValueX);
		hXvsY[j]->GetYaxis()->SetTitle(nameWantedX);
		hXvsY[j]->GetXaxis()->SetTitle(nameObsY[j]);
		prof[j]->GetYaxis()->SetTitle(nameWantedX);
		prof[j]->GetXaxis()->SetTitle(nameObsY[j]);
		for(Int_t AB = 0; AB<NrEntries; AB++) {

                         WantedX = aux->at(AB)->get_x();
                         y[j] = aux->at(AB)->get_y(j);
                         weight = aux->at(AB)->get_weight();
			hXvsY[j]->Fill(y[j], WantedX, weight);
			prof[j]->Fill(y[j], WantedX, weight);
		}

		hXvsY[j]->SetOption("colz");
		gDirectory->cd("/correlation");
		hXvsY[j]->Write();
		gDirectory->cd("/profile");
		prof[j]->Write();
	}
    cout << "Half way done"<<endl;
	for(Int_t k = 0; k<nrFitVariables; ++k) {
                nrBinsFitVar = InputObject->GetNrBinsFitVar(k);

		variableTitle = nameObsY[IndexFitVariable[k]];
		nrYBins = static_cast<Int_t>(nrBinsFitVar*(MaxValue[IndexFitVariable[k]]-MinValue[IndexFitVariable[k]])/static_cast<Int_t>(FitVarHighLimit[k]-FitVarLowLimit[k]));
		histoXYTitle = nameWantedX + "_VS_" + variableTitle + "_binned";
		//hXvsYbinned[k] = new TH2D(histoXYTitle, histoXYTitle,  nrBinsFitVar, FitVarLowLimit[k], FitVarHighLimit[k], nrBinsXHisto, WantedXLowLimit, WantedXHighLimit);
                hXvsYbinned[k] = new TH2D(histoXYTitle, histoXYTitle, nrBinsFitVar, MinValue[IndexFitVariable[k]], MaxValue[IndexFitVariable[k]], NrBinsResult, MinValueX, MaxValueX);//WantedXLowLimit, WantedXHighLimit);
		histoXYTitle = nameWantedX + "_VS_" + variableTitle + "_profile_binned";
		profBins[k] = new TProfile(histoXYTitle, "profile with bin limits", nrBinsFitVar, FitVarLowLimit[k], FitVarHighLimit[k], WantedXLowLimit, WantedXHighLimit);
		hXvsYbinned[k]->GetYaxis()->SetTitle(nameWantedX);
		hXvsYbinned[k]->GetXaxis()->SetTitle(variableTitle);
		profBins[k]->GetYaxis()->SetTitle(nameWantedX);
		profBins[k]->GetXaxis()->SetTitle(variableTitle);
		for(Int_t AB = 0; AB<NrEntries; ++AB) {
                    WantedX = aux->at(AB)->get_x();
                    y[k] = aux->at(AB)->get_y(k);
                    weight = aux->at(AB)->get_weight();
			hXvsYbinned[k]->Fill(y[IndexFitVariable[k]], WantedX);
			profBins[k]->Fill(y[IndexFitVariable[k]], WantedX, 1);
		}
		hXvsYbinned[k]->SetOption("colz");
		gDirectory->cd("/profile");
		profBins[k]->Write();
		gDirectory->cd("/correlation");
		hXvsYbinned[k]->Write();
		histoXYTitle = nameWantedX + "_VS_" + variableTitle + "_projection_binned_"+ name;
		cProj = new TCanvas(histoXYTitle, "projection", 800, 600);
		histoXYTitle = nameWantedX + "_VS_" +  variableTitle + "_projection_normalized_"+ name;
		cProjNorm = new TCanvas(histoXYTitle, "projection normalized", 800, 600);
		histoXYTitle = "sigma_projection_" + variableTitle + "_" + name;
		cSigma = new TCanvas(histoXYTitle, "sigma", 800, 600);
		hSigma = new TH1D(histoXYTitle, "sigma (gaussian fit) of projection", 100, 0, 0);
		histoXYTitle = "sigma_normalized_projection_" + variableTitle + "_" + name;
		cSigmaNorm = new TCanvas(histoXYTitle, "SigmaNorm", 800, 600);
		hSigmaNorm = new TH1D(histoXYTitle, "sigma (gaussian fit) of normalized projection", 100, 0, 0);

		for(Int_t ij=0; ij<nrYBins; ++ij) {
			histoXYTitle.Form("projection_bin_%i", ij);
			histoXYTitle = histoXYTitle + "_" + variableTitle;
			hProjection[ij]=hXvsYbinned[k]->ProjectionY(histoXYTitle, ij+1, ij+2, "l");
			hProjection[ij]->SetLineColor(ij+1);
			histoXYTitle.Form("projection_normalized_bin_%i", ij);
			histoXYTitle = histoXYTitle + "_" + variableTitle;
			if(ij == 0) {
				cProj->cd();
				hProjection[0]->SetTitle("projections of all y-bins on the wanted variable");
				hProjection[0]->SetAxisRange(0, 4000, "Y");
				hProjection[0]->GetXaxis()->SetTitle(nameWantedX);
				hProjection[0]->Draw();
				sigma = hProjection[0]->GetRMS(1);
				sigma = sigma*hProjection[0]->GetEntries();
				cSigma->cd();
				if(sigma > 0) hSigma->Fill(sigma);
				hSigma->SetLineWidth(2);
				hSigma->GetXaxis()->SetTitle("sigma");
				hSigma->GetYaxis()->SetTitle("#");
				hSigma->Draw();
				SigmaMax = sigma; //f1[ij]->GetParameter(2);
				SigmaMin = sigma; //f1[ij]->GetParameter(2);
				cProjNorm->cd();
				if((hProjection[0]->GetMean(1)) != 0) {
				hProjectionNorm[0]=new TH1D(histoXYTitle, histoXYTitle, nrBinsXHisto, MinValueX/(hProjection[0]->GetMean(1)), MaxValueX/(hProjection[0]->GetMean(1)));
				for(Int_t jk=0; jk<nrBinsXHisto; ++jk) {
					hProjectionNorm[ij]->Fill(hProjection[ij]->GetBinCenter(jk+1)/(hProjection[0]->GetMean(1)),(hProjection[0]->GetBinContent(jk+1)));
				}
				hProjectionNorm[0]->SetLineColor(ij+2);
				hProjectionNorm[0]->SetTitle("normalized projections of all y-bins on the wanted variable");
				hProjectionNorm[0]->SetAxisRange(0, 4000, "Y");
				hProjectionNorm[0]->GetXaxis()->SetTitle(nameWantedX);
				hProjectionNorm[0]->Draw();
				sigmaNorm = hProjectionNorm[0]->GetRMS(1);
				sigmaNorm = sigmaNorm*hProjectionNorm[0]->GetEntries();
				cSigmaNorm->cd();
				if(sigmaNorm > 0) hSigmaNorm->Fill(sigmaNorm);
				hSigmaNorm->SetLineWidth(2);
				hSigmaNorm->GetXaxis()->SetTitle("sigma");
				hSigmaNorm->GetYaxis()->SetTitle("#");
				hSigmaNorm->Draw();
				SigmaNormMax=sigmaNorm;
				SigmaNormMin=sigmaNorm;
				}
			}
			else {
				cProj->cd();
				hProjection[ij]->Draw("same");
				//hProjection[ij]->Fit(f1[ij], "Q");
				sigma = hProjection[ij]->GetRMS(1);
				sigma = sigma*hProjection[ij]->GetEntries();
				cSigma->cd();
				if(sigma > 0) hSigma->Fill(sigma);
				hSigma->SetLineWidth(2);
				if(SigmaMax < sigma) SigmaMax = sigma;
				if(SigmaMin > sigma) SigmaMin = sigma;
				hSigma->Draw("same");
				cProjNorm->cd();
				if((hProjection[ij]->GetMean(1)) != 0) {
				hProjectionNorm[ij]=new TH1D(histoXYTitle, histoXYTitle, nrBinsXHisto, MinValueX/(hProjection[ij]->GetMean(1)), MaxValueX/(hProjection[ij]->GetMean(1)));

				for(Int_t jk=0; jk<nrBinsFitVar; ++jk) {
					hProjectionNorm[ij]->Fill(hProjection[ij]->GetBinCenter(jk+1)/(hProjection[ij]->GetMean(1)),(hProjection[ij]->GetBinContent(jk+1)));
				}

				hProjectionNorm[ij]->SetLineColor(ij+2);
				hProjectionNorm[ij]->Draw("same");
				//hProjectionNorm[ij]->Fit(f2[ij], "Q");
				sigmaNorm = hProjectionNorm[ij]->GetRMS(1);
				sigmaNorm = sigmaNorm*hProjectionNorm[ij]->GetEntries();
				cSigmaNorm->cd();
				if(sigmaNorm > 0) hSigmaNorm->Fill(sigmaNorm);
				hSigmaNorm->SetLineWidth(2);
				if(SigmaNormMax < sigmaNorm) SigmaNormMax = sigmaNorm;
				if(SigmaNormMin > sigmaNorm) SigmaNormMin = sigmaNorm;

				hSigmaNorm->Draw("same");
				}
			}
		}
		/*if(print == 1){
                        cout<<"\n--- "<<variableTitle<<" ---\nnumber of y bins = "<<nrYBins<<endl;
			cout<<"standard deviations (sigma) of projection of observables on wanted x"<<endl;
			cout<<"--------------------------------------------------------------------"<<endl;
			cout<<"min. sigma = "<<SigmaMin<<", max. sigma = "<<SigmaMax<<endl;
			cout<<"min. sigma (normalized) = "<<SigmaNormMin<<", max. sigma (normalized) = "<<SigmaNormMax<<endl;
                }s
		cProj->Update();
		cProjNorm->Update();
		cSigma->Update();
		cSigmaNorm->Update();
		gDirectory->cd("/projection");
		cProj->Write();
		cProjNorm->Write();
		gDirectory->cd("/sigma_of_projection");
		cSigma->Write();
		cSigmaNorm->Write();
	}

        fileA->Close();
	delete cProj;
	delete cProjNorm;
        delete cSigma;
        delete cSigmaNorm;
        cout << "readwrite done"<<endl;


}

*/
void Preprocessor::StatisticAndEfficiency(){
        if(print > 1) cout<<"\nevent statistic"<<"\n==============="<<endl;
	Double_t efficiencyRD[NrDataTypes];
	Double_t efficiencyMC[NrMocaTypes];
	Double_t efficiencyBG = 0.0;
	Double_t slwtData = 0.0;
	Double_t sqwtData = 0.0;
	Double_t slwtMoca = 0.0;
	Double_t sqwtMoca = 0.0;
	Double_t slwtBG = SumPosWeightBack*BackWeight;
	Double_t sqwtBG = SumPosWeight2Back*pow(BackWeight,2);
	//TODO change names
        if(print > 1) {
	cout<<"Type"<<"\t\t\tefficiency"<<"\tefficiency2"<<"\tsum of weights"<<"\tsum of square weights"<<endl;
	cout<<"----\t\t\t----------\t-----------\t--------------\t---------------------"<<endl;
	}
	for(Int_t i = 0; i<NrDataTypes; ++i) {
		slwtData = slwtData+SumPosWeightData[i]*DataWeight[i];
		sqwtData = sqwtData+SumPosWeight2Data[i]*pow(DataWeight[i],2);
		efficiencyRD[i] = 0.0;
		if((SumPosWeight2Data[i]*DataLumi[i]) != 0.0) efficiencyRD[i] = SumPosWeightData[i]/(SumPosWeight2Data[i]*DataLumi[i]);
                if(print > 1) cout<<i<<" real data\t\t"<<efficiencyRD[i]<<"\t\t"<<slwtData/sqwtData<<"\t\t"<<SumPosWeightData[i]<<"\t\t"<<SumPosWeight2Data[i]<<endl;
	}
	for(Int_t j = 0; j<NrMocaTypes; ++j) {
		slwtMoca = slwtMoca+SumPosWeightMoca[j]*MocaWeight[j];
		sqwtMoca = sqwtMoca+SumPosWeight2Moca[j]*pow(MocaWeight[j],2);
		efficiencyMC[j] = 0.0;
		if((SumPosWeight2Moca[j]*MocaLumi[j]) != 0.0) efficiencyMC[j] = SumPosWeightMoca[j]/(SumPosWeight2Moca[j]*MocaLumi[j]);
                if(print > 1) cout<<j<<" Monte Carlo\t\t"<<efficiencyMC[j]<<"\t\t"<<slwtMoca/sqwtMoca<<"\t\t"<<SumPosWeightMoca[j]<<"\t\t"<<SumPosWeight2Moca[j]<<endl;
	}
	if((SumPosWeight2Back*BackEventNr) != 0.0) {
		efficiencyBG = SumPosWeightBack/(SumPosWeight2Back*BackEventNr);
                if(print > 1) cout<<" background\t\t"<<efficiencyBG<<"\t\t"<<slwtBG/sqwtBG<<"\t\t"<<SumPosWeightBack<<"\t\t"<<SumPosWeight2Back<<endl;
	}
}

void Preprocessor::RoundLimits(Double_t &leftLimit, Double_t &rightLimit) {
	// determine rounded limits Value
	Double_t bins[] = {0.1, 0.15, 0.2, 0.25, 0.4, 0.5, 0.6, 0.8, 1.0, 1.5};
	Int_t binNr = 120;
	Int_t one = 1;
	Int_t index;
	Double_t left;
	Double_t right;
	Double_t binWidth = (rightLimit-(leftLimit))/static_cast<Double_t>(binNr);
        if(binWidth<=0.0) binWidth = pow(10.,-4.);
	Double_t exponent = static_cast<Int_t>(log10(binWidth)+100.0)-99;
	Double_t factor = pow(10,exponent);
	binWidth = binWidth/factor;
	for(index = 0; index<9; ++index) {
		if(bins[index]>=binWidth) {
			one = 2;
			break;
		}
	}
	if(one==1) index = 8;
	do {
		binWidth = bins[index]*factor;
		left = 10.0*binWidth*static_cast<Int_t>(leftLimit/(10.0*binWidth));//TODO hier war AINT
		if(left>leftLimit) left = leftLimit-10.0*binWidth;
		right = left+static_cast<Double_t>(binNr)*binWidth;
		index++;
	} while(right<rightLimit && index!=10);

	leftLimit = left;
	rightLimit = right;
}

void Preprocessor::FitMCHistogram(){
	//------------- copy histogram of x values to FittedValueFxMC ...------------
        if(print > 1) cout<<"\nspline fit of MC f(x)-histogram\n==============================="<<endl;
	Int_t ihis = 0;
        if(print > 1) cout<<"number of bins of MC f(x)-histogram = "<<NrBinsMC<<endl;

	for(Int_t q = 0; q<NrBinsMC; q++) {
		if(ErrorFxMC[q]!=0) ihis = 1;// => weight != 0 in bin q
		FittedValueFxMC[q] = ValueFxMC[q]; // FittedValueFxMC = HUF
	//	cout<<q+1<<" before spline = "<<ValueFxMC[q]<<endl;
	}

	//-------------- fit splines to MC X-histogram and determine spline coefficients -------------
	if(ihis == 1) {
		//---------- for option SMOOTHX smooth histogram before the fit ...-----------
		if(SmoothX) {
			SmoothSplineFit *smoothedValues = new SmoothSplineFit();
			smoothedValues->SmoothAndFit(FittedValueFxMC, NrBinsMC);
			delete smoothedValues;
//			for(Int_t q = 0; q<NrBinsMC; ++q)
//			cout<<"ValueFxMC after splinefit: "<<FittedValueFxMC[q]<<endl;
		}
		//---------- least square fit of splines -> spline coefficients ----------------
		else {
			SplineCalc->LeastSquareFit(FittedValueFxMC,ErrorFxMC, NrBinsMC, WantedXLowLimit, WantedXHighLimit,NrKnots,FittedValueFxMC,aspmc);
		}

		//------------ spline function definition from smoothed data --------------
		// calculate b-spline coefficients with equidistant function values
		BSplineCoefficient *CoefficientsA = new BSplineCoefficient();
		CoefficientsA->getCoeff(FittedValueFxMC, Coeff, NrBinsMC);
	//	cout<<"\ncoefficients A from B-Spline fit of the MC-X-histogram"<<endl;
	//	cout<<"------------------------------------------------------"<<endl;
//				for(Int_t t = 0; t<NrBinsMC; t++) {
//					cout<<"\tA["<<t<<"] = "<<Coeff[t]<<endl;
//					//if((t+1)%4 == 0) cout<<endl;
//				}
		delete CoefficientsA;
	}
}

void Preprocessor::Normalization(FxFunctionMC *MCFunctionFx){
        if(print > 1) cout<<"\ncalculations for normalization\n=============================="<<endl;
	Gamma = 1.0;
	//------------ integrate x function FxFunctionMC (average f(x) in x region * x region)----------------
	Double_t FxFuncAverage;// FxFuncAverage = SAVF
	FxFuncAverage = AverageOfFunction(WantedXLowLimit, WantedXHighLimit, MCFunctionFx);// average of FxFunctionMC in x region
	Double_t FxFuncIntegral = FxFuncAverage*(WantedXHighLimit-WantedXLowLimit); // FxFuncIntegral = SINT

        if(print > 1) cout<<"average of MC f(x)-function = "<<FxFuncAverage<< "\nintegral of MC f(x)-function = "<< FxFuncIntegral<<endl;
	Double_t sumPosWeightMocaAllTypes = 0.0;
	Double_t sumAbsWeightMocaAllTypes = 0.0;
	//------------- determine number of MC events (sum of weights of every ntuple file) -----------
	for(Int_t s = 0; s<NrMocaTypes; ++s) {
		sumPosWeightMocaAllTypes = sumPosWeightMocaAllTypes+SumPosWeightMoca[s];
		sumAbsWeightMocaAllTypes = sumAbsWeightMocaAllTypes+SumAbsWeightMoca[s];
	}
	//------------ if Luminosity of the real data not given - 1.0 assumed -----------------
	if(SumLumiData == 0) SumLumiData = 1.0;

	//-------------- test user MC f(x)-function -----------------
	// 4 cases depending on specification of UserFxFunctionMC and MC luminosity
	Double_t flumus = XMCLumi;
        Bool_t userDefFxFunc = InputObject->GetMCFuncFlag();
	//userDefFxFunc = MCFunctionFx->getUserDefFxFuncFlag();
	if(userDefFxFunc == 0) {
		// no user supplied function
		// no MC luminosity defined
		if(XMCLumi == 0.0) {
                    if(print > 1){
			cout<<"\nThis is case 1"<<endl;
			cout<<"--------------"<<endl;
                    }
			// normalization of the function
			Gamma = 1/FxFuncIntegral;
			for(Int_t r = 0; r<NrKnots; r++) {
				aspmc[r] = Gamma*aspmc[r]; // aspmc are coefficients from the least square fit (espq)
			}
			FxFuncIntegral = FxFuncIntegral*Gamma; // => integral = 1
			FxFuncAverage = FxFuncAverage*Gamma; // => average = average / Integral = 1/(x-Region)
			flumus = sumAbsWeightMocaAllTypes;
                        if(print > 1) {
				cout<<"The MC f(x)-function is the default version, "<<endl;
				cout<<"which is defined by the actual "<<endl;
				cout<<"x-distribution of all MC events, "<<endl;
				cout<<"including the rejected events"<<endl;
				cout<<"with a negative weight."<<endl;
				cout<<"The default function MC f(x)-function is normalized "<<endl;
				cout<<"to an integral of one."<<endl;
				cout<<"the MC luminosity is set to zero by the user!"<<endl;
				cout<<"the value is set to the sum of |weight|s = "<<flumus<<endl;
			}
			LuminosityFactor = sumAbsWeightMocaAllTypes/SumLumiData;
			SumLumiData = 1.0;
		}
		else {
			// no user supplied function but
			// MC luminosity is defined by the user
                        if(print > 1){
			cout<<"\nThis is case 2"<<endl;
			cout<<"--------------"<<endl;
                        }
                        if(print > 1) {
				cout<<"The MC f(x)-function is the default version, "<<endl;
				cout<<"which is defined by the actual "<<endl;
				cout<<"x-distribution of all MC events, "<<endl;
				cout<<"including the rejected events"<<endl;
				cout<<"with a negative weight."<<endl;
				cout<<"The MC luminosity is specified or default = 1."<<endl;
				cout<<"Therefore the normalization of the MC f(x)-function "<<endl;
				cout<<"is determined to be consistent with "<<endl;
				cout<<"the given MC luminosity and the sum of |weight|s"<<endl;
			}
			Gamma = sumAbsWeightMocaAllTypes/(XMCLumi*FxFuncIntegral);
			FxFuncIntegral = FxFuncIntegral*Gamma;
			FxFuncAverage = FxFuncAverage*Gamma;
			LuminosityFactor = 1.0/SumLumiData;
			SumLumiData = 1.0;
		}
	}
	else {
		// function is defined by the user
		if(XMCLumi == 0.0) {
			// no user defined MC luminosity
                        if(print > 1) {
			cout<<"\nThis is case 3"<<endl;
			cout<<"--------------"<<endl;
                        }
                        if(print > 1) {
				cout<<"The MC f(x)-function is supplied by the user. "<<endl;
				cout<<"The MC luminosity is not specified and "<<endl;
				cout<<"therefore calculated as the sum of all "<<endl;
				cout<<"MC |weight|s, divided by the integral of "<<endl;
				cout<<"the user MC f(x)-function"<<endl;
			}
			flumus = sumAbsWeightMocaAllTypes/FxFuncIntegral;
			// LuminosityFactor = 1/SumLumiData, if ALL events are in the n-tuple, because integ(f(x)) = sum(|w|)
			LuminosityFactor = sumAbsWeightMocaAllTypes/FxFuncIntegral/SumLumiData;
			SumLumiData = 1.0;
		}
		else {
			// function and MC luminosity is defined by the user
                        if(print > 1) {
                            cout<<"\nThis is case 4"<<endl;
                            cout<<"--------------"<<endl;
                        }
                        if(print > 1) {
				cout<<"The MC f(x)-function is supplied by the user."<<endl;
				cout<<"The MC luminosity is specified and thus "<<endl;
				cout<<"everything is known. As a consistency check "<<endl;
				cout<<"the overall acceptance can be calculated as "<<endl;
				cout<<"the sum of all MC weights, divided by the "<<endl;
				cout<<"product of MC luminosity and the integral "<<endl;
				cout<<"of the user MC f(x)-function."<<endl;
				cout<<"Mean acceptance (sum(pos(w))/(lumi*integralFx)) = "<< sumPosWeightMocaAllTypes/(flumus*FxFuncIntegral)<<endl;
			}
			LuminosityFactor = 1.0;
		}
	}

	if(SumLumiData!=1) {
		// data luminosity is known
		LuminosityFactor = LuminosityFactor/SumLumiData;
		SumLumiData = 1.0;
	}

        if(print > 1) cout<<"\naverage and integral of MC f(x)-function after normalization:\t"<<FxFuncAverage<<"\t"<<FxFuncIntegral<<endl;

	if(XMCLumi!=0) {
		//	MC lumi specified - scale it
		SumLumiMoca = 0.0;
		for(Int_t t = 0; t<NrMocaTypes; ++t) {
			SumLumiMoca = SumLumiMoca+MocaLumi[t];
		}
		LuminosityFactor = LuminosityFactor*SumLumiMoca;
		SumLumiData = SumLumiData*SumLumiMoca;
	}
        if(print > 1) cout<<"+++++ normalization factor Gamma = "<<Gamma<<endl;

	//TODO divide into different types (when input possible)
	//--------------- normalization factor for background ---------------------
	if(SumAbsWeightBack!=0) BackWeight = BackEventNr/SumAbsWeightBack;// BackWeight = STAB(9,bla)
}

