//	author: Natalie Milke <natalie.milke@uni-dortmund.de>
//	Dortmund, 2009
//	======================================================

//  Fit of orthogonal polynomial
//
//  Orthogonal polynomials up to the fourth power are fitted to the
//	data Y(1)...Y(N), assumed to be equidistant in x (with distance
//	1 between adjacent points).
//
//	Result:   c(0)  =  orth. coeff. of first power
//	c(1)  =  orth. coeff. of second power
//	c(2)  =  orth. coeff. of third power
//	c(3)  =  orth. coeff. of fourth power
//	c(4)  =  chisquare/ndf after subtraction of fourth order
//	polynomial from the data
//
//	Restriction: N = 5 or 7 or 9 or 11 or 13 only.

#include "FitPolynomial.h"
#include "math.h"
#include <iostream>
// ClassImp(FitPolynomial)

using namespace std;
FitPolynomial::FitPolynomial(){
};
FitPolynomial::~FitPolynomial(){};

void FitPolynomial::FitOfOrthPolyn(Double_t *Y, Double_t *Z, Double_t *W, Int_t N, Double_t *c) {
	Double_t cut[] = {0.0, 4.605, 7.779, 10.645, 13.362};
	Double_t cut1 = 1.645;
	Int_t INM[] = {0, 2, 5, 9, 14};
	Double_t Q[][20] =
	{
			{ 0.632456,  0.316228, 0.566947,  0.377965,  0.188965, 0.516398,  0.387298,  0.258199,  0.129099,  0.476731,  0.381385,  0.286039,  0.190693,  0.095346, 0.444750,  0.370625,  0.296500,  0.222375,  0.148250,  0.074125},
			{ 0.534523, -0.267261, 0.545545,  0.000000, -0.327327, 0.531816,  0.132955, -0.151947, -0.322888,  0.512092,  0.204837, -0.034139, -0.204836, -0.307255, 0.491690,  0.245845,  0.044700, -0.111747, -0.223494, -0.290543},
			{ 0.316228, -0.632455, 0.408248, -0.408248, -0.408248, 0.444950, -0.222474, -0.413167, -0.286039,  0.458030, -0.091605, -0.335887, -0.351155, -0.213746, 0.459934,  0.000000, -0.250872, -0.334496, -0.292685, -0.167248},
			{ 0.119523, -0.478092, 0.241747, -0.564076,  0.080582, 0.312894, -0.469340, -0.245845,  0.201145,  0.354790, -0.354786, -0.354787, -0.059131,  0.236525, 0.379458, -0.252972, -0.367959, -0.206977,  0.042161,  0.245306}
	};
	Double_t R[][5] =
	{
			{-0.534522, -0.436436, -0.379868, -0.341394, -0.312892},
			{ 0.717136,  0.483494,  0.402291,  0.354787,  0.321964}
	};

	Double_t  fc[4];
	Double_t  WE;
	Double_t  ye;
	Double_t  yo;
	Double_t sn2 = 1.0;
	Double_t m = (N/2)-1;
	Int_t M = static_cast<Int_t>(m);
	Int_t IN = INM[M-1];// M max = 5, M min = 1

	// determine mean value
	Double_t meanY = 0.0;
	for(Int_t i = 0; i < N; ++i) {
		meanY = meanY+Y[i];
	}
	meanY = meanY/static_cast<Double_t>(N);

	// unit factors
	for(Int_t j = 0; j < 4; ++j) {
		fc[j] = 1.0;
	}

	// sum for next coefficients
	c[0] = 0.0;
	c[1] = (Y[N/2]-meanY)*R[0][M-1];
	c[2] = 0.0;
	c[3] = (Y[N/2]-meanY)*R[1][M-1];
	c[4] = pow((Y[N/2]-meanY),2);

	for(Int_t k = 0; k < N/2; ++k) {
		c[0] = c[0]+((Y[N-1-k]-meanY)-(Y[k]-meanY))*Q[0][IN+k];
		c[1] = c[1]+((Y[N-1-k]-meanY)+(Y[k]-meanY))*Q[1][IN+k];
		c[2] = c[2]+((Y[N-1-k]-meanY)-(Y[k]-meanY))*Q[2][IN+k];
		c[3] = c[3]+((Y[N-1-k]-meanY)+(Y[k]-meanY))*Q[3][IN+k];

		// chi square sum
		c[4] = c[4]+pow((Y[N-1-k]-meanY),2)+pow((Y[k]-meanY),2);
	}

	c[4] = c[4]-pow(c[3],2)-pow(c[2],2)-pow(c[1],2)-pow(c[0],2);

	if(M == 1) c[4] = 0.0;
	if(fabs(c[0]) < 0.001) c[0] = 0.0;
	if(fabs(c[1]) < 0.001) c[1] = 0.0;
	if(fabs(c[2]) < 0.001) c[2] = 0.0;
	if(fabs(c[3]) < 0.001) c[3] = 0.0;

	// damping of coefficients
	if(c[4] <= cut[M-1]) {
		if(fabs(c[3]) < 2.588) {
			fc[3] = 0.0;
			c[3] = 0.0;
			if(fabs(c[2]) < cut1) {
				fc[2] = pow(c[2],2)/(pow(c[2],2)+sn2);
				c[2] = fc[2]*c[2];
				if(fabs(c[1]) < cut1) {
					fc[1] = pow(c[1],2)/(pow(c[1],2)+sn2);
					c[1] = fc[1]*c[1];
				}
			}
		}
	}

	// reconstruct function values - center value
	Z[N/2] = meanY+c[1]*R[0][M-1]+c[3]*R[1][M-1];
	WE = 1.0/static_cast<Double_t>(N)+pow(R[0][M-1],2)+pow((fc[3]*R[1][M-1]),2);
	W[N/2] = 1.0/WE;

	// ... and left/right values
	for(Int_t l = 0; l < (N/2); ++l) {
		ye = meanY+fc[1]*c[1]*Q[1][IN+l]+fc[3]*c[3]*Q[3][IN+l];
		yo = c[0]*Q[0][IN+l]+fc[2]*c[2]*Q[2][IN+l];
		Z[l] = ye-yo;
		Z[N-1-l] = ye+yo;
		WE = 1.0/static_cast<Double_t>(N)+pow(Q[0][IN+l],2)+pow((fc[1]*Q[1][IN+l]),2)+pow((fc[2]*Q[2][IN+l]),2)+pow((fc[3]*Q[3][IN+l]),2);
		W[l] = 1.0/WE;
		W[N-1-l] = 1.0/WE;
	}
}
