{
	gROOT->SetStyle("Plain");
	gStyle->SetPalette(1);
//	gStyle->SetOptStat(11);

	TBrowser b;
}
