####### Arrow:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_Arrow.conf cursors/X_cursor

cd cursors
ln -s X_cursor left_ptr
ln -s X_cursor right_ptr
ln -s X_cursor top_left_arrow
ln -s X_cursor move
ln -s X_cursor 4498f0e0c1937ffe01fd06f973665830
cd ..
####### Cross:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_Crosshair.conf cursors/cross

cd cursors
ln -s cross crosshair
ln -s cross cross_reverse
ln -s cross tcross
ln -s cross draped_box
cd ..
####### Help arrow:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_Help.conf cursors/question_arrow

cd cursors
ln -s question_arrow d9ce0ab605698f320427677b458ad60b
cd ..
####### I(text):
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_IBeam.conf cursors/xterm
####### URL Arrow:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_Link.conf cursors/hand

cd cursors
ln -s hand hand1
ln -s hand hand2
ln -s hand 9d800788f1b08800ae810202380a0822
ln -s hand e29285e634086352946a0e7090d73106
cd ..
####### Unavailable:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_NO.conf cursors/crossed_circle

cd cursors
ln -s crossed_circle 03b6e0fcb3499374a867c041f52298f0
cd ..
####### Pen:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_NWpen.conf cursors/pencil
####### Moving:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_SizeAll.conf cursors/fleur
####### Resize NESW:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_SizeNESW.conf cursors/bottom_left_corner

cd cursors
ln -s bottom_left_corner fd_double_arrow
ln -s bottom_left_corner ll_angle
ln -s bottom_left_corner top_right_corner
ln -s bottom_left_corner fcf1c3c7cd4491d801f1e1c78f100000
cd ..
####### Resize NWSE:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_SizeNWSE.conf cursors/bottom_right_corner

cd cursors
ln -s bottom_right_corner bd_double_arrow
ln -s bottom_right_corner lr_angle
ln -s bottom_right_corner top_left_corner
ln -s bottom_right_corner c7088f0f3e6c8088236ef8e1e3e70000
cd ..
####### Resize NS:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_SizeNS.conf cursors/bottom_side

cd cursors
ln -s bottom_side double_arrow
ln -s bottom_side 00008160000006810000408080010102
ln -s bottom_side sb_v_double_arrow
ln -s bottom_side top_side
ln -s bottom_side v_double_arrow
ln -s bottom_side 2870a09082c103050810ffdffffe0204
cd ..
####### Resize WE:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_SizeWE.conf cursors/right_side

cd cursors
ln -s right_side 028006030e0e7ebffc7f7070c0600140
ln -s right_side h_double_arrow
ln -s right_side left_side
ln -s right_side sb_h_double_arrow
ln -s right_side 14fef782d02440884392942c11205230
cd ..
####### UpArrow:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_UpArrow.conf cursors/center_ptr
####### BackgroundBusy:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_AppStarting.conf cursors/left_ptr_watch

cd cursors
ln -s left_ptr_watch right_ptr_watch
ln -s left_ptr_watch 08e8e1c95fe2fc01f976f1e063a24ccd
ln -s left_ptr_watch 3ecb610c1bf2410f44200f48c40d3599
cd ..
####### Busy:
xcursorgen -p vista-aero-cursors-png vista-aero-cursors-png/aero_Wait.conf cursors/watch