"""
Example of usage pytils with TurboGears
"""
