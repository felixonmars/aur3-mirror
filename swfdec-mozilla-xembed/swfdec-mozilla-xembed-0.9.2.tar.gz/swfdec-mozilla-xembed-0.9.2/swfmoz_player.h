#ifndef SWFMOZ_PLAYER_H
#define SWFMOZ_PLAYER_H

#include "swfmoz_loader.h"

#define SWFMOZ_TYPE_PLAYER                    (swfmoz_player_get_type())
#define SWFMOZ_IS_PLAYER(obj)                 (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SWFMOZ_TYPE_PLAYER))
#define SWFMOZ_IS_PLAYER_CLASS(klass)         (G_TYPE_CHECK_CLASS_TYPE ((klass), SWFMOZ_TYPE_PLAYER))
#define SWFMOZ_PLAYER(obj)                    (G_TYPE_CHECK_INSTANCE_CAST ((obj), SWFMOZ_TYPE_PLAYER, SwfmozPlayer))
#define SWFMOZ_PLAYER_CLASS(klass)            (G_TYPE_CHECK_CLASS_CAST ((klass), SWFMOZ_TYPE_PLAYER, SwfmozPlayerClass))
#define SWFMOZ_PLAYER_GET_CLASS(obj)          (G_TYPE_INSTANCE_GET_CLASS ((obj), SWFMOZ_TYPE_PLAYER, SwfmozPlayerClass))

typedef struct _SwfmozPlayer SwfmozPlayer;
typedef struct _SwfmozPlayerClass SwfmozPlayerClass;

struct _SwfmozPlayer {

    SwfdecGtkPlayer player;
    
    NPWindow *window;
    uint32 x, y;
    uint32 width, height;

    NPP instance;
    NPStream *initial;
    
    GtkTreeModel *loaders;
    GtkWidget *container;

};

struct _SwfmozPlayerClass {
    SwfdecGtkPlayerClass player_class;
};

GType swfmoz_player_get_type(void);
SwfdecBuffer *swfmoz_player_add_headers (SwfdecBuffer *data, guint header_count, const char **header_names, const char **header_values);
void swfmoz_player_add_loader (SwfmozPlayer *player, SwfmozLoader *loader);
gboolean swfmoz_player_set_initial_stream (SwfmozPlayer *player, NPStream *stream);
SwfdecPlayer *swfmoz_player_new (NPP instance);
void swfmoz_player_remove (SwfmozPlayer *player);

#endif