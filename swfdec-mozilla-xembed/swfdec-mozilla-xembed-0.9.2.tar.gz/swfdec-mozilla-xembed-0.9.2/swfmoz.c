#include "global.h"
#include "swfmoz_player.h"

/***********************************************************************
 *
 * SWFMOZ_LOADER
 *
 ***********************************************************************/

G_DEFINE_TYPE (SwfmozLoader, swfmoz_loader, SWFDEC_TYPE_LOADER)

static void swfmoz_loader_init (SwfmozLoader *slow_loader) {
	printf("Why is this here?\n");
}

static void swfmoz_loader_dispose (GObject *object) {
  SwfmozLoader *loader = SWFMOZ_LOADER (object);

  g_free (loader->cache_file);

  G_OBJECT_CLASS (swfmoz_loader_parent_class)->dispose (object);
}

void swfmoz_loader_set_stream (SwfmozLoader *loader, NPStream *stream) {
  g_return_if_fail (SWFMOZ_IS_LOADER (loader));
  g_return_if_fail (loader->stream == NULL);
  g_return_if_fail (stream != NULL);

  if (!loader->waiting_for_stream) {
    plugin_destroy_stream (*loader->instance, stream);
    return;
  }

  loader->waiting_for_stream = FALSE;

  g_printerr ("Loading stream: %s\n", stream->url);
  g_object_ref (loader);
  stream->pdata = loader;
  loader->stream = stream;
  
  if (stream->end)
    swfdec_loader_set_size (SWFDEC_LOADER (loader), stream->end);
}

static void swfmoz_loader_load (SwfdecLoader *loader, SwfdecPlayer *player, const char *url, SwfdecBuffer *buffer, guint header_count, const char **header_names, const char **header_values) {
  SwfmozPlayer *mozplay = SWFMOZ_PLAYER (player);
  SwfmozLoader *moz = SWFMOZ_LOADER (loader);

  moz->waiting_for_stream = TRUE;
  moz->instance = &mozplay->instance;
  if (mozplay->initial) {
    swfmoz_loader_set_stream (moz, mozplay->initial);
    mozplay->initial = NULL;
    moz->initial = TRUE;
  } else {
    g_object_ref (moz);
    if (buffer) {
      SwfdecBuffer *combined;

      combined = swfmoz_player_add_headers (buffer, header_count, header_names,
	  header_values);
      plugin_post_url_notify (*moz->instance, url, NULL, (char *)combined->data,
	  combined->length, moz);
      swfdec_buffer_unref (combined);
    } else {
      // FIXME: Impossible to set headers here?
      plugin_get_url_notify (*moz->instance, url, NULL, moz);
    }
  }
}

static void swfmoz_loader_close (SwfdecStream *stream) {
  SwfmozLoader *moz = SWFMOZ_LOADER (stream);

  moz->waiting_for_stream = FALSE;

  if (*moz->instance && moz->stream)
    plugin_destroy_stream (*moz->instance, moz->stream);
}

static void swfmoz_loader_class_init (SwfmozLoaderClass *klass) {
  GObjectClass *object_class = G_OBJECT_CLASS (klass);
  SwfdecStreamClass *stream_class = SWFDEC_STREAM_CLASS (klass);
  SwfdecLoaderClass *loader_class = SWFDEC_LOADER_CLASS (klass);

  object_class->dispose = swfmoz_loader_dispose;

  stream_class->close = swfmoz_loader_close;

  loader_class->load = swfmoz_loader_load;
}

void swfmoz_loader_ensure_open (SwfmozLoader *loader) {
  g_return_if_fail (SWFMOZ_IS_LOADER (loader));

  if (loader->open)
    return;
  swfdec_loader_set_url (SWFDEC_LOADER (loader), loader->stream->url);
  swfmoz_player_add_loader ((*loader->instance)->pdata, loader);
  swfdec_stream_open (SWFDEC_STREAM (loader));
  loader->open = TRUE;
}

const char *swfmoz_loader_get_data_type_string (SwfdecLoader *loader) {
  g_return_val_if_fail (SWFDEC_IS_LOADER (loader), NULL);

  switch (swfdec_loader_get_data_type (loader)) {
    case SWFDEC_LOADER_DATA_UNKNOWN:
      return "Unknown Data";
    case SWFDEC_LOADER_DATA_SWF:
      /* FIXME: what's a useful name for flash movies? */
      return "Flash Movie";
    case SWFDEC_LOADER_DATA_FLV:
      return "Flash Video";
    case SWFDEC_LOADER_DATA_TEXT:
      return "Text";
    case SWFDEC_LOADER_DATA_XML:
      return "XML Data";
    case SWFDEC_LOADER_DATA_JPEG:
      return "JPEG image";
    case SWFDEC_LOADER_DATA_PNG:
      return "PNG image";
    default:
      g_printerr ("unknown data type %u\n", 
	  (guint) swfdec_loader_get_data_type (loader));
      return "You should never read this";
  }
}

/***********************************************************************
 *
 * SWFMOZ_PLAYER
 *
 ***********************************************************************/

G_DEFINE_TYPE (SwfmozPlayer, swfmoz_player, SWFDEC_TYPE_GTK_PLAYER)

static void swfmoz_player_init (SwfmozPlayer *player) {
  player->loaders = GTK_TREE_MODEL (gtk_list_store_new (SWFMOZ_LOADER_N_COLUMNS,
      SWFMOZ_TYPE_LOADER, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING));
}

static void swfmoz_player_dispose (GObject *object) {
  G_OBJECT_CLASS (swfmoz_player_parent_class)->dispose (object);
}

static void swfmoz_player_get_property (GObject *object, guint param_id, GValue *value,  GParamSpec * pspec) {
  //SwfmozPlayer *player = SWFMOZ_PLAYER (object);
  
  switch (param_id) {
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, param_id, pspec);
      break;
  }
}

static void swfmoz_player_set_property (GObject *object, guint param_id, const GValue *value, GParamSpec *pspec) {
  //SwfmozPlayer *player = SWFMOZ_PLAYER (object);

  switch (param_id) {
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, param_id, pspec);
      break;
  }
}

static void swfmoz_player_class_init (SwfmozPlayerClass *klass) {
  GObjectClass *object_class = G_OBJECT_CLASS (klass);

  object_class->dispose = swfmoz_player_dispose;
  object_class->get_property = swfmoz_player_get_property;
  object_class->set_property = swfmoz_player_set_property;
}

static void swfmoz_player_loaders_update (GtkListStore *store, GtkTreeIter *iter, SwfdecLoader *loader) {
  goffset loaded, size;
  gboolean error;
  const SwfdecURL *url;
  SwfdecPlayer *player;
  const char *url_string;
  char *str_loaded, *str_size;
  gchar *status, *s = NULL;

  loaded = swfdec_loader_get_loaded (loader);
  size = swfdec_loader_get_size (loader);

  /* FIXME: swfdec needs a function for this */
  g_object_get (G_OBJECT (loader), "error", &error, NULL);

  if (error == TRUE) {
    status = g_strdup("error");
  } else {
    str_loaded = g_format_size_for_display(loaded);
    str_size = g_format_size_for_display(size);
#if 0
    if (swfdec_stream_is_complete (SWFDEC_STREAM (loader))) {
      status = g_strdup_printf("%s", str_loaded);
    } else if (size < 0 || (size < loaded)) {
      status = g_strdup_printf("at %s", str_loaded);
    } else {
      status = g_strdup_printf("%s of %s", str_loaded, str_size);
    }
#endif
    status = g_strdup_printf("%s of %s", str_loaded, str_size);
    
    g_free (str_loaded);
    g_free (str_size);
  }

  url = swfdec_loader_get_url (loader);
  player = (*SWFMOZ_LOADER (loader)->instance)->pdata;
  if (url && SWFMOZ_LOADER (loader)->initial && swfdec_player_get_variables (player)) {
    /* This auto-appends the FlashVars to the reported URL. You should be able
     * to copy/paste that URL easily without breakage that way 
     * (minus cookies and referer) */
    s = g_strconcat (swfdec_url_get_url (url),
	swfdec_url_get_query (url) ? "&" : "?",
	swfdec_player_get_variables (player), NULL);
    url_string = s;
  } else if (url) {
    url_string = swfdec_url_get_url (url);
  } else if (SWFMOZ_LOADER (loader)->stream) {
    url_string = SWFMOZ_LOADER (loader)->stream->url;
  } else {
    /* we don't store URLs of requests */
    url_string = "";
  }

  gtk_list_store_set (store, iter,
    SWFMOZ_LOADER_COLUMN_LOADER, loader,
    SWFMOZ_LOADER_COLUMN_URL, url_string,
    SWFMOZ_LOADER_COLUMN_TYPE, swfmoz_loader_get_data_type_string (loader),
    SWFMOZ_LOADER_COLUMN_STATUS, status,
    -1);

  g_free (status);
  g_free (s);
}

static gboolean swfmoz_player_find_loader (GtkListStore *store, SwfdecLoader *loader, GtkTreeIter *iter) {
  GtkTreeModel *model = GTK_TREE_MODEL (store);

  if (!gtk_tree_model_get_iter_first (model, iter))
    return FALSE;
  do {
    SwfdecLoader *comp;
    gtk_tree_model_get (model, iter, SWFMOZ_LOADER_COLUMN_LOADER, &comp, -1);
    g_object_unref (comp);
    if (comp == loader)
      return TRUE;
  } while (gtk_tree_model_iter_next (model, iter));
  return FALSE;
}

static void swfmoz_player_loader_notify_cb (SwfdecLoader *loader, GParamSpec *pspec, GtkListStore *store) {
  GtkTreeIter iter;

  if (!swfmoz_player_find_loader (store, loader, &iter)) {
    g_assert_not_reached ();
  }
  swfmoz_player_loaders_update (store, &iter, loader);
}

static SwfdecBuffer *swfmoz_player_format_headers (guint header_count, const char **header_names, const char **header_values, gsize content_length) {
  GString *string;
  guint i;
  gsize len;

  g_return_val_if_fail (header_count == 0 || header_names != NULL, NULL);
  g_return_val_if_fail (header_count == 0 || header_values != NULL, NULL);

  string = g_string_new ("Content-Length: ");
  g_string_append_printf (string, "%"G_GSIZE_FORMAT, content_length);
  g_string_append (string, "\n");
  for (i = 0; i < header_count; i++) {
    g_string_append (string, header_names[i]);
    g_string_append (string, ": ");
    g_string_append (string, header_values[i]);
    g_string_append (string, "\n");
  }
  g_string_append (string, "\n");

  len = string->len;
  return swfdec_buffer_new_for_data (
      (unsigned char *)g_string_free (string, FALSE), len);
}

SwfdecBuffer *swfmoz_player_add_headers (SwfdecBuffer *data, guint header_count, const char **header_names, const char **header_values) {
  SwfdecBufferQueue *queue;
  SwfdecBuffer *buffer;

  g_return_val_if_fail (data != NULL, NULL);

  queue = swfdec_buffer_queue_new ();
  swfdec_buffer_queue_push (queue, swfmoz_player_format_headers (
	header_count, header_names, header_values, data->length));
  swfdec_buffer_queue_push (queue, swfdec_buffer_ref (data));

  buffer = swfdec_buffer_queue_pull (queue,
      swfdec_buffer_queue_get_depth (queue));
  swfdec_buffer_queue_unref (queue);

  return buffer;
}

void swfmoz_player_add_loader (SwfmozPlayer *player, SwfmozLoader *loader) {
  GtkTreeIter iter;
  
  g_return_if_fail (SWFMOZ_IS_PLAYER (player));
  g_return_if_fail (SWFMOZ_IS_LOADER (loader));

  /* add loader to the list of loaders */
  g_signal_connect (loader, "notify", G_CALLBACK (swfmoz_player_loader_notify_cb),
      GTK_LIST_STORE (player->loaders));
  gtk_list_store_append (GTK_LIST_STORE (player->loaders), &iter);
  swfmoz_player_loaders_update (GTK_LIST_STORE (player->loaders), &iter, 
      SWFDEC_LOADER (loader));
}

gboolean swfmoz_player_set_initial_stream (SwfmozPlayer *player, NPStream *stream) {
  SwfdecURL *url;

  g_return_val_if_fail (SWFMOZ_IS_PLAYER (player), FALSE);
  g_return_val_if_fail (stream != NULL, FALSE);

  if (player->initial || swfdec_player_get_url (SWFDEC_PLAYER (player)))
    return FALSE;
  player->initial = stream;
  url = swfdec_url_new (stream->url);
  if (url == NULL) {
    g_printerr ("%s is either a broken URL or Swfdec can't parse it\n",
	stream->url);
    return FALSE;
  }
  swfdec_player_set_url (SWFDEC_PLAYER (player), url);
  swfdec_gtk_player_set_playing (SWFDEC_GTK_PLAYER (player), TRUE);

  swfdec_url_free (url);

  return TRUE;
}

SwfdecPlayer *swfmoz_player_new (NPP instance) {
  SwfmozPlayer *ret;
  SwfdecSystem *system;

  system = swfdec_gtk_system_new (NULL);
  g_object_set (system, "player-type", "PlugIn", NULL);
  ret = g_object_new (SWFMOZ_TYPE_PLAYER,
      "loader-type", SWFMOZ_TYPE_LOADER, "socket-type", SWFDEC_TYPE_SOCKET,
      "system", system,
      NULL);
  ret->instance = instance;

  return SWFDEC_PLAYER (ret);
}

void swfmoz_player_remove (SwfmozPlayer *player) {
  g_return_if_fail (SWFMOZ_IS_PLAYER (player));

  swfdec_gtk_player_set_playing (SWFDEC_GTK_PLAYER (player), FALSE);
  swfdec_gtk_player_set_audio_enabled (SWFDEC_GTK_PLAYER (player), FALSE);
  gtk_widget_destroy (player->container);
  player->instance = NULL;
  g_object_unref (player);
}