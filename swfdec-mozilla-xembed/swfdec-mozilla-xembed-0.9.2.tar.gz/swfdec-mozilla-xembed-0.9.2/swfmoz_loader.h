#ifndef SWFMOZ_LOADER_H
#define SWFMOZ_LOADER_H

/* I don't know what this does */
enum {
  SWFMOZ_LOADER_COLUMN_LOADER,
  SWFMOZ_LOADER_COLUMN_URL,
  SWFMOZ_LOADER_COLUMN_TYPE,
  SWFMOZ_LOADER_COLUMN_STATUS,
  SWFMOZ_LOADER_N_COLUMNS
};

#define SWFMOZ_TYPE_LOADER                    (swfmoz_loader_get_type())
#define SWFMOZ_IS_LOADER(obj)                 (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SWFMOZ_TYPE_LOADER))
#define SWFMOZ_IS_LOADER_CLASS(klass)         (G_TYPE_CHECK_CLASS_TYPE ((klass), SWFMOZ_TYPE_LOADER))
#define SWFMOZ_LOADER(obj)                    (G_TYPE_CHECK_INSTANCE_CAST ((obj), SWFMOZ_TYPE_LOADER, SwfmozLoader))
#define SWFMOZ_LOADER_CLASS(klass)            (G_TYPE_CHECK_CLASS_CAST ((klass), SWFMOZ_TYPE_LOADER, SwfmozLoaderClass))
#define SWFMOZ_LOADER_GET_CLASS(obj)          (G_TYPE_INSTANCE_GET_CLASS ((obj), SWFMOZ_TYPE_LOADER, SwfmozLoaderClass))

typedef struct _SwfmozLoader SwfmozLoader;
typedef struct _SwfmozLoaderClass SwfmozLoaderClass;

struct _SwfmozLoader
{
  SwfdecLoader		parent;

  NPP *			instance;	/* pointer to instance we belong to or to NULL if we don't belong to any instance */
  NPStream *		stream;		/* stream we do or NULL if not created yet */
  gboolean		initial;	/* we are the initial loader */

  gboolean		waiting_for_stream;
  char *		cache_file;	/* where the file is cached */
  gboolean		open;		/* TRUE when data has arrived */
};

struct _SwfmozLoaderClass
{
  SwfdecLoaderClass loader_class;
};

GType swfmoz_loader_get_type (void);
void swfmoz_loader_ensure_open (SwfmozLoader *loader);
void swfmoz_loader_set_stream (SwfmozLoader *loader, NPStream *stream);

#endif