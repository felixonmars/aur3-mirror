/* -*- Mode: C; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 2 -*-
 *
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is mozilla.org code.
 *
 * The Initial Developer of the Original Code is
 * Netscape Communications Corporation.
 * Portions created by the Initial Developer are Copyright (C) 1998
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *   Stephen Mak <smak@sun.com>
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

/*
 * npshell.c
 *
 * Netscape Client Plugin API
 * - Function that need to be implemented by plugin developers
 *
 * This file defines a "shell" plugin that plugin developers can use
 * as the basis for a real plugin.  This shell just provides empty
 * implementations of all functions that the plugin can implement
 * that will be called by Netscape (the NPP_xxx methods defined in 
 * npapi.h). 
 *
 * dp Suresh <dp@netscape.com>
 * updated 5/1998 <pollmann@netscape.com>
 * updated 9/2000 <smak@sun.com>
 *
 */


/*
The contents of this file are subject to the Mozilla Public License

Version 1.1 (the "License"); you may not use this file except in compliance 
with the License. You may obtain a copy of the License at http://www.mozilla.org/MPL/

Software distributed under the License is distributed on an "AS IS" basis, 
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for 
the specific language governing rights and limitations under the License.

The Original Code is stub code that defines the binary interface to a Mozilla
plugin.

The Initial Developer of the Original Code is Mozilla.

Portions created by Adobe Systems Incorporated are Copyright (C) 2007. All Rights Reserved.

Contributor(s): Adobe Systems Incorporated.
*/

#include "global.h"
#include "swfmoz_player.h"

/***********************************************************************
 *
 * Implementations of plugin API functions
 *
 ***********************************************************************/

char *NPP_GetMIMEDescription(void) {
    printf("NPP_GetMIMEDescription()\n");
    return(MIME_TYPES_HANDLED);
}

NPError NPP_GetValue(NPP instance, NPPVariable variable, void *value) {
    NPError err = NPERR_NO_ERROR;

    printf("NPP_GetValue(%d)\n", variable);
    switch (variable) {
        case NPPVpluginNameString:
            *((char **)value) = PLUGIN_NAME;
            break;
        case NPPVpluginDescriptionString:
            *((char **)value) = PLUGIN_DESCRIPTION;
            break;
        case NPPVpluginNeedsXEmbed:
            *((PRBool *)value) = PR_TRUE;
            break;
        default:
            err = NPERR_GENERIC_ERROR;
    }
    return err;
}

NPError NPP_Initialize(void) {
    printf("NPP_Initialize()\n");

    gtk_init(0, 0);
    swfdec_init();

    return NPERR_NO_ERROR;
}

#ifdef OJI
jref NPP_GetJavaClass() {
    return NULL;
}
#endif

void NPP_Shutdown(void) {
    printf("NPP_Shutdown()\n");
}

NPError NPP_New(NPMIMEType pluginType, NPP instance, uint16 mode, int16 argc, char* argn[], char* argv[], NPSavedData* saved) {
    
    SwfdecPlayer* player;
    guint i;
    int xembedSupported = 0;

    printf("NPP_New()\n");

    /* if the browser does not support XEmbed, let it down easy at this point */
    NPN_GetValue(instance, NPNVSupportsXEmbedBool, &xembedSupported);
    if (!xembedSupported)
    {
        printf("Swfdec: XEmbed not supported\n");
        return NPERR_GENERIC_ERROR;
    }

    if (instance == NULL)
        return NPERR_INVALID_INSTANCE_ERROR;

    instance->pdata = player = swfmoz_player_new(instance);
    
    for (i = 0; i < argc; i++) {
        if (argn[i] == NULL)
            continue;
        if (g_ascii_strcasecmp (argn[i], "flashvars") == 0) {
            if (argv[i])
	            swfdec_player_set_variables (player, argv[i]);
        } else if (g_ascii_strcasecmp (argn[i], "scale") == 0) {
            SwfdecScaleMode scale;
            if (g_ascii_strcasecmp (argv[i], "noborder") == 0) {
	            scale = SWFDEC_SCALE_NO_BORDER;
            } else if (g_ascii_strcasecmp (argv[i], "exactfit") == 0) {
	            scale = SWFDEC_SCALE_EXACT_FIT;
            } else if (g_ascii_strcasecmp (argv[i], "noscale") == 0) {
	            scale = SWFDEC_SCALE_NONE;
            } else {
	            scale = SWFDEC_SCALE_SHOW_ALL;
            }
            swfdec_player_set_scale_mode (player, scale);
        } else if (g_ascii_strcasecmp (argn[i], "salign") == 0) {
            struct { const char *	name; SwfdecAlignment	align; } possibilities[] = {
              { "t", SWFDEC_ALIGNMENT_TOP },
              { "l", SWFDEC_ALIGNMENT_LEFT },
              { "r", SWFDEC_ALIGNMENT_RIGHT },
              { "b", SWFDEC_ALIGNMENT_BOTTOM },
              { "tl", SWFDEC_ALIGNMENT_TOP_LEFT },
              { "tr", SWFDEC_ALIGNMENT_TOP_RIGHT },
              { "bl", SWFDEC_ALIGNMENT_BOTTOM_LEFT },
              { "br", SWFDEC_ALIGNMENT_BOTTOM_RIGHT }
            };
            SwfdecAlignment align = SWFDEC_ALIGNMENT_CENTER;
            guint j;

            for (j = 0; j < G_N_ELEMENTS (possibilities); j++) {
                if (g_ascii_strcasecmp (argv[i], possibilities[j].name) == 0) {
                    align = possibilities[j].align;
                    break;
                  }
            }
            swfdec_player_set_alignment (player, align);
        }
    }
    
    return NPERR_NO_ERROR;
}

NPError NPP_Destroy(NPP instance, NPSavedData** save) {
    printf("NPP_Destroy()\n");
    
    if (instance == NULL || !SWFMOZ_IS_PLAYER (instance->pdata))
        return NPERR_INVALID_INSTANCE_ERROR;

    swfmoz_player_remove (instance->pdata);
    instance->pdata = NULL;
    return NPERR_NO_ERROR;
}


NPError NPP_SetWindow(NPP instance, NPWindow* window) {
    printf("NPP_SetWindow()\n");
    
    if (instance == NULL || !SWFMOZ_IS_PLAYER (instance->pdata))
        return NPERR_INVALID_INSTANCE_ERROR;

    return SwfmozSetWindow(instance, window); 
}


NPError NPP_NewStream(NPP instance, NPMIMEType type, NPStream* stream, NPBool seekable, uint16* stype) {
    printf("NPP_NewStream()\n");
    if (instance == NULL || !SWFMOZ_IS_PLAYER (instance->pdata))
        return NPERR_INVALID_INSTANCE_ERROR;

    if (!SWFMOZ_IS_LOADER (stream->notifyData)) {
        if (!swfmoz_player_set_initial_stream (instance->pdata, stream))
            return NPERR_INVALID_URL;
    } else {
        swfmoz_loader_set_stream (stream->notifyData, stream);
    }
  
    if (stype)
        *stype = NP_ASFILE;
    
    return NPERR_NO_ERROR;
}

int32 NPP_WriteReady(NPP instance, NPStream *stream) {
    printf("NPP_WriteReady()\n");
    if (instance == NULL || !SWFMOZ_IS_PLAYER (instance->pdata))
        return -1;
    if (!SWFMOZ_IS_LOADER (stream->pdata))
        return -1;

    return G_MAXINT32;
}


int32 NPP_Write(NPP instance, NPStream *stream, int32 offset, int32 len, void *buffer) {
    printf("NPP_Write()\n");
    SwfdecBuffer *new;
  
    if (instance == NULL || !SWFMOZ_IS_PLAYER (instance->pdata))
        return -1;
    if (!SWFMOZ_IS_LOADER (stream->pdata))
        return -1;

    new = swfdec_buffer_new_for_data (g_memdup (buffer, len), len);
    swfmoz_loader_ensure_open (stream->pdata);
    swfdec_stream_push (stream->pdata, new);
    return len;
}


NPError NPP_DestroyStream(NPP instance, NPStream *stream, NPError reason) {
    printf("NPP_DestroyStream()\n");
    if (instance == NULL || !SWFMOZ_IS_PLAYER (instance->pdata))
        return NPERR_INVALID_INSTANCE_ERROR;
    if (!SWFMOZ_IS_LOADER (stream->pdata))
        return NPERR_INVALID_INSTANCE_ERROR;
    
    swfmoz_loader_ensure_open (stream->pdata);
    swfdec_stream_close (stream->pdata);
    SWFMOZ_LOADER (stream->pdata)->stream = NULL;
    
    if (SWFMOZ_PLAYER (instance->pdata)->initial == stream->pdata)
        SWFMOZ_PLAYER (instance->pdata)->initial = NULL;
        
    g_object_unref (stream->pdata);
    return NPERR_NO_ERROR;
}


void NPP_StreamAsFile(NPP instance, NPStream *stream, const char* filename) {
    printf("NPP_StreamAsFile()\n");
    SwfmozLoader *loader;

    if (instance == NULL || !SWFMOZ_IS_PLAYER (instance->pdata))
        return;
    if (!SWFMOZ_IS_LOADER (stream->pdata))
        return;

    loader = stream->pdata;
    g_free (loader->cache_file);
    loader->cache_file = g_strdup (filename);
}


void NPP_URLNotify(NPP instance, const char* url, NPReason reason, void* notifyData) {
    printf("NPP_URLNotify()\n");
    SwfdecStream *stream;

    if (notifyData == NULL)
        return;

    stream = SWFDEC_STREAM (notifyData);

    if (reason == NPRES_NETWORK_ERR) {
        swfdec_stream_error (stream, "Network error");
    } else if (reason == NPRES_USER_BREAK) {
        swfdec_stream_error (stream, "User interrupt");
    }
    
    g_object_unref (stream);
}


void 
NPP_Print(NPP instance, NPPrint* printInfo)
{
    printf("NPP_Print()\n");
    
    return;
}

int16 NPP_HandleEvent(NPP instance, void* event)
{
    printf("NPP_HandleEvent()\n");
    
    if (instance == NULL || !SWFMOZ_IS_PLAYER (instance->pdata))
        return FALSE;
    
    //return DiamondXHandleEvent(instance, event);
    return TRUE;
}
