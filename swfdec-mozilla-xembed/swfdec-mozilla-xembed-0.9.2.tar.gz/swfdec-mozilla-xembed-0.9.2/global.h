#ifndef GLOBAL_H
#define GLOBAL_H

#include <swfdec-gtk/swfdec-gtk.h>
#include "npapi.h"

#define PLUGIN_NAME         "Shockwave Flash"
#define MIME_TYPES_HANDLED  "application/x-shockwave-flash:swf:Adobe Flash movie;application/futuresplash:spl:FutureSplash movie"
#define PLUGIN_DESCRIPTION  "Shockwave Flash 10.0 r999"

void plugin_get_url (NPP instance, const char *url, const char *target);
void plugin_get_url_notify (NPP instance, const char *url, const char *target, void *data);
void plugin_post_url (NPP instance, const char *url, const char *target, const char *data, unsigned int data_len);
void plugin_post_url_notify (NPP instance, const char *url, const char *target, const char *data, unsigned int data_len, void *user_data);
void plugin_destroy_stream (NPP instance, NPStream *stream);

#endif
