#!/bin/bash
# Localize
TEXTDOMAIN=openbox-gnome-places
# License
if [ ! -z "$1" ]; then
	clear
	cat <<EOF
    openbox-gnome-places version 0.2.2

    Dynamically generates a menu for the Openbox3-Windowmanager
    that tries to resemble the Gnome2 Places-Menu.

    Copyright (C) 2008  3ED <krzysztof1987/at/gmail/dot/com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
EOF
	exit 0
fi

# This is functions, don't edit it
function bookmarks_menu {
  echo '<menu id="bookmark-menu" label="'$"Bookmarks"'">'
	# perl regexp: generating menu; decoding hex chars
	# PS. perl is very fast and easy to use
  cat $HOME/.gtk-bookmarks \
	|perl -pe 's#^file://(.*) (.*)$#<<<\1>>><<<\2>>>#g; s#^file://(.*)/(.*)$#<<<\1/\2>>><<<\2>>>#g; s#^<<<(.*)>>><<<(.*)>>>$#<item label="\2"\>\<action name="Execute"\>\<execute>'"$FILE_BROWSER"' "\1"\</execute\>\</action\>\<\/item\>#g; s/%([a-fA-F0-9]{2})/chr(hex($1))/ge; s#&#and#g'
	#old#|perl -pe 's|^file://(.*) (.*)$|\<item label="\2"\>\<action name="Execute"\>\<execute>'"$FILE_BROWSER"' "\1"\</execute\>\</action\>\<\/item\>|g; s/%([a-fA-F0-9]{2})/chr(hex($1))/ge;'
	echo '</menu>'
}
function recentlyused_menu {
  echo '<menu id="recentdocuments-menu" label="'$"Recent Documents"'">'
	# perl regexp: printing uri; deleting empty lines;
	#              decoding hex chars; generating menu
	# 0.2.2: add-fix: `&` --> `and` # btw. openbox-xml is stupid ;p
	cat $HOME/.recently-used \
	|perl -pe 's:<URI>(.*)</URI>|.*:\1:g; s/(^|\n)[\n\s]*/$1/g; s/%([a-fA-F0-9]{2})/chr(hex($1))/ge; s|^(file:///.*/)(.*)$|<item label="\2"><action name="Execute"><execute>'"$OPEN_WRAPPER"' "\1\2"</execute></action></item>|g; s#&#and#g'
	echo '	<separator />'
	echo '	<item label="'$"Clear this list"'">'
	cat <<EOF
		<action name="Execute">
			<execute>rm ${HOME}/.recently-used</execute>
		</action>"
	</item>
</menu>
EOF
}
function print_item {
cat <<EOF
	<item label="$1">"
		<action name="Execute">
		<execute>$2 $(if [ ! -z "$3" ]; then echo "\"$3\""; fi)</execute>
		</action>
	</item>
EOF
}
function separator {
echo '<separator />'
}

echo "<openbox_pipe_menu>"

CONF="openbox-gnome-places.conf"

if [ -f "$HOME/.$CONF" ]; then
	. "$HOME/.$CONF"
else
	if [ -f "/etc/$CONF" ];then
		. "/etc/$CONF"
	else
					echo '<item label="'$"Config file not found.."'"></item>'
	fi
fi

echo '</openbox_pipe_menu>'
