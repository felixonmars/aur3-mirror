#ifndef MLEN
#define MLEN 128			/* needed for slcompress.h */
#endif
