#!/bin/bash

LP=`pwd`

if [ `id -u` -ne 0 ];
then
echo -e "\033[31mNot enough permissions to uninstall. Please login as root.\033[0m"
exit 1
else
echo -e "\033[33mUninstalling driver\033[0m"
/bin/cp -f /etc/fstab /etc/fstab.ufsd
/bin/echo -n >/etc/fstab
while read -a entry;do
    device=${entry[0]}
    mountpoint=${entry[1]}
    type=${entry[2]}
    options=${entry[3]}
    freq=${entry[4]}
    passno=${entry[5]}
    if [[ $options == *dev=ufsd* || $type == *ufsd* ]];then
	    umount $device >/dev/null 2>&1
	    rmdir $mountpoint >/dev/null 2>&1
	    echo "removing line $device $mountpoint $options $type $passno $freq $passno from fstab"
    else
	    echo "$device $mountpoint $type $options $freq $passno" >>/etc/fstab
    fi
done < /etc/fstab.ufsd


[ "`find /lib/modules/\`uname -r\` -iname ufsd.ko`" ] && rm -f `find /lib/ -iname ufsd.ko`
[ "`find /lib/modules/\`uname -r\` -iname jnl.ko`" ] && rm -f `find /lib/ -iname jnl.ko`
depmod -a


if [ -a Makefile ]
then
/usr/bin/make driver_uninstall
fi

echo -e "\033[33mDriver uninstalled!\033[0m"


if [ -d linutil ];
then
echo -e "\033[33mWould you like to uninstall NTFS/HFS utilites? [yes/no]\033[0m"
read answer
case "$answer" in
y|Y|yes|Yes|YES)
if [ -d /usr/src/paragon-ufsd-89/linutil/ ]
then
cd /usr/src/paragon-ufsd-89/linutil/
/usr/bin/make remove
cd $LP
else
cd linutil/
/usr/bin/make remove
fi
echo -e "\033[33mUtilities uninstalled!\033[0m"
   ;;
*)
   ;;
esac
fi

if [ -d /usr/src/paragon-ufsd-89 ]
    then
        dkms uninstall -m paragon-ufsd -v 89 > /dev/null 2>&1
        dkms remove -m paragon-ufsd -v 89 --all > /dev/null 2>&1
        rm -rf /usr/src/paragon-ufsd-89 > /dev/null 2>&1
        rm -rf /var/lib/dkms/paragon-ufsd > /dev/null 2>&1
fi
fi
