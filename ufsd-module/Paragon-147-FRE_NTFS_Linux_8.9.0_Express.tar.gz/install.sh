#!/bin/bash

LP=`pwd`

run_install_driver() {
echo -e "\033[31mContinue installing? [yes/no/read].\033[0m"
read answer
case "$answer" in
y|Y|yes|Yes|YES)

echo "================= UFSD install log ===================" > $LP/paragon-ufsd-install.log
echo "Start: "`date`  2>&1  >> $LP/paragon-ufsd-install.log
echo "OS Version: "`uname -a`  2>&1 >> $LP/paragon-ufsd-install.log
echo -e "\033[32mSearching and removing previously installed UFSD driver in /lib/modules/`uname -r`/\033[0m" | tee -a $LP/paragon-ufsd-install.log
[ "`find /lib/modules/\`uname -r\` -iname ufsd.ko`" ] && rm -f `find /lib/ -iname ufsd.ko`
[ "`find /lib/modules/\`uname -r\` -iname jnl.ko`" ] && rm -f `find /lib/ -iname jnl.ko`

if ! [ -d util/ ]
then
touch express.version
fi

#################################################################################################
# Next options such as dkms support and additional utilities are available in Professional      #
# version only.                                                                                 #
# Please consider buying Paragon NTF/HFS for Linux Professional if you want to make them work.  #
# http://www.paragon-software.com/home/ntfs-linux-professional/                                 #
#################################################################################################

	if [ -a util/paragon-dkms.conf ]
	then
	echo -e "\033[33mWould you like UFSD driver to rebuild after kernel updates? [yes/no]\033[0m"
	read answer
	case "$answer" in
	y|Y|yes|Yes|YES)

		if ! which dkms > /dev/null
		then
		echo -e "\033[32mError: please install dkms package first\033[0m" | tee -a $LP/paragon-ufsd-install.log
		else

		[ -d /usr/src/paragon-ufsd-89 ] && rm -rf /usr/src/paragon-ufsd-89
		[ -d /var/lib/dkms/paragon-ufsd/ ] && rm -rf /var/lib/dkms/paragon-ufsd/

		if [ -x "`which systemd`" ]
		then
			if ! [ "`systemctl status dkms_autoinstaller | grep active`" ]
			then
			echo -e "\033[31mService dkms_autoinstaller is disabled or not installed. Driver may not rebuild with kernel updates.\033[0m"  | tee -a $LP/paragon-ufsd-install.log
			echo -e "\033[31mPlease run 'insserv /usr/lib/dkms/dkms_autoinstaller' to install and\or 'systemctl start dkms_autoinstaller' to enable it.\033[0m"  | tee -a $LP/paragon-ufsd-install.log
			fi
		fi

		echo -e "\033[32mSetting DKMS configuration\033[0m" | tee -a $LP/paragon-ufsd-install.log
		mkdir /usr/src/paragon-ufsd-89/
		cp -r ./ /usr/src/paragon-ufsd-89/
		mv /usr/src/paragon-ufsd-89/util/paragon-dkms.conf /usr/src/paragon-ufsd-89/dkms.conf
		dkms add -m paragon-ufsd -v 89 >> $LP/paragon-ufsd-install.log
		echo -e "\033[32mPreparing to install\033[0m" | tee -a $LP/paragon-ufsd-install.log
		dkms build -m paragon-ufsd -v 89 >> $LP/paragon-ufsd-install.log
		
			if [ "$?" != "0" ]
			then
			echo -e "\033[31mCan't prepare driver configuration\033[0m" | tee -a $LP/paragon-ufsd-install.log
			echo "=====\/\/\/========= DKMS Configure log ==========\/\/\/======" >> $LP/paragon-ufsd-install.log
			cat /var/lib/dkms/paragon-ufsd/89/`uname -r`/`uname -m`/log/make.log >> $LP/paragon-ufsd-install.log
			echo "=====/\/\/\========= DKMS Configure log ==========/\/\/\======" >> $LP/paragon-ufsd-install.log
			exit 1
			fi

		echo "=====\/\/\/========= DKMS Configure log ==========\/\/\/======" >> $LP/paragon-ufsd-install.log
		cat /var/lib/dkms/paragon-ufsd/89/`uname -r`/`uname -m`/log/make.log >> $LP/paragon-ufsd-install.log
		echo "=====/\/\/\========= DKMS Configure log ==========/\/\/\======" >> $LP/paragon-ufsd-install.log		


		echo -e "\033[32mBuilding and installing driver to kernel `uname -r`\033[0m"  | tee -a $LP/paragon-ufsd-install.log
		dkms install -m paragon-ufsd -v 89 >> $LP/paragon-ufsd-install.log
		
			if [ "$?" != "0" ]			
			then
			echo -e "\033[31mCan't build driver\033[0m" | tee -a $LP/paragon-ufsd-install.log
			exit 1
			fi
		
		echo -e "\033[32mDriver was installed to system\033[0m" | tee -a $LP/paragon-ufsd-install.log
		fi
	;;
	*)
	touch no_dkms.version
	;;
	esac
	fi

	if [ -a express.version -o -a no_dkms.version ]
	then
	echo -e "\033[32mPreparing to install\033[0m" | tee -a $LP/paragon-ufsd-install.log
	
		[ -a Makefile ] && make clean >> $LP/paragon-ufsd-install.log

		if ! ./configure >> $LP/paragon-ufsd-install.log 2>&1
		then
		echo -e "\033[31mCan't prepare driver configuration\033[0m" | tee -a $LP/paragon-ufsd-install.log
		echo "=====\/\/\/========= Configure log ==========\/\/\/======" >> $LP/paragon-ufsd-install.log
		cat config.log >> $LP/paragon-ufsd-install.log
		echo "=====/\/\/\========= Configure log ==========/\/\/\======" >> $LP/paragon-ufsd-install.log
		exit 1
		fi
	
	echo -e "\033[32mBuilding driver to kernel `uname -r`\033[0m"  | tee -a $LP/paragon-ufsd-install.log

		if ! make driver >> $LP/paragon-ufsd-install.log 2>&1
		then
		echo -e "\033[31mCan't build driver\033[0m" | tee -a $LP/paragon-ufsd-install.log
		exit 1
		fi

	echo -e "\033[32mInstall driver to kernel `uname -r`\033[0m"  | tee -a $LP/paragon-ufsd-install.log

		if ! make driver_install >> $LP/paragon-ufsd-install.log 2>&1
		then
		echo -e "\033[31mCan't install driver\033[0m" | tee -a $LP/paragon-ufsd-install.log
		exit 1
		fi

	echo -e "\033[32mDriver was installed to system\033[0m" | tee -a $LP/paragon-ufsd-install.log
	fi

	if [ -x "`which systemd`" ]
	then
	echo -e "\033[32mSetting driver autoload at system startup\033[0m" | tee -a $LP/paragon-ufsd-install.log
	echo ufsd > /etc/modules-load.d/paragon-ufsd.conf
	fi

	if [ -d linutil ];
	then
	echo -e "\033[33mWould you like to install NTFS/HFS utilites? [yes/no]\033[0m"
	read answer
	case "$answer" in
	y|Y|yes|Yes|YES)
	
	
	which mkntfs > /dev/null 2>&1
		if [ "$?" != "1" ]			
		then
		for i in $(which -a mkntfs) ; do
		mv ${i} ${i}_
		done
		fi

		if [ -d /usr/src/paragon-ufsd-89/linutil/ ]
		then
		cd /usr/src/paragon-ufsd-89/linutil/
		else
		cd linutil/
		fi

	echo -e "\033[32mMaking NTFS/HFS utilites\033[0m" | tee -a $LP/paragon-ufsd-install.log

		if ! make >> $LP/paragon-ufsd-install.log 2>&1
		then
		echo -e "\033[31mCan't make utilites\033[0m" | tee -a $LP/paragon-ufsd-install.log
		exit -1
		fi

	echo -e "\033[32mInstalling NTFS/HFS utilites\033[0m" | tee -a $LP/paragon-ufsd-install.log

		if ! make install >> $LP/paragon-ufsd-install.log 2>&1
		then
		echo -e "\033[31mCan't install utilites\033[0m" | tee -a $LP/paragon-ufsd-install.log
		exit -1
		fi

	echo -e "\033[32mUtilites installed\033[0m" | tee -a $LP/paragon-ufsd-install.log
	cd $LP
   	;;
	*)
   	;;
	esac
	fi

echo -e "\033[32mInstallation complete!\033[0m" | tee -a $LP/paragon-ufsd-install.log
;;
r|R|read|Read|READ)
less License.txt
run_install_driver
;;
*)
;;
esac
}

if [ `id -u` -ne 0 ];
then
echo -e "\033[31mNot enough permissions to install. Please login as root.\033[0m"
exit 1
	
else
echo -e "\033[31mBy installing this software you accept the terms of End User License Agreement listed in License file.\033[0m"
run_install_driver
fi
