<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>FeSTigeMainW</name>
    <message>
        <location filename="../festige.py" line="210"/>
        <source>%1PyJack is not available.%2You&apos;ll not be able to auto-connect.%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="213"/>
        <source>%1Jack is not active.%2You&apos;ll not be able to start any VST.%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="221"/>
        <source>Loading WineServer...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="230"/>
        <source>Open Windows VST Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="230"/>
        <source>Windows VST Plugins%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="265"/>
        <source>Quit fst/dssi-vst too?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="265"/>
        <source>Do you also want to close all plugin instances too?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="295"/>
        <source>Getting info from plugin &apos;%1&apos;...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="305"/>
        <source>Delete?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="305"/>
        <source>Are you sure you want to delete plugin &apos;%1&apos; ?%2(It will NOT be available in the trash!)%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="319"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="319"/>
        <source>Could not find the selected plugin...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="331"/>
        <source>&lt;b&gt;FeSTige&lt;/b&gt; is a GUI for &apos;fst&apos; and &apos;dssi-vst&apos;,&lt;br&gt;allowing you to run Windows VST plugins on Linux.&lt;p&gt;FeSTige is being developed by falkTX,&lt;br&gt;and it&apos;s released under the terms of the GNU GPL v2 or superior.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="486"/>
        <source>Name (Ascending)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="487"/>
        <source>Name (Descending)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="488"/>
        <source>Folder (Ascending)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="489"/>
        <source>Folder (Descending)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="522"/>
        <source>Could not connect Audio output of &quot;%1&quot; to System output.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="534"/>
        <source>Could not connect Midi output &apos;%1&apos; to VST Midi input of &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="539"/>
        <source>VST Plugin Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="539"/>
        <source>Info from plugin %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="316"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="316"/>
        <source>Could not delete selected plugin...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="485"/>
        <source>Sort By</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FestigeSettingsW</name>
    <message>
        <location filename="../festige.py" line="586"/>
        <source>PyJack is installed and Jack is running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="593"/>
        <source>PyJack is installed but Jack is not running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="597"/>
        <source>PyJack is not installed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="649"/>
        <source>VST Plugins Folder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Main</name>
    <message>
        <location filename="../festige.py" line="823"/>
        <source>Loading Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="830"/>
        <source>Pre-Loading Wine...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="834"/>
        <source>Preparing home folder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../festige.py" line="853"/>
        <source>Loading Main Window...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainW</name>
    <message>
        <location filename="../mainw.ui" line="21"/>
        <source>List of plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="24"/>
        <source>List of Plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="64"/>
        <source>Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="69"/>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="92"/>
        <source>Final command executed in order to launch the plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="82"/>
        <source>Final command:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="108"/>
        <source>Copy the command to the buffer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="278"/>
        <source>Launch the selected plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="275"/>
        <source>&amp;Launch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="365"/>
        <source>Add this plugin to the current ladish studio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="362"/>
        <source>&amp;Add to Ladish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="380"/>
        <source>Show information about this plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="377"/>
        <source>&amp;Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="293"/>
        <source>Delete the selected plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="290"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="305"/>
        <source>Refresh the list of plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="302"/>
        <source>&amp;Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="227"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="240"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="246"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="263"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="266"/>
        <source>About FeSTige</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="281"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="308"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="317"/>
        <source>&amp;Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="320"/>
        <source>Configure FeSTige</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="323"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="332"/>
        <source>Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="335"/>
        <source>Open a specific plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="338"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="347"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="350"/>
        <source>Quit FeSTige</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="353"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="368"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainw.ui" line="383"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsW</name>
    <message>
        <location filename="../settingsw.ui" line="14"/>
        <source>FeSTige - Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="24"/>
        <source>Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="36"/>
        <source>Utility to use:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="106"/>
        <source>Features:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="122"/>
        <source>VSTs with no custom GUI:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="155"/>
        <source>VST Presets:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="181"/>
        <source>Ladish Support:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="207"/>
        <source>Handle Transport info:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="233"/>
        <source>MIDI Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="254"/>
        <source>Paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="260"/>
        <source>Extra VST Paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="290"/>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="301"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="325"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="391"/>
        <source>Note that recursive search is supported. No need for extra folders here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="416"/>
        <source>Outro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="453"/>
        <source>Rese&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="443"/>
        <source>Default Ladish Folder:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="583"/>
        <source>Misc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="474"/>
        <source>Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="480"/>
        <source>Auto-Connect new VSTs to System &amp;Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="489"/>
        <source>Auto-Connect &amp;Midi Input to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="555"/>
        <source>PyJack status goes here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="589"/>
        <source>&amp;Run &quot;wineserver -p&quot; at FeSTige startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="596"/>
        <source>Show &amp;warnings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="607"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="613"/>
        <source>Real-Time Scheduling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="619"/>
        <source>Enable &amp;Wine Real-Time Scheduling (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="639"/>
        <source>Enable Wine&amp;Server Real-Time Schedulling (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="656"/>
        <source>Manipulate real-time attributes with &amp;chrt (Incompatible with ladish!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="685"/>
        <source>&lt;i&gt;(*) This option requires Wine compiled with the RT patch&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="710"/>
        <source>Command to run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="716"/>
        <source>&amp;Extra arguments:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsw.ui" line="729"/>
        <source>&amp;Final command: &lt;i&gt;(preview)&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
