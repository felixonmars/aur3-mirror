#!/bin/bash

PYSCRIPT="/usr/lib/python2.7/site-packages/dmenu_udisks/dmenu_udisks.py"

if [[ "$(basename $0)" == "mount"* ]]; then
    echo 'Mount'
    python2 ${PYSCRIPT} --mount
elif [[ "$(basename $0)" == "umount"* ]]; then
    echo 'Unmount'
    python2 ${PYSCRIPT} --unmount
else
    echo "Unknown"
fi
