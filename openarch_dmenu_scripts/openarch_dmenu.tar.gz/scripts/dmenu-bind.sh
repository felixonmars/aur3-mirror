#!/bin/bash
exe=`dmenu_run -fn 'DroidSans-9' -p 'Execute:' -nb '#000000' -nf '#FFFFFF' -sb '#FFFFFF' -sf '#000000'` && eval "exec $exe"
