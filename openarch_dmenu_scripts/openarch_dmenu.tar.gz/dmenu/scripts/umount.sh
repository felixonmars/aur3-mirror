#!/bin/bash
# скрипт-велосипед повзоляет произвести отмонтирование отчуждаемых носителей
# вывод осуществляется с помощью dmenu
# Распространяется по лицензии GPLv2
# зависимости: awk, udisks, bash, libnotify, dmenu, coreutils
# ограничим круг на устройствах  cd/dvd и FS vfat,ntfs,ext2
DEV_OK=0
STR_DEV="$(mktemp)"
mount | awk '/uhelper=udisks/ {print $1, $2, $3}' 1> "${STR_DEV}"
DEV_OK=$(cat "${STR_DEV}" | wc -l)
LOGO_ERR="/usr/share/dmenu/USB-HD_err.png"
LOGO_OK="/usr/share/dmenu/USB-HD.png"

exit_() 
{
 rm -f "${STR_DEV}" 2>/dev/null
 if [ "x$1" = "x0" -o "x$1" = "x" ]; then 
	exit
 else 
	echo $1
	exit 
 fi
}

if [ "${DEV_OK}" -gt "0" ]; then
 
 ans=$(cat "${STR_DEV}" | dmenu -p 'Umount:' | awk '{ print $1 }')
 
 [[ -z ${ans} ]] && exit_ "var \'ans\' is null"
# попробуем отмонтировать выбранное устройство
# по реезультату произведем нотификацию
 udisks --unmount "${ans}"
 if [[ "$?" != "0" ]]; then 
   notify-send -i "${LOGO_ERR}" -t 5000 -u critical "Umount \"${ans}\" error!"
  else
   notify-send -i "${LOGO_OK}" -t 5000 -u low "Umount \"${ans}\" succsessful!"
 fi

else 
 exit_ "Nothing to do"
fi

exit_ 0
