#!/bin/sh

OLDPWD=$PWD
cd /usr/share/OpenTTT/
java -cp /usr/share/OpenTTT/ gui.Main $OLDPWD/$1
