package icons;

import java.awt.Image;
import java.awt.Toolkit;

public class Resources {
	public static Image main=Toolkit.getDefaultToolkit().getImage("src/icons/main.png");
	public static Image right=Toolkit.getDefaultToolkit().getImage("src/icons/rightArrow.png");
	public static Image left=Toolkit.getDefaultToolkit().getImage("src/icons/leftArrow.png");
	public static Image top=Toolkit.getDefaultToolkit().getImage("src/icons/topArrow.png");
	public static Image bottom=Toolkit.getDefaultToolkit().getImage("src/icons/bottomArrow.png");
}
