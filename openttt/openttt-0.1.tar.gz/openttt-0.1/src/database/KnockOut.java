package database;

import gui.Main;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class KnockOut implements Serializable{
	private static final long serialVersionUID = 1745374647361712628L;

	private List<List<Player>> survivors;
	private List<Game> games;

	/**
	 * Constructor
	 * @param players The surviving players, players.size() element {2^i; i element N}
	 */
	public KnockOut(List<Player> players){
		this.games=new ArrayList<Game>();
		int i=players.size();
		this.survivors=new ArrayList<List<Player>>();
		List<Player> filtered=new ArrayList<Player>();
		for (Player p : players)
			if (p.equals(Player.getNobody())) filtered.add(null);
			else filtered.add(p);
		this.survivors.add(filtered);
		while (i>1) {
			List<Player> lst=new ArrayList<Player>();
			i=i/2;
			for (int j=0;j<i;j++)
				lst.add(null);
			this.survivors.add(lst);
		}
		for (i=0; i<players.size(); i+=2){
			if (players.get(i).equals(Player.getNobody()))
				survivors.get(1).set(i/2, players.get(i+1));
			if (players.get(i+1).equals(Player.getNobody()))
				survivors.get(1).set(i/2, players.get(i));
		}
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	/**
	 * Updates and returns games
	 * @return all Games
	 */
	public List<Game> getGames(){
		List<Game> newGames=new ArrayList<Game>();
		for (List<Player> plrs : this.survivors){
			for (int i=0; i<plrs.size(); i=i+2){
				if (plrs.size()>i+1)
				if ((plrs.get(i)!=null) & (plrs.get(i+1)!=null)){
					Game g=new Game(plrs.get(i),plrs.get(i+1));
					if (!games.contains(g)){
						newGames.add(g);
						Main.getInstance().getTournament().setUnsaved(true);
					} else {
						newGames.add(games.get(games.indexOf(g)));
					}
				}
			}
		}
		games=newGames;
		return this.games;
	}

	public void addGame(Game g){
		for (List<Player> plrs : this.survivors){
			for (int i=0; i<plrs.size(); i=i+2){
				if (plrs.size()>i+1)
				if (plrs.get(i)!=null & plrs.get(i+1)!=null)
				if ((plrs.get(i).equals(g.getLeftPlayer())) & (plrs.get(i+1).equals(g.getRightPlayer()))){
					int idx=this.survivors.indexOf(plrs);
					this.survivors.get(idx+1).set(i/2, g.getWinner());
				}
			}
		}
	}
	
	public void delGame(Game g){
		for (List<Player> plrs : this.survivors){
			for (int i=0; i<plrs.size(); i=i+2){
				if (plrs.size()>i+1)
				if (plrs.get(i)!=null & plrs.get(i+1)!=null)
				if ((plrs.get(i).equals(g.getLeftPlayer())) & (plrs.get(i+1).equals(g.getRightPlayer()))){
					int idx=this.survivors.indexOf(plrs);
					this.survivors.get(idx+1).set(i/2, null);
				}
			}
		}
	}
	
	public List<List<Player>> getTree() {
		return survivors;
	}
	
}
