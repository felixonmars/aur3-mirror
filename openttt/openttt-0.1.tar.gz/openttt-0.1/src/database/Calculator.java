package database;

import gui.Language;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class Calculator implements Serializable{
	
	private static int[] arrayJGJ2={1,2};
	private static int arrayJGJ2length=2;
	private static int[] arrayJGJ3={2,3,1,3,1,2};
	private static int arrayJGJ3length=6;
	private static int[] arrayJGJ4={1,4,2,3,1,3,2,4,1,2,3,4};
	private static int arrayJGJ4length=12;
	private static int[] arrayJGJ5={2,5,3,4,
									1,5,2,4,
									1,4,2,3,
									1,3,4,5,
									1,2,3,5};
	private static int arrayJGJ5length=20;
	private static int[] arrayJGJ6={1,6,2,5,3,4,
									1,5,2,4,3,6,
									1,4,2,3,5,6,
									1,3,2,6,4,5,
									1,2,3,5,4,6};
	private static int arrayJGJ6length=30;
	private static int[] arrayJGJ7={2,7,3,6,4,5,
									6,4,7,3,1,2,
									3,1,4,7,5,6,
									7,5,1,4,2,3,
									4,2,5,1,6,7,
									1,6,2,5,3,4,
									5,3,6,2,7,1};
	private static int arrayJGJ7length=42;
	private static int[] arrayJGJ8={1,8,2,7,3,6,4,5,
									8,5,6,4,7,3,1,2,
									2,8,3,1,4,7,5,6,
									8,6,7,5,1,4,2,3,
									3,8,4,2,5,1,6,7,
									8,7,1,6,2,5,3,4,
									4,8,5,3,6,2,7,1};
	private static int arrayJGJ8length=56;
	private static int[] arrayJGJ9={2,9,3,8,4,7,5,6,
		 							1,3,9,4,8,5,6,7,
									2,4,5,1,9,6,7,8,
									3,5,6,2,1,7,8,9,
									4,6,7,3,2,8,9,1,
									5,7,8,4,3,9,1,2,
									6,8,9,5,4,1,2,3,
									7,9,1,6,3,4,5,2,
									1,8,6,3,2,7,4,5};
	private static int arrayJGJ9length=72;
	private static int[] arrayJGJ10={1,10,2,9,3,8,4,7,5,6,
									 10,2,1,3,9,4,8,5,6,7,
									 3,10,2,4,5,1,9,6,7,8,
									 4,10,3,5,6,2,1,7,8,9,
									 10,5,4,6,7,3,2,8,9,1,
									 6,10,5,7,8,4,3,9,1,2,
									 10,7,6,8,9,5,4,1,2,3,
									 8,10,7,9,1,6,3,4,5,2,
									 10,9,1,8,6,3,2,7,4,5};
	private static int arrayJGJ10length=90;
										
	/**
	 * Generates a list of games depending on the players
	 * @param p List of players
	 * @return list of games
	 */
	public static List<Game> calculateGames(List<Player> p, int group){
		int[] arrayJGJ={};
		int length=0;
		switch (p.size()){
			case 1 :System.out.println("ERROR: Zu wenige Spieler in der Gruppe.");
			case 2 :{arrayJGJ=arrayJGJ2 ;length=arrayJGJ2length ;break;}
			case 3 :{arrayJGJ=arrayJGJ3 ;length=arrayJGJ3length ;break;}
			case 4 :{arrayJGJ=arrayJGJ4 ;length=arrayJGJ4length ;break;}
			case 5 :{arrayJGJ=arrayJGJ5 ;length=arrayJGJ5length ;break;}
			case 6 :{arrayJGJ=arrayJGJ6 ;length=arrayJGJ6length ;break;}
			case 7 :{arrayJGJ=arrayJGJ7 ;length=arrayJGJ7length ;break;}
			case 8 :{arrayJGJ=arrayJGJ8 ;length=arrayJGJ8length ;break;}
			case 9 :{arrayJGJ=arrayJGJ9 ;length=arrayJGJ9length ;break;}
			case 10:{arrayJGJ=arrayJGJ10;length=arrayJGJ10length;break;}
			default:{System.out.println("ERROR: Zu viele Spieler in der Gruppe.");return null;}
		}
		List<Game> games=new ArrayList<Game>();
		int i;
		int teiler=420/length;
		for (i=0; i<length; i=i+2){
			games.add(new Game((int) (0.5*i*teiler), group, p.get(arrayJGJ[i]-1),p.get(arrayJGJ[i+1]-1)));
		}
		return games;
	}
	
	/**
	 * Returns the List of games having the given state 
	 * @param games List of games
	 * @param state state to look for
	 * @return games with given state
	 */
	public static List<Game> getGamesByState(List<Game> games, int state){
		List<Game> result=new ArrayList<Game>();
		for (Game g : games){
			if (g.getState()==state)
				result.add(g);
		}
		return result;
	}
	
	/**
	 * 2^(x-1)<i<=2
	 * @param i
	 * @return 2
	 */
	public static int nextPowerOfTwo(int i){
		int result=1;
		while (result<i){
			result*=2;
		}
		return result;
	}

	/**
	 * returns the minimum of two integers
	 * @param i integer1
	 * @param j integer2
	 * @return minimum
	 */
	public static int min(int i, int j) {
		if (i<j) return i;
		return j;
	}

	/**
	 * returns the maximum of two integers
	 * @param i	integer1
	 * @param j integer2
	 * @return maximum
	 */
	public static int max(int i, int j) {
		if (i>j) return i;
		return j;
	}

	/**
	 * returns true if a Player plays in one of the Games in the List
	 * @param list Game List
	 * @param p Player
	 * @return if player plays
	 */
	public static boolean plays(List<Game> list, Player p){
		for (Game g : list){
			if (g.getLeftPlayer().equals(p)) return true;
			if (g.getRightPlayer().equals(p)) return true;
		}
		return false;
	}
	
	/**
	 * Converts a List of groups into HTML code, containing the empty group tables
	 * @param list list of groups
	 * @return HTML group tables
	 */
	public static String htmlTabularEmpty(List<Group> list){
		String result="";
		for (Group g : list){
			result+="<table border=1 width=100% style=\"border-collapse:collapse;\"><tr>";
			int number= g.getAnzahl();
			result+="<td></td><td><b>Gruppe "+(list.indexOf(g)+1)+"</b></td>";
			
			for (int i=0; i<number; i++){
				result+="<td>"+(i+1)+"</td>";
			}
			
			result+="<td>"+Language.get("games")+"</td>";
			result+="<td>"+Language.get("sentences")+"</td>";
			result+="<td>"+Language.get("rank")+"</td></tr>";
			
			for (Player p:g.getPlayers()){
				result+="<tr><td>"+(g.getPlayers().indexOf(p)+1)+"</td><td>"+p.toString()+"</td>";
				for (int i=0; i<number; i++){
					if (g.getPlayers().get(i).equals(p))
						result+="<td>X</td>";
					else
						result+="<td>&nbsp</td>";
				}
				for (int i=0; i<3; i++)
					result+="<td>&nbsp</td>";
				result+="</tr>";
			}
			
			result+="</table>";
		}
		return result;
	}
	
	/**
	 * Creates non empty group tables in HTML
	 * @param list List of groups
	 * @return HTML tables (non empty)
	 */
	public static String htmlTabular(List<Group> list){
		String result="";
		for (Group g : list){
			result+="<table border=1 width=100% style=\"border-collapse:collapse;\"><tr>";
			int number= g.getAnzahl();
			result+="<td></td><td><b>"+Language.get("group")+" "+(list.indexOf(g)+1)+"</b></td>";
			
			for (int i=0; i<number; i++){
				result+="<td>"+(i+1)+"</td>";
			}
			
			result+="<td>"+Language.get("games")+"</td>";
			result+="<td>"+Language.get("sentences")+"</td>";
			result+="<td>"+Language.get("rank")+"</td></tr>";
			
			for (Player p:g.getPlayers()){
				result+="<tr><td>"+(g.getPlayers().indexOf(p)+1)+"</td><td>"+p.toString()+"</td>";
				for (int i=0; i<number; i++){
					String sentence="&nbsp";
					if (g.getPlayers().get(i).equals(p))
						sentence="X";
					else {
						for (Game game: g.getGames()){
							if (game.getState()==2){
								if (game.getLeftPlayer().equals(p) & game.getRightPlayer().equals(g.getPlayers().get(i)))
									sentence=game.getLeftSentences()+":"+game.getRightSentences();
								if (game.getRightPlayer().equals(p) & game.getLeftPlayer().equals(g.getPlayers().get(i)))
									sentence=game.getRightSentences()+":"+game.getLeftSentences();
							}
						}
					}
					result+="<td>"+sentence+"</td>";
				}
				String[] help=p.toArray();
				result+="<td>"+help[3]+"</td>";
				result+="<td>"+help[2]+"</td>";
				result+="<td>"+g.getPlayersPlace(p)+"</td>";
				result+="</tr>";
			}
			
			result+="</table>";
		}
		return result;
	}
	
	public static String[] tabularHead(Group g){
		List<String> result = new ArrayList<String>();
		result.add(Language.get("name"));
		for (Player p : g.getPlayers())
			result.add(p.toString());
		result.add(Language.get("balls"));
		result.add(Language.get("sentences"));
		result.add(Language.get("games"));
		return result.toArray(new String[0]);
	}
	
	public static String[][] tabular(Group g){
		List<String[]> result=new ArrayList<String[]>();
		for (Player p:g.getPlayers()){
			List<String> lst=new ArrayList<String>();
			lst.add(p.getFullName());
			for (Player q:g.getPlayers()){
				lst.add(g.getGame(p, q));
			}
			String[] help=p.toArray();
			lst.add(help[1]);
			lst.add(help[2]);
			lst.add(help[3]);
			result.add(lst.toArray(new String[0]));
		}
		return result.toArray(new String[0][0]);
	}
}
