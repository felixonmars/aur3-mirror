package database;

import gui.Language;
import gui.Main;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Qualifying implements Serializable{
	private static final long serialVersionUID = -4385411518278069896L;

	private List<Group> groups=new ArrayList<Group>();
	private List<Player> unassigned=new ArrayList<Player>();

	public List<Game> getGamesByState(int state){
		List<Game> games=new ArrayList<Game>();
		for (Group g: groups){
			games.addAll(g.getGamesByState(state));
		}
		return games;
	}
	
	public Qualifying(int gruppen){
		this.groups=new ArrayList<Group>();
		int i=0;
		for (i=0;i<gruppen;i++){
			this.addGroup();
		};
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	public List<Group> getGroups(){
		return this.groups;
	}
	
	public void assignPlayer(Player player, Group group){
		group.addPlayer(player);
		this.unassigned.remove(player);
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	public void unassignPlayer(Player player, Group group){
		group.delPlayer(player);
		this.unassigned.add(player);
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	public void addGroup(){
		this.groups.add(new Group(Language.get("group")+" "+(this.groups.size()+1)));
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	public void delGroup(int idx){
		this.groups.remove(idx);
		if (idx<groups.size()){
			int i=idx;
			for (Group g:groups.subList(idx, groups.size())){
				i++;
				g.setName(Language.get("group")+" "+i);
			}
		}
		Main.getInstance().getTournament().setUnsaved(true);
	}

	public List<Player> getUnassigned() {
		return this.unassigned;
	}
};
