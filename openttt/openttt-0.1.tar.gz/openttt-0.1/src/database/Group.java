package database;

import gui.Main;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Group implements Serializable{
	private static final long serialVersionUID = -6914347152732610120L;

	private String name="";
	private List<Player> players;
	private List<Game> games;
	
	public Group(String groupName){
		players=new ArrayList<Player>();
		games=new ArrayList<Game>();
		name=groupName;
	}
	
	public static Group getGroup(Player p){
		List<Group> groups=Main.getInstance().getTournament().getQualifying().getGroups();
		for (Group g:groups)
			if (g.getPlayers().contains(p))
				return g;
		
		return null;
	}
	
	public List<Player> getPlayersByPlace(int min, int max){
		List<Player> help=new ArrayList<Player>();
		help.addAll(players);
		Collections.sort(help);
		return help.subList(min-1, max-1);
	}
	
	public int getPlayersPlace(Player p){
		List<Player> help=new ArrayList<Player>();
		help.addAll(players);
		Collections.sort(help);
		return help.indexOf(p)+1;
	}
	
	public void swapPlayers(int i, int j){
		Player p=players.get(i);
		players.set(i, players.get(j));
		players.set(j, p);
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	@Override
	public String toString(){
		return this.name;
	}
		
	public int startGroup(){
		games=Calculator.calculateGames(players, Main.getInstance().getTournament().getQualifying().getGroups().indexOf(this)+1);
		Main.getInstance().getTournament().setUnsaved(true);
		return games.size();
	}
	
	//getter:
	public List<Player> getPlayers(){
		return players;
	}
	
	public int getAnzahl(){
		return players.size();
	}
	
	public void setName(String name){
		this.name=name;
	}
	
	public Object[][] getPlayerStats(){
		Object[][] objArr=new Object[players.size()][4];
		List<Player> help=new ArrayList<Player>();
		help.addAll(players);
		Collections.sort(help);
		for (int i=0;i<help.size();i++){
			for (int j=0;j<4;j++){
				objArr[i][j]=help.get(i).toArray()[j];
			}
		}
		return objArr;
	}
	
	public List<Game> getGames(){
		return games;
	}
	
	public List<Game> getGamesByState(int state){
		List<Game> result=new ArrayList<Game>();
		for (Game g : games){
			if (g.getState()==state){
				result.add(g);
			}
		}
		return result;
	}
	
	public String getGame(Player p, Player q){
		if (p.equals(q)) return "X";
		for (Game g:getGames()){
			if (g.getLeftPlayer().equals(p) & g.getRightPlayer().equals(q))
				return g.getLeftSentences()+":"+g.getRightSentences();
			if (g.getLeftPlayer().equals(q) & g.getRightPlayer().equals(p))
				return g.getRightSentences()+":"+g.getLeftSentences();
		}
		return "";
	}
	
	//setter:
	public void addPlayer(Player p){
		players.add(p);
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	public void delPlayer(Player p){
		players.remove(p);
		Main.getInstance().getTournament().setUnsaved(true);
	}
}
