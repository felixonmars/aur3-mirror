package database;

import java.io.Serializable;

public class Sentence implements Serializable{
	private static final long serialVersionUID = 4871248815012605304L;
	private int leftBalls=0, rightBalls=0;
	
	public Sentence(int leftBalls, int rightBalls){
		this.leftBalls=leftBalls;
		this.rightBalls=rightBalls;
	}
	
	public String toString(){
		return leftBalls+":"+rightBalls;
	}
	
	public boolean isOK(){
		int high=Calculator.max(leftBalls, rightBalls);
		int low=Calculator.min(leftBalls, rightBalls);

		boolean gt11=(high>11);
		int diff=high-low;
		if (gt11)
			return (diff==2);
		else
			return (diff>1);
	}
	
}
