package database;

import gui.Main;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Player extends Node implements Serializable, Comparable<Player>{
	private static final long serialVersionUID = 8818596806290218982L;

	private String name;
	private String vorname;
	private String verein="";
	private boolean there;
	private int balls,sentences,points;

	public static Player getNobody() {
		return new Player("nobody","nobody");
	}
	
	//checker
	public boolean equals(Player p){
		return ((this.name.equals(p.name))&(this.vorname.equals(p.vorname)));
	}
	
	public boolean isThere(){
		return there;
	}
	
	//constructor/2
	public Player(String name, String vorname){
		this.name=name.substring(0,1).toUpperCase()+name.substring(1).toLowerCase();
		this.vorname=vorname.substring(0,1).toUpperCase()+vorname.substring(1).toLowerCase();
		this.verein="";
		Main.getInstance().getTournament().setUnsaved(true);
	}
	//constructor/3
	public Player(String name, String vorname, String verein){
		this.name=name.substring(0,1).toUpperCase()+name.substring(1).toLowerCase();
		this.vorname=vorname.substring(0,1).toUpperCase()+vorname.substring(1).toLowerCase();
		this.verein=verein;
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	//getter
	@Override
	public String toString(){
		String result;
		if (this.name.equals("Nobody")&this.vorname.equals("Nobody"))
			return "<nobody>";
		if (Main.getInstance().getDoubleView())
			result=this.name+"/"+this.vorname;
		else
			result=this.name+", "+this.vorname.substring(0,1)+".";
		return result;
	}
	
	public String getFullName(){
		String result;
		if (this.name.equals("Nobody")&this.vorname.equals("Nobody"))
			return "<nobody>";
		if (Main.getInstance().getDoubleView())
			result=this.name+"/"+this.vorname;
		else
			result=this.name+", "+this.vorname;
		if (!verein.equals(""))
			result+=" ("+this.verein+")";
		return result;
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getVorname(){
		return this.vorname;
	}
	
	public String getVerein(){
		return this.verein;
	}
	
	public int getPoints(){
		return this.points;
	}
	
	public int getSentences(){
		return this.sentences;
	}
	
	public int getBalls(){
		return this.balls;
	}
	
	@Override
	public int compareTo(Player p){
		if (this.points>p.getPoints()) {return -1;};
		if (this.points<p.getPoints()) {return 1;};
		if (this.sentences>p.getSentences()) {return -1;};
		if (this.sentences<p.getSentences()) {return 1;};
		if (this.balls>p.getBalls()) {return -1;};
		if (this.balls<p.getBalls()) {return 1;};
		return 0;
	}
	
	//setter
	public void addGame(int oballs, int eballs, int osentences, int esentences){
		if (osentences>esentences) this.points++;
		else this.points--;
		this.balls+=oballs;
		this.balls-=eballs;
		this.sentences+=osentences;
		this.sentences-=esentences;
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	public void delGame(int oballs, int eballs, int osentences, int esentences){
		if (osentences>esentences) this.points--;
		else this.points++;
		this.balls-=oballs;
		this.balls+=eballs;
		this.sentences-=osentences;
		this.sentences+=esentences;
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	public String[] toArray(){
		String[] result=new String[4];
		result[0]=toString();
		int rBalls=0, lBalls=0, rSentences=0, lSentences=0, rPoints=0, lPoints=0;
		for (Game g:Group.getGroup(this).getGames()){
			if (g.getWinner()!=null & (g.getLeftPlayer().equals(this) | g.getRightPlayer().equals(this))){
				if (g.getWinner().equals(this))
					lPoints++;
				else
					rPoints++;
			}
			if (g.getLeftPlayer().equals(this)){
				lBalls+=g.getLeftBalls();
				rBalls+=g.getRightBalls();
				lSentences+=g.getLeftSentences();
				rSentences+=g.getRightSentences();
			}
			if (g.getRightPlayer().equals(this)){
				lBalls+=g.getRightBalls();
				rBalls+=g.getLeftBalls();
				lSentences+=g.getRightSentences();
				rSentences+=g.getLeftSentences();
			}
		}
		result[1]=lBalls+":"+rBalls;
		result[2]=lSentences+":"+rSentences;
		result[3]=lPoints+":"+rPoints;
		
		return result;
	}
	
	public String getPlayerPlaceGroup(){
		String result="";
		for (Group g : Main.getInstance().getTournament().getQualifying().getGroups()){
			if (g.getPlayers().contains(this)){
				List<Player> help=new ArrayList<Player>();
				help.addAll(g.getPlayers());
				Collections.sort(help);
				result+=(help.indexOf(this)+1)+".Gr"
					+(Main.getInstance().getTournament().getQualifying().getGroups().indexOf(g)+1);
			}
		}
		if (this.equals(Player.getNobody())) result=toString();
		else result+=": "+toString();
		if (!verein.equals("")) result+=" ("+verein+")";
		return result; 
	}
	
	public void setThere(boolean newThere){
		there=newThere;
	}

	@Override
	public boolean isNobody() {
		return (this.equals(Player.getNobody()));
	}
}
