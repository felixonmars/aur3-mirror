package database;

import java.io.Serializable;

public class Tournament implements Serializable{
	private static final long serialVersionUID = -3317020456348232936L;

	private Qualifying qualifying;
	private KnockOut knockOut;
	private boolean doQualifying=true, doKnockOut=true;
	private boolean unsaved=true;
	private int state;
	
	public Tournament(){
		this.state=0;
	}
	
	public void setKnockOut(KnockOut k){
		this.knockOut=k;
		this.setUnsaved(true);
	}
	
	public KnockOut getKnockOut(){
		return this.knockOut;
	}
	
	public void setQualifying(Qualifying q){
		this.qualifying=q;
		this.setUnsaved(true);
	}
	
	public Qualifying getQualifying(){
		return this.qualifying;
	}
	
	public boolean getDoQualifying(){
		return doQualifying;
	}
	
	public void setDoQualifying(boolean doQualifying){
		this.doQualifying=doQualifying;
	}
	
	public boolean getDoKnockOut(){
		return doKnockOut;
	}
	
	public void setDoKnockOut(boolean doKnockOut){
		this.doKnockOut=doKnockOut;
	}
		
	public void incState(){
		this.state++;
		this.setUnsaved(true);
	}
	
	public int getState(){
		return this.state;
	}

	public void setUnsaved(boolean unsaved) {
		this.unsaved = unsaved;
	}

	public boolean isUnsaved() {
		return unsaved;
	}
}
