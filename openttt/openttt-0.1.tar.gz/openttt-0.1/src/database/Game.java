package database;

import gui.Main;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Game extends Edge<Player> implements Serializable, Comparable<Game>{

	private static final long serialVersionUID = 786478419651897950L;
	
	private Player leftPlayer;
	private Player rightPlayer;
	private Player loser;
	private Player winner;
	private List<Sentence> sentences;
	private int leftSentences;
	private int rightSentences;
	private int leftBalls;
	private int rightBalls;
	private int state;
	private int maxSentences=3;
	private int priority;
	private Date startedDate, endedDate;
	private int group=-1;
	
	/**
	 * Constructor
	 * @param priority the higher this is the earlier it appears in lists
	 * @param leftPlayer Player on the left side
	 * @param rightPlayer Player in the right side
	 */
	public Game(int priority, int group, Player leftPlayer, Player rightPlayer){
		this.priority=priority;
		this.group=group;
		this.leftPlayer=leftPlayer;
		this.rightPlayer=rightPlayer;
		this.leftSentences=0;
		this.rightSentences=0;
		this.leftBalls=0;
		this.rightBalls=0;
		this.state=0;
		this.sentences=new ArrayList<Sentence>();
	}
	
	/**
	 * Constructor
	 * @param leftPlayer Player on the left side
	 * @param rightPlayer Player on the right side
	 */
	public Game(Player leftPlayer, Player rightPlayer) {
		this.priority=0;
		this.leftPlayer=leftPlayer;
		this.rightPlayer=rightPlayer;
		this.leftSentences=0;
		this.rightSentences=0;
		this.leftBalls=0;
		this.rightBalls=0;
		this.state=0;
		this.sentences=new ArrayList<Sentence>();
	}

	/**
	 * Adds a sentence to the Game
	 * @param leftBalls Balls of left Player
	 * @param rightBalls Balls of right Player
	 */
	public void addSentence(int leftBalls, int rightBalls){
		Main.getInstance().getTournament().setUnsaved(true);
		this.sentences.add(new Sentence(leftBalls,rightBalls));
		this.leftBalls+=leftBalls;
		this.rightBalls+=rightBalls;
		if (leftBalls>rightBalls){this.leftSentences++;} else {this.rightSentences++;};
		if (this.leftSentences==this.maxSentences){
			this.winner=this.leftPlayer;
			this.loser=this.rightPlayer;
			this.winner.addGame(this.leftBalls, this.rightBalls, this.leftSentences, this.rightSentences);
			this.loser.addGame(this.rightBalls,this.leftBalls,this.rightSentences,this.leftSentences);
			this.endGame();
		};
		if (this.rightSentences==this.maxSentences){
			this.winner=this.rightPlayer;
			this.loser=this.leftPlayer;
			this.winner.addGame(this.rightBalls,this.leftBalls,this.rightSentences,this.leftSentences);
			this.loser.addGame(this.leftBalls, this.rightBalls, this.leftSentences, this.rightSentences);
			this.endGame();
		};
		if (winner!=null)
			this.state=2;
	}
	
	@Override
	public boolean equals(Object e){
		return this.toString().equals(e.toString());
	}
	
	@Override
	public String toString(){
		return this.leftPlayer+" : "+this.rightPlayer;
	}
	
	public int getGroup(){
		return group;
	}
	
	/**
	 * Starts the Game
	 */
	public void startGame(){
		this.state=1;
		this.startedDate=new Date();
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	/**
	 * Ends the Game
	 */
	public void endGame(){
		this.state=2;
		this.endedDate=new Date();
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	/**
	 * Winner of the Game
	 * @return Winner of the Game
	 */
	public Player getWinner(){
		return this.winner;
	}
	
	/**
	 * Player on the left side
	 * @return Player on the left side
	 */
	public Player getLeftPlayer(){
		return this.leftPlayer;
	}
	
	/**
	 * Player on the right side
	 * @return Player on the right side
	 */
	public Player getRightPlayer(){
		return this.rightPlayer;
	}
	
	/**
	 * The Game's state
	 * @return the Game's state
	 */
	public int getState(){
		return this.state;
	}
	
	/**
	 * Sets a value for the Game's state
	 * @param state new State
	 */
	public void setState(int state){
		if (this.state==1 && state==2){
			this.leftPlayer.addGame(this.leftBalls, this.rightBalls, this.leftSentences, this.rightSentences);
			this.rightPlayer.addGame(this.rightBalls, this.leftBalls, this.rightSentences, this.leftSentences);
			this.startedDate=new Date();
		}
		if (this.state==2 && state<2){
			this.leftPlayer.delGame(this.leftBalls, this.rightBalls, this.leftSentences, this.rightSentences);
			this.rightPlayer.delGame(this.rightBalls, this.leftBalls, this.rightSentences, this.leftSentences);
			this.winner=null;
			this.loser=null;
			this.endedDate=null;
			this.leftBalls=0;
			this.rightBalls=0;
			this.leftSentences=0;
			this.rightSentences=0;
			this.sentences.clear();
		}
		this.state=state;
		Main.getInstance().getTournament().setUnsaved(true);
	}
	
	/**
	 * Sentences won by the left Player
	 * @return left Player's sentences
	 */
	public int getLeftSentences(){
		return this.leftSentences;
	}
	
	/**
	 * Sets a value for the left Player's won sentences
	 * @param sentences new left Player's Sentences
	 */
	public void setLeftSentences(int sentences){
		this.leftPlayer.delGame(leftBalls, rightBalls, leftSentences, rightSentences);
		this.rightPlayer.delGame(rightBalls, leftBalls, rightSentences, leftSentences);
		this.leftSentences=sentences;
		this.leftPlayer.addGame(leftBalls, rightBalls, leftSentences, rightSentences);
		this.rightPlayer.addGame(rightBalls, leftBalls, rightSentences, leftSentences);
		Main.getInstance().getTournament().setUnsaved(true);
	};
	
	/**
	 * Sentences won by the right Player
	 * @return right Player's sentences
	 */
	public int getRightSentences(){
		return this.rightSentences;
	};
	
	/**
	 * Sets a value for the right Player's won sentences
	 * @param sentences new right Player's sentences
	 */
	public void setRightSentences(int sentences){
		this.leftPlayer.delGame(leftBalls, rightBalls, leftSentences, rightSentences);
		this.rightPlayer.delGame(rightBalls, leftBalls, rightSentences, leftSentences);
		this.rightSentences=sentences;
		this.leftPlayer.addGame(leftBalls, rightBalls, leftSentences, rightSentences);
		this.rightPlayer.addGame(rightBalls, leftBalls, rightSentences, leftSentences);
		Main.getInstance().getTournament().setUnsaved(true);
	};

	/**
	 * Balls won by the left Player
	 * @return left Player's balls
	 */
	public int getLeftBalls(){
		return this.leftBalls;
	};
	
	public void setLeftBalls(int points){
		this.leftPlayer.delGame(leftBalls, rightBalls, leftSentences, rightSentences);
		this.rightPlayer.delGame(rightBalls, leftBalls, rightSentences, leftSentences);
		this.leftBalls=points;
		this.leftPlayer.addGame(leftBalls, rightBalls, leftSentences, rightSentences);
		this.rightPlayer.addGame(rightBalls, leftBalls, rightSentences, leftSentences);
		Main.getInstance().getTournament().setUnsaved(true);
	};
	
	public int getRightBalls(){
		return this.rightBalls;
	};
	
	public void setRightBalls(int points){
		this.leftPlayer.delGame(leftBalls, rightBalls, leftSentences, rightSentences);
		this.rightPlayer.delGame(rightBalls, leftBalls, rightSentences, leftSentences);
		this.rightBalls=points;
		this.leftPlayer.addGame(leftBalls, rightBalls, leftSentences, rightSentences);
		this.rightPlayer.addGame(rightBalls, leftBalls, rightSentences, leftSentences);
		Main.getInstance().getTournament().setUnsaved(true);
	}

	@Override
	public int compareTo(Game arg0) {
		if (this.priority>arg0.priority) return 1;
		if (this.priority<arg0.priority) return -1;
		return 0;
	}
	
	/**
	 * Checks containing sentences for typos
	 * @return FALSE if there is definetly a typo, otherwise TRUE
	 */
	public boolean isOK(){
		boolean result=true;
		for (Sentence s: sentences){
			result=result & s.isOK();
		}
		return result;
	}
	
	public String shortInfo(){
		return toString()+" ("+leftSentences+":"+rightSentences+")";
	}
	
	public String mediumInfo(){
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
		//TODO language
		return "<html>"+shortInfo()+"<br>Beginn:\t"+sdf.format(startedDate)
				+"<br>Punkte:\t"+leftBalls+":"+rightBalls+"</html>";
	}
	
	public String longInfo(){
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
		//TODO language
		String result="<html>"+shortInfo()+"<br>Beginn:\t"+sdf.format(startedDate)+"<br>Ende:\t"
		+sdf.format(endedDate)+"<br>Sätze: ";
		 result+=sentences.get(0).toString();
		 for (int i=1; i<sentences.size(); i++){
			 result+=", "+sentences.get(i).toString();
		 }
		 result+="</html>";
		return result;
	}

	@Override
	public Player getLeft() {
		return getLeftPlayer();
	}

	@Override
	public Player getRight() {
		return getRightPlayer();
	}

	@Override
	public String edgePrint() {
		if (state==2)
			return leftSentences+":"+rightSentences;
		return "";
	}
}
