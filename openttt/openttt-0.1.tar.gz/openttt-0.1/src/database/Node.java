package database;

public abstract class Node {

	public abstract boolean isNobody();
}
