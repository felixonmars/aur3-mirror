package database;

public abstract class Edge<T> {
	public abstract T getLeft();
	public abstract T getRight();
	public abstract String edgePrint();
}
