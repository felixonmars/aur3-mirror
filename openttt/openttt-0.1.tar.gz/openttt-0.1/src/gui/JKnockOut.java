package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.JPanel;

import database.Calculator;
import database.Game;
import database.KnockOut;
import database.Player;

@SuppressWarnings("serial")
public class JKnockOut extends JPanel{
	
	private KnockOut knockout;
	private JTreeView<Player,Game> tv;
	private JKnock jKnock;
	
	class JKnock extends JQualifying {
		public void refreshLists(){
			showEndQuali=false;
			List<Game> games=knockout.getGames();
			hole=Calculator.getGamesByState(games, 0);
			running=Calculator.getGamesByState(games, 1);
			done=Calculator.getGamesByState(games, 2);
			
			int i=jHole.getSelectedIndex();
			jHole.setListData(hole.toArray());
			jHole.setSelectedIndex(i);
			
			i=jRunning.getSelectedIndex();
			jRunning.setListData(running.toArray());
			jRunning.setSelectedIndex(i);
			
			i=jDone.getSelectedIndex();
			jDone.setListData(done.toArray());
			jDone.setSelectedIndex(i);
			
			if (jRunning.getSelectedIndex()==-1 & jRunning.getModel().getSize()>0)
				jRunning.setSelectedIndex(0);
		}
		
		@Override
		protected void handleEndGameEvent(int leftadd, int rightadd){
			Game g=((Game)this.jRunning.getSelectedValue());
			g.addSentence(leftadd, rightadd);
			if (g.getState()==2){
				knockout.addGame(g);
			}
			this.sentenceline.setText("");
			this.refreshLists();
			tv.repaint();
			Main.getInstance().refresh();
		}
		
		public JKnock(){
			super(Main.getInstance().getTournament().getQualifying());
			generateWindow();
		}
		
		protected void buildFrame(){
			this.setLayout(new FlowLayout());
	        panelmain.setPreferredSize(new Dimension(800,350));
	        this.add(this.panelmain);
		}
	}
	
	public JKnockOut(){
		this.knockout=Main.getInstance().getTournament().getKnockOut();
	}
	
	public void refresh(){
		tv.setEdges(knockout.getGames());
		jKnock.refreshLists();
		tv.repaint();
	}
	
	public void generateWindow(){
		this.setLayout(new BorderLayout());
		tv=new JTreeView<Player,Game>(knockout.getTree(), knockout.getGames());
		this.add(tv, BorderLayout.CENTER);
		jKnock=new JKnock();
		this.add(jKnock, BorderLayout.SOUTH);
	}
	
	public void showWindow(){
		Main.getInstance().showMe(this);
	}
}
