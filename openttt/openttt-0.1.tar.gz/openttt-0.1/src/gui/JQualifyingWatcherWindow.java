package gui;

import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.PrintJob;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import database.Group;

@SuppressWarnings("serial")
public class JQualifyingWatcherWindow extends JFrame {
	private List<JQualifyingWatcher> jWatchers;
	private GridLayout gl;
	
	public JQualifyingWatcherWindow(List<Group> groups){
		super(Language.get("qualifyingWatcher"));
		jWatchers=new ArrayList<JQualifyingWatcher>();
		int length=groups.size();
		gl=new GridLayout((length-1)/4+1,4);
		this.setLayout(gl);
		for (Group g : groups){
			JQualifyingWatcher jw=new JQualifyingWatcher(g);
			jWatchers.add(jw);
			add(jw);
		}
		
		//Actions
		final Action aQuit=new AbstractAction(Language.get("quit")) {
			public void actionPerformed(ActionEvent arg0) {
				Main.getInstance().removeWatcher("Q");
				dispose();
			}
		};
		
		Action aPrint=new AbstractAction(Language.get("print")) {
			public void actionPerformed(ActionEvent arg0) {
				Toolkit tk=Toolkit.getDefaultToolkit();
				PrintJob pj=tk.getPrintJob(new Frame(), "", null);
				if (pj!=null){
					Graphics g=pj.getGraphics();
					printComponents(g);
					g.dispose();
					pj.end();
				}
			}
		};
		
		Action aRefresh=new AbstractAction(Language.get("refresh")){
			public void actionPerformed(ActionEvent arg0){
				refresh();
			}
		};
		
		Action aRename=new AbstractAction(Language.get("rename")) {
			public void actionPerformed(ActionEvent arg0) {
				String newName=JOptionPane.showInputDialog(Language.get("renameTo"),getTitle());
				setTitle(newName);
			}
		};
		
//		Action aSetLines=new AbstractAction(Language.get("setLines")) {
//			public void actionPerformed(ActionEvent arg0) {
//				String sLines=JOptionPane.showInputDialog(Language.get("showLinesChange"));
//				int lines=(new Integer(sLines)).intValue();
//				gl=new GridLayout();
//				gl.setColumns(lines);
//				gl.setRows((jWatchers.size()-1)/lines+1);
//				refreshLayout();
//			}
//		};
		
		WindowListener wl=new WindowListener(){
			@Override
			public void windowActivated(WindowEvent arg0) {}
			
			@Override
			public void windowClosed(WindowEvent arg0) {}
			
			@Override
			public void windowClosing(WindowEvent arg0){
				aQuit.actionPerformed(null);
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {}

			@Override
			public void windowDeiconified(WindowEvent arg0) {}

			@Override
			public void windowIconified(WindowEvent arg0) {}

			@Override
			public void windowOpened(WindowEvent arg0) {}
        };
        
        addWindowListener(wl);
			
		//Build and add the MenuBar to Frame
        JMenuBar menuBar=new JMenuBar();
        JMenu datei=new JMenu(Language.get("file"));
        JMenu tools=new JMenu(Language.get("tools"));
        menuBar.add(datei);
        menuBar.add(tools);
        
        //Set some key-Bindings for the MenuItems and add MenuItems to Menus
        JMenuItem mRefresh=new JMenuItem(aRefresh);
        mRefresh.setAccelerator(KeyStroke.getKeyStroke('R',InputEvent.CTRL_DOWN_MASK));
        datei.add(mRefresh);
        
        JMenuItem mQuit=new JMenuItem(aQuit);
        mQuit.setAccelerator(KeyStroke.getKeyStroke('D',InputEvent.CTRL_DOWN_MASK));
        datei.add(mQuit);
        
        JMenuItem mPrint=new JMenuItem(aPrint);
        mPrint.setAccelerator(KeyStroke.getKeyStroke('P',InputEvent.CTRL_DOWN_MASK));
        tools.add(mPrint);
        
        JMenuItem mRename=new JMenuItem(aRename);
        tools.add(mRename);
        
        //TODO change Layout by input
//        JMenuItem mSetLines=new JMenuItem(aSetLines);
//        tools.add(mSetLines);
//        
        this.setJMenuBar(menuBar);
		this.pack();
		this.setVisible(true);
	}
	
	public void refresh(){
		for (JQualifyingWatcher jWatcher : jWatchers){
			jWatcher.refresh();
		}
		this.repaint();
	}
	
//	public void refreshLayout(){
//		removeAll();
//		setLayout(gl);
//		for (JQualifyingWatcher jWatcher : jWatchers){
//			add(jWatcher);
//		}
//	}
}
