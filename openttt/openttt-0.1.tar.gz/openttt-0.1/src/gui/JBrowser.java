package gui;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;

import database.Calculator;

@SuppressWarnings("serial")
public class JBrowser extends JFrame implements MouseListener {
	private JEditorPane area;
	private JScrollPane scroll;
	
	public JBrowser(String text){
		super(Language.get("groupTables"));
		this.area=new JEditorPane("text/html", text);
		area.addMouseListener(this);
		this.setLayout(new BorderLayout());
		scroll=new JScrollPane(area);
		scroll.setAutoscrolls(false);
		this.add(scroll,BorderLayout.CENTER);
		this.setSize(new Dimension(500, 600));
		
		//Actions
		Action aQuit=new AbstractAction(Language.get("quit")) {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		};
		
		Action aPrint=new AbstractAction(Language.get("print")) {
			public void actionPerformed(ActionEvent arg0) {
				File file;
				if (System.getProperty("java.io.tmpdir").charAt(0)=='/')
					file=new File(System.getProperty("java.io.tmpdir")+"/groupTable.html");
				else
					file=new File(System.getProperty("java.io.tmpdir")+"\\groupTable.html");
				System.out.println(System.getProperty("java.io.tmpdir"));
				try {
					PrintWriter out = new PrintWriter(file);
					out.write(area.getText());
					out.close();
					if (Desktop.getDesktop().isSupported(Desktop.Action.PRINT))
						Desktop.getDesktop().print(file);
					else {
						System.out.println("WARNING: Printing not supported on this platform, so trying to open in Browser.");
						Desktop.getDesktop().open(file);
					}
				} catch (FileNotFoundException e) {
					System.out.println("ERROR: File not found.");
				} catch (IOException e) {
					System.out.println("ERROR: Can't print.");
				}
				
			}
		};
		
		Action aEmpty=new AbstractAction(Language.get("emptyTables")){
			public void actionPerformed(ActionEvent arg0) {
				area.setText(Calculator.htmlTabularEmpty(Main.getInstance().getTournament().getQualifying().getGroups()));
				
			}
		};
		
		Action aRefresh=new AbstractAction(Language.get("refresh")){
			public void actionPerformed(ActionEvent arg0){
				refresh();
			}
		};
			
		//Build and add the MenuBar to Frame
        JMenuBar menuBar=new JMenuBar();
        JMenu datei=new JMenu(Language.get("file"));
        JMenu tools=new JMenu(Language.get("tools"));
        menuBar.add(datei);
        menuBar.add(tools);
        
        //Set some key-Bindings for the MenuItems and add MenuItems to Menus
        JMenuItem mRefresh=new JMenuItem(aRefresh);
        mRefresh.setAccelerator(KeyStroke.getKeyStroke('R',InputEvent.CTRL_DOWN_MASK));
        datei.add(mRefresh);
        
        JMenuItem mQuit=new JMenuItem(aQuit);
        mQuit.setAccelerator(KeyStroke.getKeyStroke('D',InputEvent.CTRL_DOWN_MASK));
        datei.add(mQuit);
        
        JMenuItem mPrint=new JMenuItem(aPrint);
        mPrint.setAccelerator(KeyStroke.getKeyStroke('P',InputEvent.CTRL_DOWN_MASK));
        tools.add(mPrint);
        
        JMenuItem mEmpty=new JMenuItem(aEmpty);
        tools.add(mEmpty);
        
        JMenuItem mFill=new JMenuItem(aRefresh);
        mFill.setText(Language.get("fillTables"));
        tools.add(mFill);
        
        this.setJMenuBar(menuBar);
		
		this.setVisible(true);
		
	}
	
	public void refresh(){
		area.setText(Calculator.htmlTabular(Main.getInstance().getTournament().getQualifying().getGroups()));
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		if (arg0.getClickCount()==2){
			Toolkit tk=Toolkit.getDefaultToolkit();
			PrintJob pj=tk.getPrintJob(new Frame(), "", null);
			if (pj!=null){
				Graphics g=pj.getGraphics();
				this.printComponents(g);
				g.dispose();
				pj.end();
			}
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		
	}

}
