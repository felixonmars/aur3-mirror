package gui;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Language {

	private static Map<String,String> keys;
	private static List<String> languages;
	private static String prefix="en_";
	private static Language theInstance;
	
	private static void createInstance(){
		if (theInstance==null) theInstance=new Language();
	}
	
	public static List<String> getLanguages(){
		createInstance();
		return languages;
	}
	
	public static void setLanguage(String langString){
		prefix=langString.substring(0,2)+"_";
		Main.getInstance().refresh();
	}
	
	private Language(){
		keys=new TreeMap<String,String>();
		languages=new ArrayList<String>();
		try {
			BufferedReader in = new BufferedReader(new FileReader("language.ini"));
			String line = null;
			while ((line = in.readLine()) != null) {
				if (line.contains("=")) {
					String[] tabs=line.split("=");
					if (tabs[0].equals("selected_Language")){
						prefix=tabs[1]+"_";
					} else if (tabs[0].equals("available_languages")){
						String[] langs=tabs[1].split(",");
						for (String s: langs)
							languages.add(s);
					} else keys.put(tabs[0], tabs[1]);
				}
				
			}
		} catch (IOException e) {
			System.out.println("ERROR: Can't read language.ini");
		}
	}
	
	public static String getPrefix(){
		return prefix;
	}
	
	public static String get(String key){
		createInstance();
		return (String) keys.get(prefix+key);
	}
	
}
