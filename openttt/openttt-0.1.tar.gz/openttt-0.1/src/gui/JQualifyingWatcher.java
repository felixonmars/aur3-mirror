package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import database.Group;

@SuppressWarnings("serial")
public class JQualifyingWatcher extends JPanel implements ActionListener {
	
	private JComboBox gruppen;
	private JTable table;
	
	public JQualifyingWatcher(Group g){
		super();
		generateWindow();
		gruppen.setSelectedItem(g);
		refresh();
	}
	
	public void generateWindow(){
		setLayout(new BorderLayout());
		
		JPanel panel=new JPanel();
		panel.setLayout(new BorderLayout());
		
		this.gruppen=new JComboBox(Main.getInstance().getTournament().getQualifying().getGroups().toArray());
		this.gruppen.addActionListener(this);
		panel.add(this.gruppen,BorderLayout.NORTH);
		
		Object[][] data = ((database.Group)this.gruppen.getSelectedItem()).getPlayerStats();
		Object[] columnNames = new String[] {Language.get("name"),Language.get("balls"),Language.get("sentences"),Language.get("games")};
				
		this.table = new JTable(4, data.length);
		table.setModel(new DefaultTableModel(data, columnNames));
		
		TableColumn c = table.getColumnModel().getColumn(0);
		c.setPreferredWidth(170);
		
		this.table.updateUI();
		
		JScrollPane scrollpane = new JScrollPane(this.table);
		
		add(panel,BorderLayout.NORTH);
		add(scrollpane);
			
		this.setPreferredSize(new Dimension(280,150));
		setVisible(true);
	}

	public void refresh(){
		Object[][] data = Main.getInstance().getTournament().getQualifying().getGroups().get(this.gruppen.getSelectedIndex()).getPlayerStats();
		String[] columnNames = new String[] {Language.get("name"),Language.get("balls"),Language.get("sentences"),Language.get("games")};
		DefaultTableModel tm=new DefaultTableModel();
		tm.setDataVector(data, columnNames);
		this.table.setModel(tm);
		
		TableColumn c = table.getColumnModel().getColumn(0);
		c.setPreferredWidth(160);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		this.refresh();
	};
	
	
}
