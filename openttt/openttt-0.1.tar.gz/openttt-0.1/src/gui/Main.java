package gui;

import icons.Resources;

import java.awt.BorderLayout;
import java.awt.MediaTracker;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

import database.Calculator;
import database.Tournament;

public class Main{

	private static Main theInstance;
	
	private JPlayers spieler;
	private JQualifying vorrunde;
	private JKnockOutBuilder knockOutBuilder;
	private JKnockOut knockOut;
	private Tournament tournament;
	private JFrame frame;
	private static String actualFile;
	private JQualifyingWatcherWindow jWatcherWindow;
	private JKnockOutWatcherWindow jKOWatcherWindow;
	private boolean doublesView=false;
	private JLabel status;
	
	private JMenuItem mSingle, mDouble, mQualifying, mKnockOut;
	
	public static Main getInstance(){
		return theInstance;
	}
	
	public boolean getDoubleView(){
		return doublesView;
	}
	
	public void refresh(){
		if (vorrunde!=null) vorrunde.refresh();
		if (knockOut!=null) knockOut.refresh();
		if (jWatcherWindow!=null) jWatcherWindow.refresh();
		if (jKOWatcherWindow!=null) jKOWatcherWindow.refresh();
		if (tournament==null){
			mQualifying.setEnabled(false);
			mKnockOut.setEnabled(false);
		} else {
			mQualifying.setEnabled(!(tournament.getState()>2));
			mKnockOut.setEnabled(!(tournament.getState()>3));
		}
		refreshState();
		frame.repaint();
	}
	
	public database.Tournament getTournament(){
		return this.tournament;
	}
	
	public static void main(String[] args) {
		theInstance=new Main();
		theInstance.generateWindow();
		if (args.length!=0){
			actualFile=args[0];
			try {
				theInstance.loadTournament(args[0]);
			} catch (FileNotFoundException e) {
				System.out.println("File not found: "+args[0]);
				actualFile=null;
				e.printStackTrace();
			} catch (IOException e) {
				System.out.println("Cant read file: "+args[0]);
				actualFile=null;
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				System.out.println("Some class Error: "+args[0]);
				actualFile=null;
				e.printStackTrace();
			}
		}
	};
	
	public Main(){
		actualFile=null;
		status=new JLabel();
		
		refreshState();
	}
	
	public void refreshState(){
		Runtime rt=Runtime.getRuntime();
		int usedMemMiB=(int)(rt.totalMemory()-rt.freeMemory());
		usedMemMiB=usedMemMiB/1024/1024;
		int maxMemMiB=(int)rt.maxMemory();
		maxMemMiB=maxMemMiB/1024/1024;
		if (actualFile==null)
			status.setText("Mem: "+usedMemMiB+"MiB / "+maxMemMiB+"MiB");
		else 
			if (tournament.isUnsaved())
				status.setText("Mem: "+usedMemMiB+"MiB / "+maxMemMiB+"MiB, File: "+actualFile+"*");
			else
				status.setText("Mem: "+usedMemMiB+"MiB / "+maxMemMiB+"MiB, File: "+actualFile);
	}
	
	public void saveT(){
		JFileChooser chooser = new JFileChooser();
		int returnVal = chooser.showOpenDialog(null);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			actualFile=chooser.getSelectedFile().getAbsoluteFile().getAbsolutePath();
			try {
				saveTournament(actualFile);
			} catch (FileNotFoundException e) {
				System.out.println("File not found.");
				e.printStackTrace();
			} catch (IOException e) {
				System.out.println("File not accessible.");
				e.printStackTrace();
			}
		};
	}
	
	public void showMe(JPanel panel){
		if (spieler!=null) this.frame.remove(spieler);
		if (vorrunde!=null) this.frame.remove(vorrunde);
		if (knockOutBuilder!=null) this.frame.remove(knockOutBuilder);
		if (knockOut!=null) this.frame.remove(knockOut);
		this.frame.add(panel);
		this.frame.pack();
	}
	
	public void startNew(){
		tournament=new database.Tournament();
		incState();
	};
	
	public void saveTournament(String fileName) throws FileNotFoundException, IOException{
		//appends ".ott" to filename if not present
		String file;
		if (fileName.endsWith(".ott")) file=fileName;
		else file=fileName+".ott";
		
		fileName=file;
		
		//writes the Object to the file
		ObjectOutputStream objOut = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
		tournament.setUnsaved(false);
		objOut.writeObject(tournament);
		objOut.close();
	};
	
	public void loadTournament(String fileName) throws FileNotFoundException, IOException, ClassNotFoundException, StreamCorruptedException {
		//reads the Object from file
		ObjectInputStream objIn = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileName)));
		tournament = (database.Tournament) objIn.readObject();
		objIn.close();

		//determines which Window to open and opens it
		if (tournament.getState()<3){
			spieler=new JPlayers();
			spieler.generateWindow();
			spieler.showWindow();
		};
		if (tournament.getState()==3){
			vorrunde=new JQualifying(tournament.getQualifying());
			vorrunde.generateWindow();
			vorrunde.showWindow();
		};
		if (tournament.getState()==4){
			knockOutBuilder=new JKnockOutBuilder();
			knockOutBuilder.generateWindow();
			knockOutBuilder.showWindow();
		}
		if (tournament.getState()==5){
			knockOut=new JKnockOut();
			knockOut.generateWindow();
			knockOut.showWindow();
		}
		
		mQualifying.setSelected(tournament.getDoQualifying());
		mKnockOut.setSelected(tournament.getDoKnockOut());
		refresh();
	};
	
	@SuppressWarnings("serial")
	public void generateWindow(){
		//generate the Frame
		frame = new JFrame(Language.get("openTTT"));
        frame.setSize(300, 200);
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        
        frame.add(status, BorderLayout.SOUTH);
        
        //set the LookAndFeel
        try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e1) {
			System.out.println("WARNING: Can't set LookAndFeel.");
		}
		
		//set the WindowIcon
		MediaTracker mt=new MediaTracker(frame);
		mt.addImage(Resources.main, 0);
		try {
			mt.waitForAll();
		} catch(Exception e) {
			System.out.println("WARNING: Can't set Icon for MainWindow.");
		};
		frame.setIconImage(Resources.main);
        
		//Define some Actions for Menu
        Action neuAction=new AbstractAction(Language.get("new")){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (tournament==null){
					Main.getInstance().startNew();				
				} else {
					//TODO language
					JOptionPane.showMessageDialog(frame, "Neues Turnier erstellen unmöglich, es ist noch ein Turnier offen!");
        		};
			};
        };
		        
        Action loadAction=new AbstractAction(Language.get("open")){
        	@Override
			public void actionPerformed(ActionEvent arg0) {       		
        		if (tournament==null){
        			JFileChooser chooser = new JFileChooser();
        			int returnVal = chooser.showOpenDialog(null);
        			if(returnVal == JFileChooser.APPROVE_OPTION) {
        				actualFile=chooser.getSelectedFile().getAbsoluteFile().getAbsolutePath();
        				try {
        					loadTournament(actualFile);
        				} catch (FileNotFoundException e) {
        					System.out.println("ERROR: File not found: "+chooser.getSelectedFile().getAbsoluteFile().getAbsolutePath());
        				} catch (StreamCorruptedException e) {
        					System.out.println("ERROR: File of wrong format: "+chooser.getSelectedFile().getAbsoluteFile().getAbsolutePath());
        				} catch (ClassNotFoundException e) {
        					System.out.println("ERROR: File of wrong format: "+chooser.getSelectedFile().getAbsoluteFile().getAbsolutePath());
        				} catch (IOException e) {
        					System.out.println("ERROR: File not accessible: "+chooser.getSelectedFile().getAbsoluteFile().getAbsolutePath());
						}
        			}
        		}
			}
        };
        
        Action saveAction=new AbstractAction(Language.get("save")){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (actualFile==null){
					saveT();
				} else {
					try {
						saveTournament(actualFile);
						refreshState();
					} catch (FileNotFoundException e) {
						System.out.println("ERROR: File not found: "+actualFile);
					} catch (IOException e) {
						System.out.println("ERROR: File not accessible: "+actualFile);
					}
				}		
			}
        };
        
        Action saveToAction=new AbstractAction(Language.get("saveas")){
        	@Override
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser = new JFileChooser();
				int returnVal = chooser.showOpenDialog(null);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					actualFile=chooser.getSelectedFile().getAbsoluteFile().getAbsolutePath();
					try {
						saveTournament(actualFile);
					} catch (FileNotFoundException e) {
						System.out.println("ERROR: File not found: "+actualFile);
					} catch (IOException e) {
						System.out.println("ERROR: File not accessible: "+actualFile);
					}
				};				
			}
        };
        
        final Action quitAction=new AbstractAction(Language.get("quit")){
        	@Override
			public void actionPerformed(ActionEvent arg0) {
        		if (tournament!=null && tournament.isUnsaved()){
        			int n = JOptionPane.showOptionDialog( null, 
        				"Es gibt ungesicherte Änderungen. Soll das Programm trotzdem geschlossen werden?",      // question 
          		        "Ungesicherte Änderungen",           													// title 
          		        JOptionPane.YES_NO_CANCEL_OPTION, 
          		        JOptionPane.QUESTION_MESSAGE,  															// icon 
          		        null, null, null);
        			if (n==JOptionPane.YES_OPTION ) 
        				frame.dispose(); 
        		} else
        			frame.dispose();
			}
        };
        
        Action openWatcherAction=new AbstractAction(Language.get("openWatcher")){
			@Override
			public void actionPerformed(ActionEvent e) {
				if (Main.getInstance().getTournament()==null){
					JOptionPane.showMessageDialog(frame, "Es ist kein Turnier zum Betrachten da!");
				} else {
					if (tournament.getState()==5 & tournament.getKnockOut()!=null & jKOWatcherWindow==null)
						jKOWatcherWindow=new JKnockOutWatcherWindow();
					if (tournament.getState()==3 & tournament.getQualifying()!=null & jWatcherWindow==null)
						jWatcherWindow=new JQualifyingWatcherWindow(tournament.getQualifying().getGroups());
				}
			}
        };
        
        Action emptyTabular=new AbstractAction(Language.get("printGames")){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if (Main.getInstance().getTournament()==null){
					JOptionPane.showMessageDialog(frame, "Es ist kein Turnier angesetzt!");
				} else {
					if (Main.getInstance().getTournament().getQualifying()==null){
						JOptionPane.showMessageDialog(frame, "Es ist keine Vorrunde angesetzt!");
					} else {
						new JBrowser(Calculator.htmlTabular(getTournament().getQualifying().getGroups()));
					}
				}
			}
        };
        
        //Displays a alert Window onClosing
        WindowListener wl=new WindowListener(){
			@Override
			public void windowActivated(WindowEvent arg0) {}
			
			@Override
			public void windowClosed(WindowEvent arg0) {}
			
			@Override
			public void windowClosing(WindowEvent arg0){
				quitAction.actionPerformed(null);
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {}

			@Override
			public void windowDeiconified(WindowEvent arg0) {}

			@Override
			public void windowIconified(WindowEvent arg0) {}

			@Override
			public void windowOpened(WindowEvent arg0) {}
        };

        //Build and add the MenuBar to Frame
        JMenuBar menuBar=new JMenuBar();
        frame.addWindowListener(wl);
        JMenu datei=new JMenu(Language.get("file"));
        JMenu tools=new JMenu(Language.get("tools"));
        JMenu prefs=new JMenu(Language.get("preferences"));
        menuBar.add(datei);
        menuBar.add(tools);
        menuBar.add(prefs);
        
        //Set some key-Bindings for the MenuItems and add MenuItems to Menus
        JMenuItem mNewAction=new JMenuItem(neuAction);
        mNewAction.setAccelerator(KeyStroke.getKeyStroke('N',InputEvent.CTRL_DOWN_MASK));
        datei.add(mNewAction);
        
        JMenuItem mLoadAction=new JMenuItem(loadAction);
        mLoadAction.setAccelerator(KeyStroke.getKeyStroke('O',InputEvent.CTRL_DOWN_MASK));
        datei.add(mLoadAction);
        
        JMenuItem mSaveAction=new JMenuItem(saveAction);
        mSaveAction.setAccelerator(KeyStroke.getKeyStroke('S',InputEvent.CTRL_DOWN_MASK));
        datei.add(mSaveAction);
        
        datei.add(saveToAction);
        
        JMenuItem mQuitAction=new JMenuItem(quitAction);
        mQuitAction.setAccelerator(KeyStroke.getKeyStroke('D',InputEvent.CTRL_DOWN_MASK));
        datei.add(mQuitAction);
        
        JMenuItem mOpenWatcherAction=new JMenuItem(openWatcherAction);
        mOpenWatcherAction.setAccelerator(KeyStroke.getKeyStroke('W',InputEvent.CTRL_DOWN_MASK));
        tools.add(mOpenWatcherAction);
        
        tools.add(emptyTabular);
        
        ButtonGroup groupDouble=new ButtonGroup();
        mSingle=new JRadioButtonMenuItem(new AbstractAction(Language.get("single")){
			public void actionPerformed(ActionEvent arg0) {
				if (((JRadioButtonMenuItem)arg0.getSource()).isSelected()) doublesView=false;
				Main.getInstance().refresh();
			}
        });
        mDouble=new JRadioButtonMenuItem(new AbstractAction(Language.get("doubles")){
			public void actionPerformed(ActionEvent arg0) {
				if (((JRadioButtonMenuItem)arg0.getSource()).isSelected()) doublesView=true;
				Main.getInstance().refresh();
			}
        });
        
        groupDouble.add(mSingle);
        groupDouble.add(mDouble);
        
        prefs.add(mSingle);
        prefs.add(mDouble);
        
        mSingle.setSelected(true);
        prefs.addSeparator();
        
        mQualifying=new JCheckBoxMenuItem(new AbstractAction(Language.get("qualifying")){
			public void actionPerformed(ActionEvent arg0) {
				if (tournament!=null){
					if (((JCheckBoxMenuItem)arg0.getSource()).isSelected()) getTournament().setDoQualifying(true);
					else getTournament().setDoQualifying(false);
				} 
			}
        });
        if (tournament!=null) mQualifying.setSelected(tournament.getDoQualifying());
        else mQualifying.setSelected(true);
        mKnockOut=new JCheckBoxMenuItem(new AbstractAction(Language.get("knockOut")){
			public void actionPerformed(ActionEvent arg0) {
				if (tournament!=null){
					if (((JCheckBoxMenuItem)arg0.getSource()).isSelected()) getTournament().setDoKnockOut(true);
					else getTournament().setDoKnockOut(false);
				}
			}
        });
        if (tournament!=null) mKnockOut.setSelected(tournament.getDoKnockOut());
        else mKnockOut.setSelected(true);
        
        prefs.add(mQualifying);
        prefs.add(mKnockOut);
        prefs.addSeparator();
        
        List<String> langs=Language.getLanguages();
        ButtonGroup groupLangs=new ButtonGroup();
        for (final String l: langs){
        	JRadioButtonMenuItem mLanguage=new JRadioButtonMenuItem(new AbstractAction(l){
				public void actionPerformed(ActionEvent arg0) {
					if (((JRadioButtonMenuItem)arg0.getSource()).isSelected()) Language.setLanguage(l);
				}
        	});
        	groupLangs.add(mLanguage);
        	prefs.add(mLanguage);
        	mLanguage.setSelected(Language.getPrefix().substring(0,2).equals(l.split(":")[0]));
        }
        
        //adds the Menu to the Frame and shows the Frame
        frame.setJMenuBar(menuBar);
        frame.setVisible(true);
        refresh();
	};
	
	public void incState(){
		// 0..not initialized
		// 2..Spielerfenster offen
		// 3..Vorrundenfenster offen
		// 4..Gruppenauswertung offen
		// 5..Knockout offen
		if (tournament.getState()!=0 & actualFile!=null){
			try {
				saveTournament(actualFile.replace(".ott", "."+tournament.getState()+".ott"));
			} catch (FileNotFoundException e) {
				System.out.println("Error: file not found!");
			} catch (IOException e) {
				System.out.println("Error: file not writable!");
			}
		}
		
		if (tournament.getState()==4){
			if (tournament.getDoKnockOut()){
				this.knockOut=new JKnockOut();
				this.knockOut.generateWindow();
				this.knockOut.showWindow();
				this.tournament.incState();
			}
		}
		if (tournament.getState()==3){
			if (tournament.getDoKnockOut()){
				this.knockOutBuilder=new JKnockOutBuilder();
				this.knockOutBuilder.generateWindow();
				this.knockOutBuilder.showWindow();
				this.tournament.incState();
			}
		}
		if (tournament.getState()==2){
			if (!getTournament().getDoQualifying()){
				//TODO noknock work around
				tournament.incState();
				incState();
			} else {
				int holegamescount=0;
				for (database.Group g:tournament.getQualifying().getGroups()){
					holegamescount+=g.startGroup();
				}
				this.vorrunde=new JQualifying(tournament.getQualifying());
				this.vorrunde.generateWindow();
				this.vorrunde.showWindow();
				this.tournament.incState();
			}
		};
		if (tournament.getState()==0){
			this.tournament.setQualifying(new database.Qualifying(1));
			this.tournament.incState();
			this.spieler=new JPlayers();
			this.spieler.generateWindow();
			this.spieler.showWindow();
			this.tournament.incState();
		};
		refresh();
	}

	public void removeWatcher(String string) {
		if (string.equals("KO"))
			jKOWatcherWindow=null;
		if (string.equals("Q"))
			jWatcherWindow=null;
		
	}

}
