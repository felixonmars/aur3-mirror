package gui;

import java.awt.Frame;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import database.Game;
import database.Player;

@SuppressWarnings("serial")
public class JKnockOutWatcherWindow extends JFrame {
	private JTreeView<Player,Game> treeView;
	
	public JKnockOutWatcherWindow(){
		super(Language.get("knockOutWatcher"));
		treeView=new JTreeView<Player,Game>(Main.getInstance().getTournament().getKnockOut().getTree(),
				Main.getInstance().getTournament().getKnockOut().getGames());
		this.add(treeView);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		
		//Actions
		final Action aQuit=new AbstractAction(Language.get("quit")) {
			public void actionPerformed(ActionEvent arg0) {
				Main.getInstance().removeWatcher("KO");
				dispose();
			}
		};
		
		Action aPrint=new AbstractAction(Language.get("print")) {
			public void actionPerformed(ActionEvent arg0) {
				Toolkit tk=Toolkit.getDefaultToolkit();
				PrintJob pj=tk.getPrintJob(new Frame(), "", null);
				if (pj!=null){
					Graphics g=pj.getGraphics();
					treeView.printAll(g);
					g.dispose();
					pj.end();
				}
			}
		};
		
		Action aRefresh=new AbstractAction(Language.get("refresh")){
			public void actionPerformed(ActionEvent arg0){
				refresh();
			}
		};
		
		Action aRename=new AbstractAction(Language.get("rename")) {
			public void actionPerformed(ActionEvent arg0) {
				String newName=JOptionPane.showInputDialog(Language.get("renameTo"),getTitle());
				setTitle(newName);
			}
		};
		
		 //Displays a alert Window onClosing
        WindowListener wl=new WindowListener(){
			@Override
			public void windowActivated(WindowEvent arg0) {}
			
			@Override
			public void windowClosed(WindowEvent arg0) {}
			
			@Override
			public void windowClosing(WindowEvent arg0){
				aQuit.actionPerformed(null);
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {}

			@Override
			public void windowDeiconified(WindowEvent arg0) {}

			@Override
			public void windowIconified(WindowEvent arg0) {}

			@Override
			public void windowOpened(WindowEvent arg0) {}
        };
        
        addWindowListener(wl);
			
		//Build and add the MenuBar to Frame
        JMenuBar menuBar=new JMenuBar();
        JMenu datei=new JMenu(Language.get("file"));
        JMenu tools=new JMenu(Language.get("tools"));
        menuBar.add(datei);
        menuBar.add(tools);
        
        //Set some key-Bindings for the MenuItems and add MenuItems to Menus
        JMenuItem mRefresh=new JMenuItem(aRefresh);
        mRefresh.setAccelerator(KeyStroke.getKeyStroke('R',InputEvent.CTRL_DOWN_MASK));
        datei.add(mRefresh);
        
        JMenuItem mQuit=new JMenuItem(aQuit);
        mQuit.setAccelerator(KeyStroke.getKeyStroke('D',InputEvent.CTRL_DOWN_MASK));
        datei.add(mQuit);
        
        JMenuItem mPrint=new JMenuItem(aPrint);
        mPrint.setAccelerator(KeyStroke.getKeyStroke('P',InputEvent.CTRL_DOWN_MASK));
        tools.add(mPrint);
        
        JMenuItem mRename=new JMenuItem(aRename);
        tools.add(mRename);
        
        this.setJMenuBar(menuBar);
		
		this.pack();
		this.setVisible(true);
	}
	
	public void refresh(){
		treeView.setEdges(Main.getInstance().getTournament().getKnockOut().getGames());
		treeView.repaint();
		repaint();
	}
}
