package gui;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JPanel;

import database.Edge;
import database.Node;


@SuppressWarnings("serial")
public class JTreeView<T extends Node, U extends Edge<T>> extends JPanel implements MouseListener{
	private Graphics graphic;
	private List<List<T>> tree;
	private List<U> edges;
	
	/**
	 * Offset for Window Decoration
	 */
	private static final int seedX=5, seedY=20;
	
	/**
	 * Height and Length of a Cell 
	 */
	private static final int h=15, l=135;
	
	/**
	 * Distances between the cells
	 */
	private static final int dx1=10, dx2=35, dy1=5, dy2=8;
	
	/**
	 * Constructor for the Tree View
	 * @param tree top level list represents the levels of the ko-tree, low level list
	 * represents the players in the level 
	 */
	public JTreeView(List<List<T>> tree, List<U> edges){
		super();
		this.tree=tree;
		this.edges=edges;
		int sizeX=tree.size()*l+(tree.size()-1)*(dx1+dx2)+2*seedX;
		int sizeY=tree.get(0).size()*h+(tree.get(0).size()-1)*dy1+(tree.get(0).size()/2-1)*(dy2-dy1)+2*seedY-2*h+1;
		this.setPreferredSize(new Dimension(sizeX,sizeY));
		this.addMouseListener(this);
	}
	
	public void setEdges(List<U> edges){
		this.edges=edges;
	}
	
	private int[] getFootCoord(int layer,int elemNum){
		int[] result=new int[2];
		result[0]=seedX+(l+(dx1+dx2))*layer;
		
		if (layer==0){
			result[1]=seedY+(dy1+h)*(elemNum)+(dy2-dy1)*(elemNum/2);
		} else {
			result[1]=getFootCoord(layer-1, 2*elemNum)[1]
			         +(getFootCoord(layer-1, 2*elemNum+1)[1]-getFootCoord(layer-1, 2*elemNum)[1])/2;
		}
		
		return result;
	}
	
	public void drawTree(){
		int i=0, j=0;
		for (List<T> objects: tree){
			for (T object: objects){
				if (object==null)
					drawNode("",i,j);
				else
					drawNode(object.toString(),i,j);
				j++;
			}
			j=0;
			i++;
		}
	}
	
	private void drawNode(String text, int layer, int elemNum){
		int[] footCoord=getFootCoord(layer, elemNum);
		
		int lbx=footCoord[0];
		int lby=footCoord[1];
		
		int rbx=lbx+l;
		int rby=lby;
		
		int ltx=lbx;
		int lty=lby-h;
		
		int rtx=rbx;
		int rty=lty;
		
		graphic.drawString(text,lbx+1,lby-2);
		graphic.drawLine(lbx, lby, rbx, rby);	//bottom line
		graphic.drawLine(lbx, lby, ltx, lty);	//left line
		graphic.drawLine(rbx, rby, rtx, rty);	//right line
		graphic.drawLine(ltx, lty, rtx, rty);	//top line
		drawChildLine(layer,elemNum);
	}
	
	private void drawChildLine(int layer, int elemNum) {
		if (layer==0) return;
		int[] foot1=getFootCoord(layer-1, elemNum*2);
		int[] foot2=getFootCoord(layer-1, elemNum*2+1);
		int[] foot12=getFootCoord(layer, elemNum);
		
		U edge=null;
		for (U edge1:edges){
			T node1=tree.get(layer-1).get(elemNum*2);
			T node2=tree.get(layer-1).get(elemNum*2+1);
			if (edge1.getLeft().equals(node1) & edge1.getRight().equals(node2)){
				edge=edge1;
				break;
			}
		}
	
		graphic.drawLine(foot1[0]+l, foot1[1]-h/2, foot1[0]+l+dx1, foot1[1]-h/2);
		graphic.drawLine(foot2[0]+l, foot2[1]-h/2, foot2[0]+l+dx1, foot2[1]-h/2);
		graphic.drawLine(foot2[0]+l+dx1, foot2[1]-h/2, foot1[0]+l+dx1, foot1[1]-h/2);
		graphic.drawLine(foot12[0],foot12[1]-h/2,foot1[0]+l+dx1,foot12[1]-h/2);
		if (edge!=null)
			graphic.drawString(edge.edgePrint(),foot1[0]+l+dx1+2, foot12[1]-h/2-2);
	}

	@Override
	public void paintComponent(Graphics g){
		this.graphic=g;
		drawTree();
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		if (arg0.getClickCount()==2){
			Toolkit tk=Toolkit.getDefaultToolkit();
			PrintJob pj=tk.getPrintJob(new Frame(), "", null);
			if (pj!=null){
				Graphics g=pj.getGraphics();
				this.printAll(g);
				g.dispose();
				pj.end();
			}
		}
		
	}

	public void mouseEntered(MouseEvent arg0) {
		
	}

	public void mouseExited(MouseEvent arg0) {
		
	}

	public void mousePressed(MouseEvent arg0) {
		
	}

	public void mouseReleased(MouseEvent arg0) {
		
	}
	
}
