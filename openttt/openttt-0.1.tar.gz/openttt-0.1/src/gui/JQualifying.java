package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Collections;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;

import database.Calculator;
import database.Game;
import database.Qualifying;

public class JQualifying extends JPanel implements ActionListener, KeyListener {

	private static final long serialVersionUID = 2720930716902608144L;
	protected List<database.Game> hole, running, done;
	private Qualifying qualifying;
	
	private JPanel panel1, panel1_1, panel2, panel2_1, panel3, panel3_1;
	protected JPanel panelmain;
	protected JList jHole, jRunning, jDone;
	private JButton refresh, startgame, addsentence, declarefinished, endQualifying, unfinishGame, unsetGame;
	protected JTextField sentenceline;
	private JGroupTable jgt;
	
	protected boolean showEndQuali=true;
	
	public JQualifying(Qualifying q){
		super();
		this.qualifying=q;
	}
	
	public void showWindow(){
		Main.getInstance().showMe(this);
	}
	
	public void refresh(){
		refreshLists();
	}
	
	public void refreshLists(){
		int idxhole,idxrunning,idxfinished;
		idxhole=jHole.getSelectedIndex();
		idxrunning=jRunning.getSelectedIndex();
		idxfinished=jDone.getSelectedIndex();
		hole=qualifying.getGamesByState(0);
		Collections.sort(hole);
		running=qualifying.getGamesByState(1);
		done=qualifying.getGamesByState(2);
		jHole.setListData(hole.toArray());
		jRunning.setListData(running.toArray());
		jDone.setListData(done.toArray());
		jHole.setSelectedIndex(idxhole);
		jRunning.setSelectedIndex(idxrunning);
		jDone.setSelectedIndex(idxfinished);
		jHole.updateUI();
		jRunning.updateUI();
		jDone.updateUI();
		if (jRunning.getSelectedIndex()==-1 & jRunning.getModel().getSize()>0)
			jRunning.setSelectedIndex(0);
		jgt.refresh();
	}
	
	public void generateWindow(){
		//Calculate Group Games:
		jHole=new JList();
		jRunning=new JList();
		jDone=new JList();
		jgt=new JGroupTable(qualifying);
		
		//initializing other Arrays:
		this.refresh();
		
		//Setting up Frame and Panels:
        this.panel1=new JPanel();
        this.panel1.setLayout(new BorderLayout());
        this.panel1.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(Language.get("prepared")),
                BorderFactory.createEmptyBorder(5,5,5,5)));
        
        this.panel1_1=new JPanel();
        this.panel1_1.setLayout(new GridLayout(2,1));
        
        this.panel2=new JPanel();
        this.panel2.setLayout(new BorderLayout());
        this.panel2.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(Language.get("running")),
                BorderFactory.createEmptyBorder(5,5,5,5)));
        
        this.panel2_1=new JPanel();
       	this.panel2_1.setLayout(new GridLayout(2,1));
        
        this.panel3=new JPanel();
        this.panel3.setLayout(new BorderLayout());
        this.panel3.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(Language.get("done")),
                BorderFactory.createEmptyBorder(5,5,5,5)));
        
        this.panel3_1=new JPanel();
        if (showEndQuali) this.panel3_1.setLayout(new GridLayout(2,1));
        else this.panel3_1.setLayout(new GridLayout(1,1));
        
        this.panelmain=new JPanel();
        this.panelmain.setLayout(new GridLayout(1,3));
        
        //Building panel1:
        this.jHole.addMouseListener(new MouseAdapter() {
        	@Override
			public void mouseClicked(MouseEvent e){
        		   if(e.getClickCount() == 2){
        		     int index = jHole.locationToIndex(e.getPoint());
        		     hole.get(index).startGame();
        		     Main.getInstance().refresh();
        		     }
        		   }

		});
        this.jHole.setCellRenderer(new ListCellRenderer(){
			@Override
			public Component getListCellRendererComponent(JList arg0,
					Object arg1, int arg2, boolean isSelected, boolean arg4) {
				Game g=(Game)arg1;
				JLabel lbl;
				if (g.getGroup()==-1){
					lbl=new JLabel(g.toString());
				} else {
					lbl=new JLabel("["+g.getGroup()+"] "+g.toString());
				}
				boolean plays=Calculator.plays(running, ((Game)arg1).getLeftPlayer())
							| Calculator.plays(running, ((Game)arg1).getRightPlayer());
				if (isSelected){
					lbl.setOpaque(true);
					lbl.setBackground(getForeground());
					lbl.setForeground(getBackground());
					if (plays){
						lbl.setForeground(Color.yellow);
						lbl.setBackground(Color.red);
					}
				} else {
					if (plays)
						lbl.setForeground(Color.red);
				}
				return lbl;
			}
        });
        
        this.jHole.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(Language.get("games")),
                BorderFactory.createEmptyBorder(5,5,5,5)));
        this.panel1.add(new JScrollPane(jHole));
        
        //Building panel2:
        this.jRunning=new JList(this.running.toArray());
        this.jRunning.setCellRenderer(new ListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList arg0, Object arg1,
					int arg2, boolean arg3, boolean arg4) {
				Game g=(Game)arg1;
				JLabel lbl;
				if (g.getGroup()==-1){
					lbl=new JLabel(g.shortInfo());
				} else {
					lbl=new JLabel("["+g.getGroup()+"] "+g.shortInfo());
				}
				lbl.setToolTipText(((Game)arg1).mediumInfo());
				if (arg3){
					lbl.setOpaque(true);
					lbl.setBackground(getForeground());
					lbl.setForeground(getBackground());
				}
				return lbl;
			}
		});
        this.jRunning.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(Language.get("games")),
                BorderFactory.createEmptyBorder(5,5,5,5)));
        this.panel2.add(new JScrollPane(this.jRunning), BorderLayout.CENTER);
        
        this.sentenceline=new JTextField("");
        this.sentenceline.addKeyListener(this);
        this.sentenceline.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(Language.get("ballsleftballsright")),
                BorderFactory.createEmptyBorder(5,5,5,5)));
        this.panel2_1.add(this.sentenceline);
        
        this.unsetGame=new JButton(Language.get("breakGame"));
        this.unsetGame.addActionListener(this);
        this.panel2_1.add(this.unsetGame);
        
        this.panel2.add(this.panel2_1, BorderLayout.SOUTH);
                
        //Building panel3:
        this.jDone=new JList(this.done.toArray());
        this.jDone.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(Language.get("games")),
                BorderFactory.createEmptyBorder(5,5,5,5)));
        this.jDone.setCellRenderer(new ListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList arg0, Object arg1,
					int arg2, boolean arg3, boolean arg4) {
				Game g=(Game)arg1;
				JLabel lbl;
				if (g.getGroup()==-1){
					lbl=new JLabel(g.shortInfo());
				} else {
					lbl=new JLabel("["+g.getGroup()+"] "+g.shortInfo());
				}
				lbl.setToolTipText(((Game)arg1).longInfo());
				if (arg3){
					lbl.setOpaque(true);
					lbl.setBackground(getForeground());
					lbl.setForeground(getBackground());
				}			
				if (arg3){
					lbl.setOpaque(true);
					lbl.setBackground(getForeground());
					lbl.setForeground(getBackground());
					if (!g.isOK()){
						lbl.setForeground(Color.yellow);
						lbl.setBackground(Color.red);
					}
				} else {
					if (!g.isOK())
						lbl.setForeground(Color.red);
				}
				return lbl;
			}
		});
        this.panel3.add(new JScrollPane(this.jDone),BorderLayout.CENTER);
        
        this.unfinishGame=new JButton(Language.get("continueGame"));
        this.unfinishGame.addActionListener(this);
        this.panel3_1.add(this.unfinishGame);
        
        this.endQualifying=new JButton(Language.get("endQualifying"));
        this.endQualifying.addActionListener(this);
        if (showEndQuali) this.panel3_1.add(this.endQualifying);
        
        this.panel3.add(this.panel3_1,BorderLayout.SOUTH);
        
        //Building panelmain:
        this.panelmain.add(this.panel1);
        this.panelmain.add(this.panel2);
        this.panelmain.add(this.panel3);
        
        //Building frame:
        buildFrame();
        this.setVisible(true);
	}
	
	protected void buildFrame(){
		this.setLayout(new GridBagLayout());
        GridBagConstraints c=new GridBagConstraints();
        
        c.fill=GridBagConstraints.BOTH;
		c.weightx=0.5;
		c.weighty=0.5;
		
		c.gridx=0; c.gridy=0;
        this.add(jgt,c);
        
        c.gridy=1;
        panelmain.setPreferredSize(new Dimension(900,350));
        
        this.add(this.panelmain,c);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource()==startgame){
			database.Game game=(Game) this.jHole.getSelectedValue();
			game.startGame();
			refresh();
		}
		if (arg0.getSource()==addsentence){
			int leftadd=new Integer(this.sentenceline.getText().substring(0, this.sentenceline.getText().indexOf(",")));
			int rightadd=new Integer(this.sentenceline.getText().substring(this.sentenceline.getText().indexOf(",")+1, this.sentenceline.getText().length()));
			((database.Game) this.jHole.getSelectedValue()).addSentence(leftadd, rightadd);
			Main.getInstance().refresh();
		}
		if (arg0.getSource()==declarefinished){
			database.Game game2=(Game) this.jRunning.getSelectedValue();
			game2.endGame();
			Main.getInstance().refresh();
		}
		if (arg0.getSource()==endQualifying){
			if (this.running.isEmpty()&&this.hole.isEmpty()){
				Main.getInstance().incState();
			} else{
				JOptionPane.showMessageDialog(this, "Es sind noch nicht alle Spiele gespielt!");
			}
		}
		if (arg0.getSource()==refresh)
			this.refresh();
		if (arg0.getSource()==unfinishGame){
			database.Game game=(Game) this.jDone.getSelectedValue();
			game.setState(1);
			if (game.getGroup()==-1)
				Main.getInstance().getTournament().getKnockOut().delGame(game);
			Main.getInstance().refresh();
		}
		if (arg0.getSource()==unsetGame){
			database.Game game=(Game) this.jRunning.getSelectedValue();
			game.setState(0);
			Main.getInstance().refresh();
		}
	}

	@Override
	public void keyPressed(KeyEvent arg0) {}

	@Override
	public void keyReleased(KeyEvent arg0) {
		if (arg0.getKeyCode()==KeyEvent.VK_ENTER){
			if (jRunning.getSelectedIndex()!=-1){
				try {
					int leftadd=new Integer(this.sentenceline.getText().substring(0, this.sentenceline.getText().indexOf(",")));
					int rightadd=new Integer(this.sentenceline.getText().substring(this.sentenceline.getText().indexOf(",")+1, this.sentenceline.getText().length()));
					handleEndGameEvent(leftadd,rightadd);
				} catch (Exception e) {
					System.out.println("WARNING: Malformed sentence line.");
				}
				
			}
		}
		if (arg0.getKeyCode()==KeyEvent.VK_DOWN){
			this.jRunning.setSelectedIndex(Calculator.min(this.jRunning.getSelectedIndex()+1,this.running.size()));
		}
		if (arg0.getKeyCode()==KeyEvent.VK_UP){
			this.jRunning.setSelectedIndex(Calculator.max(this.jRunning.getSelectedIndex()-1,0));
		}
	}

	@Override
	public void keyTyped(KeyEvent arg0) {};
	
	protected void handleEndGameEvent(int leftadd, int rightadd){
		((Game)this.jRunning.getSelectedValue()).addSentence(leftadd, rightadd);
		this.sentenceline.setText("");
		Main.getInstance().refresh();
	}
}
