package gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListCellRenderer;

import database.Group;
import database.Player;

@SuppressWarnings("serial")
public class JPlayers extends JPanel implements KeyListener, MouseListener{
	private List<Player> unassignedPlayers;
	private List<Group> groups;
	
	private JList jUnassignedPlayers, jGroupedPlayers;
	private JTextField jPlayerName,jFilter;
	private JComboBox jGroups;
	
	private JButton jNewPlayer, jRemovePlayer, jAssignPlayer, jUnassignPlayer, jOk, jAddGroup, jDelGroup;
	private JButton jPlayerDown;
	private JButton jPlayerUp;
	
	private void refreshLists(){
		if (groups.size()!=jGroups.getModel().getSize()){
			DefaultComboBoxModel model = new DefaultComboBoxModel(groups.toArray());
			jGroups.setModel(model);
		}
		List<Player> lst=new ArrayList<Player>();
		String text=jFilter.getText();
		text=text.toLowerCase();
		if (text.equals(""))
			lst.addAll(unassignedPlayers);
		else
			for (Player p : unassignedPlayers){
				boolean contains=true;
				for (String s:text.split(" ")){
					contains=contains & p.getFullName().toLowerCase().contains(s);
				}
				if (contains){
					lst.add(p);
				}
			}
		jUnassignedPlayers.setListData(lst.toArray());
		if (jGroups.getSelectedItem()!=null)
			jGroupedPlayers.setListData(((Group)jGroups.getSelectedItem()).getPlayers().toArray(new Player[0]));
		else
			jGroupedPlayers.setListData(new int[][] {});
	}
	
	public void showWindow(){
		Main.getInstance().showMe(this);
	}
	
	public void generateWindow(){ 
		//database elements
		unassignedPlayers=Main.getInstance().getTournament().getQualifying().getUnassigned();
		groups=Main.getInstance().getTournament().getQualifying().getGroups();
		
		//actions
		Action ok=new AbstractAction(Language.get("startQualifying")){
			@Override
			public void actionPerformed(ActionEvent arg0){
				Main.getInstance().incState();
			}
		};
		
		Action newPlayer=new AbstractAction(Language.get("addPlayer")){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String name=jPlayerName.getText();
				String preName=name.split(",")[0].replace(" ", "");
				String surName=name.split(",")[1].replace(" ", "");
				String club="";
				if (name.split(",").length>2)
					club=name.split(",")[2];
				club=","+club;
				club=club.replace(", ", ",");
				club=club.replace(",", "");
				Player player;
				if (club.equals(""))
					player=new Player(preName, surName);
				else
					player=new Player(preName, surName, club);
				unassignedPlayers.add(player);
				refreshLists();
			}
		};
		
		Action removePlayer=new AbstractAction(Language.get("delPlayer")){
			@Override
			public void actionPerformed(ActionEvent arg0){
				unassignedPlayers.remove(jUnassignedPlayers.getSelectedValue());
				refreshLists();
			}
		};
		
		Action assignPlayer=new AbstractAction(">"){
			@Override
			public void actionPerformed(ActionEvent e) {
				if (jUnassignedPlayers.getSelectedValue()!=null){
					Player player=((Player)jUnassignedPlayers.getSelectedValue());
					Group group=((Group)jGroups.getSelectedItem());
					Main.getInstance().getTournament().getQualifying().assignPlayer(player, group);
					refreshLists();
				}
			}
		};
		
		Action unassignPlayer=new AbstractAction("<"){
			@Override
			public void actionPerformed(ActionEvent e) {
				Player player=((Player)jGroupedPlayers.getSelectedValue());
				Group group=((Group)jGroups.getSelectedItem());
				Main.getInstance().getTournament().getQualifying().unassignPlayer(player, group);
				refreshLists();
			}
		};
		
		Action playerUp=new AbstractAction("^"){
			@Override
			public void actionPerformed(ActionEvent e){
				int index=jGroupedPlayers.getSelectedIndex();
				if (jGroupedPlayers.getSelectedIndex()>0){
					((Group) jGroups.getSelectedItem()).swapPlayers(jGroupedPlayers.getSelectedIndex(), jGroupedPlayers.getSelectedIndex()-1);
					index=jGroupedPlayers.getSelectedIndex()-1;
				}
				refreshLists();
				jGroupedPlayers.setSelectedIndex(index);
			}
		};
		
		Action playerDown=new AbstractAction("v"){
			@Override
			public void actionPerformed(ActionEvent e){
				int index=jGroupedPlayers.getSelectedIndex();
				if (jGroupedPlayers.getSelectedIndex()<((Group)jGroups.getSelectedItem()).getAnzahl()-1){
					((Group) jGroups.getSelectedItem()).swapPlayers(jGroupedPlayers.getSelectedIndex(), jGroupedPlayers.getSelectedIndex()+1);
					index=jGroupedPlayers.getSelectedIndex()+1;
				}					
				refreshLists();
				jGroupedPlayers.setSelectedIndex(index);
			}
		};
		
		Action refresh=new AbstractAction(){
			@Override
			public void actionPerformed(ActionEvent e) {
				refreshLists();
			}	
		};
		
		Action addGroup=new AbstractAction(Language.get("addGroup")){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Main.getInstance().getTournament().getQualifying().addGroup();
				refreshLists();
				jGroups.setSelectedIndex(jGroups.getItemCount()-1);
			}
		};
		
		Action delGroup=new AbstractAction(Language.get("delGroup")){
			@Override
			public void actionPerformed(ActionEvent arg0){
				unassignedPlayers.addAll(((Group)jGroups.getSelectedItem()).getPlayers());
				Main.getInstance().getTournament().getQualifying().delGroup(jGroups.getSelectedIndex());
				refreshLists();
			}
		};
		
		//non-button elements
		jUnassignedPlayers=new JList();
		jUnassignedPlayers.addMouseListener(this);
		jUnassignedPlayers.setCellRenderer(new ListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList list, Object value,
					int index, boolean isSelected, boolean cellHasFocus) {
				JLabel lbl=new JLabel(((Player)value).getFullName());
				if (cellHasFocus){
					lbl.setOpaque(true);
					lbl.setBackground(getForeground());
					lbl.setForeground(getBackground());
				}
				return lbl;
			}
		});
		
		jGroupedPlayers=new JList();
		jGroupedPlayers.addMouseListener(this);
		jGroupedPlayers.setCellRenderer(new ListCellRenderer() {
			@Override
			public Component getListCellRendererComponent(JList list, Object value,
					int index, boolean isSelected, boolean cellHasFocus) {
				JLabel lbl=new JLabel(((Player)value).getFullName());
				if (isSelected){
					lbl.setOpaque(true);
					lbl.setBackground(getForeground());
					lbl.setForeground(getBackground());
				}
				return lbl;
			}
		});
		
		jPlayerName=new JTextField();
		jPlayerName.addKeyListener(this);
		jFilter=new JTextField();
		jFilter.addKeyListener(this);
		jGroups=new JComboBox(groups.toArray(new Group[0]));
		jGroups.setAction(refresh);
		jGroups.setSelectedIndex(0);
		refreshLists();
		
		//buttons
		jOk=new JButton(ok);
		jNewPlayer=new JButton(newPlayer);
		jRemovePlayer=new JButton(removePlayer);
		jAssignPlayer=new JButton(assignPlayer);
//		jAssignPlayer.setIcon(new ImageIcon(Resources.right));
		jUnassignPlayer=new JButton(unassignPlayer);
//		jUnassignPlayer.setIcon(new ImageIcon(Resources.left));
		jPlayerUp=new JButton(playerUp);
//		jPlayerUp.setIcon(new ImageIcon(Resources.top));
		jPlayerDown=new JButton(playerDown);
//		jPlayerDown.setIcon(new ImageIcon(Resources.bottom));
		jAddGroup=new JButton(addGroup);
		jDelGroup=new JButton(delGroup);
		
		//building layout
		setLayout(new GridBagLayout());
		
		GridBagConstraints c=new GridBagConstraints();
		c.fill=GridBagConstraints.BOTH;
		c.weightx=0.5;
		c.weighty=0;
		
		c.gridx=0; c.gridy=0; c.gridwidth=2; c.gridheight=1;
		add(jPlayerName, c);
		
		c.gridx=0; c.gridy=1; c.gridwidth=1; c.gridheight=1;
		add(jFilter, c);
		
		c.gridx=1; c.gridy=1; c.gridwidth=1; c.gridheight=1;
		add(jRemovePlayer, c);

		c.gridx=0; c.gridy=2; c.gridwidth=2; c.gridheight=7;
		c.weighty=0.8;
		add(new JScrollPane(jUnassignedPlayers), c);
		c.weighty=0;
		
		c.weightx=0;
		c.gridx=2; c.gridy=2; c.gridwidth=1; c.gridheight=1;
		add(jAssignPlayer, c);
		
		c.gridx=2; c.gridy=3; c.gridwidth=1; c.gridheight=1;
		add(jUnassignPlayer, c);
		
		c.gridx=2; c.gridy=5; c.gridwidth=1; c.gridheight=1;
		add(jPlayerUp, c);
		
		c.gridx=2; c.gridy=6; c.gridwidth=1; c.gridheight=1;
		add(jPlayerDown, c);
		c.weightx=0.5;
		
		c.gridx=3; c.gridy=0; c.gridwidth=2; c.gridheight=1;
		add(jGroups, c);
		
		c.gridx=3; c.gridy=1; c.gridwidth=1; c.gridheight=1;
		add(jAddGroup, c);
		
		c.gridx=4; c.gridy=1; c.gridwidth=1; c.gridheight=1;
		add(jDelGroup, c);
		
		c.gridx=3; c.gridy=2; c.gridwidth=2; c.gridheight=6;
		c.weighty=0.8;
		add(new JScrollPane(jGroupedPlayers), c);
		c.weighty=0;
		
		c.gridx=3; c.gridy=8; c.gridwidth=2; c.gridheight=1;
		add(jOk, c);
		setPreferredSize(new Dimension(600,400));
	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		if ((arg0.getSource()==jPlayerName)&&(arg0.getKeyCode()==KeyEvent.VK_ENTER)){
			jNewPlayer.doClick();
			jPlayerName.setText("");
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0){
		if ((arg0.getSource()==jFilter)){
			refreshLists();
		}
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		
	}
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		if (arg0.getClickCount()==2){
			if (arg0.getSource()==jUnassignedPlayers){
				jAssignPlayer.doClick();
				return;
			}
			if (arg0.getSource()==jGroupedPlayers){
				jUnassignPlayer.doClick();
				return;
			}
		}
	}
	
	@Override
	public void mouseEntered(MouseEvent arg0) {}
	@Override
	public void mouseExited(MouseEvent arg0) {}
	@Override
	public void mousePressed(MouseEvent arg0) {}
	@Override
	public void mouseReleased(MouseEvent arg0) {}
};
