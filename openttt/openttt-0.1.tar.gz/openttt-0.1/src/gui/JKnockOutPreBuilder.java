package gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class JKnockOutPreBuilder extends JPanel {
	//TODO complete preBuilder
	
	private JComboBox jGroupNum, jPlaceNum;
	private JPanel pRight;
	private List<JPanel> pComboBoxes;
	private String actualFile;
	
	public JKnockOutPreBuilder(){
		jGroupNum=new JComboBox(new String[] {	"1","2","3","4","5","6","7","8",
												"9","10","11","12","13","14","15","16",
												"17","18","19","20","21","22","23","24",
												"25","26","27","28","29","30","31","32"	});
		jPlaceNum=new JComboBox(new String[] {	"1","2","3","4","5","6","7","8"	} );
		pComboBoxes=new ArrayList<JPanel>();
	}
	
	public void generateWindow(){
		//TODO language
		JFrame jFrame=new JFrame("Knock Out Pre Builder");
		jFrame.setLayout(new BorderLayout());
		JPanel pLeft=new JPanel();
		JPanel pTopLeft=new JPanel();
		
		Action aSave=new AbstractAction(Language.get("save")){
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser chooser = new JFileChooser();
				int returnVal = chooser.showOpenDialog(null);
				if(returnVal == JFileChooser.APPROVE_OPTION) {
					actualFile=chooser.getSelectedFile().getAbsoluteFile().getAbsolutePath();
					try {
						save(actualFile);
					} catch (FileNotFoundException e) {
						System.out.println("File not found.");
						e.printStackTrace();
					} catch (IOException e) {
						System.out.println("File not accessible.");
						e.printStackTrace();
					}
				}				
			}
		};
		
		pLeft.setLayout(new BorderLayout());
		pTopLeft.setLayout(new BorderLayout());
		
		pTopLeft.add(jGroupNum, BorderLayout.WEST);
		pTopLeft.add(jPlaceNum, BorderLayout.EAST);
	}
	
	public void save(String fileName) throws FileNotFoundException,IOException{
		String file;
		if (fileName.endsWith(".otk")) file=fileName;
		else file=fileName+".otk";
		
		fileName=file;
		
		ObjectOutputStream objOut = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
		objOut.writeObject(pComboBoxes);
		objOut.close();
	}
	
	public void refresh(){
		int plrs=(jGroupNum.getSelectedIndex()+1)*(jPlaceNum.getSelectedIndex()+1);
		
	}
}
