package gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;

import database.Calculator;
import database.Group;
import database.KnockOut;
import database.Player;

@SuppressWarnings("serial")
public class JKnockOutBuilder extends JPanel {
	private List<JComboBox> jComboBoxes;
	private JComboBox jOffset, jToPlace;
	private List<Player> players;
	private JPanel pan2;
	private List<JPanel> boxes;
	
	public JKnockOutBuilder(){
		boxes=new ArrayList<JPanel>();
		players=new ArrayList<Player>();
		players.add(Player.getNobody());
		int from=1,to=2;
		for (Group g : Main.getInstance().getTournament().getQualifying().getGroups()){
			if (g.getAnzahl()<to)
				players.addAll(g.getPlayersByPlace(from, g.getAnzahl()-1));
			else	
				players.addAll(g.getPlayersByPlace(from, to));
		}
	}
	
	public void generateWindow(){
		JPanel pan1,pan1_1;
		pan1=new JPanel();
		pan1_1=new JPanel();
		pan2=new JPanel();
		
		//build pan1_1
		Integer[] numbers={1,2,3,4,5,6,7,8};
		this.jOffset=new JComboBox(numbers);
		jOffset.setSelectedIndex(0);
		jOffset.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				refresh(true);
			}
		});
		
		this.jToPlace=new JComboBox(numbers);
		jToPlace.setSelectedIndex(1);
		jToPlace.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				refresh(true);
			}
		});
		JLabel lSurvivors=new JLabel(Language.get("to"));
		
		//build pan1_1
		pan1_1.add(jOffset);
		pan1_1.add(lSurvivors);
		pan1_1.add(jToPlace);
				
		//build pan2
		jComboBoxes=new ArrayList<JComboBox>();
		refresh(true);
		
		//start button
		Action aStart=new AbstractAction(Language.get("start")) {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				List<Player> plrs=new ArrayList<Player>();
				for (JComboBox box : jComboBoxes){
					plrs.add((Player)box.getSelectedItem());
				}
				Main.getInstance().getTournament().setKnockOut(new KnockOut(plrs));
				Main.getInstance().incState();
			}
		};
		JButton jStart=new JButton(aStart);
		
		//build pan1
		pan1.setLayout(new BorderLayout());
		pan1.add(pan1_1,BorderLayout.NORTH);
		pan1.add(jStart, BorderLayout.SOUTH);
		
		//build main panel
		this.setLayout(new BorderLayout());
		this.add(pan1, BorderLayout.WEST);
		this.add(pan2,BorderLayout.CENTER);
		
	}
	
	public void refresh(boolean jNumberChange){
		if (jNumberChange){
			players=new ArrayList<Player>();
			players.add(Player.getNobody());
			List<Group> groups=Main.getInstance().getTournament().getQualifying().getGroups();
			
			for (Group g : groups){
				if (g.getAnzahl()<jToPlace.getSelectedIndex()+1)
					players.addAll(g.getPlayersByPlace(jOffset.getSelectedIndex()+1, g.getAnzahl()+1));
				else
					players.addAll(g.getPlayersByPlace(jOffset.getSelectedIndex()+1, jToPlace.getSelectedIndex()+2));
			}
			for (JPanel box : boxes){
				pan2.remove(box);
			}
			jComboBoxes=new ArrayList<JComboBox>();
			for (int i=0; i<Calculator.nextPowerOfTwo(players.size()-1);i++){
				JComboBox box=new JComboBox(players.toArray());
				box.setRenderer(new ComboRenderer());
				box.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						refresh(false);
					}
				});
				
				jComboBoxes.add(box);
			}
			pan2.setLayout(new GridLayout(Calculator.nextPowerOfTwo(players.size()-1), 1));
			int j=0;
			for (JComboBox box: jComboBoxes){
				j++;
				JPanel panTemp=new JPanel();
				panTemp.add(new JLabel("#"+j+":"));
				panTemp.add(box);
				boxes.add(panTemp);
				pan2.add(panTemp);
			}
			Main.getInstance().showMe(this);
		}
	}
	
	
	public void showWindow(){
		Main.getInstance().showMe(this);
	}
	
	class ComboRenderer implements ListCellRenderer{
		@Override
		public Component getListCellRendererComponent(JList list, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {
			JLabel result;
			result=new JLabel(((Player)value).getPlayerPlaceGroup());
			if (isSelected){
				result.setOpaque(true);
				result.setForeground(getBackground());
				result.setBackground(getForeground());
			}
			return result;
		}
	}
}
