package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import database.Calculator;
import database.Group;
import database.Qualifying;

@SuppressWarnings("serial")
public class JGroupTable extends JPanel implements ActionListener {
	private JComboBox gruppen;
	private JTable table;
	private int width=0;
	private Qualifying qualifying;
	
	public JGroupTable(Qualifying q){
		super();
		this.qualifying=q;
		generateWindow();
	}
	
	public void generateWindow(){
		setLayout(new BorderLayout());
		
		JPanel panel=new JPanel();
		panel.setLayout(new BorderLayout());
		
		gruppen=new JComboBox(qualifying.getGroups().toArray());
		gruppen.addActionListener(this);
		panel.add(this.gruppen,BorderLayout.NORTH);
		
//		data[zeile][spalte]
		String[][] data = Calculator.tabular((Group) gruppen.getSelectedItem());
		String[] columnNames = Calculator.tabularHead((Group)gruppen.getSelectedItem());
		System.out.println("columnNames.length="+columnNames.length);
		System.out.println("data.length="+data.length);
		
		table = new JTable(data, columnNames);
		width=300;
		
		table.getColumnModel().getColumn(0).setPreferredWidth(width);
		JScrollPane scrollpane = new JScrollPane(this.table);
		
		add(panel,BorderLayout.NORTH);
		add(scrollpane);
			
		setPreferredSize(new Dimension(500,150));
		setVisible(true);
	}

	public void refresh(){
		String[][] data = Calculator.tabular((Group) gruppen.getSelectedItem());
		String[] columnNames = Calculator.tabularHead((Group) gruppen.getSelectedItem());
		DefaultTableModel tm=new DefaultTableModel();
		tm.setDataVector(data, columnNames);
		table.setModel(tm);
		table.getColumnModel().getColumn(0).setPreferredWidth(width);
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		refresh();
	};
}
