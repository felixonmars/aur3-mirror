ranking
====

It move pictures (by default) into year/month directory

Depend
======

python3

Installation
============

```
git clone https://github.com/Chipsterjulien/ranking.git
python setup.py install
```

Usage
=====

```
python ranking -h
```
