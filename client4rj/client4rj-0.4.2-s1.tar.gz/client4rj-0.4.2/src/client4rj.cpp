/*
   Client4Rj is an 802.1x client tool for Linux, which is compatible with MyStar0.1.1 for Windows.
*/

#include "client4rj.h"

client4rj::client4rj(QDialog *parent)
	:QDialog(parent)
{
	setupUi(this);
	autocontimerid=0;
	
	authifname->clear();
	foreach(QNetworkInterface interfaceX,QNetworkInterface::allInterfaces())
		if(interfaceX.name()!="lo")
			authifname->addItem(interfaceX.name());
	
	QSettings settings("lsyer", "client4rj");
	move(settings.value("pos", QPoint(100, 60)).toPoint());
	autoreconn->setCheckState( (Qt::CheckState)(settings.value("autoreconn",Qt::Checked).toInt()) );
	autorun->setCheckState((Qt::CheckState)(settings.value("autorun",Qt::Unchecked).toInt()) );
	savepwd->setCheckState((Qt::CheckState)(settings.value("savepwd",Qt::Checked).toInt()) );
	autoconnect->setCheckState((Qt::CheckState)(settings.value("autoconnect",Qt::Unchecked).toInt()) );
	nameEdit->setText(settings.value("name").toString());
	if(savepwd->checkState()){
		passEdit->setText(settings.value("pass").toString());
	}
	repeatAuthNum = settings.value("repeatAuthNum",1).toInt();
	authenticationMode = settings.value("authenticationMode",0).toInt();
	echoInterval = settings.value("echoInterval",3).toInt();
	reconnInterval = settings.value("reconnInterval",30).toInt();
	authifname->setCurrentIndex( authifname->findText( settings.value("authifname","eth0").toString() ) );
	usedhcp->setCurrentIndex( settings.value("usedhcp",0).toInt() );
	
	connect(autorun,SIGNAL(clicked()),this,SLOT(autorunchange()));
	
	connect(hideButton,SIGNAL(clicked()),this,SLOT(switchstat()));
	connect(aboutButton,SIGNAL(clicked()),this,SLOT(about()));
	connect(connectButton,SIGNAL(clicked()),this,SLOT(p_connect()));
	connect(setconfButton,SIGNAL(clicked()),this,SLOT(setconf()));
	connect(exitButton,SIGNAL(clicked()),this,SLOT(quit()));

	connect(&thread,SIGNAL(mystate(int)),this,SLOT(chkstate(int)));
	
	createActions();
	createTrayIcon();
	connect(trayIcon, SIGNAL(activated(QSystemTrayIcon::ActivationReason)),
            this, SLOT(iconActivated(QSystemTrayIcon::ActivationReason)));
	icon = QIcon(":/images/neticon.xpm");
	icon1 = QIcon(":/images/neticon1.xpm");
	setWindowIcon(icon);
	trayIcon->setIcon(icon);
	trayIcon->setToolTip("Client for RuiJie");
	trayIcon->show();
	if(autoconnect->checkState()){
		p_connect();
	}
}

void client4rj::p_connect()
{
	if(nameEdit->text()==""||passEdit->text()==""){
		sLabel->setText(QString(tr("请填写用户名和密码！")));
		return;
	}
	strncpy(name,(nameEdit->text()).toStdString().c_str(),32);
	strncpy(pass,(passEdit->text()).toStdString().c_str(),32);
	strncpy(authinterface,(authifname->currentText()).toStdString().c_str(),32);
	thread.setConfig(name,pass,authinterface,usedhcp->currentIndex(),repeatAuthNum,authenticationMode,echoInterval);
	if(thread.m_state == 5){
    	sLabel->setText(QString(tr("正建立连接...")));
    	connectButton->setText(QString(tr("停止"))); 
		thread.start();
	}else{
        trayIcon->setIcon(icon);
        sLabel->setText(QString(tr("正在停止，请稍候...")));
        connectButton->setDisabled(true);
        connectAct->setDisabled(true);
		thread.disconnectnet();
	}
}

void client4rj::createActions()
{
    connectAct = new QAction(tr("(&C)连  接"), this);
    connect(connectAct, SIGNAL(triggered()), this, SLOT(p_connect()));
    
    hideAct = new QAction(tr("(&H)隐  藏"), this);
    connect(hideAct, SIGNAL(triggered()), this, SLOT(switchstat()));
    
    setAct = new QAction(tr("(&S)设  置"), this);
    connect(setAct, SIGNAL(triggered()), this, SLOT(setconf()));

    aboutAct = new QAction(tr("(&A)关  于"), this);
    connect(aboutAct, SIGNAL(triggered()), this, SLOT(about()));

    quitAct = new QAction(tr("(&Q)退  出"), this);
    connect(quitAct, SIGNAL(triggered()), this, SLOT(quit()));
}

void client4rj::createTrayIcon()
{
    trayIconMenu = new QMenu(this);
    trayIconMenu->addAction(connectAct);
    trayIconMenu->addAction(hideAct);
    trayIconMenu->addAction(setAct);
    trayIconMenu->addAction(aboutAct);
    trayIconMenu->addSeparator();
    trayIconMenu->addAction(quitAct);

    trayIcon = new QSystemTrayIcon(this);
    trayIcon->setContextMenu(trayIconMenu);
}
void client4rj::iconActivated(QSystemTrayIcon::ActivationReason reason)
{
    switch (reason) {
    //case QSystemTrayIcon::Trigger:
    case QSystemTrayIcon::DoubleClick:
		switchstat();
        break;
    //case QSystemTrayIcon::MiddleClick:
        //showMessage();
        //break;
    default:
        ;
    }
}
void client4rj::switchstat(){
	setVisible(isHidden());
	isHidden()?hideAct->setText(tr("(&H)显  示")):hideAct->setText(tr("(&H)隐  藏"));
}
void client4rj::about()
{
   this->show();
   QMessageBox::about(this, tr("关于 - lsyer"),
            tr("<p>Client for RuiJie Ver0.4.2</p><p>Author:<a href=http://lishao378.blog.sohu.com target=_blank>lsyer</a>(木子)<br>2008-4-4</p>"));
}
void client4rj::quit()
{
	QSettings settings("lsyer", "client4rj");
	settings.setValue("pos", pos());
	settings.setValue("name", nameEdit->text());
	settings.setValue("pass", passEdit->text());
	settings.setValue("authifname", authifname->currentText());
	settings.setValue("usedhcp", usedhcp->currentIndex());
	settings.setValue("autoreconn",autoreconn->checkState());
	settings.setValue("autorun",autorun->checkState());
	settings.setValue("savepwd",savepwd->checkState());
	settings.setValue("autoconnect",autoconnect->checkState());
	if(thread.m_state == 3){
		thread.disconnectnet();
	}
	qApp->quit();
}
void client4rj::setconf()
{
	this->show();
	confwin newdialog(this);
	if(newdialog.exec()&&newdialog.isok){
		repeatAuthNum = newdialog.renum->value();
		authenticationMode = newdialog.authmode->currentIndex();
		echoInterval = newdialog.echointer->value();
		reconnInterval = newdialog.reconnInterval->value();
		auth_p = newdialog.auth_p->currentIndex();
	}
	QSettings settings("lsyer", "client4rj");
	settings.setValue("repeatAuthNum", repeatAuthNum);
	settings.setValue("authenticationMode", authenticationMode);
	settings.setValue("echoInterval", echoInterval);
	settings.setValue("reconnInterval", reconnInterval);
	settings.setValue("auth_p", auth_p);
}
void client4rj::closeEvent ( QCloseEvent * event )
{
    hide();
    event->ignore();
}
void client4rj::timerEvent(QTimerEvent *event)
{
	if(event->timerId() == autocontimerid){
		thread.terminate();
		thread.wait();
		thread.start();
	}else{
		QWidget::timerEvent(event);
	}
}
void client4rj::contextMenuEvent(QContextMenuEvent *event)
{
    //QMenu menu(this);
   // menu.addAction(cutAct);
    //menu.addAction(copyAct);
    //menu.addAction(pasteAct);
    trayIconMenu->exec(event->globalPos());
	return ;
}
void client4rj::sendecho(){
	sLabel->setText(QString(tr("认证成功！<br>正发送 Echo 报文...")));
	return;
}
void client4rj::reconnect(){
	sLabel->setText(QString(tr("重新开始认证！")));
	return;
}
void client4rj::chkstate(int state){
	switch (state){
		case 0:
			sLabel->setText(QString(tr("正在寻找认证服务器...")));
			break;
		case 1:
			sLabel->setText(QString(tr("已找到认证服务器，<br>正发送用户名...")));
			break;
		case 2:
			sLabel->setText(QString(tr("用户名有效，<br>正发送密码...")));
			break;
		case 3:
			trayIcon->setIcon(icon1);
			sLabel->setText(QString(tr("认证成功！")));
			connectButton->setText(QString(tr("断开")));
			connectAct->setText(tr("(&C)断  开"));
			if(autoreconn){
				autocontimerid=startTimer(reconnInterval*60*1000);
			}
			break;
		case 4:
			sLabel->setText(QString(tr("认证失败!! :( ")));
			connectButton->setText(QString(tr("连接")));
			connectButton->setDisabled(false);
			connectAct->setText(tr("(&C)连  接"));
			connectAct->setDisabled(false);
			break;
		case 5:
			trayIcon->setIcon(icon);
			sLabel->setText(QString(tr("连接已断开！")));
			connectButton->setText(QString(tr("连接")));
			connectButton->setDisabled(false);
			connectAct->setText(tr("(&C)连  接"));
			connectAct->setDisabled(false);
			break;
		default:
			break;
	}
	return;
}
void client4rj::autorunchange(){
	if(autorun->checkState() == Qt::Unchecked){
		printf("Unchecked\n");
		QProcess::execute("rm -f /usr/share/autostart/client4rj.desktop");
	}else{
		printf("Checked\n");
		QProcess::execute("cp /usr/share/applications/client4rj.desktop /usr/share/autostart/client4rj.desktop");
	}
}
