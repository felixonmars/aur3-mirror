#include "dothread.h"

dothread::dothread(QObject *parent)
    : QThread(parent)
{
	m_authenticationMode=-1; //是哪种认证模式：0:标准 1:实达
	m_fakeAddress=NULL;  // or set to "123.45.67.89" etc.
	m_state=5;//当前认证状态
	
	blogIsInitialized=0;	
	l=NULL;
}
void dothread::run(){
	connectnet();
}
int dothread::connectnet()
{
	u_int32_t                 l_ip;
	struct libnet_ether_addr *l_ether_addr;
	
	int                 p_fd;
	fd_set              read_set;
	char                filter_buf[256];
	struct bpf_program  filter_code;
	u_int32_t           p_netaddr,p_netmask;
	struct pcap_pkthdr *pkt_hdr;
	char                p_errbuf[PCAP_ERRBUF_SIZE];
	
	int             msgLen;
	char            msgBuf[256];
	char           *pmsgBuf;
	int             isFirstPacketFromServer=1;
	struct timespec timeout;
	int packetCount_SentFindServer=0;
	int packetCount_SentName=0;
	int packetCount_SentPassword=0;
	int m_curRepeatAuthNum=0;
	
	int noip_afterauth=1;
	
	if(m_usedhcp == 1){
	    QProcess myProcess;
	    myProcess.start(QString("dhclient %1").arg(m_nic));
		myProcess.waitForFinished();
	}
	

	m_serialNo.ulValue = 0x1000002a;        //the initial serial number, a magic number!
	//if (!l){
		if((l=libnet_init(LIBNET_LINK, m_nic,l_errbuf))==NULL){
			err_msg("libnet_init: %s\n", l_errbuf);
			return 1;
		}
	//}

	if((p=pcap_open_live(m_nic,65536,0, 500, p_errbuf))==NULL){
   		err_msg("pcap_open_live: %s\n",p_errbuf);
		return 1;
   	}
   	p_fd=pcap_fileno(p); //we can pselect() it in the following code.

	if((l_ether_addr=libnet_get_hwaddr(l))==NULL)
	{
		err_msg("unable to get local mac address :%s\n",libnet_geterror(l));
		goto err2;
	}

	memcpy(m_localMAC,l_ether_addr,sizeof(m_localMAC));

	if(m_fakeAddress==NULL)
	{
		if((l_ip=libnet_get_ipaddr4(l))==-1){
			err_msg("unable to get ip address--ingored... :%s\n",libnet_geterror(l));
       	 	l_ip=0;
       	 }
         memcpy(m_ip,&l_ip,sizeof(m_ip));
	}

	if(pcap_lookupnet(m_nic,&p_netaddr,&p_netmask,p_errbuf)==-1)
	{
		err_msg("unable to get netmask--igored... %s\n",p_errbuf);
		p_netmask=0;
	}
	memcpy(m_netmask,&p_netmask,sizeof(m_netmask));

	InitializeBlog(m_ip,m_netmask,m_netgate,m_dns1); //see blog.c and bloc.h for details

	//set the filter. Here I'm sure filter_buf is big enough.
	snprintf(filter_buf,sizeof(filter_buf),FILTER_STR, m_localMAC[0],m_localMAC[1],
        m_localMAC[2],m_localMAC[3],m_localMAC[4],m_localMAC[5]);
	if(pcap_compile(p, &filter_code,filter_buf, 0, p_netmask)==-1)
	{
		err_msg("pcap_compile(): %s", pcap_geterr(p));
		goto err2;
	}
	if(pcap_setfilter(p, &filter_code)==-1)
	{
		err_msg("pcap_setfilter(): %s", pcap_geterr(p));
		goto err2;
	}
	pcap_freecode(&filter_code); // avoid  memory-leak
   
	//search for the server
beginAuthentication:
	if(++m_curRepeatAuthNum>m_repeatAuthNum){
		m_state=4;
		emit mystate(m_state); 
		m_state=5;
		goto err2;
	}
	m_state=0;
	emit mystate(m_state); //start auth;
	(void)SendFindServerPacket(l); //the first time to search for server
	packetCount_SentFindServer=1;
	packetCount_SentName=0;
	packetCount_SentPassword=0;
      
	while(m_state != 5){
		FD_ZERO(&read_set);
      	FD_SET(p_fd, &read_set);
      	timeout.tv_sec =1;
      	timeout.tv_nsec =0; // 1 second

		//wait with all signals(except SIGINT) blocked.
		switch ( pselect(p_fd+1,&read_set,NULL,NULL,&timeout,NULL) )
		{
          case -1: //Normally, this case should not happen since sig_intr() never returns!
                   goto err2;
          case 0:  //timed out
                   switch(m_state)
                   {
                      case 0:
                             if(++packetCount_SentFindServer>3){
                             	puts("Restarting authenticaton!");
                             	goto beginAuthentication;
                             }
                             (void)SendFindServerPacket(l);
                             continue; //jump to next loop of while(1) to receive next packet
                      case 1:
                             if(++packetCount_SentName>3){
                             	puts("Restarting authenticaton!");
                             	goto beginAuthentication;
                             }
                             (void)SendNamePacket(l, pkt_data);
                             continue;
                      case 2:
                            if(++packetCount_SentPassword>3){
                            	puts("Restarting authenticaton!");
                            	goto beginAuthentication;
                            }
                            (void)SendPasswordPacket(l, pkt_data);
                             continue;
                      default:
                             goto err2;
                   }
		}

		//Here return value of pselect must be 1

		if((pcap_next_ex(p,&pkt_hdr,&pkt_data))!=1)
			continue;

		//收到的第二个及其以后的有效packet的源MAC必须等于头次收到的有效分组的源MAC
		if ((!isFirstPacketFromServer)&&(memcmp(m_destMAC,pkt_data+6,6)!=0))
			continue;

		//received a packet successfully. for convenience, SUPPOSE it's the RIGHT packet!! but maybe WRONG!!
		//for example, we have NEVER vefified the length of packet, fancying the packet's length is 0x11 ?!

		switch( pkt_data[0x12] )        //分析EAP包类型
		{
          case 0x01:        //表示请求
                    switch( pkt_data[0x16] )
                    {
                        case 0x01:   //type 1,以用户名应答
                                 if(m_state!=0) continue;
                                 
                                 m_state=1;
                                 emit mystate(m_state);                                 
                                 fputs("@@ Server found, requesting user name...\n",stdout);
                                 //获得服务器的MAC地址
                                 if (isFirstPacketFromServer){
                                 	memcpy( m_destMAC, pkt_data+6, 6);
                                 	isFirstPacketFromServer=0;
                                 }
                                  ++packetCount_SentName;
                                 (void)SendNamePacket(l, pkt_data);
                                 break;
                        case 0x04:   //type 4,challage，以MD5计算得到的值应答
                                 if(m_state!=1) continue;
                                 m_state=2;
                                 emit mystate(m_state);                                 
                                 fputs("@@ User name valid, requesting password...\n",stdout);
                                 ++packetCount_SentPassword;
                                 (void)SendPasswordPacket(l, pkt_data);
                                 break;
                    }
                    break;
          case 0x03:         //认证成功
                    if(m_state!=2) continue;
                    /*dhcp code*/
                    if(m_usedhcp == 2 && noip_afterauth){
					    QProcess myProcess;
					    myProcess.start(QString("dhclient %1").arg(m_nic));
						myProcess.waitForFinished();
						noip_afterauth=0;
						goto beginAuthentication;
                   	}
                    /*dhcp code over*/
                    m_state=3;
                    emit mystate(m_state);
                    fputs("@@ Password valid, authentication SUCCESS!!! :)\n",stdout);
                    
                    //send echo packets.
                    if (m_echoInterval<=0) goto done; //user has echo disabled
                    
                    //uTemp.ulValue = *(((u_long *)(pkt_data+0x9d)));
                    offset=ntohs( *((u_int16_t*)(pkt_data+0x10)) );
                    uTemp.ulValue = *((u_int32_t *)(pkt_data+(0x11+offset)-0x08));
                    m_key.btValue[0] = Alog(uTemp.btValue[3]);
                    m_key.btValue[1] = Alog(uTemp.btValue[2]);
                    m_key.btValue[2] = Alog(uTemp.btValue[1]);
                    m_key.btValue[3] = Alog(uTemp.btValue[0]);

                    // continue echoing
                    fputs("Keeping sending echo... \n",stdout);
                    while(SendEchoPacket(l,pkt_data)==0 && m_state!=5){
                    	sleep(m_echoInterval);
					}
					
                    goto done; //认证成功并且不需要echo则完成，此处不可少，否则将无限循环进行连接
                    break;
          case 0x04:        //认证失败(用户名或密码错误/不在上网时段内/重复上网等)
                   if((m_state==0)||(m_state==3)) continue;
                   msgLen=ntohs( *((u_int16_t*)(pkt_data+0x10)) )-10;
                   if (msgLen>0)
                      {
                         if(msgLen>=(sizeof(msgBuf)-1)) msgLen=sizeof(msgBuf)-1;
                         memset(msgBuf,'\0',sizeof(msgBuf));
                         memcpy(msgBuf, pkt_data+0x1c, msgLen);
                         pmsgBuf=msgBuf;
                         //remove the leanding "\r\n" which seems alway to exist!
                         if((msgLen>2)&&(msgBuf[0]==0xd)&&(msgBuf[1]==0xa)) pmsgBuf+=2;
                      }
                   else { pmsgBuf=""; } //这个估计是服务器告知静默或确认断网的包

                   m_state=4;
                   emit mystate(m_state);
                   m_state=5;
                   fprintf(stdout,"@@ Authenticaton failed!!! :(%s\n",pmsgBuf);
                   (void)SendEndCertPacket(l);

                   goto err2;

                   break;

		}// end switch
	}// end while
done:
	pcap_close(p);
	libnet_destroy(l);
	return 0;

err2:
	pcap_close(p);
	libnet_destroy(l);
	return 1;
}


void dothread::setConfig(char *name,char *pass,char *authinterface,int usedchp,int repeatAuthNum,int authenticationMode,int echoInterval)
{
	m_name = name;
	m_password = pass;
	m_nic = authinterface;
	m_usedhcp = usedchp;
	m_repeatAuthNum = repeatAuthNum;
	m_authenticationMode = authenticationMode;
	m_echoInterval = echoInterval;
	printf("%s %s %s %d %d %d %d",m_name,m_password,m_nic,m_usedhcp,m_repeatAuthNum,m_authenticationMode,m_echoInterval);
	//m_fakeaddress = ;
	
	//just set them to zero since they don't seem to be important.
	memset(m_netgate,0,sizeof(m_netgate));
	memset(m_dns1,0,sizeof(m_dns1));
	
	static uint8_t RuijieExtra[144] = {        //Ruijie OEM Extra （V2.56）  by soar
        ////////////////////////////////////////////////////////////////////////////
        //
        // OEM Extra
        // 0 --> 22
        0xff,0xff,0x37,0x77,            // Encode( 0x00,0x00,0x13,0x11 )   Ruijie OEM Mark		//求反并头尾颠倒.add by lsyer
        0xff,                           // Encode( 0x01/00  EnableDHCP flag )
        0x00,0x00,0x00,0x00,            // Encode( IP )
        0x00,0x00,0x00,0x00,            // Encode( SubNetMask )
        0x00,0x00,0x00,0x00,            // Encode( NetGate )
        0x00,0x00,0x00,0x00,            // Encode( DNS )
        0x00,0x00,                      // Checksum( )
        // 23 --> 58
        0x00,0x00,0x13,0x11,0x38,0x30,0x32,0x31,0x78,0x2E,0x65,0x78,0x65,0x00,0x00,0x00,    // ASCII 8021x.exe
        0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,    //
        0x00,0x00,0x00,0x00,
        // 59 --> 77
        0x02,0x38,0x00,0x00,            // 8021x.exe File Version (2.56.00)		//base16 code.add by lsyer
        0x00,                           // unknow flag
        0x00,0x00,0x13,0x11,0x00,0x28,0x1A,0x28,0x00,0x00,0x13,0x11,0x17,0x22,              // Const strings
        // 78 --> 118
        0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,    // 32bits spc. Random strings
        0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,    // 32bits spc. Random strings
        0x00,0x00,0x13,0x11,0x18,0x06,0x00,0x00,0x00,                                       // Const strings
        // 119
        0x00,                           // DHCP and first time flag
        // V2.56 (and upper?) added
        // 120 -->
        0x1A,0x0E,0x00,0x00,0x13,0x11,0x2D,0x08,                                            // Const strings
        // 128 --> 141
        0x00,0x00,0x00,0x00,0x00,0x00,                                                      // True NIC MAC
        0x1A,0x08,0x00,0x00,0x13,0x11,0x2F,0x02                                             // Const strings
   };
   memcpy(OEMExtra,RuijieExtra,sizeof(RuijieExtra));
}

void dothread::disconnectnet()
{
	if(m_state==3){
		if((l=libnet_init(LIBNET_LINK, m_nic,l_errbuf))==NULL)
			err_msg("libnet_init: %s\n", l_errbuf);
		(void)SendEndCertPacket(l);
		libnet_destroy(l);
	}
	m_state=5;
	emit mystate(m_state);
	terminate();
}
//blog.cpp
//configure the 4 parameters Blog() and FillNetParameter() need.
void dothread::InitializeBlog(const unsigned char *m_ip, const unsigned char *m_netmask,
         const unsigned char *m_netgate, const unsigned char *m_dns1)
{
   memcpy(m_IP,m_ip,4);
   memcpy(m_NetMask,m_netmask,4);
   memcpy(m_NetGate,m_netgate,4);
   memcpy(m_DNS1,m_dns1,4);

   Blog();

   blogIsInitialized=1;
}

//Fill in some additional information  Ruijie Corp. required.
//You should call InitializeBlog() before calling this function.
void dothread::FillNetParamater(unsigned char ForFill[])
{
	if(blogIsInitialized==0) err_quit("Blog algorithm not initialied yet \n");

	ForFill[ 0] = Alog( m_IP[0] );
	ForFill[ 1] = Alog( m_IP[1] );
	ForFill[ 2] = Alog( m_IP[2] );
	ForFill[ 3] = Alog( m_IP[3] );
	ForFill[ 4] = Alog( m_NetMask[0] );
	ForFill[ 5] = Alog( m_NetMask[1] );
	ForFill[ 6] = Alog( m_NetMask[2] );
	ForFill[ 7] = Alog( m_NetMask[3] );
	ForFill[ 8] = Alog( m_NetGate[0] );
	ForFill[ 9] = Alog( m_NetGate[1] );
	ForFill[10] = Alog( m_NetGate[2] );
	ForFill[11] = Alog( m_NetGate[3] );
	ForFill[12] = Alog( m_DNS1[0] );
        ForFill[13] = Alog( m_DNS1[1] );
	ForFill[14] = Alog( m_DNS1[2] );
	ForFill[15] = Alog( m_DNS1[3] );
	ForFill[16] = Alog( circleCheck[0] );
	ForFill[17] = Alog( circleCheck[1] );
}

//A transformation of one-byte-for-one-byte
unsigned char dothread::Alog(unsigned char BForAlog)
{
        int a=0,b=0,c=0,d=0,iRt;

        a=BForAlog;
        c=a;
        d=a;
        c&=0x40;
        b=a;
        d>>=2;
        c|=d;
        d=a;
        c>>=2;
        d&=0x20;
        c|=d;
        d=a;
        c>>=2;
        d&=0x10;
        c|=d;

        d=a;
        d&=2;
        b<<=2;
        d|=b;
        b=a;
        d<<=2;
        b&=4;
        a&=8;
        d|=b;
        d<<=2;
        d|=a;

        c>>=1;
        d<<=1;
        c|=d;
        iRt=(~c)&0xff;
        return iRt;
}

//那帮家伙们，单靠这个算法就想区别实达客户端和非实达客户端 -_- !! 
//The only use of function Blog() is to work out circleCheck[2],
//with and only with the help of 4 parameters----m_IP, m_NetMask, m_NetGate, m_DNS1
void dothread::Blog(void)
{
        static unsigned char Table[]={
                0x00,0x00,0x21,0x10,0x42,0x20,0x63,0x30,0x84,0x40,0xA5,0x50,0xC6,0x60,0xE7,0x70,
                0x08,0x81,0x29,0x91,0x4A,0xA1,0x6B,0xB1,0x8C,0xC1,0xAD,0xD1,0xCE,0xE1,0xEF,0xF1,
                0x31,0x12,0x10,0x02,0x73,0x32,0x52,0x22,0xB5,0x52,0x94,0x42,0xF7,0x72,0xD6,0x62,
                0x39,0x93,0x18,0x83,0x7B,0xB3,0x5A,0xA3,0xBD,0xD3,0x9C,0xC3,0xFF,0xF3,0xDE,0xE3,
                0x62,0x24,0x43,0x34,0x20,0x04,0x01,0x14,0xE6,0x64,0xC7,0x74,0xA4,0x44,0x85,0x54,
                0x6A,0xA5,0x4B,0xB5,0x28,0x85,0x09,0x95,0xEE,0xE5,0xCF,0xF5,0xAC,0xC5,0x8D,0xD5,
                0x53,0x36,0x72,0x26,0x11,0x16,0x30,0x06,0xD7,0x76,0xF6,0x66,0x95,0x56,0xB4,0x46,
                0x5B,0xB7,0x7A,0xA7,0x19,0x97,0x38,0x87,0xDF,0xF7,0xFE,0xE7,0x9D,0xD7,0xBC,0xC7,
                0xC4,0x48,0xE5,0x58,0x86,0x68,0xA7,0x78,0x40,0x08,0x61,0x18,0x02,0x28,0x23,0x38,
                0xCC,0xC9,0xED,0xD9,0x8E,0xE9,0xAF,0xF9,0x48,0x89,0x69,0x99,0x0A,0xA9,0x2B,0xB9,
                0xF5,0x5A,0xD4,0x4A,0xB7,0x7A,0x96,0x6A,0x71,0x1A,0x50,0x0A,0x33,0x3A,0x12,0x2A,
                0xFD,0xDB,0xDC,0xCB,0xBF,0xFB,0x9E,0xEB,0x79,0x9B,0x58,0x8B,0x3B,0xBB,0x1A,0xAB,
                0xA6,0x6C,0x87,0x7C,0xE4,0x4C,0xC5,0x5C,0x22,0x2C,0x03,0x3C,0x60,0x0C,0x41,0x1C,
                0xAE,0xED,0x8F,0xFD,0xEC,0xCD,0xCD,0xDD,0x2A,0xAD,0x0B,0xBD,0x68,0x8D,0x49,0x9D,
                0x97,0x7E,0xB6,0x6E,0xD5,0x5E,0xF4,0x4E,0x13,0x3E,0x32,0x2E,0x51,0x1E,0x70,0x0E,
                0x9F,0xFF,0xBE,0xEF,0xDD,0xDF,0xFC,0xCF,0x1B,0xBF,0x3A,0xAF,0x59,0x9F,0x78,0x8F,
                0x88,0x91,0xA9,0x81,0xCA,0xB1,0xEB,0xA1,0x0C,0xD1,0x2D,0xC1,0x4E,0xF1,0x6F,0xE1,
                0x80,0x10,0xA1,0x00,0xC2,0x30,0xE3,0x20,0x04,0x50,0x25,0x40,0x46,0x70,0x67,0x60,
                0xB9,0x83,0x98,0x93,0xFB,0xA3,0xDA,0xB3,0x3D,0xC3,0x1C,0xD3,0x7F,0xE3,0x5E,0xF3,
                0xB1,0x02,0x90,0x12,0xF3,0x22,0xD2,0x32,0x35,0x42,0x14,0x52,0x77,0x62,0x56,0x72,
                0xEA,0xB5,0xCB,0xA5,0xA8,0x95,0x89,0x85,0x6E,0xF5,0x4F,0xE5,0x2C,0xD5,0x0D,0xC5,
                0xE2,0x34,0xC3,0x24,0xA0,0x14,0x81,0x04,0x66,0x74,0x47,0x64,0x24,0x54,0x05,0x44,
                0xDB,0xA7,0xFA,0xB7,0x99,0x87,0xB8,0x97,0x5F,0xE7,0x7E,0xF7,0x1D,0xC7,0x3C,0xD7,
                0xD3,0x26,0xF2,0x36,0x91,0x06,0xB0,0x16,0x57,0x66,0x76,0x76,0x15,0x46,0x34,0x56,
                0x4C,0xD9,0x6D,0xC9,0x0E,0xF9,0x2F,0xE9,0xC8,0x99,0xE9,0x89,0x8A,0xB9,0xAB,0xA9,
                0x44,0x58,0x65,0x48,0x06,0x78,0x27,0x68,0xC0,0x18,0xE1,0x08,0x82,0x38,0xA3,0x28,
                0x7D,0xCB,0x5C,0xDB,0x3F,0xEB,0x1E,0xFB,0xF9,0x8B,0xD8,0x9B,0xBB,0xAB,0x9A,0xBB,
                0x75,0x4A,0x54,0x5A,0x37,0x6A,0x16,0x7A,0xF1,0x0A,0xD0,0x1A,0xB3,0x2A,0x92,0x3A,
                0x2E,0xFD,0x0F,0xED,0x6C,0xDD,0x4D,0xCD,0xAA,0xBD,0x8B,0xAD,0xE8,0x9D,0xC9,0x8D,
                0x26,0x7C,0x07,0x6C,0x64,0x5C,0x45,0x4C,0xA2,0x3C,0x83,0x2C,0xE0,0x1C,0xC1,0x0C,
                0x1F,0xEF,0x3E,0xFF,0x5D,0xCF,0x7C,0xDF,0x9B,0xAF,0xBA,0xBF,0xD9,0x8F,0xF8,0x9F,
                0x17,0x6E,0x36,0x7E,0x55,0x4E,0x74,0x5E,0x93,0x2E,0xB2,0x3E,0xD1,0x0E,0xF0,0x1E};
        static unsigned char sCircleBase[0x15]={
                0x00,0x00,0x13,0x11,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
                0x00,0x00,0x00,0x00,0x00};
        int iCircle=0x15;
        int i,ax=0,bx=0,dx=0;

        sCircleBase[0x05] = m_IP[0];
        sCircleBase[0x06] = m_IP[1];
        sCircleBase[0x07] = m_IP[2];
        sCircleBase[0x08] = m_IP[3];
        sCircleBase[0x09] = m_NetMask[0];
        sCircleBase[0x0a] = m_NetMask[1];
        sCircleBase[0x0b] = m_NetMask[2];
        sCircleBase[0x0c] = m_NetMask[3];
        sCircleBase[0x0d] = m_NetGate[0];
        sCircleBase[0x0e] = m_NetGate[1];
        sCircleBase[0x0f] = m_NetGate[2];
        sCircleBase[0x10] = m_NetGate[3];
        sCircleBase[0x11] = m_DNS1[0];
        sCircleBase[0x12] = m_DNS1[1];
        sCircleBase[0x13] = m_DNS1[2];
        sCircleBase[0x14] = m_DNS1[3];

        for ( i=0 ; i<iCircle ; i++ )
        {
                dx = ax;
                bx = 0;
                bx = (bx&0xff00) | sCircleBase[i]; // add "( )" by cdx
                dx &= 0xffff;
                dx >>= 8;
                dx ^= bx;
                bx = 0;
                bx &= 0x00ff;
                bx |= (ax&0xff)<<8;

                ax = Table[dx*2] | Table[dx*2+1]<<8;
                ax ^= bx;
        }
        circleCheck[0] = (unsigned char) ((ax&0xff00)>>8);
        circleCheck[1] = (unsigned char) (ax&0x00ff);
}
//sendpacket.cpp
int dothread::SendFindServerPacket(libnet_t *l)
{
   static uint8_t broadPackage[0x3E8] = {        //广播包，用于寻找服务器
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x88,0x8E,0x01,0x01,
           0x00,0x00};
           
   uint8_t StandardAddr[] = {0x01,0x80,0xC2,0x00,0x00,0x03};
   uint8_t RuijieAddr[]     = {0x01,0xD0,0xF8,0x00,0x00,0x03};
/*
   extern uint8_t  m_localMAC[6];
   extern int    m_authenticationMode;
*/

   if (m_authenticationMode==1) memcpy(broadPackage,RuijieAddr,6);
      else memcpy( broadPackage, StandardAddr, 6 );
   memcpy( broadPackage+6, m_localMAC, 6 );   //填充MAC地址
   
   memcpy (broadPackage+18,OEMExtra,sizeof(OEMExtra));

   FillNetParamater( &broadPackage[0x17] );

   fputs(">> Searching for server...\n",stdout);

   return (libnet_write_link(l,broadPackage, 0x3E8)==0x3E8)?0:-1;
}

int dothread::SendNamePacket(libnet_t *l, const u_char *pkt_data)
{
   static uint8_t ackPackage[0x3E8] = {        //应答包，包括用户名和MD5
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x88,0x8E,0x01,0x00,
           0x00,0x0D,0x02,0x01,0x00,0x0D,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,
           0xFF,0x37,0x77,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x13,0x11,0x38,0x30,0x32,0x31,0x78,0x2E,
           0x65,0x78,0x65,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
   
/*
   extern char *m_name;
   extern uint8_t  m_destMAC[6];
   extern uint8_t  m_localMAC[6];
*/
   int nameLen;

   nameLen=strlen(m_name);
   memcpy(ackPackage,m_destMAC,6);  //将目的MAC地址填入组织回复的包
   memcpy(ackPackage+6,m_localMAC,6);  //将本机MAC地址填入组织回复的包
   ackPackage[0x12]=0x02;            //code,2代表应答
   ackPackage[0x13]=pkt_data[0x13];  //id, HERE as if it's alway 1 from ShiDa ??
   *(short *)(ackPackage+0x10) = htons((short)(5+nameLen));//len
   *(short *)(ackPackage+0x14) = *(short *)(ackPackage+0x10);//len
   memcpy(ackPackage+0x17,m_name,nameLen); //填入用户名

   FillNetParamater( &OEMExtra[0x05] );
   memcpy(ackPackage+0x17+nameLen,OEMExtra,0x6e);

   fputs(">> Sending user name...\n",stdout);

   return (libnet_write_link(l,ackPackage, 0x3E8)==0x3E8)?0:-1;
}

int dothread::SendPasswordPacket(libnet_t *l,const u_char *pkt_data)
{
   static uint8_t ackPackage[0x3E8] = {        //应答包，包括用户名和MD5
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x88,0x8E,0x01,0x00,
           0x00,0x0D,0x02,0x01,0x00,0x0D,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,
           0xFF,0x37,0x77,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x13,0x11,0x38,0x30,0x32,0x31,0x78,0x2E,
           0x65,0x78,0x65,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

   unsigned char   md5Data[256]; //密码,md5 buffer
   unsigned char  *md5Dig;       //result of md5 sum
   int             md5Len=0;
/*
   extern char *m_name;
   extern char *m_password;
   extern uint8_t  m_destMAC[6];
   extern uint8_t  m_localMAC[6];
*/
   int nameLen,passwordLen;

   nameLen=strlen(m_name); passwordLen=strlen(m_password);

   memcpy(ackPackage,m_destMAC,6);
   memcpy(ackPackage+6,m_localMAC,6); //将本机MAC地址填入组织回复的包

   ackPackage[0x12] = 0x02;                //code,2代表应答
   ackPackage[0x13]=pkt_data[0x13];        //id
   *(ackPackage+0x16) = *(pkt_data+0x16);  //type，即应答方式,HERE should alway be 4

   *(short *)(ackPackage+0x10) = htons((short)( 22+nameLen)); //len
   *(short *)(ackPackage+0x14) = *(short *)( ackPackage+0x10 );

   md5Data[md5Len++] = ackPackage[0x13];//ID
   memcpy(md5Data+md5Len,m_password,passwordLen); md5Len+=passwordLen; //密码
   memcpy(md5Data+md5Len,pkt_data+0x18,pkt_data[0x17]); md5Len+=pkt_data[0x17]; //密匙
   md5Dig =ComputeHash( md5Data, md5Len);

   ackPackage[0x17]=16;               //length of md5sum is always 16.
   memcpy(ackPackage+0x18,md5Dig,16);

   memcpy(ackPackage+0x28,m_name,nameLen);

   FillNetParamater( &OEMExtra[0x05] );
   memcpy(ackPackage+0x28+nameLen,OEMExtra,0x6e);

   fputs(">> Sending password... \n",stdout);
   return (libnet_write_link(l,ackPackage, 0x3E8)==0x3E8)?0:-1;
}

int dothread::SendEchoPacket(libnet_t *l,const u_char *pkt_data)
{
   static uint8_t echoPackage[] = {        //echo包，用于每5秒钟激活一次
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x88,0x8E,0x01,0xBF,
           0x00,0x1E,0xFF,0xFF,0x37,0x77,0x7F,0x9F,0xF7,0xFF,0x00,0x00,0xFF,0xFF,0x37,0x77,
           0x7F,0x9F,0xF7,0xFF,0x00,0x00,0xFF,0xFF,0x37,0x77,0x7F,0x3F,0xFF};
   ULONG_BYTEARRAY uCrypt1,uCrypt2,uCrypt1_After,uCrypt2_After;
/*
   extern ULONG_BYTEARRAY  m_serialNo;
   extern ULONG_BYTEARRAY  m_key;
   extern uint8_t  m_destMAC[6];
   extern uint8_t  m_localMAC[6];
*/
   m_serialNo.ulValue++;
   //m_serialNo is initialized at the beginning of main() of dothread.c, and
   //m_key is initialized in dothread.c when the 1st Authentication-Success packet is received.

   uCrypt1.ulValue = m_key.ulValue + m_serialNo.ulValue;
   uCrypt2.ulValue = m_serialNo.ulValue;

   memcpy( echoPackage, m_destMAC, 6 );
   memcpy( echoPackage+6, m_localMAC, 6 );

   uCrypt1_After.ulValue = htonl( uCrypt1.ulValue );
   uCrypt2_After.ulValue = htonl( uCrypt2.ulValue );

   echoPackage[0x18] = Alog(uCrypt1_After.btValue[0]);
   echoPackage[0x19] = Alog(uCrypt1_After.btValue[1]);
   echoPackage[0x1a] = Alog(uCrypt1_After.btValue[2]);
   echoPackage[0x1b] = Alog(uCrypt1_After.btValue[3]);
   echoPackage[0x22] = Alog(uCrypt2_After.btValue[0]);
   echoPackage[0x23] = Alog(uCrypt2_After.btValue[1]);
   echoPackage[0x24] = Alog(uCrypt2_After.btValue[2]);
   echoPackage[0x25] = Alog(uCrypt2_After.btValue[3]);

   return (libnet_write_link(l,echoPackage, 0x2d)==0x2d)?0:-1;
}

int  dothread::SendEndCertPacket(libnet_t *l)
{
/*
   extern uint8_t  m_destMAC[6];
   extern uint8_t  m_localMAC[6];
*/

   static uint8_t ExitPacket[0x3E8]={
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x88,0x8E,0x01,0x02,
           0x00,0x00,0xFF,0xFF,0x37,0x77,0xFF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x08,0x15,0x00,0x00,0x13,0x11,0x38,0x30,0x32,
           0x31,0x78,0x2E,0x65,0x78,0x65,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
           0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x02,0x1F,0x00,
           0x00,0x01,0x00,0x00,0x13,0x11,0x00,0x28,0x1A,0x28,0x00,0x00,0x13,0x11,0x17,0x22,
           0x64,0x91,0x60,0x60,0x65,0x65,0x69,0x61,0x64,0x64,0x94,0x93,0x91,0x92,0x96,0x65,
           0x95,0x64,0x68,0x91,0x62,0x68,0x62,0x94,0x9A,0xD6,0x94,0x68,0x66,0x69,0x6C,0x65};

   memcpy( ExitPacket, m_destMAC, 6 );
   memcpy( ExitPacket+6,m_localMAC, 6 );
   
   memcpy (ExitPacket+18,OEMExtra,sizeof(OEMExtra));
   
   FillNetParamater( &ExitPacket[0x17] );
   fputs(">> Logouting... \n",stdout);
   return (libnet_write_link(l,ExitPacket,0x80)==0x80)?0:-1;
}
