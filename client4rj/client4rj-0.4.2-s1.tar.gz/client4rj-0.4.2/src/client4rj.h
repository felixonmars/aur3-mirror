/*  mystar.h & mystar.cpp are writton by lsyer */

#ifndef CLIENT4RJ_H
#define CLIENT4RJ_H

#include <QDialog>
#include <QCloseEvent>
#include <QSystemTrayIcon>
#include <QMenu>
#include <QMessageBox>
#include <QProcess>
#include <QSettings>
#include "ui_client4rj.h"
#include "dothread.h"
#include "confwin.h"
class client4rj:public QDialog,public Ui::client4rj
{
	Q_OBJECT
public:
	client4rj(QDialog *parent=0);
protected:
	void closeEvent ( QCloseEvent * event );
	void timerEvent(QTimerEvent *event);
//for context menu
	void contextMenuEvent(QContextMenuEvent *event);
private:
	void createActions();
	void createTrayIcon();
	QIcon icon;
	QIcon icon1;
	QSystemTrayIcon *trayIcon;
	QMenu *trayIconMenu;
	QAction *connectAct;
	QAction *hideAct;
	QAction *aboutAct;
	QAction *quitAct;
	QAction *setAct;
	dothread thread;
	char name[32];
	char pass[32];
	int repeatAuthNum;
	int authenticationMode;
	int echoInterval,reconnInterval;
	int auth_p;
	char authinterface[32];
	int autocontimerid;
	
private slots:
	void p_connect();
	void about();
	void quit();
	void setconf();
	void iconActivated(QSystemTrayIcon::ActivationReason reason);
	void switchstat();
	
	void reconnect();
	void sendecho();
	
	void chkstate(int state);
	void autorunchange();
};

#endif /* CLIENT4RJ_H */
