#include "confwin.h"

confwin::confwin(QDialog*parent)
	:QDialog(parent)
{
	setupUi(this);
	isok = false;
	connect(okButton,SIGNAL( clicked() ),this,SLOT(setisok()));
	connect(applyButton,SIGNAL( clicked() ),this,SLOT(setisok()));
	
	QSettings settings("lsyer", "client4rj");
	renum->setValue(settings.value("repeatAuthNum",1).toInt());
	authmode->setCurrentIndex(settings.value("authenticationMode",0).toInt());
	echointer->setValue(settings.value("echoInterval",10).toInt());
	reconnInterval->setValue(settings.value("reconnInterval",30).toInt());
	auth_p->setCurrentIndex( settings.value("auth_p",0).toInt() );
}
void confwin::setisok()
{
	isok = true;
}
