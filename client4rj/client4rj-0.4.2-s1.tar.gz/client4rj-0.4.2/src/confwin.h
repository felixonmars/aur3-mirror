#ifndef __CONFWIN_H__
#define __CONFWIN_H__

#include <QSettings>
#include <QNetworkInterface>
#include "ui_confwin.h"
class confwin:public QDialog,public Ui::confwin
{
	Q_OBJECT
public:
	confwin(QDialog *parent=0);
	bool isok;
private slots:
	void setisok();
};

#endif // __CONFWIN_H__
