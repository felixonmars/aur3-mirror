#ifndef DOTHREAD_H
#define DOTHREAD_H

#include <QThread>
#include <QProcess>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <setjmp.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pcap.h>
#include <libnet.h>
//#include "global.h"
typedef union
{
	u_int32_t   ulValue;
	u_int8_t    btValue[4];
}ULONG_BYTEARRAY;
//#include "sendpacket.h"
#include <string.h>
#include <sys/types.h>
//#include <libnet.h>
//sendpacket.cpp
#include "md5.h"
//
#include "myerr.h"
//#include "blog.h"
  /* The Blog algorithm is mainly de-assembled out by SnowWings.        */
  /* We should thank him very much, because the algorithm is crucial.  */

#include <sys/types.h>
//

#define FILTER_STR "ether[12:2]=0x888e and ether dst %02x:%02x:%02x:%02x:%02x:%02x"

class dothread:public QThread
{
    Q_OBJECT    
public:
	dothread(QObject *parent = 0);
	void disconnectnet(); //do some cleanup work on exit
	
	void setConfig(char *name,char *pass,char *authinterface,int usedchp,int repeatAuthNum,int authenticationMode,int echoInterval); //configure related parameters
	/* 当前认证状态
	   0:未找到服务器                      1:已找到服务器，未通过用户名认证
	   2:已通过用户名认证，未通过MD5认证   3:已通过MD5认证，通网成功         
	   4:认证失败						  5:已停止
	*/
	volatile sig_atomic_t m_state;//当前认证状态
protected:
	void run();
private:
	libnet_t * l;
	pcap_t * p;
	char *m_name;//用户名
	char *m_password;//密码
	int m_repeatAuthNum;
	int m_authenticationMode; //是哪种广播模式：0:标准 1:实达
	int m_echoInterval;
	char *m_nic;//网卡
	char *m_fakeAddress;  // or set to "123.45.67.89" etc.
	int m_usedhcp;
	uint8_t OEMExtra[0x200];
	/* These information should be worked out by initialization portion. */
	unsigned char m_localMAC[6];//本机的MAC地址
	unsigned char m_destMAC[6];//服务器的MAC地址.
	unsigned char m_ip[4];	//当前选择的网卡的IP地址
	unsigned char m_netmask[4];//当前选择的网卡的子网掩码
	unsigned char m_netgate[4];//当前选择的网卡的网关
	unsigned char m_dns1[4];   //当前选择的网卡的DNS
	
	ULONG_BYTEARRAY m_serialNo;  //序列号,收到第一个有效的Authentication-Success-packet时初始化
	ULONG_BYTEARRAY m_key;       //密码加密键值,在main()函数开始时初始化
	
	//connectnet
	const u_char       *pkt_data;
	u_int16_t       offset;
	ULONG_BYTEARRAY uTemp;
	char l_errbuf[LIBNET_ERRBUF_SIZE];
	
	int connectnet();

	
	//blog.h
	void InitializeBlog(const unsigned char *m_ip, const unsigned char *m_netmask,
         const unsigned char *m_netgate, const unsigned char *m_dns1);
         
	void FillNetParamater(unsigned char ForFill[]);
	
	unsigned char Alog(unsigned char BForAlog);
		//blog.cpp	
	int            blogIsInitialized;
	unsigned char  m_IP[4];
	unsigned char  m_NetMask[4];
	unsigned char  m_NetGate[4];
	unsigned char  m_DNS1[4];
	unsigned char  circleCheck[2]; //那两个鬼值
	void Blog(void);
		//sendpacket.h
	/**********************************************************************************************
	  Those 5 functions below return 0 if ok, -1 if fail. However they should never fail normally,
	  so we usually ignore the return values JUST FOR CONVENIENCE.
	  If detecting the errors,which might happen, is very important to your program, don't ingore it.
	**********************************************************************************************/
	
	int SendFindServerPacket(libnet_t *l);
	int SendNamePacket(libnet_t *l, const u_char *pkt_data);
	int SendPasswordPacket(libnet_t *l,const u_char *pkt_data);
	int SendEchoPacket(libnet_t *l,const u_char *pkt_data);
	int SendEndCertPacket(libnet_t *l);
	//
signals:
	void mystate(int state);
};

#endif // __DOTHREAD_H__
