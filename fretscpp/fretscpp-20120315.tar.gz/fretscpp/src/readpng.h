#ifndef __HDR_readpng_h
#define __HDR_readpng_h


#include "includes.h"

GLuint loadImage(const char *filename, GLuint &texture, int &imgwidth, int &imgheight, GLfloat &twidth, GLfloat &theight);


#endif
