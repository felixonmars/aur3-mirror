#ifndef __HDR_sfxfof_h
#define __HDR_sfxfof_h


/**
 * Load sound effects specific to frets-on-fire
 */
void load_all_sfx();

int esfx_randombadnote();


#endif
