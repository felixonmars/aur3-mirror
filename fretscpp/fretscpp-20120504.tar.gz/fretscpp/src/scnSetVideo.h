#ifndef __HDR_scnSetVideo_h
#define __HDR_scnSetVideo_h



#endif
