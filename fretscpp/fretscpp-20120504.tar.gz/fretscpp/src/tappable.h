#ifndef __HDR_tappable_h
#define __HDR_tappable_h


enum eTappableMode
{
	ET_NONE=0,
	ET_RFMOD,
	ET_GH2STRICT,
	ET_GH2,
	ET_GH2SLOPPY,
	ET_ANY
};

class tPlayer;


#endif
