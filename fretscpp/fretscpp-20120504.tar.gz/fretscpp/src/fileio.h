#ifndef __HDR_fileio_h
#define __HDR_fileio_h


#include "includes.h"

vector<string> listDirContents(string dir, int flags=0);
int fileExists(std::string name);


#endif
