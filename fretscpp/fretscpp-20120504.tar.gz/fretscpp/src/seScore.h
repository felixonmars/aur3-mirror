#ifndef __HDR_seScore_h
#define __HDR_seScore_h


#include "includes.h"

void showStars(int promille, GLfloat dx=0, GLfloat dy=0);
void scoreStarsInstrument(int instrument, GLfloat &ypos);


#endif
