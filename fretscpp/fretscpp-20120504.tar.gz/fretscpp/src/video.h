#ifndef __HDR_video_h
#define __HDR_video_h


void videoToFullscreen();
void videoExitFullscreen();
void doResize(int w, int h);
void findvideomodes();
void checkFullscreenRes();


#endif
