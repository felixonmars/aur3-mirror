#!/bin/bash

GAME = "Day Of Defeat"

if [ ! -d ./hlds ]; then
	echo "No previous hlds installation found"
	mkdir hlds
fi
echo "Updating $GAME dedicated server"
./steam -command update -game "dod" -dir hlds
cd hlds
echo "Starting $GAME dedicated server"
sleep 1
screen -A -m -d -S dod-server ./srcds_run -console -game dod +maxplayer 16 -autoupdate
