#!/bin/bash

GAME = "Left 4 Dead"

if [ ! -d ./srcds ]; then
	echo "No previous srcds installation found"
	mkdir srcds
fi
echo "Updating $GAME dedicated server"
./steam -command update -game "l4d_full" -dir srcds
cd srcds
echo "Starting $GAME dedicated server"
sleep 1
screen -A -m -d -S l4d-server ./srcds_run -console -game left4dead +map l4d_hospital01_apartment -autoupdate
