#!/bin/bash

GAME = "Counter-Strike 1.6"

if [ ! -d ./hlds ]; then
	echo "No previous hlds installation found"
	mkdir hlds
fi
echo "Updating $GAME dedicated server"
./steam -command update -game "cstrike" -dir hlds
cd hlds
echo "Starting $GAME dedicated server"
sleep 1
screen -A -m -d -S cs-server ./srcds_run -console -game cstrike +map de_dust2 +maxplayer 16 -autoupdate
