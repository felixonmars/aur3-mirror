#!/bin/bash

GAME = "Half-Life 2 Deathmtch"

if [ ! -d ./srcds ]; then
	echo "No previous srcds installation found"
	mkdir srcds
fi
echo "Updating $GAME dedicated server"
./steam -command update -game "hl2mp" -dir srcds
cd srcds
echo "Starting $GAME dedicated server"
sleep 1
screen -A -m -d -S hl2dm-server ./srcds_run -console -game hl2mp +maxplayer 16 -autoupdate
