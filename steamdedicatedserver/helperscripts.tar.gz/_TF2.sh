#!/bin/bash

GAME = "Team Fortress 2"

if [ ! -d ./srcds ]; then
	echo "No previous srcds installation found"
	mkdir srcds
fi
echo "Updating $GAME dedicated server"
./steam -command update -game "orangebox" -dir srcds
cd srcds/orangebox
echo "Starting $GAME dedicated server"
sleep 1
screen -A -m -d -S tf2-server ./srcds_run -console -game tf +map pl_goldrush +maxplayer 26 -autoupdate
