#!/bin/bash

GAME = "Deathmatch Classic"

if [ ! -d ./hlds ]; then
	echo "No previous hlds installation found"
	mkdir hlds
fi
echo "Updating $GAME dedicated server"
./steam -command update -game "dmc" -dir hlds
cd hlds
echo "Starting $GAME dedicated server"
sleep 1
screen -A -m -d -S dmc-server ./srcds_run -console -game dmc +map dm_crossfire +maxplayer 16 -autoupdate
