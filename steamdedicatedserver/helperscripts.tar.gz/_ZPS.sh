#!/bin/bash

GAME = "Zombie Panic: Source"

if [ ! -d ./srcds ]; then
	echo "No previous srcds installation found"
	mkdir srcds
fi
echo "Updating $GAME dedicated server"
./steam -command update -game "zps" -dir srcds
cd srcds
echo "Starting $GAME dedicated server"
sleep 1
screen -A -m -d -S zps-server ./srcds_run -console -game zps +maxplayer 26 -autoupdate
