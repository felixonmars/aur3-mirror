#!/bin/bash

GAME = "Team Fortress Classic"

if [ ! -d ./hlds ]; then
	echo "No previous hlds installation found"
	mkdir hlds
fi
echo "Updating $GAME dedicated server"
./steam -command update -game "tfc" -dir hlds
cd hlds
echo "Starting $GAME dedicated server"
sleep 1
screen -A -m -d -S tfc-server ./srcds_run -console -game tfc +maxplayer 26 -autoupdate
