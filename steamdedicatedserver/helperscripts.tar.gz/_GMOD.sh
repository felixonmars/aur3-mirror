#!/bin/bash

GAME = "Garry's Mod"

if [ ! -d ./srcds ]; then
	echo "No previous srcds installation found"
	mkdir srcds
fi
echo "Updating $GAME dedicated server"
./steam -command update -game "garrysmod" -dir srcds
cd srcds
echo "Starting $GAME dedicated server"
sleep 1
screen -A -m -d -S gmod-server ./srcds_run -console -game gmod +map gm_construct +maxplayer 16 -autoupdate
